#include <stdio.h>
#include <iostream>
#include "Windows.h"
#include "HCNetSDK.h"
#include "plaympeg4.h"
#include <time.h>
using namespace std;

#pragma comment(lib, "lib/GdiPlus.lib")
#pragma comment(lib, "lib/HCNetSDK.lib")
#pragma comment(lib, "lib/PlayCtrl.lib")

void makelog(char* log, const char * format, ...);

typedef HWND(WINAPI *PROCGETCONSOLEWINDOW)();
PROCGETCONSOLEWINDOW GetConsoleWindowAPI;

LONG lPort; //Global Player Port No.

void CALLBACK g_RealDataCallBack_V30(LONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, void* dwUser)
{
	FILE* f = (FILE*)dwUser;

	HWND hWnd = GetConsoleWindowAPI();

	switch (dwDataType)
	{
	case NET_DVR_SYSHEAD: //System Header
		if (lPort >= 0)
		{
			//break;  //If the handle is obtained before streaming, the following APIs do not need to be called.

			if (!PlayM4_GetPort(&lPort))  ///Get unused channel No. of player
			{
				break;
			}
			//m_iPort = lPort; //The first callback data is system header. Assign obtained player port No. to global port, and it will be used in next callback.
			if (dwBufSize > 0)
			{
				if (!PlayM4_SetStreamOpenMode(lPort, STREAME_REALTIME))  //Set Real-time Stream Playing Mode
				{
					break;
				}

				if (!PlayM4_OpenStream(lPort, pBuffer, dwBufSize, 1024 * 1024)) //Open stream API
				{
					break;
				}

				if (!PlayM4_Play(lPort, hWnd)) //Start playing
				{
					break;
				}
			}
			break;
	case NET_DVR_STREAMDATA:   //Stream data
		if (dwBufSize > 0 && lPort != -1)
		{
			if (!PlayM4_InputData(lPort, pBuffer, dwBufSize))
			{
				break;
			}
			fwrite(pBuffer, sizeof(BYTE), dwBufSize, f);//pBuffer is h264 stream
		}
		break;
	default: //Other data
		if (dwBufSize > 0 && lPort != -1)
		{
			if (!PlayM4_InputData(lPort, pBuffer, dwBufSize))
			{
				break;
			}
		}
		break;
		}
	}
}

void CALLBACK g_ExceptionCallBack(DWORD dwType, LONG lUserID, LONG lHandle, void *pUser)
{
	char tempbuf[256] = { 0 };
	switch (dwType)
	{
	case EXCEPTION_RECONNECT:    //Reconnect in live view
		printf("----------reconnect--------%d\n", time(NULL));
		break;
	default:
		break;
	}
}

/*********************************************************
Function:	MessageCallback
Desc:		alarm, callback functions dealing with the info of card in ATM
Input:	lCommand,message type; pAlarmer,info of device which upload message;pAlarmInfo, message info content;dwBufLen,message length; pUser, user parameter
Output:
Return:
**********************************************************/
void CALLBACK MessageCallback(LONG lCommand, NET_DVR_ALARMER *pAlarmer, char *pAlarmInfo, DWORD dwBufLen, void* pUser)
{
	//Sleep(100000);
	UNREFERENCED_PARAMETER(pUser);
	//AlarmMessage(lCommand, pAlarmer, pAlarmInfo, dwBufLen);

}

void demo_main()
{
	//---------------------------------------
	// Initialize
	//check3
	if (!NET_DVR_Init())
	{
		printf("fail \t NET_DVR_Init ErrCode:%d\n", NET_DVR_GetLastError());
		return;
	}
	else
	{
		printf("success \t NET_DVR_Init\n");
	}
	
	char log[128];
	makelog(log, "sdk v%x", NET_DVR_GetSDKBuildVersion());
	printf("success \t %s\n", log);

	//---------------------------------------
	//Set connected time and reconnected time
	NET_DVR_SetConnectTime(2000, 1);
	NET_DVR_SetReconnect(10000, true);

	//---------------------------------------
    //Set callback function of exception message
	NET_DVR_SetExceptionCallBack_V30(0, NULL, g_ExceptionCallBack, NULL);


	//---------------------------------------
	// Get window handle of control center
	//HMODULE hKernel32 = GetModuleHandle("kernel32");
	//GetConsoleWindowAPI = (PROCGETCONSOLEWINDOW)GetProcAddress(hKernel32, "GetConsoleWindow");
	//HWND hWnd = GetConsoleWindow();
	//---------------------------------------
	// Register device
	LONG lUserID;

	//Login parameters, including IP address, user name, and password, etc.
	NET_DVR_USER_LOGIN_INFO struLoginInfo = { 0 };
	struLoginInfo.bUseAsynLogin = 0; //synchronous login mode	
	strcpy_s(struLoginInfo.sDeviceAddress, "192.168.1.64"); //IP Address
	struLoginInfo.wPort = 8000; //Service port
	strcpy_s(struLoginInfo.sUserName, "admin"); //User name
	strcpy_s(struLoginInfo.sPassword, "1234qwer"); //Password

	//Device information, output parameters
	NET_DVR_DEVICEINFO_V40 struDeviceInfoV40 = { 0 };

	lUserID = NET_DVR_Login_V40(&struLoginInfo, &struDeviceInfoV40);
	if (lUserID < 0)
	{
		printf("fail \t Login, ErrCode(%d)\n", NET_DVR_GetLastError());
		NET_DVR_Cleanup();
		return;
	}
	else
	{
		printf("success \t Login, loginHandle: %d, sSerialNumber:%s\n", lUserID, struDeviceInfoV40.struDeviceV30.sSerialNumber);
	}

	//---------------------------------------
	//Start live view and set callback data stream
	LONG lRealPlayHandle;

	NET_DVR_PREVIEWINFO struPlayInfo = { 0 };
	struPlayInfo.hPlayWnd = NULL;         //Set the handle as valid when the stream should be decoded by SDK, while set the handle as null when only streaming.
	struPlayInfo.lChannel = 1;       //Live view channel No.
	struPlayInfo.dwStreamType = 0;       //0-Main Stream, 1-Sub-Stream, 2-Stream 3, 3-Stream 4, and so on.
	struPlayInfo.dwLinkMode = 0;       //0-TCP Mode, 1-UDP Mode, 2-Multi-play mode, 3-RTP Mode, 4-RTP/RTSP, 5-RSTP/HTTP
	struPlayInfo.bBlocked = 1;       //0-Non-Blocking Streaming, 1-Blocking Streaming

	FILE* f;
	fopen_s(&f, "getframe.h264", "wb");

	lRealPlayHandle = NET_DVR_RealPlay_V40(lUserID, &struPlayInfo, g_RealDataCallBack_V30, f);
	if (lRealPlayHandle < 0)
	{
		printf("NET_DVR_RealPlay_V40 error, %d\n", NET_DVR_GetLastError());
		NET_DVR_Logout(lUserID);
		NET_DVR_Cleanup();
		return;
	}
	else
	{
		printf("NET_DVR_RealPlay_V40 success, handle(%d)\n", lRealPlayHandle);
	}

	Sleep(30000);
	//---------------------------------------
	//Stop live view
	NET_DVR_StopRealPlay(lRealPlayHandle);

	//Release player resource
	PlayM4_Stop(lPort);
	PlayM4_CloseStream(lPort);
	PlayM4_FreePort(lPort);

	fclose(f);

	//User logout
	NET_DVR_Logout(lUserID);
	NET_DVR_Cleanup();

	return;
}

void makelog(char* log, const char * format, ...)
{
	char szLogInfo[1024 * 5] = { 0 };
	va_list arglist;
	va_start(arglist, format);
	vsprintf(szLogInfo, format, arglist);
	va_end(arglist);
		
	sprintf(log, "%s", szLogInfo);
}