#pragma once

#ifdef	HikivisionSDKDLLL_EXPORT
#define HikivisionSDKDLLL_PORT  __declspec(dllexport)   // export DLL information
#else
#define HikivisionSDKDLLL_PORT  __declspec(dllimport)   // import DLL information
#endif 

#define MY_CONVENTION __stdcall

#include <stdio.h>
#include <iostream>
#include <Windows.h>
#include "incEn/HCNetSDK.h"
#include "incEn/plaympeg4.h"
#include <time.h>
#include <string.h>
using namespace std;

#include "AutoLock_Hiki.h"

typedef void(CallBackHikiVisionDecode)(void* pParam, int width, int hegith, unsigned char* data, float fps);

class HikivisionSDKDLLL_PORT CHikiVSSDKDLL
{
public:
	CHikiVSSDKDLL();
	~CHikiVSSDKDLL();

	unsigned char* m_temp;
	char m_url[512];
	char m_ip[64];
	char m_id[64];
	char m_pw[64];
	int m_lChannel;
	int m_dwStreamType;//substream

	// Register device
	LONG m_lUserID;
	LONG m_lRealPlayHandle;
	LONG m_lPort;
	LONG m_lWidth, m_lHeight;

	bool init(char* sdkversion, int iGpuid, void* param, CallBackHikiVisionDecode* func);
	void release();
	bool login(char* url, char* log, char* ip = nullptr, char* id = nullptr, char* pw = nullptr);
	void logoff();
	bool playstream(char * log);
	void stopstream();

	void makelog(char* log, const char * format, ...);
	static void CALLBACK g_RealDataCallBack_V30(LONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, void* dwUser);
	static void CALLBACK g_ExceptionCallBack(DWORD dwType, LONG lUserID, LONG lHandle, void *pUser);
	static void CALLBACK DecCBFun(long nPort, char* pBuf, long nSize, FRAME_INFO* pFrameInfo, void* nUser, long nReserved2);
	void RealDataCallBack_V30(LONG lRealHandle, DWORD dwDataType, BYTE *pBuffer, DWORD dwBufSize, void* dwUser);

	CAutoLock_Hiki* m_lock;

	
	int m_iGpu;
	void* m_pParam;
	CallBackHikiVisionDecode* m_func;//send decode data to UniTraffic
};