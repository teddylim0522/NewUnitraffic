#include "HikivisionSDKDLL.h"

#pragma comment(lib, "lib/GdiPlus.lib")
#pragma comment(lib, "lib/HCNetSDK.lib")
#pragma comment(lib, "lib/PlayCtrl.lib")

int g_bInitDone = false;
int g_nCount = 0;//total connections


CHikiVSSDKDLL::CHikiVSSDKDLL()
{	
	m_lPort = 0;
}

CHikiVSSDKDLL::~CHikiVSSDKDLL()
{
	
}

bool CHikiVSSDKDLL::init(char* sdkversion, int iGpuid, void* param, CallBackHikiVisionDecode* func)
{
	if (!g_bInitDone)
	{
		if (!NET_DVR_Init())
		{
			sprintf(sdkversion, "Hikivision init fail, ErrCode:%d\n", NET_DVR_GetLastError());
			return false;
		}

		g_bInitDone = true;
	}

	makelog(sdkversion, "Hikivision sdk v%x", NET_DVR_GetSDKBuildVersion());

	//---------------------------------------
	//Set connected time and reconnected time
	NET_DVR_SetConnectTime(2000, 1);
	NET_DVR_SetReconnect(10000, true);

	//---------------------------------------
	//Set callback function of exception message
	NET_DVR_SetExceptionCallBack_V30(0, NULL, g_ExceptionCallBack, NULL);

	m_iGpu = iGpuid;
	m_pParam = param; //UniTafficView pointer
	m_func = func;  //after decode callback

	g_nCount++;

	m_temp = (unsigned char*)calloc(1, sizeof(unsigned char));
	m_lock = new CAutoLock_Hiki(nullptr);

	return true;
}

void CHikiVSSDKDLL::release()
{
	g_nCount--;

	if (g_nCount == 0 && g_bInitDone)
	{
		NET_DVR_Cleanup();
		g_bInitDone = false;
	}

	if (m_lock)
	{
		delete m_lock;
		m_lock = nullptr;
	}

	if (m_temp)
		free(m_temp);
}

bool CHikiVSSDKDLL::login(char* url, char* log, char* ip, char* id, char* pw)
{
	bool ret = true;

	bool setinfo = false;
	if (ip && id && pw && strlen(ip) > 0 && strlen(id) > 0 && strlen(pw) > 0)
	{
		strcpy(m_ip, ip);
		strcpy(m_id, id);
		strcpy(m_pw, pw);
		setinfo = true;
	}

	if (strlen(url) > 0)
	{
		char url_copy[512];
		strcpy(url_copy, url);
		strcpy(m_url, url_copy);

		if (!setinfo)
		{
			//rtsp://admin:1234qwer@192.168.1.64:554/Streaming/channels/101
			//rtsp://^admin^:1234qwer^@192.168.1.64^:554^/Streaming^/channels^/101
			char* token, *context;

			//get id
			token = strtok_s(url_copy, "rtsp:///", &context);
			sprintf(m_id, "%s", token);

			//get pw
			token = strtok_s(NULL, "@", &context);
			sprintf(m_pw, "%s", token);

			//get ip
			token = strtok_s(NULL, ":", &context);
			sprintf(m_ip, "%s", token);

			//get channel
			token = strtok_s(NULL, "/", &context);
			token = strtok_s(NULL, "/", &context);
			token = strtok_s(NULL, "/", &context);
			token = strtok_s(NULL, "/", &context);

			//rtsp://����� ID:��й�ȣ@IP �ּ�:��Ʈ/Streaming/channels/ä�ι�ȣ&��Ʈ����ȣ
			if (!token)
			{
				sprintf(log, "Hikivision URL not valid");
				return false;
			}

			int temp = atoi(token);
			m_lChannel = temp / 100;    //ä�ι�ȣ
			m_dwStreamType = temp % 10; //��Ʈ����ȣ
		}
	}

	NET_DVR_USER_LOGIN_INFO struLoginInfo = { 0 };
	struLoginInfo.bUseAsynLogin = 0; //synchronous login mode
	strcpy_s(struLoginInfo.sDeviceAddress, m_ip); //IP Address
	struLoginInfo.wPort = 8000; //Service port
	strcpy_s(struLoginInfo.sUserName, m_id); //User name
	strcpy_s(struLoginInfo.sPassword, m_pw); //Password


	//Device information, output parameters
	NET_DVR_DEVICEINFO_V40 struDeviceInfoV40 = { 0 };

	m_lUserID = NET_DVR_Login_V40(&struLoginInfo, &struDeviceInfoV40);
	if (m_lUserID < 0)
	{
		sprintf(log, "Hikivision Login fail, ErrCode(%d)", NET_DVR_GetLastError());
		NET_DVR_Cleanup();
		ret = false;
	}
	else
	{
		sprintf(log, "Hikivision Login success, loginHandle: %d, sSerialNumber:%s", m_lUserID, struDeviceInfoV40.struDeviceV30.sSerialNumber);
	}


	return ret;
}

void CHikiVSSDKDLL::logoff()
{
	NET_DVR_Logout(m_lUserID);
}

bool CHikiVSSDKDLL::playstream(char * log)
{
	bool ret = true;

	//---------------------------------------
	//Start live view and set callback data stream

	NET_DVR_PREVIEWINFO struPlayInfo = { 0 };
	struPlayInfo.hPlayWnd = NULL;	//Set the handle as valid when the stream should be decoded by SDK, while set the handle as null when only streaming.
	struPlayInfo.lChannel = m_lChannel;		    //Live view channel No.
	struPlayInfo.dwStreamType = 0;  // m_dwStreamType;	//0-Main Stream, 1-Sub-Stream, 2-Stream 3, 3-Stream 4, and so on.
	struPlayInfo.dwLinkMode = 0;	//0-TCP Mode, 1-UDP Mode, 2-Multi-play mode, 3-RTP Mode, 4-RTP/RTSP, 5-RSTP/HTTP
	struPlayInfo.bBlocked = 1;      //0-Non-Blocking Streaming, 1-Blocking Streaming

	m_lRealPlayHandle = NET_DVR_RealPlay_V40(m_lUserID, &struPlayInfo, g_RealDataCallBack_V30, this);
	if (m_lRealPlayHandle < 0)
	{
		sprintf(log, "Hikivision Play fail, ErrCode(%d)\n", NET_DVR_GetLastError());
		NET_DVR_Logout(m_lUserID);
		NET_DVR_Cleanup();
		ret = false;
	}
	else
	{
		sprintf(log, "Hikivision Play success, handle(%d)\n", m_lRealPlayHandle);
	}

	return ret;
}

void CHikiVSSDKDLL::stopstream()
{
	//---------------------------------------
	//Stop live view
	NET_DVR_StopRealPlay(m_lRealPlayHandle);

	//Release player resource
	PlayM4_Stop(m_lPort);
	PlayM4_CloseStream(m_lPort);
	PlayM4_FreePort(m_lPort);
}

void CHikiVSSDKDLL::makelog(char * log, const char * format, ...)
{
	char szLogInfo[1024 * 5] = { 0 };
	va_list arglist;
	va_start(arglist, format);
	vsprintf(szLogInfo, format, arglist);
	va_end(arglist);

	sprintf(log, "%s", szLogInfo);
}

void CHikiVSSDKDLL::g_RealDataCallBack_V30(LONG lRealHandle, DWORD dwDataType, BYTE * pBuffer, DWORD dwBufSize, void * dwUser)
{
	CHikiVSSDKDLL* pThis = (CHikiVSSDKDLL*)dwUser;

	pThis->RealDataCallBack_V30(lRealHandle, dwDataType, pBuffer, dwBufSize, NULL);
	//switch (dwDataType)
	//{
	//case NET_DVR_SYSHEAD: //System Header
	//	if (pThis->m_lPort >= 0)
	//	{
	//		//break;  //If the handle is obtained before streaming, the following APIs do not need to be called.
	//		if (!PlayM4_GetPort(&pThis->m_lPort))  ///Get unused channel No. of player
	//		{
	//			break;
	//		}
	//		//m_iPort = lPort; //The first callback data is system header. Assign obtained player port No. to global port, and it will be used in next callback.
	//		if (dwBufSize > 0)
	//		{
	//			if (!PlayM4_SetStreamOpenMode(pThis->m_lPort, STREAME_REALTIME))  //Set Real-time Stream Playing Mode
	//			{
	//				break;
	//			}
	//			if (!PlayM4_GetPictureSize(pThis->m_lPort, &pThis->m_lWidth, &pThis->m_lHeight))
	//			{
	//				break;
	//			}
	//			if (!PlayM4_OpenStream(pThis->m_lPort, pBuffer, dwBufSize, pThis->m_lWidth * pThis->m_lHeight)) //Open stream API
	//			{
	//				break;
	//			}
	//			if (!PlayM4_Play(pThis->m_lPort, NULL)) //Start playing
	//			{
	//				break;
	//			}
	//		}
	//		break;
	//case NET_DVR_STREAMDATA:   //Stream data
	//	if (dwBufSize > 0 && pThis->m_lPort != -1)
	//	{
	//		//if (!PlayM4_InputData(pThis->m_lPort, pBuffer, dwBufSize))
	//		//{
	//		//	break;
	//		//}
	//		void* pParam = reinterpret_cast<void*>(m_hNvDec);
	//		pThis->m_funcReceived((void*)pParam, pThis->m_lWidth, pThis->m_lHeight, "H265", pBuffer, dwBufSize, false, 0, 0);
	//	}
	//	break;
	//default: //Other data
	//	if (dwBufSize > 0 && pThis->m_lPort != -1)
	//	{
	//		if (!PlayM4_InputData(pThis->m_lPort, pBuffer, dwBufSize))
	//		{
	//			break;
	//		}
	//	}
	//	break;
	//	}
	//}
}

void CHikiVSSDKDLL::g_ExceptionCallBack(DWORD dwType, LONG lUserID, LONG lHandle, void * pUser)
{
	char tempbuf[256] = { 0 };
	switch (dwType)
	{
	case EXCEPTION_RECONNECT:    //Reconnect in live view
		printf("----------reconnect--------%d\n", time(NULL));
		break;
	default:
		break;
	}
}

//Data decoding callback function,
//Function: Transcode the YV_12 format video data stream into BGR type picture data that can be processed by opencv, and display it in real time.
void CHikiVSSDKDLL::DecCBFun(long nPort, char * pBuf, long nSize, FRAME_INFO * pFrameInfo, void* nUser, long nReserved2)
{
	CHikiVSSDKDLL* pThis = (CHikiVSSDKDLL*)nUser;
	if (pFrameInfo->nType == T_YV12)
	{	
		//pThis->m_pParam : CUniTrafficView pointer
		//pThis->m_func : CUniTrafficView::Callbackfunc_decoded_Hikivision function pointer
		pThis->m_func(pThis->m_pParam, pFrameInfo->nWidth, pFrameInfo->nHeight, (unsigned char*)pBuf, pFrameInfo->nFrameRate);
	}	
}

void CHikiVSSDKDLL::RealDataCallBack_V30(LONG lRealHandle, DWORD dwDataType, BYTE * pBuffer, DWORD dwBufSize, void * dwUser)
{
	switch (dwDataType)
	{
	case NET_DVR_SYSHEAD: //System Header
		if (m_lPort >= 0)
		{
			//break;  //If the handle is obtained before streaming, the following APIs do not need to be called.

			if (!PlayM4_GetPort(&m_lPort))  ///Get unused channel No. of player
			{
				break;
			}
			//m_iPort = lPort; //The first callback data is system header. Assign obtained player port No. to global port, and it will be used in next callback.
			if (dwBufSize > 0)
			{
				if (!PlayM4_SetStreamOpenMode(m_lPort, STREAME_REALTIME))  //Set Real-time Stream Playing Mode
				{
					break;
				}

				//if (!PlayM4_GetPictureSize(m_lPort, &m_lWidth, &m_lHeight))
				//{
				//	break;
				//}

				if (!PlayM4_OpenStream(m_lPort, pBuffer, dwBufSize, 1024 * 1024)) //Open stream API
				{
					break;
				}

				if (!PlayM4_SetDecCallBackMend(m_lPort, DecCBFun, this))
				{
					break;
				}

				if (!PlayM4_Play(m_lPort, NULL)) //Start playing
				{
					break;
				}

			}
			break;
	case NET_DVR_STREAMDATA:   //Stream data
		if (dwBufSize > 0 && m_lPort != -1)
		{
			if (!PlayM4_InputData(m_lPort, pBuffer, dwBufSize))
			{
				break;
			}
			//void* pParam = reinterpret_cast<void*>(m_hNvDec);
			//m_funcReceived((void*)pParam, 4096, 2160, "H265", pBuffer, dwBufSize, false, 0, 0);
		}
		break;
	default: //Other data
		if (dwBufSize > 0 && m_lPort != -1)
		{
			if (!PlayM4_InputData(m_lPort, pBuffer, dwBufSize))
			{
				break;
			}
		}
		break;
		}
	}
}