#pragma once

#include <stdio.h>
#include <Windows.h>
#include <list>
using namespace std;

#pragma once
#include "opencv2/highgui/highgui_c.h"
#include "opencv2/imgproc/imgproc_c.h"
#include "opencv2/core/version.hpp"
#include "opencv2/opencv.hpp"
using namespace cv;

typedef struct
{
	char name[MAX_PATH];
	IplImage* img;
	Mat* imgMat;
	int* saveParam;
	int isUse;
	int isMat;
}sImage;

class CQueueList
{
public:
	CQueueList(int _size) : m_MAX(_size)
	{
		m_QueueImage.clear();

		m_hMTXQueuePos = CreateMutex(nullptr, FALSE, nullptr);
	}

	~CQueueList()
	{
		CQueueList_ClearAll();
		m_QueueImage.clear();

		CloseHandle(m_hMTXQueuePos);
	}

public:
	inline int CQueueList_canPushCheck()
	{
		int ret = 0;

		WaitForSingleObject(m_hMTXQueuePos, INFINITE);
		if (m_QueueImage.size() >= m_MAX)
		{
			printf("[error] save image queue full \n");
			ret = -1;
		}
		ReleaseMutex(m_hMTXQueuePos);

		return ret;
	}
	inline int CQueueList_pushback(sImage* _psImage)
	{
		//sImage* psImage = new sImage();
		//strcpy(psImage->name, _name);
		//cvCopy(psImage->img, _img);

		int ret = 0;

		WaitForSingleObject(m_hMTXQueuePos, INFINITE);
		if (m_QueueImage.size() < m_MAX)
		{
			m_QueueImage.push_back(_psImage);
		}
		else
		{
			printf("[error] save image queue full \n");
			ret = -1;
		}
		ReleaseMutex(m_hMTXQueuePos);

		return ret;
	}

	inline sImage* CQueueList_front()
	{
		sImage* stemp = nullptr;

		WaitForSingleObject(m_hMTXQueuePos, INFINITE);
		if (m_QueueImage.size() > 0)
		{
			stemp = m_QueueImage.front();
		}
		ReleaseMutex(m_hMTXQueuePos);

		return stemp;
	}

	inline int CQueueList_popfront()
	{
		int ret = 0;

		WaitForSingleObject(m_hMTXQueuePos, INFINITE);
		if (m_QueueImage.size() > 0)
		{
			m_QueueImage.pop_front();
		}
		else
		{
			ret = -1;
		}
		ReleaseMutex(m_hMTXQueuePos);

		return ret;
	}

	inline int CQueueList_ClearAll()
	{
		WaitForSingleObject(m_hMTXQueuePos, INFINITE);
		sImage* stemp = nullptr;
		while (m_QueueImage.size() > 0)
		{
			stemp = nullptr;
			stemp = m_QueueImage.front();
			if (stemp)
			{
				if(stemp->img) cvReleaseImage(&stemp->img);

				if (stemp->imgMat)
				{
					delete stemp->imgMat;
					stemp->imgMat = nullptr;
				}

				//delete(stemp);
			}

			m_QueueImage.pop_front();
		}
		ReleaseMutex(m_hMTXQueuePos);

		return 0;
	}

	inline int CQueueList_getMaxSize()
	{
		return m_MAX;
	}

private:
	HANDLE m_hMTXQueuePos;
	const int m_MAX;

	list<sImage*> m_QueueImage;
};