#pragma once

#ifdef UNSSAVEPICTURE_EXPORTS
#define UNSSAVEPICTURE_PORT extern "C" __declspec( dllexport ) 
#else
#define UNSSAVEPICTURE_PORT extern "C" __declspec( dllimport ) 
#endif //else _USRDLL

#define IS_EQUAL(A, B)  ( (A)==(B) )

#ifndef DQUOT_WRAP
#define DQUOT_WRAP(_x_) #_x_
#endif

#ifndef T_FUNC
#define MY_CONVENTION __stdcall

#define T_FUNC(_func_) TypeOf_##_func_
#define T_P_FUNC(_func_) T_FUNC(_func_)*
#define DECL_FUNC(_func_) T_FUNC(_func_) _func_
#define DECL_P_FUNC(_func_) T_P_FUNC(_func_) _func_

#define TYPEDEF_FUNC(_ret_ , _func_ , _para_)				typedef _ret_ MY_CONVENTION T_FUNC(_func_) _para_
#define GET_PROC_FUNC(_func_, _hmodule_ , _name_)			_func_ = (T_P_FUNC(_func_)) GetProcAddress(_hmodule_, _name_)

#if defined _M_X64
#   define GET_PROC_FUNC2(_func_, _hmodule_, _parasize_)	_func_ = reinterpret_cast<T_P_FUNC(_func_)> ( GetProcAddress(_hmodule_, DQUOT_WRAP(_func_)) ) 
#elif defined _M_IX86
#define GET_PROC_FUNC2(_func_, _hmodule_, _parasize_)		_func_ = reinterpret_cast<T_P_FUNC(_func_)> ( GetProcAddress(_hmodule_, DQUOT_WRAP(_##_func_@_parasize_)) )            //Func = (TypeOfFunc) GetProcAddress(hModule, "_Func@parasize")
#else
#   error Unsupported Platform
#endif

#endif //of T_FUNC


#if defined (_DLL_UNSSAVEPICTURE_AS_IMPLICIT_ )

#define TYPEDEF_AND_DECLARE(_ret_, _func_, _para_)      UNSSAVEPICTURE_PORT _ret_ MY_CONVENTION _func_ _para_;

#elif defined( _DLL_UNSSAVEPICTURE_AS_EXPLICIT_)

#define TYPEDEF_AND_DECLARE(_ret_, _func_, _para_)      TYPEDEF_FUNC(_ret_, _func_,  _para_) ;  DECL_P_FUNC(_func_)=nullptr; 

#elif defined( _DLL_UNSSAVEPICTURE_AS_EXTERN_EXPLICT_)

#define TYPEDEF_AND_DECLARE(_ret_, _func_, _para_)      TYPEDEF_FUNC(_ret_, _func_,  _para_) ;  extern DECL_P_FUNC(_func_);
#endif //

#ifdef TYPEDEF_AND_DECLARE

TYPEDEF_AND_DECLARE(int, UNSSAVEPICTURE_GetApis, (int* ot_pApiNum, void*** ot_pApiList));
TYPEDEF_AND_DECLARE(HANDLE, UNSSAVEPICTURE_Start, (int _size, int _num));
TYPEDEF_AND_DECLARE(int, UNSSAVEPICTURE_Stop, (HANDLE _in_h));
TYPEDEF_AND_DECLARE(int, UNSSAVEPICTURE_Save, (HANDLE _in_h, void* _path, void* _img, int* _saveParam, int _isMat));
#undef TYPEDEF_AND_DECLARE
#endif //TYPEDEF_AND_DECLARE


#if defined( _DLL_UNSSAVEPICTURE_AS_EXPLICIT_)    

inline HMODULE LoadUNSSAVEPICTUREDll(void)
{
	HMODULE hModule = ::LoadLibraryW(L"UNSSavePicture.dll");
	DWORD errorCode = GetLastError();
	if (hModule == nullptr)
	{
		char dbgmsg[512];
		sprintf_s(dbgmsg, "[ERROR] LoadLibraryW(L\"UNSSavePicture.dll\") Failed!, errCode[%d]", errorCode);
		OutputDebugStringA(dbgmsg);
		return nullptr;
	}

#if 0
	int ret = -1;
	GET_PROC_FUNC(UNSSAVEPICTURE_GetApis, hModule, ("_UNSSAVEPICTURE_GetApis@8"));
	if (UNSSAVEPICTURE_GetApis) ret = 0;

	int nApiNum = 0;
	void** MyApiList[] = {
		(void**)&UNSSAVEPICTURE_GetApis,
		(void**)&UNSSAVEPICTURE_Start,
		(void**)&UNSSAVEPICTURE_Stop,
		(void**)&UNSSAVEPICTURE_Save,
	};

	if (ret >= 0) {
		ret = UNSSAVEPICTURE_GetApis(&nApiNum, MyApiList);
	}

	if ((ret < 0) || (nApiNum != _countof(MyApiList))) {
		::FreeLibrary(hModule);
		hModule = nullptr;
		OutputDebugStringW(L"[Error][UNS_SavePicture]can't get apis for UNS_SavePictureDll\r\n");
	}

#else
	GET_PROC_FUNC2(UNSSAVEPICTURE_Start, hModule, 8);
	GET_PROC_FUNC2(UNSSAVEPICTURE_Stop, hModule, 4);
	GET_PROC_FUNC2(UNSSAVEPICTURE_Save, hModule, 12);
#endif

	return hModule;
}
inline int FreeUNSSAVEPICTUREDll(HMODULE _inHmodule)
{
	if (_inHmodule != nullptr)
	{
		FreeLibrary(_inHmodule);
		_inHmodule = nullptr;
	}

	return 0;
}

#elif defined( _DLL_UNSSAVEPICTURE_AS_EXTERN_EXPLICT_)

extern HMODULE LoadUNSSAVEPICTUREDll(void);

#endif 