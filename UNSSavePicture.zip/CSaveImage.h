#pragma once
#include <Windows.h>
#include <process.h>
#include "CQueueList.h"

#ifndef GET_7FFE008CLOCK_MICROSEC
#define GET_7FFE008CLOCK_MICROSEC ((*(__int64 *)0x7FFE0008)/10)             //*(__int64 *)0x7FFE0008 //unit : 100nanosecond
#define GET_7FFE008CLOCK_MILLISEC ((*(__int64 *)0x7FFE0008)/(10*1000))      //*(__int64 *)0x7FFE0008 //unit : 100nanosecond
#define GET_7FFE008CLOCK_SEC ((*(__int64 *)0x7FFE0008)/(10*1000*1000))      //*(__int64 *)0x7FFE0008 //unit : 100nanosecond
#endif

class CSaveIamge
{
public:
	CQueueList * m_listqueue;
	sImage** m_psImage;
	Mat* mImgMat;
	HANDLE m_hMutex;
	HANDLE m_ThreadFile;
	int m_isRun;
	int m_index;
	int m_num;

	CSaveIamge(int _size, int _num);
	~CSaveIamge();
public:

	int CSaveIamge_pushValidCheck();
	int CSaveIamge_push(char* _name, void* _img, int* _saveParam, int _isMat = 0);
	int CSaveIamge_SavetoFile(sImage* _psImg);
	int CSaveIamge_pop(sImage* _psImg);
	int CSaveIamge_writelog(const char * _name);

	static unsigned __stdcall Thread_SavetoFile(void *pParam);
};