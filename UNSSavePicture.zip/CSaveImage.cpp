#include "stdafx.h"
#include "CSaveImage.h"
#include <string.h>

CSaveIamge::CSaveIamge(int _size, int _num)
{
	m_listqueue = new CQueueList(_size);
	m_isRun = TRUE;

	m_index = 0;
	m_num = _num;

	m_psImage = (sImage**)malloc(_size * sizeof(sImage*));
	for (int i = 0; i < _size; i++)
	{
		m_psImage[i] = (sImage*)malloc(sizeof(sImage));
		m_psImage[i]->isUse = 0;
		m_psImage[i]->isMat = 0;
		m_psImage[i]->img = nullptr;
		m_psImage[i]->imgMat = nullptr;
	}

	m_hMutex = ::CreateEvent(NULL, TRUE, FALSE, NULL);

	m_ThreadFile = (HANDLE)_beginthreadex(NULL, 0, CSaveIamge::Thread_SavetoFile, (void*)this, 0, NULL);
}

CSaveIamge::~CSaveIamge()
{
	m_isRun = FALSE;

	Sleep(100);

	if (m_ThreadFile)
	{
		DWORD exitCode = 0;
		GetExitCodeThread(m_ThreadFile, &exitCode);

		while (exitCode == STILL_ACTIVE)
		{
			TerminateThread(m_ThreadFile, 0);

			GetExitCodeThread(m_ThreadFile, &exitCode);
			Sleep(100);
		}

		CloseHandle(m_ThreadFile);
		m_ThreadFile = nullptr;
	}

	if (m_hMutex)
	{
		CloseHandle(m_hMutex);
		m_hMutex = nullptr;
	}

	int queueMax = m_listqueue->CQueueList_getMaxSize();
	delete m_listqueue;

	for (int i = 0; i < queueMax; i++)
	{
		if (m_psImage[i]) free(m_psImage[i]); m_psImage[i] = nullptr;
	}

	if (m_psImage) free(m_psImage); m_psImage = nullptr; 
}

int CSaveIamge::CSaveIamge_pushValidCheck()
{
	if (m_listqueue->CQueueList_canPushCheck() < 0) return -1;

	return 0;
}

int CSaveIamge::CSaveIamge_push(char* _name, void* _img, int* _saveParam, int _isMat)
{
	if (_name == nullptr) return -1;
	if (_img == nullptr) return -1;

	if (CSaveIamge_pushValidCheck() < 0) return -1;

	int queueMax = m_listqueue->CQueueList_getMaxSize();

	sImage* psImage = m_psImage[m_index];
	if (psImage == nullptr)
		return -1;
	memset(psImage->name, 0, sizeof(char)*MAX_PATH);

	while (psImage->isUse != 0)
	{
		if ((++m_index %  queueMax) == 0)
		{
			m_index = 0;
		}
		psImage = m_psImage[m_index];
	}

	string temp(_name);
	temp.replace(temp.find(".jpg"), 4, ".jpeg");

	strncpy_s(psImage->name, temp.c_str(), temp.length());
	psImage->isUse = 1;
	psImage->isMat = _isMat;

	if (!_isMat)
	{
		IplImage* pImg = (IplImage*)_img;

		psImage->img = cvCreateImage(cvSize(pImg->width, pImg->height), pImg->depth, pImg->nChannels);
		cvCopy(pImg, (IplImage*)psImage->img);

		if (_saveParam) memcpy(psImage->saveParam, _saveParam, sizeof(_saveParam));

		//cvSaveImage(_name, pImg); return 0;
	}
	else //deep copy
	{
		Mat* img = (Mat*)_img;

		psImage->imgMat = new Mat;
		img->copyTo(*psImage->imgMat);
	}

	m_listqueue->CQueueList_pushback(psImage);
	SetEvent(m_hMutex);

	if ((++m_index %  queueMax) == 0)
	{
		m_index = 0;
	}
	return 0;
}

int CSaveIamge::CSaveIamge_SavetoFile(sImage * _psImage)
{
	sImage* psImage = _psImage;

	if (!psImage->isMat)
	{
		//cvSaveImage(psImage->name, psImage->img);// , psImage->saveParam); //can't using opencv4.4.0

		Mat temp;
		temp = cvarrToMat(psImage->img);
		imwrite(psImage->name, temp);
		temp.release();

		cvReleaseImage((IplImage**)&psImage->img);
	}
	else
	{
		imwrite(psImage->name, *psImage->imgMat);
		delete psImage->imgMat;
		psImage->imgMat = nullptr;
	}

	string temp(psImage->name);
	temp.replace(temp.find(".jpeg"), 5, ".jpg");

	int ret = rename(psImage->name, temp.c_str());
	DWORD error = GetLastError();

	char errorlog[MAX_PATH];
	sprintf_s(errorlog, "1st-error(%d), ", error);
	if (ret != 0)// last rename return  check
	{
		char log[MAX_PATH];
		sprintf_s(log, "%s - rename fail, %s", temp.c_str(), errorlog);
		CSaveIamge_writelog(log);
	}

	int i = 1;
	while (ret != 0)
	{
		Sleep(100);
		ret = rename(psImage->name, temp.c_str());
		error = GetLastError();
		if (i == 1)
			sprintf_s(errorlog, "%dnd-error(%d), ", i++, error);
		else
			sprintf_s(errorlog, "%dth-error(%d), ", i++, error);

		if (ret != 0)// last rename return  check
		{
			char log[MAX_PATH];
			sprintf_s(log, "%s - rename fail, %s", temp.c_str(), errorlog);
			CSaveIamge_writelog(log);
		}

		if (i > 3)//5times try
			break;
	}

	//if (ret != 0)// last rename return  check
	//{
	//	char log[MAX_PATH];
	//	sprintf_s(log, "%s - rename fail, %s", temp.c_str(), errorlog);
	//	CSaveIamge_writelog(log);
	//}

	int index = temp.find("lpr/input/");//30 
	if (index > 0)
	{
		char log[MAX_PATH];
		//sprintf_s(log, "%s - file saved, %s", temp.c_str(), errorlog);
		sprintf_s(log, "%s - file saved", temp.c_str());
		CSaveIamge_writelog(log);
	}

	psImage->isUse = 0;
	psImage->isMat = 0;

	m_listqueue->CQueueList_popfront();

	return 0;
}

int CSaveIamge::CSaveIamge_pop(sImage * _psImage)
{
	sImage* psImage = _psImage;
	if (psImage)
	{
		if (psImage->img)
		{
			cvReleaseImage((IplImage**)&psImage->img);
			psImage->isUse = 0;
		}
	}
	m_listqueue->CQueueList_popfront();

	return 0;
}

int CSaveIamge::CSaveIamge_writelog(const char * _log)
{
	SYSTEMTIME  tCurTime;
	::GetLocalTime(&tCurTime);

	char currentPath[MAX_PATH], makePath[MAX_PATH];	
	DWORD dwLength = GetModuleFileNameA(nullptr, currentPath, MAX_PATH);
	if (0 != dwLength)
	{
		char* path = currentPath + dwLength;
		while (--path != currentPath && *path != L'\\');
		if (*path == L'\\')
		{
			*path = L'\0';
		}
	}	
	sprintf_s(makePath, "%s\\CommLog", currentPath);

	CreateDirectoryA(makePath, nullptr);

	char todayfolder[MAX_PATH];
	sprintf_s(todayfolder, "%s\\%04d%02d%02d", makePath, (int)tCurTime.wYear, (int)tCurTime.wMonth, (int)tCurTime.wDay);
	CreateDirectoryA(todayfolder, nullptr);

	//CommLog
	char fileName[MAX_PATH];
	sprintf_s(fileName, "%s\\SaveHistory_Log_%04d%02d%02d_%02d.log", todayfolder, (int)tCurTime.wYear, (int)tCurTime.wMonth, (int)tCurTime.wDay, m_num + 1);

	char strLog[MAX_PATH];
	//strLog.Format("[%02d:%02d:%02d:%03d] %s", tCurTime.GetHour(), tCurTime.GetMinute(), tCurTime.GetSecond(), tCurTime.GetTickCount(), str);
	sprintf_s(strLog, "[%02d:%02d:%02d:%03d] %s", (int)tCurTime.wHour, (int)tCurTime.wMinute, (int)tCurTime.wSecond, (int)tCurTime.wMilliseconds, _log);

	FILE *log;
	if (fopen_s(&log, fileName, "at") == 0)
	{
		fprintf_s(log, "%s\n", strLog);
		fclose(log);
	}

	return 0;
}

unsigned __stdcall CSaveIamge::Thread_SavetoFile(void * pParam)
{
	if (pParam == nullptr) return -1;
	CSaveIamge* me = (CSaveIamge*)pParam;

	CQueueList* qImg = me->m_listqueue;
	sImage* psImage = nullptr;

	while (me->m_isRun)
	{
		WaitForSingleObject(me->m_hMutex, INFINITE);

		while (psImage = qImg->CQueueList_front())
		{
			me->CSaveIamge_SavetoFile(psImage);
			//me->CSaveIamge_pop(psImage);
		}

		ResetEvent(me->m_hMutex);
	}

	return 0;
}