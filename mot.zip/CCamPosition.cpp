
#include "CCamPosition.h"
#include "common.h"


CCamPosition::CCamPosition(void * _param)
{
	calculate_CCamPosition(_param);
}

CCamPosition::~CCamPosition()
{
}


void CCamPosition::calculate_CCamPosition(void* _param)
{
	if (_param == nullptr)
	{
		return;
	}

	st_det_mot_param *param = reinterpret_cast<st_det_mot_param *>(_param);

	m_fCamHeight = param->fCamHeight;
	m_fLengthLow = param->fLengthLow;
# if SPEED_KOREA_EXPRESSWAY_MODE == 1
	if (param->fLengthHigh == 0.0f)
	{
		m_fLengthCen = param->fLengthCen;

		//m_Alpha = atan(m_fLengthHigh / m_fCamHeight); // camera's angle
		float alphaLow = atan(m_fLengthLow / m_fCamHeight); // camera's low angle
		float alphaCen = atan(m_fLengthCen / m_fCamHeight); // camera's center angle

		m_Teta = (alphaCen - alphaLow) * 2.0f;
		m_Alpha = alphaLow + m_Teta;
	}
	else
	{
		m_Alpha = atan(param->fLengthHigh / m_fCamHeight); // camera's angle
		m_Teta = m_Alpha - atan(m_fLengthLow / m_fCamHeight);
	}
#else
	m_fLengthHigh = param->fLengthHigh;

	m_Alpha = atan(m_fLengthHigh / m_fCamHeight); // camera's angle
	m_Teta = m_Alpha - atan(m_fLengthLow / m_fCamHeight);
	
#endif

	m_fLengLowScr = sqrtf(m_fCamHeight * m_fCamHeight + m_fLengthLow * m_fLengthLow);
	
	m_fHeightCenter = m_fLengLowScr * cosf(m_Teta / 2.0f);

	m_fLengthScreen = 2.0f * sin(m_Teta / 2.0f) * m_fLengLowScr;
}

void CCamPosition::CCamPosition_SetViolationLine(int _comp1, int _comp2, float _inH, void*_param)
{
	if (_param == nullptr)
	{
		return;
	}

	st_det_mot_param *param = reinterpret_cast<st_det_mot_param *>(_param);

	if (_comp1 < _comp2) //_comp1 : ptLine[0].y, _comp2: ptLine[2].y
	{
		m_nStartY = _comp1;
		m_nEndY = _comp2;
	}
	else
	{
		m_nStartY = _comp2;
		m_nEndY = _comp1;
	}

	param->top_line = (float)m_nStartY / (float)_inH;// param->net.h;
	param->bottom_rate = (float)m_nEndY / (float)_inH;// param->net.h;

	//hai
	float fCenterTop = m_fLengthScreen / 2.0f - param->top_line * m_fLengthScreen;
	float fCenterTouch = param->bottom_rate * m_fLengthScreen - m_fLengthScreen / 2.0f;

	m_AlphaTop = m_Alpha - m_Teta / 2.0f + atan(fCenterTop / m_fHeightCenter);
	m_AlphaTouch = m_Alpha - m_Teta / 2.0f - atan(fCenterTouch / m_fHeightCenter);

# if SPEED_KOREA_EXPRESSWAY_MODE == 1
	m_fTopReal = tan(m_AlphaTop) * m_fCamHeight;
	m_fTouchReal = tan(m_AlphaTouch) * m_fCamHeight;
#else
	m_fTopReal = m_fLengthHigh - tan(m_AlphaTop) * m_fCamHeight;
	m_fTouchReal = m_fLengthHigh - tan(m_AlphaTouch) * m_fCamHeight;
#endif
}

int CCamPosition::CCamPosition_GetStartY()
{
	return m_nStartY;
}

int CCamPosition::CCamPosition_GetEndY()
{
	return m_nEndY;
}

float CCamPosition::CCamPosition_GetRealDistance()
{
	return m_fTouchReal - m_fTopReal;
}


float CCamPosition::CCamPosition_Ydistance_calculation(int nHeight, int nTrackPtY/*, float& fUndercarriageD*/)
{
	float fUndercarriageH = 0.25f;
	float fTrackPtReal = 0.0;
	float fCenterTrack = 0.0;
	float AlphaTrackPt = 0.0;
	float nRatio = (float)nTrackPtY / (float)(nHeight - 1);

	if (nRatio <= 0.5f)
	{
		fCenterTrack = m_fLengthScreen / 2.0f - nRatio * m_fLengthScreen;

		AlphaTrackPt = m_Alpha - m_Teta / 2.0f + atan(fCenterTrack / m_fHeightCenter);
	}
	else
	{
		fCenterTrack = nRatio * m_fLengthScreen - m_fLengthScreen / 2.0f;

		AlphaTrackPt = m_Alpha - m_Teta / 2.0f - atan(fCenterTrack / m_fHeightCenter);
	}

	fTrackPtReal = tan(AlphaTrackPt) * m_fCamHeight;
	//fUndercarriageD = tan(AlphaTrackPt) * (m_fCamHeight - fUndercarriageH);

	return fTrackPtReal;
}
