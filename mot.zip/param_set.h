#pragma once

#include "common.h"

//definition for get and set mode funcion
#define OPERATION_MODE_DISPLAY				0x00000000//0	//violation data no save
#define OPERATION_MODE_ALL					0x00000001//1	//violation data all save
#define OPERATION_MODE_BIKE					0x00000002//2	//bike(helmet, overriding, mobile, umbrella) violation data save
#define OPERATION_MODE_SIGNAL				0x00000004//4	//signal violation data save
#define OPERATION_MODE_TRACKING				0x00000008//8	//touch line passed through vehicle SAVE
#define OPERATION_MODE_SPEED				0x00000010//16	//speed violation data save
#define OPERATION_MODE_LANE					0x00000020//32	//lane(wrong direction) violation data save
#define OPERATION_MODE_REVERSE				0x00000040//64	//reverse violation data save //20190523 hai reverse violation
#define OPERATION_MODE_ILLEAGALPARKING		0x00000080//128 //parking on illeagal area violation data save 
#define OPERATION_MODE_LAST					OPERATION_MODE_ILLEAGALPARKING
#define OPERATION_MODE_MAX_SUM				OPERATION_MODE_LAST*2 - 2

extern "C" char* getModulPath();
extern "C" void makeViolationDirectory(st_det_mot_param * param);
extern "C" bool CreateFolder(char* strPath, int nLength);
extern "C" int  ReverseFindChar(char *strPath, char delimiter);

//extern "C" bool get_parameter(st_det_mot_param *param);
extern "C" bool param_initialize(st_det_mot_param *param, st_biker_info* biker_info);

extern "C" void setMode(st_det_mot_param *param, int nMode); //2018.10.29 young
extern "C" bool getMode(st_det_mot_param *param, int nMode);