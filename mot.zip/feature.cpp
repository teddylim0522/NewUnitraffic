
#include "feature.h"
//#include <conio.h>

void get_channel_image(Mat &image, Mat *ch_image, Mat *ag_ch_image, st_feature &feature)
{
	int n_bin = feature.n_bin;
	int n_grad_channel = feature.n_bin + feature.n_grad_mag;
	int n_channel = feature.n_channel;

	for (int k = 0; k < n_channel; k++)
	{
		ch_image[k].create(image.rows, image.cols, CV_32F);
		ch_image[k].setTo(Scalar(0.0));
	}

#if USE_HYBRID
	Mat color_ch_image[3];
#endif

	if (feature.use_color_channel)
	{
#if USE_HYBRID
		for (int k = 0; k < 3; k++)
		{
			color_ch_image[k].create(image.rows, image.cols, CV_32FC1);
		}
#endif

#if YCBCR444
		if (image.type() == CV_32FC3)
		{
#if USE_HYBRID
			yc_to_ch_image_32F(image, color_ch_image);
			ch_image[n_grad_channel] = color_ch_image[0].clone();
#else
			yc_to_ch_image_32F(image, &ch_image[n_grad_channel]);
#endif
		}
		else if (image.type() == CV_8UC3)
		{
#if USE_HYBRID
			yc_to_ch_image(image, color_ch_image);
			ch_image[n_grad_channel] = color_ch_image[0].clone();
#else
			yc_to_ch_image(image, &ch_image[n_grad_channel]);
#endif
		}
		else
		{
			printf("�������� �ʴ� �÷� �����Դϴ�.!!!!!!!!!\n");
		}
#else
#if USE_HYBRID
		_luv_to_ch_image(image, color_ch_image);
		ch_image[n_grad_channel] = color_ch_image[0].clone();
#else
		_luv_to_ch_image(image, &ch_image[n_grad_channel]);
#endif
#endif
	}
	else
		image.convertTo(ch_image[n_grad_channel], CV_32FC1);

	if (feature.use_color_channel)
	{
		Mat grad_image, mag_image;
		grad_image.create(image.rows, image.cols, CV_32F);
		mag_image = ch_image[n_bin];

		Mat grad_image_tmp[3], mag_image_tmp[3];

		Mat color_merge_ch_image[3];
		float alpha = 0.171875;
		for (int ch = 0; ch < 3; ch++)
		{
#if NEXT_CHIP_HW_STYLE
			color_merge_ch_image[ch].create(image.rows, image.cols, CV_32F);
			color_merge_ch_image[ch] = (alpha * ch_image[n_grad_channel]) + ((1 - alpha) * ch_image[n_grad_channel + ch]);

			for (int i = 0; i < color_merge_ch_image[ch].rows; i++)
			{
				for (int j = 0; j < color_merge_ch_image[ch].cols; j++)
				{
					color_merge_ch_image[ch].at<float>(i, j) = (int)(color_merge_ch_image[ch].at<float>(i, j) + 0.5);
				}
			}
#endif


			grad_image_tmp[ch].create(image.rows, image.cols, CV_32F);
			mag_image_tmp[ch].create(image.rows, image.cols, CV_32F);
#if USE_HYBRID
			get_mag_grad_image(color_ch_image[ch], grad_image_tmp[ch], mag_image_tmp[ch]);
#else
#if NEXT_CHIP_HW_STYLE
			get_mag_grad_image(color_merge_ch_image[ch], grad_image_tmp[ch], mag_image_tmp[ch]);
#else
			get_mag_grad_image(ch_image[n_grad_channel + ch], grad_image_tmp[ch], mag_image_tmp[ch]);
#endif

#endif
		}

		max_mag_grad_image(grad_image_tmp, mag_image_tmp, grad_image, mag_image);
		get_grad_ch_image(grad_image, mag_image, ch_image, n_bin);
	}
	else
	{
		Mat grad_image, mag_image;
		grad_image.create(image.rows, image.cols, CV_32F);
		mag_image = ch_image[n_bin];

		get_mag_grad_image(ch_image[n_grad_channel], grad_image, ch_image[n_bin]);
		get_grad_ch_image(grad_image, mag_image, ch_image, n_bin);
	}

	if (ag_ch_image == NULL) return;

	Mat *tmp_ag_ch_image = new Mat[n_channel];
	get_pooling_channel_image(ch_image, tmp_ag_ch_image, feature);

#if HW_APPROXIMATION
	_local_normalization(tmp_ag_ch_image, n_grad_channel, 3, LOCAL_NORM_FACTOR, 0.0);
#else
	_local_normalization(tmp_ag_ch_image, n_grad_channel, 3, LOCAL_NORM_FACTOR, 0.0);
//	local_normalization(tmp_ag_ch_image, n_grad_channel, 3, LOCAL_NORM_FACTOR);
#endif

	_global_normalization(&tmp_ag_ch_image[n_grad_channel], N_LAST_CHANNEL, 256.0);

	channel_gaussian_blur(tmp_ag_ch_image, ag_ch_image, n_channel);

#if 0
	for (int i = 0; i < n_channel; i++)
	{
		char fname[20];
		FILE *fp;
		sprintf(fname, "%d_feature.txt", i);
		fp = fopen(fname, "w");
		for (int j = 0; j < ag_ch_image[i].rows; j++)
		{
			for (int k = 0; k < ag_ch_image[i].cols; k++)
			{
				double val = ag_ch_image[i].at<float>(j, k);
				int i_val = val * (1 << 16);
				fprintf(fp, "%04x ", i_val);
				//printf("%04x ",i_val);
			}
			fprintf(fp, "\n");
			//printf("\n");
		}
		fclose(fp);
	}
	printf("Save Feature!");
	getch();
#endif

#if 0
	Mat disp_image(image.rows, image.cols, CV_8UC1);
	for (int k = 0; k < n_channel; k++)
	{
		char disp_name[20];
		convertScaleAbs(ch_image[k], disp_image, 1, 0);
		sprintf(disp_name, "%d_bin", k);
		imshow(disp_name, disp_image);
	}
	waitKey(0);
#endif

	delete[] tmp_ag_ch_image;
}

void get_octave_channel_image(Mat &image, Mat *ch_image, st_feature &feature)
{
	int n_bin = feature.n_bin;
	int n_grad_channel = feature.n_bin + feature.n_grad_mag;
	int n_last_channel = feature.n_last_channel;

	if (feature.use_color_channel)
		_luv_to_ch_image(image, &ch_image[n_grad_channel]);
	else
		image.convertTo(ch_image[n_grad_channel], CV_32FC1);

	if (feature.use_color_channel)
	{
		Mat grad_image, mag_image;
		grad_image.create(image.rows, image.cols, CV_32F);
		mag_image.create(image.rows, image.cols, CV_32F);
		ch_image[n_bin] = mag_image;

		Mat grad_image_tmp[3], mag_image_tmp[3];
		for (int ch = 0; ch < n_last_channel; ch++)
		{
			grad_image_tmp[ch].create(image.rows, image.cols, CV_32F);
			mag_image_tmp[ch].create(image.rows, image.cols, CV_32F);
			get_mag_grad_image(ch_image[n_grad_channel + ch], grad_image_tmp[ch], mag_image_tmp[ch]);
		}

		max_mag_grad_image(grad_image_tmp, mag_image_tmp, grad_image, mag_image);
		get_grad_ch_image(grad_image, ch_image[n_bin], ch_image, n_bin);
	}
	else
	{
		Mat grad_image;
		grad_image.create(image.rows, image.cols, CV_32F);
		get_mag_grad_image(ch_image[n_grad_channel], grad_image, ch_image[n_bin]);
		get_grad_ch_image(grad_image, ch_image[n_bin], ch_image, n_bin);
	}
}

void get_fast_channel_image(Mat *ch_image, Mat *f_ch_image, int n_channel, float scale)
{
	for (int i = 0; i < n_channel; i++)
	{
		//_resize(ch_image[i], f_ch_image[i], Size(), scale, scale);
		resize(ch_image[i], f_ch_image[i], Size(), scale, scale);
	}
}

void rgb_to_luv(Mat &rgb_image, Mat &luv_image)
{
	Mat image_32f;
	rgb_image.convertTo(image_32f, CV_32FC3);
	image_32f *= 1. / 255;
	cvtColor(image_32f, luv_image, cv::COLOR_BGR2Luv);
	for (int y = 0; y < luv_image.rows; y++)
	{
		Vec3f *src_ptr = luv_image.ptr<Vec3f>(y);
#if 0
		for (int x = 0; x < luv_image.cols; x++)
		{
			//src_ptr[x][0] = src_ptr[x][0] * 255. / 100.;
			//src_ptr[x][1] = (src_ptr[x][1]+ 134) * 255. / 354.;
			//src_ptr[x][2] = (src_ptr[x][2]+ 140) * 255. / 262;

			src_ptr[x][0] = src_ptr[x][0];
			src_ptr[x][1] = (src_ptr[x][1] + 134);
			src_ptr[x][2] = (src_ptr[x][2] + 140);
		}
#endif
	}
}

void _rgb_to_yc(Mat &rgb_image, Mat &yc_image)
{
	float Y, Cb, Cr;
	for (int y = 0; y < rgb_image.rows; y++)
	{
		Vec3b *src_ptr = rgb_image.ptr<Vec3b>(y);
		Vec3b *dst_ptr = yc_image.ptr<Vec3b>(y);

		for (int x = 0; x < rgb_image.cols; x++)
		{
			Y = (float)(0.29900*src_ptr[x][2] + 0.58700*src_ptr[x][1] + 0.11400*src_ptr[x][0] + 0.5);
			Cb = (float)(-0.169*src_ptr[x][2] - 0.331*src_ptr[x][1] + 0.500*src_ptr[x][0] + 128 + 0.5);
			Cr = (float)(0.500*src_ptr[x][2] - 0.419*src_ptr[x][1] - 0.081*src_ptr[x][0] + 128 + 0.5);
			//Cr = (src_ptr[x][2] - Y) * 0.713 + 128;
			//Cb = (src_ptr[x][0] - Y) * 0.564 + 128;

#if 0
			printf("src_ptr[x][2] = %d src_ptr[x][1] = %d, src_ptr[x][0] = %d \n", src_ptr[x][2], src_ptr[x][1], src_ptr[x][0]);
			printf("%d) dst_ptr_tmp[%d][0] = %d, Y = %f \n", y, x, dst_ptr_tmp[x][0], Y);
			printf("%d) dst_ptr_tmp[%d][2] = %d, Cb = %f \n", y, x, dst_ptr_tmp[x][1], Cr);
			printf("%d) dst_ptr_tmp[%d][1] = %d, Cr = %f \n", y, x, dst_ptr_tmp[x][2], Cb);
#endif

			if (Y > 255) Y = 255;
			if (Cr > 255) Cr = 255;
			if (Cb > 255) Cb = 255;

			if (Y < 0) Y = 0;
			if (Cr < 0) Cr = 0;
			if (Cb < 0) Cb = 0;

			dst_ptr[x][0] = (unsigned char)Y;
			dst_ptr[x][1] = (unsigned char)Cr;
			dst_ptr[x][2] = (unsigned char)Cb;
			//printf("111dst_ptr[x][0] = %d\n", dst_ptr[x][0]);

#if 0
			dst_ptr[x][0] = dst_ptr[x][0] & 0xFC;
			dst_ptr[x][1] = dst_ptr[x][1] & 0xFC;
			dst_ptr[x][2] = dst_ptr[x][2] & 0xFC;
#endif

			//printf("2222dst_ptr[x][0] = %d\n", dst_ptr[x][0]);
		}
	}
}

void rgb_to_yc(Mat &rgb_image, Mat &yc_image)
{
	cvtColor(rgb_image, yc_image, cv::COLOR_BGR2YCrCb);
}

void _rgb_to_yc_32F(Mat &rgb_image, Mat &yc_image)
{
	float Y, Cb, Cr;
	for (int y = 0; y < rgb_image.rows; y++)
	{
		Vec3b *src_ptr = rgb_image.ptr<Vec3b>(y);
		Vec3f *dst_ptr = yc_image.ptr<Vec3f>(y);

		for (int x = 0; x < rgb_image.cols; x++)
		{
			Y = (float)(0.29900*src_ptr[x][2] + 0.58700*src_ptr[x][1] + 0.11400*src_ptr[x][0]);
			Cb = (float)(-0.169*src_ptr[x][2] - 0.331*src_ptr[x][1] + 0.500*src_ptr[x][0] + 128);
			Cr = (float)(0.500*src_ptr[x][2] - 0.419*src_ptr[x][1] - 0.081*src_ptr[x][0] + 128);
			//Cr = (src_ptr[x][2] - Y) * 0.713 + 128;
			//Cb = (src_ptr[x][0] - Y) * 0.564 + 128;

#if 0
			printf("src_ptr[x][2] = %d src_ptr[x][1] = %d, src_ptr[x][0] = %d \n", src_ptr[x][2], src_ptr[x][1], src_ptr[x][0]);
			printf("%d) dst_ptr_tmp[%d][0] = %d, Y = %f \n", y, x, dst_ptr_tmp[x][0], Y);
			printf("%d) dst_ptr_tmp[%d][2] = %d, Cb = %f \n", y, x, dst_ptr_tmp[x][1], Cr);
			printf("%d) dst_ptr_tmp[%d][1] = %d, Cr = %f \n", y, x, dst_ptr_tmp[x][2], Cb);
#endif

			if (Y > 255) Y = 255;
			if (Cr > 255) Cr = 255;
			if (Cb > 255) Cb = 255;

			if (Y < 0) Y = 0;
			if (Cr < 0) Cr = 0;
			if (Cb < 0) Cb = 0;

			dst_ptr[x][0] = Y;
			dst_ptr[x][1] = Cr;
			dst_ptr[x][2] = Cb;
			//printf("111dst_ptr[x][0] = %d\n", dst_ptr[x][0]);

#if 0
			dst_ptr[x][0] = dst_ptr[x][0] & 0xFC;
			dst_ptr[x][1] = dst_ptr[x][1] & 0xFC;
			dst_ptr[x][2] = dst_ptr[x][2] & 0xFC;
#endif

			//printf("2222dst_ptr[x][0] = %d\n", dst_ptr[x][0]);
		}
	}
}

void image_to_ch_image_32F(Mat &yc_image, Mat *ch_image)
{
	int n_color_channel = 3;
	for (int y = 0; y < yc_image.rows; y++)
	{
		Vec3f *src_ptr = yc_image.ptr<Vec3f>(y);
		float *dst_ptr[3];
		for (int ch = 0; ch < n_color_channel; ch++)
		{
			dst_ptr[ch] = ch_image[ch].ptr<float>(y);
		}
		for (int x = 0; x < yc_image.cols; x++)
		{
			for (int ch = 0; ch < n_color_channel; ch++)
			{
				dst_ptr[ch][x] = src_ptr[x][ch];
			}
		}
	}
}

void image_to_ch_image(Mat &yc_image, Mat *ch_image)
{
	int n_color_channel = 3;
	for (int y = 0; y < yc_image.rows; y++)
	{
		Vec3b *src_ptr = yc_image.ptr<Vec3b>(y);
		float *dst_ptr[3];
		for (int ch = 0; ch < n_color_channel; ch++)
		{
			dst_ptr[ch] = ch_image[ch].ptr<float>(y);
		}
		for (int x = 0; x < yc_image.cols; x++)
		{
			for (int ch = 0; ch < n_color_channel; ch++)
			{
				dst_ptr[ch][x] = src_ptr[x][ch];
			}
		}
	}
}

void yc_to_rgb(Mat &yc_image, Mat &rgb_image)
{
	float R, G, B;
	for (int y = 0; y < rgb_image.rows; y++)
	{
		Vec3b *src_ptr = yc_image.ptr<Vec3b>(y);
		Vec3b *dst_ptr = rgb_image.ptr<Vec3b>(y);

		for (int x = 0; x < rgb_image.cols; x++)
		{
			R = (float)(src_ptr[x][0] + 1.402 * (src_ptr[x][1] - 128) + 0.5);
			G = (float)(src_ptr[x][0] - 0.344 * (src_ptr[x][2] - 128) - 0.714 * (src_ptr[x][1] - 128) + 0.5);
			B = (float)(src_ptr[x][0] + 1.772 * (src_ptr[x][2] - 128) + 0.5);

#if 0
			printf("src_ptr[x][2] = %d src_ptr[x][1] = %d, src_ptr[x][0] = %d \n", src_ptr[x][2], src_ptr[x][1], src_ptr[x][0]);
			printf("%d) dst_ptr_tmp[%d][0] = %d, R = %f \n", y, x, dst_ptr_tmp[x][0], R);
			printf("%d) dst_ptr_tmp[%d][2] = %d, B = %f \n", y, x, dst_ptr_tmp[x][1], B);
			printf("%d) dst_ptr_tmp[%d][1] = %d, G = %f \n", y, x, dst_ptr_tmp[x][2], G);
#endif

			if (R > 255) R = 255;
			if (G > 255) G = 255;
			if (B > 255) B = 255;

			if (R < 0) R = 0;
			if (G < 0) G = 0;
			if (B < 0) B = 0;

			dst_ptr[x][0] = (unsigned char)B;
			dst_ptr[x][1] = (unsigned char)G;
			dst_ptr[x][2] = (unsigned char)R;
		}
	}
}

void yc444_to_yc422(Mat &yc444, Mat &yc422)
{
	yc422 = yc444.clone();

	for (int i = 0; i < yc422.rows; i++)
	{
		for (int j = 0; j < yc422.cols; j++)
		{
			if (!(j % 2))
			{
				if (j == yc422.cols - 1)
					yc422.at<Vec3b>(i, j)[1] = yc444.at<Vec3b>(i, j - 1)[1];
				else
					yc422.at<Vec3b>(i, j)[1] = yc444.at<Vec3b>(i, j + 1)[1];
			}
			else
				yc422.at<Vec3b>(i, j)[2] = yc444.at<Vec3b>(i, j - 1)[2];
		}
	}

	/*for(int y = 0; y < yc444.rows; y++)
	{
	Vec3b *src_ptr = yc444.ptr<Vec3b>(y);
	Vec3b *dst_ptr = yc422.ptr<Vec3b>(y);

	for (int x = 0; x < yc444.cols; x++ )
	{
	dst_ptr[x][0] = src_ptr[x][0];//Y channel
	if((x%2) == 0)
	{
	dst_ptr[x][1] = (src_ptr[x][1] + src_ptr[x+1][1])/2.0 + 0.5;//Cr channel
	dst_ptr[x][2] = (src_ptr[x][2] + src_ptr[x+1][2])/2.0 + 0.5;//Cb channel
	}
	else
	{
	dst_ptr[x][1] = dst_ptr[x - 1][1];//Cr channel
	dst_ptr[x][2] = dst_ptr[x - 1][2];//Cb channel
	}
	}
	}*/
}

void yc444_to_yc422_2(Mat &yc444, Mat &yc422)
{
	Mat tmp = yc444.clone();
	Mat itmp = Mat::zeros(yc444.rows, yc444.cols, CV_8UC3);

	if (yc444.type() == CV_32FC3)
	{
		for (int i = 0; i < itmp.rows; i++)
		{
			for (int j = 0; j < itmp.cols; j++)
			{
				itmp.at<Vec3b>(i, j)[0] = (int)(tmp.at<Vec3f>(i, j)[0] + 0.5);

				if (!(j % 2))
				{
					if (j == itmp.cols - 1)
						itmp.at<Vec3b>(i, j)[1] = (int)(tmp.at<Vec3f>(i, j)[1] + 0.5);
					else
					{
						itmp.at<Vec3b>(i, j)[1] = (int)((tmp.at<Vec3f>(i, j)[1] + tmp.at<Vec3f>(i, j + 1)[1]) / 2 + 0.5);
						itmp.at<Vec3b>(i, j + 1)[1] = itmp.at<Vec3b>(i, j)[1];
					}
				}
				else
				{
					itmp.at<Vec3b>(i, j)[2] = (int)((tmp.at<Vec3f>(i, j)[2] + tmp.at<Vec3f>(i, j - 1)[2]) / 2 + 0.5);
					itmp.at<Vec3b>(i, j - 1)[2] = itmp.at<Vec3b>(i, j)[2];
				}
			}
		}

		if (!yc422.empty())
			yc422.release();

		yc422 = itmp.clone();
	}

	else
	{
		for (int i = 0; i < tmp.rows; i++)
		{
			for (int j = 0; j < tmp.cols; j++)
			{
				if (!(j % 2))
				{
					if (j == tmp.cols - 1)
						tmp.at<Vec3b>(i, j)[1] = yc444.at<Vec3b>(i, j)[1];
					else
					{
						tmp.at<Vec3b>(i, j)[1] = (int)((float)(yc444.at<Vec3b>(i, j)[1] + yc444.at<Vec3b>(i, j + 1)[1]) / 2 + 0.5);
						tmp.at<Vec3b>(i, j + 1)[1] = tmp.at<Vec3b>(i, j)[1];
					}
				}
				else
				{
					tmp.at<Vec3b>(i, j)[2] = (int)((float)(yc444.at<Vec3b>(i, j)[2] + yc444.at<Vec3b>(i, j - 1)[2]) / 2 + 0.5);
					tmp.at<Vec3b>(i, j - 1)[2] = tmp.at<Vec3b>(i, j)[2];
				}
			}
		}

		if (!yc422.empty())
			yc422.release();

		yc422 = tmp.clone();
	}
}

void yc444_to_yc420(Mat &yc444, Mat &yc420)
{
	for (int y = 0; y < yc444.rows; y++)
	{
		Vec3b *src_ptr = yc444.ptr<Vec3b>(y);
		Vec3b *dst_ptr = yc420.ptr<Vec3b>(y);

		Vec3b *src_ptr_next;
		if (y == (yc444.rows - 1)) src_ptr_next = yc444.ptr<Vec3b>(y);
		else src_ptr_next = yc444.ptr<Vec3b>(y + 1);

		Vec3b *dst_ptr_prev;
		if (y > 0) dst_ptr_prev = yc420.ptr<Vec3b>(y - 1);

		for (int x = 0; x < yc444.cols; x++)
		{
			dst_ptr[x][0] = src_ptr[x][0];//y channel
			if (((x % 2) == 0) && ((y % 2) == 0))
			{
				dst_ptr[x][1] = (src_ptr[x][1] + src_ptr[x + 1][1] + src_ptr_next[x][1] + src_ptr_next[x + 1][1]) / 4.0 + 0.5;//Cr channel
				dst_ptr[x][2] = (src_ptr[x][2] + src_ptr[x + 1][2] + src_ptr_next[x][2] + src_ptr_next[x + 1][2]) / 4.0 + 0.5;//Cb channel
			}
			else if ((x % 2) == 1)
			{
				dst_ptr[x][1] = dst_ptr[x - 1][1];//Cr channel
				dst_ptr[x][2] = dst_ptr[x - 1][2];//Cb channel
			}
			else
			{
				dst_ptr[x][1] = dst_ptr_prev[x][1];//Cr channel
				dst_ptr[x][2] = dst_ptr_prev[x][2];//Cb channel
			}
		}
	}
}

void yc422_to_yc444(Mat &yc422, Mat &yc444)
{
	for (int y = 0; y < yc422.rows; y++)
	{
		Vec3b *src_ptr = yc422.ptr<Vec3b>(y);
		Vec3b *dst_ptr = yc444.ptr<Vec3b>(y);

		for (int x = 0; x < yc422.cols; x++)
		{
			dst_ptr[x][0] = src_ptr[x][0];//y channel
			if ((x % 2) == 0)
			{
				dst_ptr[x][1] = src_ptr[x][1];//Cr channel
				dst_ptr[x][2] = src_ptr[x][2];//Cb channel
			}
			else
			{
				if (x == (yc422.cols - 1))//������ column�� ��
				{
					dst_ptr[x][1] = src_ptr[x - 1][1];//Cr channel
					dst_ptr[x][2] = src_ptr[x - 1][2];//Cb channel
				}
				else
				{
					dst_ptr[x][1] = (src_ptr[x - 1][1] + src_ptr[x + 1][1]) / 2.0 + 0.5;//Cr channel
					dst_ptr[x][2] = (src_ptr[x - 1][2] + src_ptr[x + 1][2]) / 2.0 + 0.5;//Cb channel
				}
			}

#if 0
			dst_ptr[x][0] = dst_ptr[x][0] & 0xFC;
			dst_ptr[x][1] = dst_ptr[x][1] & 0xFC;
			dst_ptr[x][2] = dst_ptr[x][2] & 0xFC;
#endif
		}
	}
}

void yc_to_ch_image(Mat &yc_image, Mat *ch_image)
{
	int n_color_channel = 3;
	for (int y = 0; y < yc_image.rows; y++)
	{
		Vec3b *src_ptr = yc_image.ptr<Vec3b>(y);
		float *dst_ptr[3];
		for (int ch = 0; ch < n_color_channel; ch++)
		{
			dst_ptr[ch] = ch_image[ch].ptr<float>(y);
		}
		for (int x = 0; x < yc_image.cols; x++)
		{
			for (int ch = 0; ch < n_color_channel; ch++)
			{
				dst_ptr[ch][x] = src_ptr[x][ch];
			}
		}
	}
}

void yc_to_ch_image_32F(Mat &yc_image, Mat *ch_image)
{
	int n_color_channel = 3;
	for (int y = 0; y < yc_image.rows; y++)
	{
		Vec3f *src_ptr = yc_image.ptr<Vec3f>(y);
		float *dst_ptr[3];
		for (int ch = 0; ch < n_color_channel; ch++)
		{
			dst_ptr[ch] = ch_image[ch].ptr<float>(y);
		}
		for (int x = 0; x < yc_image.cols; x++)
		{
			for (int ch = 0; ch < n_color_channel; ch++)
			{
				dst_ptr[ch][x] = src_ptr[x][ch];
			}
		}
	}
}

void _channel_split(Mat &color_image, Mat *ch_image)
{
	int n_color_channel = 3;
	for (int y = 0; y < color_image.rows; y++)
	{
		Vec3b *src_ptr = color_image.ptr<Vec3b>(y);
		unsigned char *dst_ptr[3];
		for (int ch = 0; ch < n_color_channel; ch++)
		{
			dst_ptr[ch] = ch_image[ch].ptr<unsigned char>(y);
		}
		for (int x = 0; x < color_image.cols; x++)
		{
			for (int ch = 0; ch < n_color_channel; ch++)
			{
				dst_ptr[ch][x] = src_ptr[x][ch];
			}
		}
	}
}

void _channel_merge(Mat *ch_image, Mat &color_image)
{
	int n_color_channel = 3;
	for (int y = 0; y < color_image.rows; y++)
	{
		Vec3b *dst_ptr = color_image.ptr<Vec3b>(y);
		unsigned char *src_ptr[3];
		for (int ch = 0; ch < n_color_channel; ch++)
		{
			src_ptr[ch] = ch_image[ch].ptr<unsigned char>(y);
		}
		for (int x = 0; x < color_image.cols; x++)
		{
			for (int ch = 0; ch < n_color_channel; ch++)
			{
				dst_ptr[x][ch] = src_ptr[ch][x];
			}
		}
	}
}

void _luv_to_ch_image(Mat &luv_image, Mat *ch_image)
{
	int n_color_channel = 3;
	for (int y = 0; y < luv_image.rows; y++)
	{
		Vec3f *src_ptr = luv_image.ptr<Vec3f>(y);
		float *dst_ptr[3];
		for (int ch = 0; ch < n_color_channel; ch++)
		{
			dst_ptr[ch] = ch_image[ch].ptr<float>(y);
		}
		for (int x = 0; x < luv_image.cols; x++)
		{
			for (int ch = 0; ch < n_color_channel; ch++)
			{
				dst_ptr[ch][x] = src_ptr[x][ch];
			}
		}
	}
}

void luv_to_ch_image(Mat &luv_image, Mat &ch_image)
{
	split(luv_image, &ch_image);
}

void get_mag_grad_image(Mat &image, Mat &grd_image, Mat &mag_image)
{
	Mat xDiff(image.rows, image.cols, CV_32FC1), yDiff(image.rows, image.cols, CV_32FC1);
	int ddepth = CV_32FC1;

	Mat smooth_image;

#if NEXT_CHIP_HW_STYLE
	double **corner_value_x = new double *[2];
	double **corner_value_y = new double *[2];
	for (int i = 0; i < 2; i++)
	{
		corner_value_x[i] = new double[image.rows];
		corner_value_y[i] = new double[image.cols];
	}
#endif

#if HW_APPROXIMATION
#if NEXT_CHIP_HW_STYLE
	_GaussianBlur2(image, smooth_image, Size(3, 3), 1.0, corner_value_x, corner_value_y);
	_Sobel2(smooth_image, xDiff, ddepth, 1, 0, 1, corner_value_x, corner_value_y);
	_Sobel2(smooth_image, yDiff, ddepth, 0, 1, 1, corner_value_x, corner_value_y);
#else
	_GaussianBlur(image, smooth_image, Size(3, 3), 1.0);
	_Sobel(smooth_image, xDiff, ddepth, 1, 0, 1);
	_Sobel(smooth_image, yDiff, ddepth, 0, 1, 1);

#endif
#else
	GaussianBlur(image, smooth_image, Size(3, 3), 1.0);
	Sobel(smooth_image, xDiff, ddepth, 1, 0, 1);
	Sobel(smooth_image, yDiff, ddepth, 0, 1, 1);
#endif

	double grad_tmp, mag_tmp;
	for (int y = 0; y < image.rows; y++)
	{
		float *ptr1 = xDiff.ptr<float>(y);
		float *ptr2 = yDiff.ptr<float>(y);
		float *grd_ptr = grd_image.ptr<float>(y);
		float *mag_ptr = mag_image.ptr<float>(y);
		float *image_ptr = smooth_image.ptr<float>(y);
		for (int x = 0; x < image.cols; x++)
		{
#if HW_APPROXIMATION
			grad_tmp = get_approximate_angle(ptr1[x], ptr2[x], 5);
			mag_tmp = max(abs(ptr1[x]), abs(ptr2[x])) + 0.5*min(abs(ptr1[x]), abs(ptr2[x]));

#if HW_APPROXIMATION
			int val = mag_tmp * (1 << 4);
			mag_tmp = val / 16.0;//val0;
#endif
#else
			if (abs(ptr1[x]) < 0.00001)
				grad_tmp = 0.;
			else
				grad_tmp = (float)(((atan(ptr2[x] / ptr1[x])) * (180 / CV_PI)) + 90);

			mag_tmp = sqrt((ptr1[x] * ptr1[x]) + (ptr2[x] * ptr2[x]));
#endif

			grd_ptr[x] = (float)grad_tmp;
			mag_ptr[x] = (float)mag_tmp;
		}
	}
#if HW_APPROXIMATION
	for (int i = 0; i < 2; i++)
	{
		delete[] corner_value_x[i];
		delete[] corner_value_y[i];
	}

	delete[] corner_value_x;
	delete[] corner_value_y;
#endif
}

float get_approximate_angle(float dx, float dy, int angle_step)
{
	float angle;
	float abs_dx = abs(dx);
	float abs_dy = abs(dy);
	bool b_sign = ((dx*dy) >= 0) ? 1 : 0;

	if (abs_dx >= abs_dy)
	{
		angle = get_0_to_45_angle(abs_dx, abs_dy, angle_step);
	}
	else
	{
		angle = 90 - get_0_to_45_angle(abs_dy, abs_dx, angle_step);
	}

	if (b_sign)
	{
		angle = angle + 90;
	}
	else
	{
		angle = 90 - angle;
	}
	return angle;
}

float get_0_to_45_angle(float a, float b, int angle_step)
{
	float angle;
	float tan_table[9] = { 22.40625 / 256., 45.125 / 256., 68.59375 / 256., 93.1875 / 256., 119.375 / 256., 147.8125 / 256., 179.25 / 256., 214.8125 / 256., 256. / 256. };//5, 10, 15,.... 45

	if (b < (a * tan_table[0]))//0-5
	{
		angle = 2.5;
	}
	else if (b < (a * tan_table[1]))//5-10
	{
		angle = 7.5;
	}
	else if (b < (a * tan_table[2]))//10-15
	{
		angle = 12.5;
	}
	else if (b < (a * tan_table[3]))//15-20
	{
		angle = 17.5;
	}
	else if (b < (a * tan_table[4]))//20-25
	{
		angle = 22.5;
	}
	else if (b < (a * tan_table[5]))//25-30
	{
		angle = 27.5;
	}
	else if (b < (a * tan_table[6]))//30-35
	{
		angle = 32.5;
	}
	else if (b < (a * tan_table[7]))//35-40
	{
		angle = 37.5;
	}
	else//40-45
	{
		angle = 42.5;
	}

	return angle;
}

void max_mag_grad_image(Mat *_grad_image, Mat *_mag_image, Mat &grad_image, Mat &mag_image)
{
	for (int y = 0; y < _grad_image[0].rows; y++)
	{
		float *grad[3], *mag[3];
		float *grad_ptr = grad_image.ptr<float>(y);
		float *mag_ptr = mag_image.ptr<float>(y);
		for (int c = 0; c < 3; c++)
		{
			grad[c] = _grad_image[c].ptr<float>(y);
			mag[c] = _mag_image[c].ptr<float>(y);
		}
		for (int x = 0; x < _grad_image[0].cols; x++)
		{
			float max_magnitude = -INFINITY, temp_magnitude, temp_gradient;

			temp_magnitude = mag[0][x] * RRIOR_Y_WEIGHT;

			temp_gradient = grad[0][x];
#ifdef HW_APPROXIMATION
			int int_magnitude = temp_magnitude * (1 << 4);
			max_magnitude = (float)int_magnitude / 16.0;
#endif

			/*float max_magnitude, temp_magnitude , temp_gradient;

			max_magnitude = mag[0][x] * RRIOR_Y_WEIGHT;

			temp_magnitude = mag[0][x] * RRIOR_Y_WEIGHT;

			int int_magnitude = max_magnitude * (1 << 4);
			max_magnitude = (float)int_magnitude / 16.0;

			int_magnitude = temp_magnitude * (1 << 4);
			temp_magnitude = (float)int_magnitude / 16.0;

			temp_gradient = grad[0][x];*/

			for (int c = 1; c < 3; c++)
			{
				temp_magnitude = mag[c][x];

#ifdef HW_APPROXIMATION
				int_magnitude = temp_magnitude * (1 << 4);
				temp_magnitude = (float)int_magnitude / 16.0;
#endif

				if (temp_magnitude > max_magnitude)
				{
					temp_gradient = grad[c][x];
					max_magnitude = temp_magnitude;

					//b_select = FALSE;
				}

				/*if (mag[c][x] >= max_magnitude)
				{
				max_magnitude = temp_magnitude = mag[c][x];
				temp_gradient = grad[c][x];

				int_magnitude = max_magnitude * (1 << 4);
				max_magnitude = (float)int_magnitude / 16.0;

				int_magnitude = temp_magnitude * (1 << 4);
				temp_magnitude = (float)int_magnitude / 16.0;
				}
				*/
			}
			//total ++;
			//n_select += b_select;

			grad_ptr[x] = (float)temp_gradient;
			mag_ptr[x] = (float)max_magnitude;
		}
	}

	//printf("n_select = %d, total = %d, => %f \n", n_select, total, (float)n_select/total);
}

void get_grad_ch_image(Mat &grad_image, Mat &mag_image, Mat *ch_image, int n_bin)
{
	float **ch_ptr = new float *[n_bin];
	float base_weight = 0.08203125;
	float norm_weight = 0.984375;//12*base_weight

	for (int y = 0; y < grad_image.rows; y++)
	{
		float *grad = grad_image.ptr<float>(y);
		float *mag = mag_image.ptr<float>(y);
		for (int k = 0; k < n_bin; k++)
		{
			ch_ptr[k] = ch_image[k].ptr<float>(y);
		}

		for (int x = 0; x < grad_image.cols; x++)
		{
			double f_bin = grad[x] * n_bin / (180.0);
			int l_bin = (int)(floor(f_bin)), r_bin;
			double weight = f_bin - l_bin;

			if (l_bin >= (n_bin - 1))
			{
				l_bin = n_bin - 1;
				r_bin = 0;
			}
			else
			{
				r_bin = l_bin + 1;
			}

#if HW_APPROXIMATION
			double _weight = weight * 12 * base_weight;//weight approximation
			//printf("weight = %f, _weight = %f\n", weight, _weight);
			ch_ptr[l_bin][x] = (float)((norm_weight - _weight)*mag[x]);
			ch_ptr[r_bin][x] = (float)(_weight*mag[x]);
#else
			ch_ptr[l_bin][x] = (float)((1.0 - weight)*mag[x]);
			ch_ptr[r_bin][x] = (float)(weight*mag[x]);
#endif
		}
	}

	delete ch_ptr;
}

void get_pooling_image(Mat *ch_image, Mat *pooling_image, st_feature &feature)
{
	int n_bin = feature.n_bin;
	int n_grad_mag = feature.n_grad_mag;
	int n_grad_channel = n_bin + n_grad_mag;
	int n_channel = feature.n_channel;

	Mat *tmp_ch_image = new Mat[n_channel];
	get_pooling_channel_image(ch_image, tmp_ch_image, feature);
	_local_normalization(tmp_ch_image, n_grad_channel, 3, 0.5, 0.01);
	channel_gaussian_blur(tmp_ch_image, pooling_image, n_channel);

	delete[] tmp_ch_image;
}

void get_pooling_channel_image(Mat *ch_image, Mat *ag_ch_image, st_feature &feature)
{
	int cell_width = feature.cell_width;
	int cell_height = feature.cell_height;
	int n_channel = feature.n_channel;
	char *pooling_type = feature.pooling_type;

	for (int k = 0; k < n_channel; k++)
	{
		ag_ch_image[k].create(ch_image[k].rows / cell_height, ch_image[k].cols / cell_width, CV_32F);
		pooling_block(ch_image[k], ag_ch_image[k], cell_width, cell_height, pooling_type);
	}
}

void pooling_block(Mat &src_image, Mat &dst_image, int x_block, int y_block, char *pooling_type)
{
	int x_block_margin = src_image.cols % x_block;
	int y_block_margin = src_image.rows % y_block;
	int x_end = src_image.cols - x_block_margin - (x_block - 1);
	int y_end = src_image.rows - y_block_margin - (y_block - 1);

	float **src_ptr = new float *[y_block];
	float *dst_ptr;
	int dst_x_id = 0, dst_y_id = 0;
	for (int y = 0; y < y_end; y += y_block)
	{
		for (int i = 0; i < y_block; i++)
		{
			src_ptr[i] = src_image.ptr<float>(i + y);
		}
		dst_ptr = dst_image.ptr<float>(dst_y_id);
		dst_y_id++;
		dst_x_id = 0;

		for (int x = 0; x < x_end; x += x_block)
		{
			if (strcmp(pooling_type, "average_pooling") == 0)
			{
				float sum = 0;
				for (int i = 0; i < y_block; i++)
				{
					for (int j = 0; j < x_block; j++)
					{
#if NEXT_CHIP_HW_STYLE
						int i_val = (int)(src_ptr[i][x + j] * (1 << 12));
						float f_val = i_val / (float)(1 << 12);
						sum += f_val;
#else

						sum += src_ptr[i][x + j];
#endif
					}
				}
				dst_ptr[dst_x_id++] = sum / (x_block * y_block);
			}
			else if (strcmp(pooling_type, "max_pooling") == 0)
			{
				float max = -1.0;
				for (int i = 0; i < y_block; i++)
				{
					for (int j = 0; j < x_block; j++)
					{
						if (src_ptr[i][x + j] > max)
						{
							max = src_ptr[i][x + j];
						}
					}
				}
				dst_ptr[dst_x_id++] = max;
			}
			else
			{
				float sum = 0;
				for (int i = 0; i < y_block; i++)
				{
					for (int j = 0; j < x_block; j++)
					{
						sum += src_ptr[i][x + j];
					}
				}
				dst_ptr[dst_x_id++] = sum;
			}
		}
	}

	delete[] src_ptr;
}

void channel_gaussian_blur(Mat *src_ch_image, Mat *dst_ch_image, int n_channel)
{
#if NEXT_CHIP_HW_STYLE
	double **corner_value_x = new double *[2];
	double **corner_value_y = new double *[2];
	for (int i = 0; i < 2; i++)
	{
		corner_value_x[i] = new double[src_ch_image[0].rows];
		corner_value_y[i] = new double[src_ch_image[0].cols];
	}
#endif

	for (int k = 0; k < n_channel; k++)
	{
#if HW_APPROXIMATION
		_GaussianBlur(src_ch_image[k], dst_ch_image[k], Size(3, 3), 1.0);
#else
		GaussianBlur(src_ch_image[k], dst_ch_image[k], Size(3, 3), 1.0);
#endif
	}

#if HW_APPROXIMATION
	for (int i = 0; i < 2; i++)
	{
		delete[] corner_value_x[i];
		delete[] corner_value_y[i];
	}

	delete[] corner_value_x;
	delete[] corner_value_y;
#endif
}

void local_normalization(Mat *image, int n_channel, int block_size, float min_value)
{
	Mat image_tmp(image[0].rows, image[0].cols, CV_32F);
	blur(image[n_channel - 1], image_tmp, Size(block_size, block_size));
	image_tmp = image_tmp * (block_size * block_size) + min_value;
	for (int k = 0; k < n_channel; k++)
	{
		divide(image[k], image_tmp, image[k]);
	}
}

void generate_feature_vectors_from_window(Mat *ag_image, CvMat *t_data, int index, st_feature &feature, int auto_retrain_padding_size)
{
	int cell_width = feature.cell_width;
	int cell_height = feature.cell_height;
	int n_channel = feature.n_channel;

	int image_width = ag_image[0].cols - (2 * (auto_retrain_padding_size / cell_width));
	int image_height = ag_image[0].rows - (2 * (auto_retrain_padding_size / cell_height));
	int resized_x_padding_size = auto_retrain_padding_size / cell_width;
	int resized_y_padding_size = auto_retrain_padding_size / cell_height;

	int n_feat_per_ch = image_width * image_height;
	int n_feat = n_feat_per_ch * n_channel;

	for (int k = 0; k < n_channel; k++)
	{
		for (int y = 0; y < image_height; y++)
		{
			float *ptr = ag_image[k].ptr<float>(y + resized_y_padding_size);
			memcpy(&t_data->data.fl[(n_feat*index) + (n_feat_per_ch * k) + (y*image_width)], &ptr[resized_x_padding_size], sizeof(ptr[0])*image_width);
		}
	}
}

void generate_feature_vectors_from_full_image(Mat *ag_image, CvMat *t_data, int x_start, int y_start, st_feature &feature)
{
	int n_hor_cell = feature.n_hor_cell;
	int n_ver_cell = feature.n_ver_cell;
	int n_channel = feature.n_channel;

	int image_width = ag_image[0].cols;
	int image_height = ag_image[0].rows;

	int n_feat_per_ch = n_hor_cell * n_ver_cell;
	int n_feat = n_feat_per_ch * n_channel;

	for (int k = 0; k < n_channel; k++)
	{
		for (int y = 0; y < n_ver_cell; y++)
		{
			float *ptr = ag_image[k].ptr<float>(y + y_start);
			memcpy(&t_data->data.fl[(k*n_feat_per_ch) + (y*n_hor_cell)], &ptr[x_start], sizeof(ptr[0])*n_hor_cell);
		}
	}
}

void generate_feature_rows_from_full_image(Mat *ag_image, CvMat *b_data, int x_start, st_feature &feature)
{
	int n_hor_cell = feature.n_hor_cell;
	int n_ver_cell = feature.n_ver_cell;
	int n_channel = feature.n_channel;

	int image_width = ag_image[0].cols;
	int image_height = ag_image[0].rows;

	int n_feat_per_ch = n_hor_cell * ag_image[0].rows;
	int n_feat = n_feat_per_ch * n_channel;

	for (int k = 0; k < n_channel; k++)
	{
		for (int y = 0; y < ag_image[0].rows; y++)
		{
			float *ptr = ag_image[k].ptr<float>(y);
			memcpy(&b_data->data.fl[(k*n_feat_per_ch) + (y*n_hor_cell)], &ptr[x_start], sizeof(ptr[0])*n_hor_cell);
		}
	}
}

void get_feature_vector_from_feature_rows(Mat *ag_image, CvMat *s_feat, CvMat *t_feat, int y_start, st_feature &feature, int n_copy)
{
	int n_hor_cell = feature.n_hor_cell;
	int n_ver_cell = feature.n_ver_cell;
	int n_channel = feature.n_channel;

	int image_width = ag_image[0].cols;
	int image_height = ag_image[0].rows;

	int n_feat_per_ch = n_hor_cell * ag_image[0].rows;
	int n_feat = n_feat_per_ch * n_channel;

	for (int k = 0; k < n_channel; k++)
	{
		memcpy(&t_feat->data.fl[k*n_copy], &s_feat->data.fl[(k*n_feat_per_ch) + (y_start*n_hor_cell)], sizeof(t_feat->data.fl[0])*n_copy);
	}
}

void _Sobel2(Mat &src, Mat &dst, int ddepth, int dx, int dy, int ksize, double **corner_value_x, double **corner_value_y)
{
	if (dx == 1)//dx
	{
		for (int y = 0; y < src.rows; y++)
		{
			float *src_row = src.ptr<float>(y);
			float *dst_row = dst.ptr<float>(y);

			for (int x = 0; x < src.cols; x++)
			{
				if (x == 0)//boundary �� ��..
				{
					dst_row[x] = -corner_value_x[0][y] + src_row[x + 1];
				}
				else if ((x == (src.cols - 1)))
				{
					dst_row[x] = -src_row[x - 1] + corner_value_x[1][y];
				}
				else
				{
					dst_row[x] = -src_row[x - 1] + src_row[x + 1];
				}
			}
		}
	}
	else//dy
	{
		for (int y = 0; y < src.rows; y++)
		{
			float *src_row = src.ptr<float>(y);
			float *dst_row = dst.ptr<float>(y);

			if (y == 0)//boundary �� ��..
			{
				for (int x = 0; x < src.cols; x++)
				{
					float *prev_src_row = src.ptr<float>(y);
					float *next_src_row = src.ptr<float>(y + 1);

					dst_row[x] = -corner_value_y[0][x] + next_src_row[x];
				}
			}
			else if (y == src.rows - 1)
			{
				for (int x = 0; x < src.cols; x++)
				{
					float *prev_src_row = src.ptr<float>(y - 1);
					float *next_src_row = src.ptr<float>(y);

					dst_row[x] = -prev_src_row[x] + corner_value_y[1][x];
				}
			}
			else
			{
				float *prev_src_row = src.ptr<float>(y - 1);
				float *next_src_row = src.ptr<float>(y + 1);
				for (int x = 0; x < src.cols; x++)
				{
					dst_row[x] = -prev_src_row[x] + next_src_row[x];
				}
			}
		}
	}
}

void _Sobel(Mat &src, Mat &dst, int ddepth, int dx, int dy, int ksize)
{
	if (dx == 1)//dx
	{
		for (int y = 0; y < src.rows; y++)
		{
			float *src_row = src.ptr<float>(y);
			float *dst_row = dst.ptr<float>(y);

			for (int x = 0; x < src.cols; x++)
			{
				if ((x == 0) || (x == (src.cols - 1)))//boundary �� ��..
				{
					dst_row[x] = 0;
				}
				else
				{
					dst_row[x] = -src_row[x - 1] + src_row[x + 1];
				}
			}
		}
	}
	else//dy
	{
		for (int y = 0; y < src.rows; y++)
		{
			float *src_row = src.ptr<float>(y);
			float *dst_row = dst.ptr<float>(y);

			if ((y == 0) || (y == (src.rows - 1)))//boundary �� ��..
			{
				for (int x = 0; x < src.cols; x++)
				{
					dst_row[x] = 0;
				}
			}
			else
			{
				float *prev_src_row = src.ptr<float>(y - 1);
				float *next_src_row = src.ptr<float>(y + 1);
				for (int x = 0; x < src.cols; x++)
				{
					dst_row[x] = -prev_src_row[x] + next_src_row[x];
				}
			}
		}
	}
}

void _GaussianBlur2(Mat &src, Mat &dst, Size ksize, double sigmaX, double **corner_value_x, double **corner_value_y)
{
	int x = 0, y = 0;

	dst.create(src.rows, src.cols, src.type());
	float filter[9] = { 1. / 16, 2. / 16, 1. / 16, 2. / 16, 4. / 16, 2. / 16, 1. / 16, 2. / 16, 1. / 16 };
	//float filter[9] = {0.0751, 0.1238, 0.0751, 0.1238, 0.2042, 0.1238, 0.0751, 0.1238, 0.0751};

	for (y = 0; y < src.rows; y++)
	{
		float *src_row = src.ptr<float>(y);
		float *dst_row = dst.ptr<float>(y);
		float *prev_src_row;
		float *next_src_row;

		if (y == 0)
		{
			prev_src_row = src.ptr<float>(y);
			next_src_row = src.ptr<float>(y + 1);

			for (x = 0; x < src.cols; x++)
			{
				if (x == 0)
					corner_value_y[0][x] = src_row[x] * 3 / 4 + src_row[x + 1] / 4;
				else if (x == (src.cols - 1))
					corner_value_y[0][x] = src_row[x] * 3 / 4 + src_row[x - 1] / 4;
				else
					corner_value_y[0][x] = src_row[x - 1] / 4 + src_row[x] / 2 + src_row[x + 1] / 4;
			}
		}
		else if (y == (src.rows - 1))
		{
			prev_src_row = src.ptr<float>(y - 1);
			next_src_row = src.ptr<float>(y);

			for (x = 0; x < src.cols; x++)
			{
				if (x == 0)
					corner_value_y[1][x] = src_row[x] * 3 / 4 + src_row[x + 1] / 4;
				else if (x == (src.cols - 1))
					corner_value_y[1][x] = src_row[x] * 3 / 4 + src_row[x - 1] / 4;
				else
					corner_value_y[1][x] = src_row[x - 1] / 4 + src_row[x] / 2 + src_row[x + 1] / 4;
			}
		}
		else
		{
			prev_src_row = src.ptr<float>(y - 1);
			next_src_row = src.ptr<float>(y + 1);
		}

		for (x = 0; x < src.cols; x++)
		{
			if (x == 0)
			{
				dst_row[x] = prev_src_row[x] * filter[0] + prev_src_row[x] * filter[1] + prev_src_row[x + 1] * filter[2]
					+ src_row[x] * filter[3] + src_row[x] * filter[4] + src_row[x + 1] * filter[5]
					+ next_src_row[x] * filter[6] + next_src_row[x] * filter[7] + next_src_row[x + 1] * filter[8];

				if (!y)
					corner_value_x[0][y] = src_row[x] * 3 / 4 + next_src_row[x] / 4;
				else if (y == src.rows - 1)
					corner_value_x[0][y] = src_row[x] * 3 / 4 + prev_src_row[x] / 4;
				else
					corner_value_x[0][y] = prev_src_row[x] / 4 + src_row[x] / 2 + next_src_row[x] / 4;
			}
			else if (x == (src.cols - 1))
			{
				dst_row[x] = prev_src_row[x - 1] * filter[0] + prev_src_row[x] * filter[1] + prev_src_row[x] * filter[2]
					+ src_row[x - 1] * filter[3] + src_row[x] * filter[4] + src_row[x] * filter[5]
					+ next_src_row[x - 1] * filter[6] + next_src_row[x] * filter[7] + next_src_row[x] * filter[8];

				if (!y)
					corner_value_x[1][y] = src_row[x] * 3 / 4 + next_src_row[x] / 4;
				else if (y == src.rows - 1)
					corner_value_x[1][y] = src_row[x] * 3 / 4 + prev_src_row[x] / 4;
				else
					corner_value_x[1][y] = prev_src_row[x] / 4 + src_row[x] / 2 + next_src_row[x] / 4;
			}
			else
			{
				dst_row[x] = prev_src_row[x - 1] * filter[0] + prev_src_row[x] * filter[1] + prev_src_row[x + 1] * filter[2]
					+ src_row[x - 1] * filter[3] + src_row[x] * filter[4] + src_row[x + 1] * filter[5]
					+ next_src_row[x - 1] * filter[6] + next_src_row[x] * filter[7] + next_src_row[x + 1] * filter[8];
			}
		}
	}
}

void _GaussianBlur(Mat &src, Mat &dst, Size ksize, double sigmaX)
{
	dst.create(src.rows, src.cols, src.type());
	float filter[9] = { 1. / 16, 2. / 16, 1. / 16, 2. / 16, 4. / 16, 2. / 16, 1. / 16, 2. / 16, 1. / 16 };
	//float filter[9] = {0.0751, 0.1238, 0.0751, 0.1238, 0.2042, 0.1238, 0.0751, 0.1238, 0.0751};

	for (int y = 0; y < src.rows; y++)
	{
		float *src_row = src.ptr<float>(y);
		float *dst_row = dst.ptr<float>(y);
		float *prev_src_row;
		float *next_src_row;

		if (y == 0)
		{
			prev_src_row = src.ptr<float>(y);
			next_src_row = src.ptr<float>(y + 1);
		}
		else if (y == (src.rows - 1))
		{
			prev_src_row = src.ptr<float>(y - 1);
			next_src_row = src.ptr<float>(y);
		}
		else
		{
			prev_src_row = src.ptr<float>(y - 1);
			next_src_row = src.ptr<float>(y + 1);
		}

		for (int x = 0; x < src.cols; x++)
		{
			if (x == 0)
			{
				dst_row[x] = prev_src_row[x] * filter[0] + prev_src_row[x] * filter[1] + prev_src_row[x + 1] * filter[2]
					+ src_row[x] * filter[3] + src_row[x] * filter[4] + src_row[x + 1] * filter[5]
					+ next_src_row[x] * filter[6] + next_src_row[x] * filter[7] + next_src_row[x + 1] * filter[8];
			}
			else if (x == (src.cols - 1))
			{
				dst_row[x] = prev_src_row[x - 1] * filter[0] + prev_src_row[x] * filter[1] + prev_src_row[x] * filter[2]
					+ src_row[x - 1] * filter[3] + src_row[x] * filter[4] + src_row[x] * filter[5]
					+ next_src_row[x - 1] * filter[6] + next_src_row[x] * filter[7] + next_src_row[x] * filter[8];
			}
			else
			{
				dst_row[x] = prev_src_row[x - 1] * filter[0] + prev_src_row[x] * filter[1] + prev_src_row[x + 1] * filter[2]
					+ src_row[x - 1] * filter[3] + src_row[x] * filter[4] + src_row[x + 1] * filter[5]
					+ next_src_row[x - 1] * filter[6] + next_src_row[x] * filter[7] + next_src_row[x + 1] * filter[8];
			}
		}
	}
}

void _resize(Mat &src, Mat &dst, Size dsize, double fx, double fy, int interpolation)
{
	int dst_width, dst_height;
	if (dsize.width == 0)
	{
		dst_width = src.cols * fx;
	}
	else
	{
		dst_width = dsize.width;
	}

	if (dsize.height == 0)
	{
		dst_height = src.rows * fy;
	}
	else
	{
		dst_height = dsize.height;
	}

	Mat local_dst(dst_height, dst_width, src.type());

	if ((src.type() == CV_8UC1) || (src.type() == CV_8UC3))
	{
		_resize_8U(src, local_dst);
	}
	else if ((src.type() == CV_32FC1) || (src.type() == CV_32FC3))
	{
		_resize_32F(src, local_dst);
	}
	else
	{
		printf("�������� �ʴ� �÷������Դϴ�.!!!!!!!!!!!!!!!!");
	}

	dst = local_dst.clone();
}

void _resize_8U(Mat &src, Mat &dst)
{
	uchar* src_data = (uchar *)src.data;
	uchar* dst_data = (uchar *)dst.data;

	float tx, ty;
	int x, y;
	float dx, dy, sx, sy;
	int a, b, c, d;

	if (dst.cols <= src.cols)
	{
		tx = (float)(src.cols) / dst.cols;
		sx = (tx - 1) / 2.0;
	}
	else
	{
		tx = (float)(src.cols - 1) / (dst.cols - 1);
		sx = 0;
	}

	if (dst.rows <= src.rows)
	{
		ty = (float)(src.rows) / dst.rows;
		sy = (ty - 1) / 2.0;
	}
	else
	{
		ty = (float)(src.rows - 1) / (dst.rows - 1);
		sy = 0;
	}

	for (int i = 0; i < dst.rows; i++)
	{
		for (int j = 0; j < dst.cols; j++)
		{
			x = (int)(tx*j + sx);
			y = (int)(ty*i + sy);

			dx = tx*j + sx - x;
			dy = ty*i + sy - y;

			a = y*src.step1() + x * src.channels();
			b = y*src.step1() + (x + 1) *src.channels();
			c = (y + 1)*src.step1() + x * src.channels();
			d = (y + 1)*src.step1() + (x + 1)*src.channels();

			for (int k = 0; k < src.channels(); k++)
			{
				float a_ = (float)src_data[a + k] * (1 - dx)*(1 - dy);
				float b_ = dx == 0 ? 0 : (float)src_data[b + k] * dx*(1 - dy);
				float c_ = dy == 0 ? 0 : (float)src_data[c + k] * (1 - dx)*dy;
				float d_ = (dx == 0 || dy == 0) ? 0 : (float)src_data[d + k] * dx*dy;
				float sum = a_ + b_ + c_ + d_ + 0.5;
				dst_data[i*dst.step1() + j*dst.channels() + k] = saturate_cast<uchar>(sum);
			}
		}
	}
}

void _resize_2x_HW(Mat &src, Mat &dst)
{
	int i, j;

	if (!dst.empty())
		dst.release();

	dst = Mat::zeros(src.rows * 2, src.cols * 2, src.type());

	Mat tmp = Mat::zeros(src.rows, dst.cols, CV_32FC3);

	for (i = 0; i < src.rows; i++)
	{
		int y[2] = { 0, 0 };
		int cr[2] = { 0, 0 };
		int cb[2] = { 0, 0 };
		bool idx = false;

		for (j = 0; j < src.cols; j++)
		{
			if (!j)
			{
				y[idx] = src.at<Vec3b>(i, j)[0];
				cr[idx] = src.at<Vec3b>(i, j)[1];
				cb[idx] = src.at<Vec3b>(i, j)[2];

				tmp.at<Vec3f>(i, j)[0] = y[idx];
				tmp.at<Vec3f>(i, j)[1] = cr[idx];
				tmp.at<Vec3f>(i, j)[2] = cb[idx];
			}
			else
			{
				y[idx] = src.at<Vec3b>(i, j)[0];
				cr[idx] = src.at<Vec3b>(i, j)[1];
				cb[idx] = src.at<Vec3b>(i, j)[2];

				tmp.at<Vec3f>(i, j * 2)[0] = y[idx];
				tmp.at<Vec3f>(i, j * 2)[1] = cr[idx];
				tmp.at<Vec3f>(i, j * 2)[2] = cb[idx];

				float y0 = (float)(y[0] + y[1]) / 2.0;
				float cr0 = (float)(cr[0] + cr[1]) / 2.0;
				float cb0 = (float)(cb[0] + cb[1]) / 2.0;

				tmp.at<Vec3f>(i, j * 2 - 1)[0] = y0;
				tmp.at<Vec3f>(i, j * 2 - 1)[1] = cr0;
				tmp.at<Vec3f>(i, j * 2 - 1)[2] = cb0;
			}

			idx = !idx;
		}

		tmp.at<Vec3f>(i, j * 2 - 1)[0] = y[!idx];
		tmp.at<Vec3f>(i, j * 2 - 1)[1] = cr[!idx];
		tmp.at<Vec3f>(i, j * 2 - 1)[2] = cb[!idx];
	}

	for (i = 0; i < dst.cols; i++)
	{
		float y[2] = { 0, 0 };
		float cr[2] = { 0, 0 };
		float cb[2] = { 0, 0 };
		bool idx = false;

		for (j = 0; j < src.rows; j++)
		{
			if (!j)
			{
				y[idx] = tmp.at<Vec3f>(j, i)[0];
				cr[idx] = tmp.at<Vec3f>(j, i)[1];
				cb[idx] = tmp.at<Vec3f>(j, i)[2];

				dst.at<Vec3b>(j, i)[0] = y[idx] - (int)y[idx] >= 0.5 ? y[idx] + 1 : y[idx];
				dst.at<Vec3b>(j, i)[1] = cr[idx] - (int)cr[idx] >= 0.5 ? cr[idx] + 1 : cr[idx];
				dst.at<Vec3b>(j, i)[2] = cb[idx] - (int)cb[idx] >= 0.5 ? cb[idx] + 1 : cb[idx];
			}
			else
			{
				y[idx] = tmp.at<Vec3f>(j, i)[0];
				cr[idx] = tmp.at<Vec3f>(j, i)[1];
				cb[idx] = tmp.at<Vec3f>(j, i)[2];

				dst.at<Vec3b>(j * 2, i)[0] = y[idx] - (int)y[idx] >= 0.5 ? y[idx] + 1 : y[idx];
				dst.at<Vec3b>(j * 2, i)[1] = cr[idx] - (int)cr[idx] >= 0.5 ? cr[idx] + 1 : cr[idx];
				dst.at<Vec3b>(j * 2, i)[2] = cb[idx] - (int)cb[idx] >= 0.5 ? cb[idx] + 1 : cb[idx];

				float y0 = (y[0] + y[1]) / 2;
				float cr0 = (cr[0] + cr[1]) / 2;
				float cb0 = (cb[0] + cb[1]) / 2;

				dst.at<Vec3b>(j * 2 - 1, i)[0] = y0 - (int)y0 >= 0.5 ? y0 + 1 : y0;
				dst.at<Vec3b>(j * 2 - 1, i)[1] = cr0 - (int)cr0 >= 0.5 ? cr0 + 1 : cr0;
				dst.at<Vec3b>(j * 2 - 1, i)[2] = cb0 - (int)cb0 >= 0.5 ? cb0 + 1 : cb0;
			}

			idx = !idx;
		}

		idx = !idx;

		dst.at<Vec3b>(j * 2 - 1, i)[0] = y[idx] - (int)y[idx] >= 0.5 ? y[idx] + 1 : y[idx];
		dst.at<Vec3b>(j * 2 - 1, i)[1] = cr[idx] - (int)cr[idx] >= 0.5 ? cr[idx] + 1 : cr[idx];
		dst.at<Vec3b>(j * 2 - 1, i)[2] = cb[idx] - (int)cb[idx] >= 0.5 ? cb[idx] + 1 : cb[idx];
	}
}

void _resize_8U_2x_HW(Mat &src, Mat &dst)
{
	uchar* src_data = (uchar *)src.data;
	uchar* dst_data = (uchar *)dst.data;

	float tx, ty;
	int x, y;
	float dx, dy;
	int a, b, c, d;

	tx = (float)(src.cols) / (dst.cols);
	ty = (float)(src.rows) / (dst.rows);

	float sum;
	for (int i = 0; i < dst.rows; i++)
	{
		for (int j = 0; j < dst.cols; j++)
		{
			x = (int)(tx*j);
			y = (int)(ty*i);

			dx = tx*j - x;
			dy = ty*i - y;
			a = y*src.step1() + x * src.channels();
			b = y*src.step1() + (x + 1) * src.channels();
			c = (y + 1)*src.step1() + x * src.channels();
			d = (y + 1)*src.step1() + (x + 1) * src.channels();

			if ((x >= (src.cols - 1)) && (y >= (src.rows - 1)))
			{
				for (int k = 0; k < src.channels(); k++)
				{
					sum = (float)src_data[a + k] + 0.5;
					dst_data[i*dst.step1() + j*dst.channels() + k] = saturate_cast<uchar>(sum);
				}
			}
			else if (x >= (src.cols - 1))
			{
				for (int k = 0; k < src.channels(); k++)
				{
					sum = (float)src_data[a + k] * (1 - dy) + (float)src_data[c + k] * dy + 0.5;
					dst_data[i*dst.step1() + j*dst.channels() + k] = saturate_cast<uchar>(sum);
				}
			}
			else if (y >= (src.rows - 1))
			{
				for (int k = 0; k < src.channels(); k++)
				{
					sum = (float)src_data[a + k] * (1 - dx) + (float)src_data[b + k] * dx + 0.5;
					dst_data[i*dst.step1() + j*dst.channels() + k] = saturate_cast<uchar>(sum);
				}
			}
			else
			{
				for (int k = 0; k < src.channels(); k++)
				{
					sum = (float)src_data[a + k] * (1 - dx)*(1 - dy) + (float)src_data[b + k] * dx*(1 - dy) + (float)src_data[c + k] * (1 - dx)*dy + (float)src_data[d + k] * dx*dy + 0.5;
					dst_data[i*dst.step1() + j*dst.channels() + k] = saturate_cast<uchar>(sum);
				}
			}
		}
	}
}

void _resize_32F(Mat &src, Mat &dst)
{
	float* src_data = (float *)src.data;
	float* dst_data = (float *)dst.data;

	float tx, ty;
	int x, y;
	float dx, dy, sx, sy;
	int a, b, c, d;

	if (dst.cols <= src.cols)
	{
		tx = (float)(src.cols) / dst.cols;
		sx = (tx - 1) / 2.0;
	}
	else
	{
		tx = (float)(src.cols - 1) / (dst.cols - 1);
		sx = 0;
	}
	if (dst.rows <= src.rows)
	{
		ty = (float)(src.rows) / dst.rows;
		sy = (ty - 1) / 2.0;
	}
	else
	{
		ty = (float)(src.rows - 1) / (dst.rows - 1);
		sy = 0;
	}

	for (int i = 0; i < dst.rows; i++)
	{
		for (int j = 0; j < dst.cols; j++)
		{
			x = (int)(tx*j + sx);
			y = (int)(ty*i + sy);

			dx = tx*j + sx - x;
			dy = ty*i + sy - y;

			a = y*src.step1() + x * src.channels();
			b = y*src.step1() + (x + 1) *src.channels();
			c = (y + 1)*src.step1() + x * src.channels();
			d = (y + 1)*src.step1() + (x + 1)*src.channels();

			for (int k = 0; k < src.channels(); k++)
			{
				float a_ = (float)src_data[a + k] * (1 - dx)*(1 - dy);
				float b_ = dx == 0 ? 0 : (float)src_data[b + k] * dx*(1 - dy);
				float c_ = dy == 0 ? 0 : (float)src_data[c + k] * (1 - dx)*dy;
				float d_ = (dx == 0 || dy == 0) ? 0 : (float)src_data[d + k] * dx*dy;
				float sum = a_ + b_ + c_ + d_;
				dst_data[i*dst.step1() + j*dst.channels() + k] = sum;
			}
		}
	}
}

void _local_normalization(Mat *image, int n_channel, int block_size, float min_value, float thresh)
{
	Mat image_tmp(image[0].rows, image[0].cols, CV_32F);

	for (int y = 0; y < image_tmp.rows; y++)
	{
		float *src_row = image[n_channel - 1].ptr<float>(y);
		float *dst_row = image_tmp.ptr<float>(y);
		float *prev_src_row;
		float *next_src_row;

		if (y == 0)
		{
			prev_src_row = image[n_channel - 1].ptr<float>(y);
			next_src_row = image[n_channel - 1].ptr<float>(y + 1);
		}
		else if (y == (image[0].rows - 1))
		{
			prev_src_row = image[n_channel - 1].ptr<float>(y - 1);
			next_src_row = image[n_channel - 1].ptr<float>(y);
		}
		else
		{
			prev_src_row = image[n_channel - 1].ptr<float>(y - 1);
			next_src_row = image[n_channel - 1].ptr<float>(y + 1);
		}

		for (int x = 0; x < image[n_channel - 1].cols; x++)
		{
			if (x == 0)
			{
				dst_row[x] = (prev_src_row[x] + prev_src_row[x] + prev_src_row[x + 1]
					+ src_row[x] + src_row[x] + src_row[x + 1]
					+ next_src_row[x] + next_src_row[x] + next_src_row[x + 1])
					+ min_value;
			}
			else if (x == (image[n_channel - 1].cols - 1))
			{
				dst_row[x] = (prev_src_row[x - 1] + prev_src_row[x] + prev_src_row[x]
					+ src_row[x - 1] + src_row[x] + src_row[x]
					+ next_src_row[x - 1] + next_src_row[x] + next_src_row[x])
					+ min_value;
			}
			else
			{
				dst_row[x] = (prev_src_row[x - 1] + prev_src_row[x] + prev_src_row[x + 1]
					+ src_row[x - 1] + src_row[x] + src_row[x + 1]
					+ next_src_row[x - 1] + next_src_row[x] + next_src_row[x + 1])
					+ min_value;
			}
		}
	}

	for (int k = 0; k < n_channel; k++)
	{
		for (int y = 0; y < image_tmp.rows; y++)
		{
			float *src_row = image[k].ptr<float>(y);
			float *dst_row = image_tmp.ptr<float>(y);

			for (int x = 0; x < image[k].cols; x++)
			{
				float val = src_row[x] / dst_row[x];
				int val2 = val * (1 << 19);

				src_row[x] = (float)val2 / (float)(1 << 19);

			}
		}
	}
}

void _global_normalization(Mat *ch_image, int n_channel, float global_value)
{
	for (int i = 0; i < n_channel; i++)
	{
		ch_image[i] /= global_value;
	}
}

void _color_conversion(Mat &image, Mat &conv_image, bool b_train)
{
	if (b_train == true)
	{
#if YCBCR444
		_rgb_to_yc(image, conv_image);
#if YCBCR422
		Mat yc_image422(image.rows, image.cols, CV_8UC3);
		yc444_to_yc422(conv_image, yc_image422);
		yc422_interpolation(yc_image422, conv_image);
		//conv_image = yc_image422.clone();
		//yc422_to_yc444(yc_image422, image);
#endif

#else
		rgb_to_luv(image, conv_image);
#endif
	}
	else
	{
#if YCBCR444
		_rgb_to_yc(image, conv_image);
#if YCBCR422
		Mat yc_image422(image.rows, image.cols, CV_8UC3);
		yc444_to_yc422(conv_image, yc_image422);
		yc422_interpolation(yc_image422, conv_image);
		//conv_image = yc_image422.clone();
		//yc422_to_yc444(yc_image422, image);
#endif

#else
		rgb_to_luv(image, conv_image);
#endif
	}
}

void feature_cutting_precision(CvMat *feature, int prec_leng, int s_ch, int e_ch)
{
	int n_feat_per_ch = N_HOR_CELL * N_VER_CELL;
	int multiplier = pow(2, prec_leng);

	for (int ch = s_ch; ch <= e_ch; ch++)
	{
		for (int f_id = 0; f_id < n_feat_per_ch; f_id++)
		{
			//printf("1) feature = %f\n", feature->data.fl[(ch*n_feat_per_ch)+f_id]);
			int i_feature = feature->data.fl[(ch*n_feat_per_ch) + f_id] * multiplier;
			feature->data.fl[(ch*n_feat_per_ch) + f_id] = (float)i_feature / multiplier;
			//printf("2) i_feature = %d, feature = %f\n", i_feature, feature->data.fl[(ch*n_feat_per_ch)+f_id]);
		}
	}
}

void channel_cutting_precision(Mat *ch_image, st_feature &feature, int prec_leng)
{
	int n_channel = feature.n_channel;
	int multiplier = pow(2, prec_leng);
	for (int ch = 0; ch < n_channel; ch++)
	{
		for (int y = 0; y < ch_image[ch].rows; y++)
		{
			float *src_ptr = ch_image[ch].ptr<float>(y);
			for (int x = 0; x < ch_image[ch].cols; x++)
			{
				//printf("1) feature = %f\n", src_ptr[x]);

				int i_feature = src_ptr[x] * multiplier;
				src_ptr[x] = (float)i_feature / multiplier;

				//printf("2) i_feature = %d, feature = %f\n", i_feature, src_ptr[x]);
			}
		}
	}
}

void yc422_interpolation(Mat &in, Mat &out)
{
	out = in.clone();

	for (int i = 0; i < in.rows; i++)
	{
		for (int j = 0; j < in.cols; j++)
		{
			if (j > 1)
			{
				if (!(j % 2))
				{
					out.at<Vec3b>(i, j - 1)[2] = (int)((float)(in.at<Vec3b>(i, j)[2] + in.at<Vec3b>(i, j - 2)[2]) / 2 + 0.5);
				}
				else
				{
					out.at<Vec3b>(i, j - 1)[1] = (int)((float)(in.at<Vec3b>(i, j)[1] + in.at<Vec3b>(i, j - 2)[1]) / 2 + 0.5);
				}
			}
		}
	}
}