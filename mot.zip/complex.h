#include <opencv2/core/mat.hpp>
using namespace cv;


typedef struct st_
{
	double Re;
	double Im;
} dg_complex;

#ifndef PI
#define PI	3.14159265358979323846264338327950288
#endif

void fft(dg_complex *v, int n);
void ifft(dg_complex *v, int n);
void complex_add(dg_complex a, dg_complex b, dg_complex &c);
void complex_subtraction(dg_complex a, dg_complex b, dg_complex &c);
void complex_multiplier(dg_complex a, dg_complex b, dg_complex &c);
void complex_division(dg_complex a, dg_complex b, dg_complex &c);
void complex_conjugate(dg_complex a, dg_complex &b);
void complex_add_vector(dg_complex *a, dg_complex *b, int n_point, dg_complex *c);
void complex_multiplier_vector(dg_complex *a, dg_complex *b, int n_point, dg_complex *c);
void complex_division_vector(dg_complex *a, dg_complex *b, int n_point, dg_complex *c);
void complex_conjugate_vector(dg_complex *a, int n_point, dg_complex *b);
void mat_to_complex(cv::Mat &image, dg_complex *c_x);
void complex_to_mat(dg_complex *c_x, int n_point, cv::Mat &image);

void _fft(dg_complex *x, int n, int flag);
void _fft2D(dg_complex *x, int n1, int n2, int flag);
void _fft3D(dg_complex *x, int n1, int n2, int n3, int flag);
