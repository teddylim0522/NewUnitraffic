#pragma once
#include "common.h" // #include header about opencv
#include "CCamPosition.h"

#ifdef XYCOOR_MODE
struct sIOUbox
{
	float total;
	float left;
	float right;
	int side; //[0]default(outsize of roi), [1]left, [2]right
};
#endif

class CRegion
{
public:
	int m_nSelectedPoint;

	cv::Point m_ptRoad[MAX_PTROAD]; //ITS
	float m_fa, m_fc, m_fd;
	float m_fRYbot, m_fRYcen, m_fRYtop;

	float m_fPXleft, m_fPXcen, m_fPXright; //distance from pole to road side
	float m_faX, m_fcX, m_fdX;
	//cv::Point m_ptPoleOrigin;
	int m_nPoleLineHei;


	cv::Point m_ptLine[MAX_PTLINE]; //2018.08.08
						 // line point on image
						 // L1 L6 M0 R8 R4
						 // L3 L7 M2 R9 R5

	                     // ITS Mode
	                     // L--T[01]             C--T[0]       R-T[04]
	                     // 200L[10]	                       200R[11]
	                     // 100L[m_ptRoad[15]]                 100R[m_ptRoad[16]] //Only use ITS Mode, using m_ptRoad 
	                     // L--B[03]             C--B[02]      R--B[5]

	cv::Point m_ptROI[4];  //20190213 hai Parking
						 // ROI point on image
						 // 0  1
						 // 2  3

	cv::Point m_ptAREA[7]; //20190423 hai Daewoo
						 // 0 1 2
						 // 4 5 6 7

	cv::Rect m_rtSignalArea[3];// [0]Red, [1]Green, [2]Yellow

	cv::Rect m_rtLeftRedSignalArea;

	float a02, b02, c02; // wrong lane violation 2018.08.08
	float a13, b13, c13; // wrong lane violation 2018.08.08
	float a45, b45, c45; // wrong lane violation 2018.08.08
	float a67, b67, c67; // wrong lane violation 2018.08.08
	float a89, b89, c89; // wrong lane violation 2018.08.08

						 //20190213 hai Parking
	float aO, bO, cO;	 //0-2 line
	float aI, bI, cI;	 //1-3 line

	// simple_mode == 1
	cv::Point m_ptXspeed[5];
	float aX_coord, bX_coord, cX_coord; // to tranfer Image X to Road X

	//X and Y calculation
	cv::Point m_ptVanish[7];
	cv::Point m_ptVanishX, m_ptVanishY;
	bool m_bUseYparabol, m_bUseXparabol;

	float aR_wL, bR_wL, cR_wL;
	float aR_wR, bR_wR, cR_wR;

	float aR_hT, bR_hT, cR_hT;
	float aR_hB, bR_hB, cR_hB;

	float aH, bH, cH; // linear euqation for Y distance determination
	float aW, bW, cW; // linear euqation for X distance determination
	float fLoopLength;
	float fLoopAngle;

	int nHumanCountCheck[MAX_TRACK];

	//KAI POC
	cv::Rect m_rtKAIWorkPlace[2]; //2 ROIs

public:

	CRegion();
	~CRegion();

	void CRegion_setLine(cv::Point* _ptLine);
	cv::Point* CRegion_getLine();

	void CRegion_setROI(cv::Point* _ptROI);
	cv::Point* CRegion_getROI();

	//20190423 Daewoo
	void CRegion_setAREA(cv::Point* _ptAREA);
	cv::Point* CRegion_getAREA();

	int CRegion_getXwithIndex(int mode, int _index);
	int CRegion_getYwithIndex(int mode, int _index);
	cv::Point CRegion_setPoint(int mode, int _index);// mode[1] : setPoint with Line, mode[2] : setPoint with ROI

	void CRegion_setRtSignalArea(int index, cv::Rect _rtRedSignalArea);
	cv::Rect CRegion_getRtSignalArea(int index);

	void CRegion_setRtLeftRedSignalArea(cv::Rect _rtLeftRedSignalArea);
	cv::Rect CRegion_getRtLeftRedSignalArea();

	void CRegion_update_line_points(int nPt, int nCameraIndex);
	void CRegion_update_ROI_points(int nPt, int nCameraIndex);
	void CRegion_update_AREA_points(int nPt, int nCameraIndex); //20190423 Daewoo
	void CRegion_update_Signal_points(int index, int nCameraIndex); //20190423 Daewoo
	void CRegion_update_LeftRedSignal_points(int nCameraIndex); //20190423 Daewoo

	void CRegion_copy(int mode, cv::Point* _point);

	void CRegion_calculate_line_params();
	

	int CRegion_AccidentCheckArea(int _mode, int _Y);
	//int CRegion_LaneArea(int _Y);
	//float CRegion_RadarArea(int nLine, float _Y);
	int CRegion_get_Lane_Xvalue(int nLine, int _Y);
	//int CRegion_get_Lane_Yvalue(int nLine, int nMode, int _X);

	int CRegion_Object_IsinArea(int nPtX, int nPtY, int nBoxWidth); // 2018.11.09 hai
	int CRegion_Object_outside_LeftRight(int nResImg_W, int nPtX, int nPtY); //20200128 BacNinh
	int CRegion_line_touch_forLaneVio_topbot(int nPtY, int nPtHeight, int line, bool bTop);
	int CRegion_line_touch_forLaneVio_side(int nPtX1, int nPtX2, int nPtY);
	bool CRegion_line_touch_save_LPImage(int nPtY, int nPtHeight, int line);

	bool CRegion_line_touch_count(cv::Rect detectBox, cv::Point ptCountLine[2], int nTrackID);
	bool CRegion_line_touch_forLightVio_start(int nPtStartY, int nPtStopY, int line);
	bool CRegion_line_touch_forLightVio_stop(int nPtStopY, int nPtHeight, int line);


	//ITS
	void CRegion_setRoad(cv::Point* _ptRoad);
	void CRegion_update_road_points(int nPt, int nCameraIndex);
	cv::Point* CRegion_getRoad();

	// simple_mode == 1
	void CRegion_set_Xspeed_points(cv::Point* _ptXspeed);
	void CRegion_update_Xspeed_points(int nCameraIndex);
	cv::Point* CRegion_get_Xspeed_points();
	void CRegion_calculate_XspeedROI_params(CCamPosition* pCamPosition, int nHeight, float fXRightMid, float fXRightLeft);
	void CRegion_get_distance_simple(CCamPosition* pCamPosition, int nHeight, cv::Point ptCrt, float& fDistanceY, float& fDistanceX);

	//X and Y calculation
	void CRegion_setVanishing(cv::Point* _ptVanish);
	void CRegion_update_vanish_points(int nCameraIndex);
	cv::Point* CRegion_getVanish();

	void CRegion_calculate_tranformation(int nDisplayHei, int nDisplayWid, float fStartYBot, float fStartYCen, float fStartYTop, float fPoleXleft, float fPoleXcen, float fPoleXright);
	void CRegion_get_XYdistance(int nHeight, int nPtY, int nPtX, float& fDistanceY, float& fDistanceX);
	float CRegion_determinantOfMatrix(float mat[3][3]);
	void CRegion_get_TranformCoeffs(int nCoord, float coeff[3][4]);
	void CRegion_calculate_vanishing_params(int nDisplayHei, int nDisplayWid);
	float CRegion_get_Xdistance(int nPtX, int nPtY);
	float CRegion_get_Ydistance(int nHeight, int nPtX, int nPtY);
	float CRegion_get_XTop(int nPtBotX, int nPtBotY, int nPtTopY);
	void CRegion_get_Angle_Width(int nPtLeftX, int nPtCenX, int nPtRightX, int nPtY, float &fCosAngle, float &fTotalWidth);

	//KAI POC
	void CRegion_setRtKAIWorkPlace(int index, cv::Rect _rtArea);
	cv::Rect CRegion_getRtKAIWorkPlace(int index);
	void CRegion_update_KAIWorkPlace(int index, int nCameraIndex);
	
#if ITS_MODE ==1
    sIOUbox CRegion_getIOU_BOXwithMask(cv::Rect box, cv::Mat& total, cv::Mat& left, cv::Mat& right);//20210330 skkang
#endif  

#if VDS_MODE == 1					// sRoadbox points
	int l_box_max;					// 0 ------------ 1
	sRoadbox l_box[ROAD_LINE_MAX];	// |              |
	int r_box_max;					// |			  |
	sRoadbox r_box[ROAD_LINE_MAX];  // 2 ------------ 3
	void CRegion_copy_raodbox(int lBoxMax, sRoadbox* leftbox, int rBoxMax, sRoadbox* rightbox);
	void CRegion_update_roadbox(int nPt, int nCameraIndex, eRoadboxPoint point, int side); //side : [0] is left

	int m_startCnt[2][ROAD_LINE_MAX];
	int m_EndCnt[2][ROAD_LINE_MAX];
	int CRegion_roadbox_determine(st_det_mot_param *param, int nTrack, cv::Rect rtResBox, cv::Mat& image, unsigned long long timestamp);
#endif
};