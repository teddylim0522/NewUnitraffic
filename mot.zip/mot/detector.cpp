﻿#include "darknet.h"
#include "argv.h"
#include "common.h"



static int coco_ids[] = { 1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,27,28,31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,70,72,73,74,75,76,77,78,79,80,81,82,84,85,86,87,88,89,90 };
void mosaic_draw(IplImage* frame, CvRect _rect, int mb)
{
	int w_point = 0, h_point = 0, y_start = 0, x_start = 0;
	int r = 0, g = 0, b = 0;
	int w_p, h_p;
	int nCnt;
	for (int i = 0; i < ceil(_rect.height) / mb; i++)
	{
		for (int j = 0; j < ceil(_rect.width) / mb; j++)
		{
			nCnt = 0;
			r = 0; g = 0; b = 0;

			x_start = _rect.x + j * mb;
			y_start = _rect.y + i * mb;

			for (int mb_y = y_start; mb_y < y_start + mb; mb_y++)
			{
				for (int mb_x = x_start; mb_x < x_start + mb; mb_x++)
				{
					CvScalar color;
					w_p = mb_x;
					h_p = mb_y;

					if (mb_x >= frame->width)
					{
						w_p = frame->width - 1;
					}
					if (mb_y >= frame->height)
					{
						h_p = frame->height - 1;
					}
					color = cvGet2D(frame, h_p, w_p);
					b += color.val[0];
					g += color.val[1];
					r += color.val[2];
					nCnt++;
				}
			}
			b /= nCnt;
			g /= nCnt;
			r /= nCnt;

			cvRectangleR(frame, cvRect(x_start, y_start, mb, mb), cvScalar(b, g, r, 0), CV_FILLED, 1, 0);
		}
	}
}

void train_detector(char *datacfg, char *cfgfile, char *weightfile, int *gpus, int ngpus, int clear, int train_test)
{
	srand((unsigned int)time(NULL));

	list *options = read_data_cfg(datacfg);
	char *train_images = option_find_str(options, "train", "");
	char *backup_dir = "D:/darknet/weights";

	char *base = basecfg(cfgfile);
	printf("%s\n", base);

	network *nets = calloc(ngpus, sizeof(network));

	int seed = rand();
	for (int i = 0; i < ngpus; ++i)
	{
		srand(seed);

#ifdef GPU
		cuda_set_device(gpus[i]);
#endif

		nets[i] = load_network(cfgfile, weightfile, clear);
		nets[i].learning_rate *= ngpus;
	}

	char cfgfile_test[CHAR_LENGTH];
	network net_test;
	if (train_test)
	{
		find_replace(cfgfile, ".cfg", "_test.cfg", cfgfile_test);
		net_test = parse_network_cfg(cfgfile_test, 0, 0);
	}

	network net = nets[0];

	int imgs = net.batch * net.subdivisions * ngpus;
	printf("Learning Rate: %g, Momentum: %g, Decay: %g\n", net.learning_rate, net.momentum, net.decay);
	data train, buffer;

	layer l = net.layers[net.n - 1];

	int classes = l.classes;
	float jitter = l.jitter;

	list *plist = get_paths(train_images);
	char **paths = (char **)list_to_array(plist);

	load_args args = get_base_args(net);
	args.coords = l.coords;
	args.paths = paths;
	args.n = imgs;
	args.m = plist->size;
	printf("%d\n", args.m);
	args.classes = classes;
	args.jitter = jitter;
	args.num_boxes = l.max_boxes;
	args.d = &buffer;
	args.type = DETECTION_DATA;
	args.threads = TRAIN_DETECTOR_THREADS;

	pthread_t load_thread = load_data(args);
	clock_t time;
	int count = 0;
	int save_cnt = -1;
	float avg_loss = -1;
	while (get_current_batch(net) < net.max_batches + ngpus)
	{
		if (l.random && count++ % 10 == 0)
		{
			printf("Resizing\n");
			int dim = (rand() % 10 + 10) * 32;
			if (get_current_batch(net) + 200 > net.max_batches)
				dim = 608;
			printf("%d\n", dim);
			args.w = dim;
			args.h = dim;

			pthread_join(load_thread, 0);
			train = buffer;
			free_data(train);
			load_thread = load_data(args);

			for (int i = 0; i < ngpus; ++i)
			{
				resize_network(nets + i, dim, dim);
			}
			net = nets[0];
		}

		time = clock();
		pthread_join(load_thread, 0);
		train = buffer;
		load_thread = load_data(args);

#if 0
		for (int k = 0; k < l.max_boxes; ++k)
		{
			box b = float_to_box(train.y.vals[k], 1);
			if (!b.x)
				break;
			printf("loaded: %f %f %f %f\n", b.x, b.y, b.w, b.h);

			image im = float_to_image(net.w, net.h, 3, train.X.vals[k]);
			draw_bbox(im, b, 3, 1, 0, 0);
			show_image(im, "roi");
			cvWaitKey(0);
			free_image(im);
		}
#endif

		printf("Loaded: %lf seconds\n", sec(clock() - time));

		time = clock();
		float loss = 0;

#ifdef GPU
		if (ngpus == 1)
		{
			loss = train_network(net, train);
		}
		else
		{
			loss = train_networks(nets, ngpus, train, 4);
		}
#else
		loss = train_network(net, train);
#endif

		if (avg_loss < 0)
			avg_loss = loss;
		avg_loss = avg_loss * .9 + loss * .1;

		int i = get_current_batch(net);
		printf("%ld: %f, %f avg, %f rate, %lf seconds, %d images\n", get_current_batch(net), loss, avg_loss, get_current_rate(net), sec(clock() - time), i*imgs);

		if (save_cnt == -1)
			save_cnt = i / 1000;

		if (i / 1000 > save_cnt)
		{
			i /= 1000;
			i *= 1000;
			save_cnt++;

#ifdef GPU
			if (ngpus != 1)
				sync_nets(nets, ngpus, 0);
#endif

			char buff[256];
			sprintf(buff, "%s/%s", backup_dir, base);
			mkdir(buff);

			sprintf(buff, "%s/%s_%d.weights", buff, base, i);
			save_weights(net, buff);

			if (train_test)
			{
				test_detector(datacfg, cfgfile_test, net_test, buff, 0, 0, 0, 0, 0);
			}
		}
		free_data(train);
	}

#ifdef GPU
	if (ngpus != 1)
		sync_nets(nets, ngpus, 0);
#endif

	char buff[256];
	sprintf(buff, "%s/%s/%s_%d.weights", backup_dir, base, base, net.max_batches);
	save_weights(net, buff);
}

int write_log(char* strLog, int nCameraIndex)
{
	char makePath[260];
	sprintf(makePath, "D:\\DSME\\CommLog");

	//CommLog
	char fileName[260];
	sprintf(fileName, "%s\\DSMELog_%02d.log", makePath, nCameraIndex);

	FILE *log;
	if (fopen_s(&log, fileName, "at") == 0)
	{
		fprintf_s(log, "%s\n", strLog);
		fclose(log);
	}

	return 0;
}

int make_det_mot_param(st_det_mot_param *param, int nCamIndex)
{
	//write_log("make_det_mot_param start", nCamIndex);
	char *datacfg = param->data_full_name;
	char *cfgfile = param->cfg_full_name;
	char *weightfile = param->weight_full_name;

	cuda_set_device(param->gpu_id);

	//write_log("make_det_mot_param cuda_set_device", nCamIndex);

	param->net = parse_network_cfg(cfgfile, 1, param->gpu_id);
	//char strLog[260];
	//sprintf(strLog, "parse_network_cfg %d %d", param->gpu_id, param->net.gpu_index);
	//write_log(strLog, nCamIndex);

	load_weights(&param->net, weightfile);

	//write_log("make_det_mot_param load_weights", nCamIndex);
	list *options = read_data_cfg(datacfg);
	char *name_list = option_find_str(options, "names", "");
	param->names = get_labels(name_list);
	free_list(options);

	//write_log("make_det_mot_param read_data_cfg", nCamIndex);
	//param->alphabet = load_alphabet();

	param->l = param->net.layers[param->net.n - 1];
	param->boxes = calloc(param->l.w*param->l.h*param->l.n, sizeof(box));
	param->probs = calloc(param->l.w*param->l.h*param->l.n, sizeof(float *));
	for (int j = 0; j < param->l.w*param->l.h*param->l.n; ++j)
		param->probs[j] = calloc(param->l.classes, sizeof(float *));

	param->mot_info = calloc(1, sizeof(st_mot_info));
	param->mot_info->object_flow_number = calloc(param->net.layers[param->net.n - 1].classes, sizeof(int));
	//param->mot_info->object_flow_number_Daewoo = calloc(param->net.layers[param->net.n - 1].classes, sizeof(int)); //20190423 hai Daewoo
	param->mot_info->object_flow_total = calloc(param->net.layers[param->net.n - 1].classes, sizeof(int)); //20190214 hai Status Log
	param->mot_info->object_flow_number_forTopline = calloc(param->net.layers[param->net.n - 1].classes, sizeof(int));//yk 2018.12.03
	param->class_group_id = calloc(param->l.classes, sizeof(int));
	param->vio_head_class = calloc(param->n_vio_head_class, sizeof(int));

	param->mot_info->object_flow_number_out = calloc(param->net.layers[param->net.n - 1].classes, sizeof(int)); //20191211 skkang stats as direction
	param->mot_info->object_flow_total_out = calloc(param->net.layers[param->net.n - 1].classes, sizeof(int)); //20191211 skkang stats as direction

	for (int c = 0; c < MAX_TRACK; c++) {
		param->track_color[c] = cvScalar(rand() % 256, rand() % 256, rand() % 256, rand() % 256);
	}

	//20190222 hai Class color
	for (int c = 0; c <= ACCIDENT_CLASS_ID + 1; c++)
	{
		if (SHOW_AS_SIMPLE)
		{
			if (c == 7 || c == 8 || c == 9)
				param->class_color[c] = cvScalar(0, 128, 32, 0);
			else
				param->class_color[c] = cvScalar(88, 181, 53, 0);//102, 0, 0, 0);// 초록
		}
		else
			param->class_color[c] = cvScalar(rand() % 256, rand() % 256, rand() % 256, rand() % 256);

	}

	//20190222 hai Violation Color B-G-R
	if (SHOW_AS_SIMPLE)
	{
		param->vio_color[BIKE_VIOLATION_CLR] = cvScalar(36, 32, 237, 0);
		param->vio_color[SIGNAL_VIOLATION_CLR] = cvScalar(36, 32, 237, 0);

		param->vio_color[OVER_SPEED_CLR] = cvScalar(36, 32, 237, 0);
		param->vio_color[LOW_SPEED_CLR] = cvScalar(36, 32, 237, 0);
		param->vio_color[LANE_VIOLATION_CLR] = cvScalar(36, 32, 237, 0);
		param->vio_color[ILLEGAL_PARKING_CLR] = cvScalar(32, 127, 237, 0);

		param->vio_color[ACCIDENT_CLR] = cvScalar(36, 32, 237, 0);
		param->vio_color[REVERSE_VIOLATION_CLR] = cvScalar(36, 32, 237, 0);

		param->vio_color[TRACKING_CLR] = cvScalar(238, 238, 0, 0);
	}
	else
	{
		param->vio_color[BIKE_VIOLATION_CLR] = cvScalar(255, 0, 0, 0);
		param->vio_color[SIGNAL_VIOLATION_CLR] = cvScalar(0, 255, 0, 0);

		param->vio_color[OVER_SPEED_CLR] = cvScalar(128, 0, 255, 0);
		param->vio_color[LOW_SPEED_CLR] = cvScalar(0, 128, 255, 0);
		param->vio_color[LANE_VIOLATION_CLR] = cvScalar(255, 0, 128, 255);
		param->vio_color[ILLEGAL_PARKING_CLR] = cvScalar(255, 128, 0, 0);

		param->vio_color[ACCIDENT_CLR] = cvScalar(255, 255, 128, 0);
		param->vio_color[REVERSE_VIOLATION_CLR] = cvScalar(0, 0, 128, 0);

		param->vio_color[TRACKING_CLR] = cvScalar(238, 238, 0, 0);
	}

	param->nms = NMS_IOU;
	//	param->thresh = DETECT_THRESH;

	//	param->fp_count = fopen("inin_count.log", "w");
	//	sprintf(param->fp_count_end_name, "inin_count.end");

	return 1;
}


void free_det_mot_param(st_det_mot_param *param)
{
	if (param)
	{
		free(param->boxes);
		free_ptrs((void **)param->probs, param->l.w*param->l.h*param->l.n);

		if (param->mot_info)
		{
			free(param->mot_info->object_flow_number);
			//free(param->mot_info->object_flow_number_Daewoo); //20190423 hai Daewoo
			free(param->mot_info->object_flow_total); //20190214 hai Status Log
			free(param->mot_info->object_flow_number_forTopline);//yk 2018.12.03

			free(param->mot_info->object_flow_number_out);
			free(param->mot_info->object_flow_total_out);

			free(param->mot_info);

			param->mot_info = NULL;
		}

		free(param->class_group_id);
		free(param->vio_head_class);

		if (param->names)
			free_ptrs((void**)param->names, param->net.layers[param->net.n - 1].classes);
		free_network(param->net);	//20190715 young
		param = NULL;
	}
}

void run_det(image im, st_det_mot_param *param, float *X)
{
	network_predict(param->net, X);
	_get_region_boxes(im, 0, 0, param->l, 1, 1, param->thresh, param->probs, param->boxes);
	//	_do_nms_sort(param->boxes, param->probs, param->l.w*param->l.h*param->l.n, param->l.classes, param->nms);
	_do_group_nms_sort(param);

}

void run_mot(int nCameraIndex, IplImage *frame, st_det_mot_param *param, st_biker_info *biker_info)//hai 2018.12.12
{
	//param->mot_info->n_track_num = tracking_function(frame, param->l.w*param->l.h*param->l.n, param->boxes, param->probs, param->l.classes, param->mot_info, param->sub_box_list);
	param->mot_info->n_track_num = tracking_function(nCameraIndex, frame, param->l.w*param->l.h*param->l.n, param->boxes, param->probs, param->l.classes, param->mot_info, param->sub_box_list, biker_info, param->mot_DataSave, param); //hai 2019.01.14
}

void run_det_mot(int nCameraIndex, IplImage *frame, st_det_mot_param *param, char *strTitle, st_biker_info *biker_info)//hai 2018.12.12
{
	float detection_time = 0, tracking_time = 0, total_time = 0;;
	clock_t detection_time_c, tracking_time_c, total_time_c;
	total_time_c = clock();

	//hai 2018.11.30
	IplImage *disp_image = cvCreateImage(cvGetSize(frame), frame->depth, frame->nChannels);
	cvCopy(frame, disp_image, 0);
	cvCvtColor(frame, frame, CV_RGB2BGR);

	////20190406 young. Fill the top and bottom areas with black.
	//memset(frame->imageData, 0, frame->width * (int)(frame->height * param->top_line / 2) * 3);
	//int nPosition = frame->width * (frame->height - 2) * 3;
	//memset(frame->imageData + nPosition, 0, frame->width * (int)(2 * 3));

	image im = make_image(frame->width, frame->height, 3);
	ipl_into_image(frame, im);

	cvCopy(disp_image, frame, 0);	//20190406 copy back

	//============= making non - detection region ============
	////hai 2018.11.30
	//IplImage *disp_image = cvCreateImage(cvGetSize(frame), frame->depth, frame->nChannels);
	//cvCopy(frame, disp_image, 0);

	//IplImage *detect_image = cvCreateImage(cvGetSize(frame), frame->depth, frame->nChannels); //hai 2018.11.30
	//cvCopy(frame, detect_image, 0);//hai 2018.11.30

	//memset(detect_image->imageData, 0, detect_image->width * (int)(frame->height * param->top_line / 3) * 3);	//yk 2018.12.03

	//cvCvtColor(detect_image, detect_image, CV_RGB2BGR);
	//image im = make_image(detect_image->width, detect_image->height, 3);
	//ipl_into_image(detect_image, im);
	////	image sized = resize_image(im, param->net.w, param->net.h);
	//cvCvtColor(detect_image, detect_image, CV_BGR2RGB);
	//==================================

	float *X = im.data;

	detection_time_c = clock();
	run_det(im, param, X);
	detection_time = sec(clock() - detection_time_c);

	if (param->show_det_on)
	{
		for (int d = 0; d < param->mot_info->n_detect_num; d++)
		{
			cvRectangleR(disp_image, param->mot_info->det_box_info[d].bouding_box, param->track_color[param->mot_info->det_box_info[d].class_id], 2, 1, 0);
		}
	}

	tracking_time_c = clock();
	run_mot(nCameraIndex, frame, param, biker_info);//hai 2018.12.12
	tracking_time = sec(clock() - tracking_time_c);

	// 2018.10... hai
	for (int d = 0; d < param->mot_info->n_detect_num; d++)
	{
		if (param->mot_info->det_box_info[d].bouding_box.width < LIMITED_WIDTH && param->mot_info->det_box_info[d].bouding_box.height < LIMITED_HEIGHT)//indonesia demo
		{
			if (COUNT_MODE_COUNTRY == 2)
			{
				if (param->mot_info->det_box_info[d].class_id == 7 || param->mot_info->det_box_info[d].class_id == 8 || param->mot_info->det_box_info[d].class_id == 9 || param->mot_info->det_box_info[d].class_id == 10 || param->mot_info->det_box_info[d].class_id == 11)
				{
					//cvRectangleR(frame, param->mot_info->det_box_info[d].bouding_box, param->track_color[param->mot_info->det_box_info[d].class_id], 2, 1, 0);
					//cvRectangleR(frame, param->mot_info->det_box_info[d].bouding_box, param->class_color[param->mot_info->det_box_info[d].class_id], 1, 1, 0); //20190222 hai Class color  //20190327
				}
			}
			else
			{
				if (COUNT_MODE_COUNTRY == 3 || COUNT_MODE_COUNTRY == 4)
				{
					if (param->mot_info->det_box_info[d].class_id == 2)
						param->mot_info->det_box_info[d].class_id = 1;

					if (param->mot_info->det_box_info[d].class_id == 7 || param->mot_info->det_box_info[d].class_id == 8 || param->mot_info->det_box_info[d].class_id == 9)
					{
						mosaic_draw(frame, param->mot_info->det_box_info[d].bouding_box, 8);
					}

					if (param->mot_info->det_box_info[d].bouding_box.height >= (frame->height / 5) && COUNT_MODE_COUNTRY == 3) //20190429
						cvRectangleR(frame, param->mot_info->det_box_info[d].bouding_box, param->class_color[TRUCK_CLASS_ID], 1, 1, 0);
					else
						cvRectangleR(frame, param->mot_info->det_box_info[d].bouding_box, param->class_color[param->mot_info->det_box_info[d].class_id], 1, 1, 0);
				}
				else if (param->mot_info->det_box_info[d].class_id == 7 || param->mot_info->det_box_info[d].class_id == 8 || param->mot_info->det_box_info[d].class_id == 9)//|| param->mot_info->det_box_info[d].class_id == 10 || param->mot_info->det_box_info[d].class_id == 11)
				{
					cvRectangleR(frame, param->mot_info->det_box_info[d].bouding_box, param->class_color[param->mot_info->det_box_info[d].class_id], 1, 1, 0); //20190222 hai Class color  //20190327
				}
			}
		}

		if (param->show_det_on)
		{
			if (param->mot_info->det_box_info[d].class_id == 4 || param->mot_info->det_box_info[d].class_id == 5 || param->mot_info->det_box_info[d].class_id == 6)
			{
				cvRectangleR(disp_image, param->mot_info->det_box_info[d].bouding_box, cvScalar(0, 255, 0, 0), 2, 1, 0);
				char textTmp[CHAR_LENGTH];
				sprintf(textTmp, "[MT]%.2f", param->mot_info->det_box_info[d].score);
				CvFont font;
				cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.8, 0.8, 0, 0, 1);
				cvPutText(disp_image, textTmp, cvPoint((int)param->mot_info->det_box_info[d].bouding_box.x, (int)param->mot_info->det_box_info[d].bouding_box.y), &font, cvScalar(0, 255, 0, 0));

				cvShowImage("[MT]", disp_image);
			}

			if (param->mot_info->det_box_info[d].class_id == 15)
			{
				cvRectangleR(disp_image, param->mot_info->det_box_info[d].bouding_box, cvScalar(0, 0, 255, 0), 2, 1, 0);
				char textTmp[CHAR_LENGTH];
				sprintf(textTmp, "[UMBRELLA]%.2f", param->mot_info->det_box_info[d].score);
				CvFont font;
				cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.8, 0.8, 0, 0, 1);
				cvPutText(disp_image, textTmp, cvPoint((int)param->mot_info->det_box_info[d].bouding_box.x, (int)param->mot_info->det_box_info[d].bouding_box.y), &font, cvScalar(0, 0, 255, 0));

				cvShowImage("[UMBRELLA]", disp_image);
			}
			else if (param->mot_info->det_box_info[d].class_id == 16)
			{
				cvRectangleR(disp_image, param->mot_info->det_box_info[d].bouding_box, cvScalar(0, 0, 255, 0), 2, 1, 0);
				char textTmp[CHAR_LENGTH];
				sprintf(textTmp, "[MOBILE]%.2f", param->mot_info->det_box_info[d].score);
				CvFont font;
				cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.8, 0.8, 0, 0, 1);
				cvPutText(disp_image, textTmp, cvPoint((int)param->mot_info->det_box_info[d].bouding_box.x, (int)param->mot_info->det_box_info[d].bouding_box.y), &font, cvScalar(0, 0, 255, 0));

				cvShowImage("[MOBILE]", disp_image);
			}
		}
	}
	if (disp_image)
	{
		cvReleaseImage(&disp_image);
		disp_image = NULL;
	}
	//cvReleaseImage(&detect_image);//hai 2018.11.30 ------> making non-detection region

	free_image(im);

	total_time = sec(clock() - total_time_c);
	printf("det: %.4f / mot: %.4f / total: %.4f\n", detection_time, tracking_time, total_time);
}


void test_detector(char *datacfg, char *cfgfile, network net, char *weightfile, char *filename, float thresh, float hier_thresh, char *outfile, int fullscreen)
{
	srand((unsigned int)time(NULL));

	list *options = read_data_cfg(datacfg);
	char *name_list = option_find_str(options, "names", "");
	char **names = get_labels(name_list);

	if (weightfile)
	{
		//LoadLowpWeightsAsFloatUpto(&net, weightfile, 0, net.n);
		load_weights(&net, weightfile);
	}

	float forward_time = 0, detection_time = 0, total_time = 0, tracking_time = 0;
	clock_t forward_time_c, detection_time_c, total_time_c, tracking_time_c;


	char reset_on = 0, reset_trigger_done = 0;

	st_mot_info *mot_info = calloc(1, sizeof(st_mot_info));
	mot_info->object_flow_number = calloc(net.layers[net.n - 1].classes, sizeof(int));
	//mot_info->object_flow_number_Daewoo = calloc(net.layers[net.n - 1].classes, sizeof(int)); //20190423 hai Daewoo
	mot_info->object_flow_total = calloc(net.layers[net.n - 1].classes, sizeof(int)); //20190214 hai Status Log
	mot_info->object_flow_number_forTopline = calloc(net.layers[net.n - 1].classes, sizeof(int));//yk 2018.12.03

	image **alphabet = load_alphabet();

	st_sub_box_info *sub_box_list = calloc(1, sizeof(st_sub_box_info));

	st_biker_info *biker_info = calloc(1, sizeof(st_biker_info));//hai 2018.12.12

	st_mot_DataSave *mot_DataSave = calloc(1, sizeof(st_mot_DataSave));//hai 2019.01.14


#if WEBCAM
	IplImage *webcam = 0;
	CvCapture *capture = cvCaptureFromCAM(0);
	cvNamedWindow("WebCam Frame Capture", 0);
	cvResizeWindow("WebCam Frame Capture", 640, 480);

#elif RTSP
	//CvCapture* capture = cvCaptureFromFile("rtsp://admin:vision@172.20.10.8/profile2/media.smp");
	CvCapture* capture = cvCaptureFromFile("C:/Users/kms/Desktop/data/5) test data/LABFIS/HCVR_ca6_main_20180122102906.avi");
	IplImage *frame;
#else
	image_info in = image_setting();

#ifdef IMAGE_LOAD_THREAD
	image im_buffer, sized_buffer;

	load_args args = { 0 };
	args.w = net.w;
	args.h = net.h;
	args.im = &im_buffer;
	args.resized = &sized_buffer;
	args.type = IMAGE_DATA;
	args.threads = 1;

	args.path = calloc(CHAR_LENGTH, sizeof(char));
	args.path = in.image_path[IMAGE_START];

	pthread_t load_thread = load_data_in_thread(args);
#endif
#endif

#if TRACKING
	CvScalar track_color[MAX_TRACK];
	for (int c = 0; c < MAX_TRACK; c++)
	{
		track_color[c] = cvScalar(rand() % 256, rand() % 256, rand() % 256, rand() % 256);
	}
#endif

#if EVAL
	eval_info ev_info = eval_setting(weightfile, cfgfile);
#endif

	float nms = NMS_IOU;
	thresh = DETECT_THRESH;

	FILE *fp_count = fopen("inin_count.end", "w");



#if WEBCAM || RTSP
	int i = 0;
	while (1)
#else
	for (int i = IMAGE_START; i < in.n_path; i++)
#endif
	{
		total_time_c = clock();

#if WEBCAM
		cvGrabFrame(capture);
		webcam = cvRetrieveFrame(capture, 1);
		cvCvtColor(webcam, webcam, CV_RGB2BGR);

		//cvShowImage("WebCam Frame Capture", webcam);
		//cvWaitKey(1);
		//continue;

		image im = make_image(640, 480, 3);
		ipl_into_image(webcam, im);
		image sized = resize_image(im, net.layers[0].w, net.layers[0].h);

#elif RTSP
		frame = cvQueryFrame(capture);
		if (!frame)
			break;

		cvCvtColor(frame, frame, CV_RGB2BGR);

		//cvShowImage("Video", frame);
		//cvWaitKey(1);

		image im = make_image(frame->width, frame->height, 3);
		ipl_into_image(frame, im);
		image sized = resize_image(im, net.layers[0].w, net.layers[0].h);

		//cvShowImage("Video", frame);
		//cvWaitKey(1);
		//continue;
#else
#ifdef IMAGE_LOAD_THREAD
		pthread_join(load_thread, 0);

		image im = im_buffer;
		image sized = sized_buffer;

		int path_index = (i + 1 < in.n_path) ? i + 1 : i;
		args.path = in.image_path[path_index];
		load_thread = load_data_in_thread(args);

#else
		image im = load_image_color(in.image_path[i], 0, 0);
		image sized = resize_image(im, net.layers[0].w, net.layers[0].h);
#endif
#endif


		float *X = sized.data;
		forward_time_c = clock();
		network_predict(net, X);
		forward_time = sec(clock() - forward_time_c);

		layer l = net.layers[net.n - 1];
		box *boxes = calloc(l.w*l.h*l.n, sizeof(box));
		float **probs = calloc(l.w*l.h*l.n, sizeof(float *));
		for (int j = 0; j < l.w*l.h*l.n; ++j)
			probs[j] = calloc(l.classes, sizeof(float *));
		float **masks = 0;
		if (l.coords > 4)
		{
			masks = calloc(l.w*l.h*l.n, sizeof(float*));
			for (int j = 0; j < l.w*l.h*l.n; ++j)
				masks[j] = calloc(l.coords - 4, sizeof(float *));
		}

		int n_gt = 0;
		char *gt_file = "NULL";
		box_label *gt = read_boxes(gt_file, &n_gt);
		_get_region_boxes(im, gt, n_gt, l, 1, 1, thresh, probs, boxes);

		if (l.softmax_tree && nms)
			do_nms_obj(boxes, probs, l.w*l.h*l.n, l.classes, nms);
		else if (nms)
			_do_nms_sort(boxes, probs, l.w*l.h*l.n, l.classes, nms);

		detection_time = sec(clock() - forward_time_c);




#if TRACKING
		IplImage *image = cvCreateImage(cvSize(im.w, im.h), IPL_DEPTH_8U, im.c);
		image_into_ipl(im, image);
#endif

#if SHOW_DET
		draw_detections(im, l.w*l.h*l.n, thresh, boxes, probs, masks, names, alphabet, l.classes);
		//		draw_and_save_object_count(im, l.w*l.h*l.n, probs, thresh, names, alphabet, l.classes, fp_save);
		show_image(im, "Detection Results");
#endif

		//char detector_save_path[CHAR_LENGTH];
		//sprintf(detector_save_path, "%s/%d", "C:/Users/kms/Desktop/image/detector", i);
		//save_image_png(im, detector_save_path);
		tracking_time_c = clock();
#if TRACKING
		int track_num;
		//track_num = tracking_function(image, l.w*l.h*l.n, boxes, probs, l.classes, mot_info, sub_box_list); 

		//hai 2018.12.12
		//track_num = tracking_function(image, l.w*l.h*l.n, boxes, probs, l.classes, mot_info, sub_box_list, biker_info, mot_DataSave, NULL);


#if		SAVE_DRAW_FLOW

		char buff[80], file_path[100];
		int current_time;
		current_time = get_current_data_time(buff, "m");

		if ((current_time == 0) && (reset_trigger_done == 0))
		{
			reset_on = 1;
			reset_trigger_done = 1;

			fclose(fp_count);
			sprintf(file_path, "stat_%s.log", buff);
			fopen(file_path, "w");
		}


		if (current_time != 0)
		{
			reset_trigger_done = 0;
		}

		object_flow_count(mot_info, track_num, l.classes, reset_on, image->height * 2 / 3);

		if (reset_on == 1)
		{
			reset_on = 0;
		}
		object_flow_draw(image, mot_info, l.classes, names);
		object_flow_save(fp_count, mot_info, l.classes, 0, buff);

#endif


#if SHOW_MOT
		for (int t = 0; t < track_num; t++)
		{
			cvRectangleR(image, mot_info->mot_box_info[t].bouding_box, track_color[mot_info->mot_box_info[t].track_id], 4, 1, 0);
			char textTmp[CHAR_LENGTH];
			sprintf(textTmp, "%d_%d", mot_info->mot_box_info[t].class_id, mot_info->mot_box_info[t].track_id);
			CvFont font;
			cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 1, 1, 0, 0, 1);
			cvPutText(image, textTmp, cvPoint((int)mot_info->mot_box_info[t].bouding_box.x, (int)mot_info->mot_box_info[t].bouding_box.y), &font, track_color[mot_info->mot_box_info[t].track_id]);

			cvLine(image, cvPoint(0, image->height * 2 / 3), cvPoint(image->width - 1, image->height * 2 / 3), cvScalar(0, 0, 255, 0), 3, 8, 0);
		}
		cvShowImage("track result", image);
#endif
#endif

#if EVAL && INRIA
		eval_inria_detections(ev_info.fp, im, l.w*l.h*l.n, thresh, boxes, probs, names, l.classes, i);

#elif EVAL && (KITTI_TRAIN || KITTI_TRAIN_SORT || KITTI_TRAIN_VAL || KITTI_TEST)
		size_t len = strlen(in.image_path[i]);
		char *s = in.image_path[i];
		char *val = 0;
		for (int c = 0; c < len; ++c)
		{
			if (s[c] == '/')
			{
				val = s + c + 1;
			}
		}
		find_replace(val, ".png", "", val);
		int save_index = atoi(val);

		eval_kitti_detections(ev_info.fp_dt_dir, im, l.w*l.h*l.n, thresh, boxes, probs, names, l.classes, save_index);

#elif EVAL && MOT17det_TEST
		eval_mot17_detections(&ev_info, im, l.w*l.h*l.n, thresh, boxes, probs, names, l.classes, i);
#endif

#if IMAGE_SAVE
		char save_image_path[CHAR_LENGTH];
		sprintf(save_image_path, "%s/%d", SAVE_DIR, i);
		save_image(im, save_image_path);
#endif

		free_image(im);
		free_image(sized);
		if (image) cvReleaseImage(&image);

		free(boxes);
		free_ptrs((void **)probs, l.w*l.h*l.n);
		tracking_time = sec(clock() - tracking_time_c);
		total_time = sec(clock() - total_time_c);


#if WEBCAM
		printf("%f / %f / %f / %f\n", forward_time, detection_time, tracking_time, total_time);
#else
		printf("%d: %f / %f / %f / %f\n", i, forward_time, detection_time, tracking_time, total_time);
#endif

		cvWaitKey(WAIT_KEY);
	}

	printf("for done\n");
	fclose(fp_count);
#if EVAL && INRIA
	fclose(ev_info.fp);

#elif EVAL && (KITTI_TRAIN || KITTI_TRAIN_SORT || KITTI_TRAIN_VAL)
	char *kitti_gt_dir = "D:/Database/4) KITTI/object/training/label_2";
	char *kitti_dt_dir = ev_info.fp_dt_dir;
	char *kitti_eval_dir = ev_info.fp_eval_dir;
	eval(kitti_gt_dir, kitti_dt_dir, kitti_eval_dir, 0, in.n_path);
#endif

#if WEBCAM || RTSP

#else
	free_image_info(in);
#endif
	free(mot_info->object_flow_number);
	//free(mot_info->object_flow_number_Daewoo); //20190223 hai Daewoo
	free(mot_info->object_flow_total); //20190214 hai Status Log
	free(mot_info->object_flow_number_forTopline);//yk 2018.12.03
	free(mot_info);
	free(sub_box_list);
	cvDestroyAllWindows();
	printf("cvDestroyAllWindows doen\n");

	free(biker_info); //hai 2018.12.12
}

static int get_coco_image_id(char *filename)
{
	char *p = strrchr(filename, '_');
	return atoi(p + 1);
}

static void print_cocos(FILE *fp, char *image_path, box *boxes, float **probs, int num_boxes, int classes, int w, int h)
{
	int i, j;
	int image_id = get_coco_image_id(image_path);
	for (i = 0; i < num_boxes; ++i)
	{
		float xmin = boxes[i].x - boxes[i].w / 2.;
		float xmax = boxes[i].x + boxes[i].w / 2.;
		float ymin = boxes[i].y - boxes[i].h / 2.;
		float ymax = boxes[i].y + boxes[i].h / 2.;

		if (xmin < 0) xmin = 0;
		if (ymin < 0) ymin = 0;
		if (xmax > w) xmax = w;
		if (ymax > h) ymax = h;

		float bx = xmin;
		float by = ymin;
		float bw = xmax - xmin;
		float bh = ymax - ymin;

		for (j = 0; j < classes; ++j)
		{
			if (probs[i][j]) fprintf(fp, "{\"image_id\":%d, \"category_id\":%d, \"bbox\":[%f, %f, %f, %f], \"score\":%f},\n", image_id, coco_ids[j], bx, by, bw, bh, probs[i][j]);
		}
	}
}

void print_detector_detections(FILE **fps, char *id, box *boxes, float **probs, int total, int classes, int w, int h)
{
	int i, j;
	for (i = 0; i < total; ++i)
	{
		float xmin = boxes[i].x - boxes[i].w / 2. + 1;
		float xmax = boxes[i].x + boxes[i].w / 2. + 1;
		float ymin = boxes[i].y - boxes[i].h / 2. + 1;
		float ymax = boxes[i].y + boxes[i].h / 2. + 1;

		if (xmin < 1) xmin = 1;
		if (ymin < 1) ymin = 1;
		if (xmax > w) xmax = w;
		if (ymax > h) ymax = h;

		for (j = 0; j < classes; ++j)
		{
			if (probs[i][j]) fprintf(fps[j], "%s %f %f %f %f %f\n", id, probs[i][j],
				xmin, ymin, xmax, ymax);
		}
	}
}

void print_imagenet_detections(FILE *fp, int id, box *boxes, float **probs, int total, int classes, int w, int h)
{
	int i, j;
	for (i = 0; i < total; ++i)
	{
		float xmin = boxes[i].x - boxes[i].w / 2.;
		float xmax = boxes[i].x + boxes[i].w / 2.;
		float ymin = boxes[i].y - boxes[i].h / 2.;
		float ymax = boxes[i].y + boxes[i].h / 2.;

		if (xmin < 0) xmin = 0;
		if (ymin < 0) ymin = 0;
		if (xmax > w) xmax = w;
		if (ymax > h) ymax = h;

		for (j = 0; j < classes; ++j)
		{
			int class = j;
			if (probs[i][class]) fprintf(fp, "%d %d %f %f %f %f %f\n", id, j + 1, probs[i][class],
				xmin, ymin, xmax, ymax);
		}
	}
}

void validate_detector_flip(char *datacfg, char *cfgfile, char *weightfile, char *outfile)
{
	int j;
	list *options = read_data_cfg(datacfg);
	char *valid_images = option_find_str(options, "valid", "data/train.list");
	char *name_list = option_find_str(options, "names", "data/names.list");
	char *prefix = option_find_str(options, "results", "results");
	char **names = get_labels(name_list);
	char *mapf = option_find_str(options, "map", 0);
	int *map = 0;
	if (mapf) map = read_map(mapf);

	network net = parse_network_cfg(cfgfile, 0, 0);
	if (weightfile)
	{
		load_weights(&net, weightfile);
	}
	set_batch_network(&net, 2);
	fprintf(stderr, "Learning Rate: %g, Momentum: %g, Decay: %g\n", net.learning_rate, net.momentum, net.decay);
	srand(time(0));

	list *plist = get_paths(valid_images);
	char **paths = (char **)list_to_array(plist);

	layer l = net.layers[net.n - 1];
	int classes = l.classes;

	char buff[1024];
	char *type = option_find_str(options, "eval", "voc");
	FILE *fp = 0;
	FILE **fps = 0;
	int coco = 0;
	int imagenet = 0;
	if (0 == strcmp(type, "coco"))
	{
		if (!outfile) outfile = "coco_results";
		snprintf(buff, 1024, "%s/%s.json", prefix, outfile);
		fp = fopen(buff, "w");
		fprintf(fp, "[\n");
		coco = 1;
	}
	else if (0 == strcmp(type, "imagenet"))
	{
		if (!outfile) outfile = "imagenet-detection";
		snprintf(buff, 1024, "%s/%s.txt", prefix, outfile);
		fp = fopen(buff, "w");
		imagenet = 1;
		classes = 200;
	}
	else
	{
		if (!outfile) outfile = "comp4_det_test_";
		fps = calloc(classes, sizeof(FILE *));
		for (j = 0; j < classes; ++j)
		{
			snprintf(buff, 1024, "%s/%s%s.txt", prefix, outfile, names[j]);
			fps[j] = fopen(buff, "w");
		}
	}

	box *boxes = calloc(l.w*l.h*l.n, sizeof(box));
	float **probs = calloc(l.w*l.h*l.n, sizeof(float *));
	for (j = 0; j < l.w*l.h*l.n; ++j) probs[j] = calloc(classes + 1, sizeof(float *));

	int m = plist->size;
	int i = 0;
	int t;

	float thresh = .005;
	float nms = .45;

	int nthreads = 4;
	image *val = calloc(nthreads, sizeof(image));
	image *val_resized = calloc(nthreads, sizeof(image));
	image *buf = calloc(nthreads, sizeof(image));
	image *buf_resized = calloc(nthreads, sizeof(image));
	pthread_t *thr = calloc(nthreads, sizeof(pthread_t));

	image input = make_image(net.w, net.h, net.c * 2);

	load_args args = { 0 };
	args.w = net.w;
	args.h = net.h;

	//args.type = IMAGE_DATA;
	args.type = LETTERBOX_DATA;

	for (t = 0; t < nthreads; ++t)
	{
		args.path = paths[i + t];
		args.im = &buf[t];
		args.resized = &buf_resized[t];
		thr[t] = load_data_in_thread(args);
	}
	time_t start = time(0);
	for (i = nthreads; i < m + nthreads; i += nthreads)
	{
		fprintf(stderr, "%d\n", i);
		for (t = 0; t < nthreads && i + t - nthreads < m; ++t)
		{
			pthread_join(thr[t], 0);
			val[t] = buf[t];
			val_resized[t] = buf_resized[t];
		}
		for (t = 0; t < nthreads && i + t < m; ++t)
		{
			args.path = paths[i + t];
			args.im = &buf[t];
			args.resized = &buf_resized[t];
			thr[t] = load_data_in_thread(args);
		}
		for (t = 0; t < nthreads && i + t - nthreads < m; ++t)
		{
			char *path = paths[i + t - nthreads];
			char *id = basecfg(path);
			copy_cpu(net.w*net.h*net.c, val_resized[t].data, 1, input.data, 1);
			flip_image(val_resized[t]);
			copy_cpu(net.w*net.h*net.c, val_resized[t].data, 1, input.data + net.w*net.h*net.c, 1);

			network_predict(net, input.data);
			int w = val[t].w;
			int h = val[t].h;
			get_region_boxes(l, w, h, net.w, net.h, thresh, probs, boxes, 0, 0, map, .5, 0);
			if (nms) do_nms_sort(boxes, probs, l.w*l.h*l.n, classes, nms);
			if (coco)
			{
				print_cocos(fp, path, boxes, probs, l.w*l.h*l.n, classes, w, h);
			}
			else if (imagenet)
			{
				print_imagenet_detections(fp, i + t - nthreads + 1, boxes, probs, l.w*l.h*l.n, classes, w, h);
			}
			else
			{
				print_detector_detections(fps, id, boxes, probs, l.w*l.h*l.n, classes, w, h);
			}
			free(id);
			free_image(val[t]);
			free_image(val_resized[t]);
		}
	}
	for (j = 0; j < classes; ++j)
	{
		if (fps) fclose(fps[j]);
	}
	if (coco)
	{
		fseek(fp, -2, SEEK_CUR);
		fprintf(fp, "\n]\n");
		fclose(fp);
	}
	fprintf(stderr, "Total Detection Time: %f Seconds\n", (double)(time(0) - start));
}

void validate_detector(char *datacfg, char *cfgfile, char *weightfile, char *outfile)
{
	int j;
	list *options = read_data_cfg(datacfg);
	char *valid_images = option_find_str(options, "valid", "data/train.list");
	char *name_list = option_find_str(options, "names", "data/names.list");
	char *prefix = option_find_str(options, "results", "results");
	char **names = get_labels(name_list);
	char *mapf = option_find_str(options, "map", 0);
	int *map = 0;
	if (mapf) map = read_map(mapf);

	network net = parse_network_cfg(cfgfile, 0, 0);
	if (weightfile)
	{
		load_weights(&net, weightfile);
	}
	set_batch_network(&net, 1);
	fprintf(stderr, "Learning Rate: %g, Momentum: %g, Decay: %g\n", net.learning_rate, net.momentum, net.decay);
	srand(time(0));

	list *plist = get_paths(valid_images);
	char **paths = (char **)list_to_array(plist);

	layer l = net.layers[net.n - 1];
	int classes = l.classes;

	char buff[1024];
	char *type = option_find_str(options, "eval", "voc");
	FILE *fp = 0;
	FILE **fps = 0;
	int coco = 0;
	int imagenet = 0;
	if (0 == strcmp(type, "coco"))
	{
		if (!outfile) outfile = "coco_results";
		snprintf(buff, 1024, "%s/%s.json", prefix, outfile);
		fp = fopen(buff, "w");
		fprintf(fp, "[\n");
		coco = 1;
	}
	else if (0 == strcmp(type, "imagenet"))
	{
		if (!outfile) outfile = "imagenet-detection";
		snprintf(buff, 1024, "%s/%s.txt", prefix, outfile);
		fp = fopen(buff, "w");
		imagenet = 1;
		classes = 200;
	}
	else
	{
		if (!outfile) outfile = "comp4_det_test_";
		fps = calloc(classes, sizeof(FILE *));
		for (j = 0; j < classes; ++j)
		{
			snprintf(buff, 1024, "%s/%s%s.txt", prefix, outfile, names[j]);
			fps[j] = fopen(buff, "w");
		}
	}

	box *boxes = calloc(l.w*l.h*l.n, sizeof(box));
	float **probs = calloc(l.w*l.h*l.n, sizeof(float *));
	for (j = 0; j < l.w*l.h*l.n; ++j) probs[j] = calloc(classes + 1, sizeof(float *));

	int m = plist->size;
	int i = 0;
	int t;

	float thresh = .005;
	float nms = .45;

	int nthreads = 4;
	image *val = calloc(nthreads, sizeof(image));
	image *val_resized = calloc(nthreads, sizeof(image));
	image *buf = calloc(nthreads, sizeof(image));
	image *buf_resized = calloc(nthreads, sizeof(image));
	pthread_t *thr = calloc(nthreads, sizeof(pthread_t));

	load_args args = { 0 };
	args.w = net.w;
	args.h = net.h;

	//args.type = IMAGE_DATA;
	args.type = LETTERBOX_DATA;

	for (t = 0; t < nthreads; ++t)
	{
		args.path = paths[i + t];
		args.im = &buf[t];
		args.resized = &buf_resized[t];
		thr[t] = load_data_in_thread(args);
	}
	time_t start = time(0);
	for (i = nthreads; i < m + nthreads; i += nthreads)
	{
		fprintf(stderr, "%d\n", i);
		for (t = 0; t < nthreads && i + t - nthreads < m; ++t)
		{
			pthread_join(thr[t], 0);
			val[t] = buf[t];
			val_resized[t] = buf_resized[t];
		}
		for (t = 0; t < nthreads && i + t < m; ++t)
		{
			args.path = paths[i + t];
			args.im = &buf[t];
			args.resized = &buf_resized[t];
			thr[t] = load_data_in_thread(args);
		}
		for (t = 0; t < nthreads && i + t - nthreads < m; ++t)
		{
			char *path = paths[i + t - nthreads];
			char *id = basecfg(path);
			float *X = val_resized[t].data;
			network_predict(net, X);
			int w = val[t].w;
			int h = val[t].h;
			get_region_boxes(l, w, h, net.w, net.h, thresh, probs, boxes, 0, 0, map, .5, 0);
			if (nms) do_nms_sort(boxes, probs, l.w*l.h*l.n, classes, nms);
			if (coco)
			{
				print_cocos(fp, path, boxes, probs, l.w*l.h*l.n, classes, w, h);
			}
			else if (imagenet)
			{
				print_imagenet_detections(fp, i + t - nthreads + 1, boxes, probs, l.w*l.h*l.n, classes, w, h);
			}
			else
			{
				print_detector_detections(fps, id, boxes, probs, l.w*l.h*l.n, classes, w, h);
			}
			free(id);
			free_image(val[t]);
			free_image(val_resized[t]);
		}
	}
	for (j = 0; j < classes; ++j)
	{
		if (fps) fclose(fps[j]);
	}
	if (coco)
	{
		fseek(fp, -2, SEEK_CUR);
		fprintf(fp, "\n]\n");
		fclose(fp);
	}
	fprintf(stderr, "Total Detection Time: %f Seconds\n", (double)(time(0) - start));
}

void validate_detector_recall(char *cfgfile, char *weightfile)
{
	network net = parse_network_cfg(cfgfile, 0, 0);
	if (weightfile)
	{
		load_weights(&net, weightfile);
	}
	set_batch_network(&net, 1);
	fprintf(stderr, "Learning Rate: %g, Momentum: %g, Decay: %g\n", net.learning_rate, net.momentum, net.decay);
	srand(time(0));

	list *plist = get_paths("D:/Database/7) deep_learning/VOC_COCO/train.txt");
	char **paths = (char **)list_to_array(plist);

	layer l = net.layers[net.n - 1];
	int classes = l.classes;

	int j, k;
	box *boxes = calloc(l.w*l.h*l.n, sizeof(box));
	float **probs = calloc(l.w*l.h*l.n, sizeof(float *));
	for (j = 0; j < l.w*l.h*l.n; ++j) probs[j] = calloc(classes, sizeof(float *));

	int m = plist->size;
	int i = 0;

	float thresh = .001;
	float iou_thresh = .5;
	float nms = .4;

	int total = 0;
	int correct = 0;
	int proposals = 0;
	float avg_iou = 0;

	for (i = 0; i < m; ++i)
	{
		char *path = paths[i];
		image orig = load_image_color(path, 0, 0);
		image sized = resize_image(orig, net.w, net.h);
		char *id = basecfg(path);
		network_predict(net, sized.data);

		int n_gt = 0;
		box_label *gt = read_boxes("test.txt", &n_gt);
		_get_region_boxes(orig, gt, n_gt, l, 1, 1, thresh, probs, boxes);

		if (l.softmax_tree && nms)
			do_nms_obj(boxes, probs, l.w*l.h*l.n, l.classes, nms);
		else if (nms)
			_do_nms_sort(boxes, probs, l.w*l.h*l.n, l.classes, nms);

		//get_region_boxes(l, sized.w, sized.h, net.w, net.h, thresh, probs, boxes, 0, 1, 0, .5, 1);
		//if (nms) do_nms(boxes, probs, l.w*l.h*l.n, 1, nms);

		char labelpath[4096];
		find_replace(path, "images", "labels", labelpath);
		find_replace(labelpath, "JPEGImages", "labels", labelpath);
		find_replace(labelpath, ".jpg", ".txt", labelpath);
		find_replace(labelpath, ".JPEG", ".txt", labelpath);

		int num_labels = 0;
		box_label *truth = read_boxes(labelpath, &num_labels);

		box truth_box;
		truth_box.x = truth->x;
		truth_box.y = truth->y;
		truth_box.w = truth->w;
		truth_box.h = truth->h;
		draw_bbox(orig, truth_box, 3, 1, 1, 1);

		for (k = 0; k < l.w*l.h*l.n; ++k)
		{
			if (probs[k][0] > thresh)
			{
				++proposals;
			}
		}
		for (j = 0; j < num_labels; ++j)
		{
			++total;
			box t = { truth[j].x, truth[j].y, truth[j].w, truth[j].h };
			float best_iou = 0;
			for (k = 0; k < l.w*l.h*l.n; ++k)
			{
				float iou = box_iou(boxes[k], t);
				if (probs[k][0] > thresh && iou > best_iou)
				{
					draw_bbox(orig, boxes[k], 3, 1, 1, 1);

					best_iou = iou;
				}
			}
			avg_iou += best_iou;
			if (best_iou > iou_thresh)
			{
				++correct;
			}
		}

		show_image(orig, "test");
		cvWaitKey(0);

		fprintf(stderr, "%5d %5d %5d\tRPs/Img: %.2f\tIOU: %.2f%%\tRecall:%.2f%%\n", i, correct, total, (float)proposals / (i + 1), avg_iou * 100 / total, 100.*correct / total);
		free(id);
		free_image(orig);
		free_image(sized);
	}
}

void run_detector(int argc, char **argv)
{
	char *prefix = find_char_arg(argc, argv, "-prefix", 0);
	float thresh = find_float_arg(argc, argv, "-thresh", .20);
	float hier_thresh = find_float_arg(argc, argv, "-hier", .5);
	int cam_index = find_int_arg(argc, argv, "-c", 0);
	int frame_skip = find_int_arg(argc, argv, "-s", 0);
	int avg = find_int_arg(argc, argv, "-avg", 3);
	if (argc < 4)
	{
		fprintf(stderr, "usage: %s %s [train/test/valid] [cfg] [weights (optional)]\n", argv[0], argv[1]);
		return;
	}
	char *gpu_list = find_char_arg(argc, argv, "-gpus", 0);
	char *outfile = find_char_arg(argc, argv, "-out", 0);
	int *gpus = 0;
	int gpu = 0;
	int ngpus = 0;
	if (gpu_list)
	{
		printf("%s\n", gpu_list);
		int len = strlen(gpu_list);
		ngpus = 1;
		int i;
		for (i = 0; i < len; ++i)
		{
			if (gpu_list[i] == ',') ++ngpus;
		}
		gpus = calloc(ngpus, sizeof(int));
		for (i = 0; i < ngpus; ++i)
		{
			gpus[i] = atoi(gpu_list);
			gpu_list = strchr(gpu_list, ',') + 1;
		}
	}
	else
	{
		gpu = 0;
		gpus = &gpu;
		ngpus = 1;
	}

	int clear = find_arg(argc, argv, "-clear");
	int fullscreen = find_arg(argc, argv, "-fullscreen");
	int width = find_int_arg(argc, argv, "-w", 0);
	int height = find_int_arg(argc, argv, "-h", 0);
	int fps = find_int_arg(argc, argv, "-fps", 0);

	char *datacfg = argv[3];
	char *cfg = argv[4];
	char *weights = (argc > 5) ? argv[5] : 0;
	char *filename = (argc > 6) ? argv[6] : 0;
	if (0 == strcmp(argv[2], "train"))
	{
		train_detector(datacfg, cfg, weights, gpus, ngpus, clear, 0);
	}
	else if (0 == strcmp(argv[2], "train_test"))
	{
		train_detector(datacfg, cfg, weights, gpus, ngpus, clear, 1);
	}
	else if (0 == strcmp(argv[2], "test"))
	{
		network net = parse_network_cfg(cfg, 1, 0);
		test_detector(datacfg, cfg, net, weights, filename, thresh, hier_thresh, outfile, fullscreen);
	}
	else if (0 == strcmp(argv[2], "test_iter"))
	{
		network net = parse_network_cfg(cfg, 1, 0);

		int *iters;
		char *iter_list = find_char_arg(argc, argv, "-iter", 0);
		if (iter_list)
		{
			int len = strlen(iter_list);
			int n_iter = 1;
			for (int i = 0; i < len; ++i)
			{
				if (iter_list[i] == ',')
					++n_iter;
			}
			iters = calloc(n_iter, sizeof(int));
			for (int i = 0; i < n_iter; ++i)
			{
				iters[i] = atoi(iter_list);
				iter_list = strchr(iter_list, ',') + 1;
			}
		}
		else
		{
			int n_iter = 3;
			iters = calloc(n_iter, sizeof(int));
			iters[0] = 10000;
			iters[1] = 10000;
			iters[2] = 10000;
		}

		for (int i = iters[0]; i <= iters[2]; i += iters[1])
		{
			char tmp[300];
			sprintf(tmp, "%s_%d.weights", weights, i);
			test_detector(datacfg, cfg, net, tmp, filename, thresh, hier_thresh, outfile, fullscreen);
		}
	}
	else if (0 == strcmp(argv[2], "valid"))
		validate_detector(datacfg, cfg, weights, outfile);
	else if (0 == strcmp(argv[2], "valid2"))
		validate_detector_flip(datacfg, cfg, weights, outfile);
	else if (0 == strcmp(argv[2], "recall"))
		validate_detector_recall(cfg, weights);
	else if (0 == strcmp(argv[2], "demo"))
	{
		list *options = read_data_cfg(datacfg);
		int classes = option_find_int(options, "classes", 20);
		char *name_list = option_find_str(options, "names", "data/names.list");
		char **names = get_labels(name_list);
		demo(cfg, weights, thresh, cam_index, filename, names, classes, frame_skip, prefix, avg, hier_thresh, width, height, fps, fullscreen);
	}
}

void eval_inria_detections(FILE *fp, image im, int num, float thresh, box *boxes, float **probs, char **names, int classes, int image_cnt)
{
	for (int i = 0; i < num; ++i)
	{
		int class_ = max_index(probs[i], classes);
		float prob = probs[i][class_];

		//if (prob > thresh && strcmp(names[class_], "car") == 0)
		if (prob > thresh && (strcmp(names[class_], "Pedestrian") == 0 || strcmp(names[class_], "person") == 0))
		{
			box b = boxes[i];

			int left = (b.x - b.w / 2.) * im.w;
			int right = (b.x + b.w / 2.) * im.w;
			int top = (b.y - b.h / 2.) * im.h;
			int bot = (b.y + b.h / 2.) * im.h;

			if (left < 0) left = 0;
			if (right > im.w - 1) right = im.w - 1;
			if (top < 0) top = 0;
			if (bot > im.h - 1) bot = im.h - 1;

			int x = left;
			int y = top;
			int w = right - left;
			int h = bot - top;

			fprintf(fp, "%d %d %d %d %d %f\n", image_cnt + 1, x, y, w, h, prob);
		}
	}
}

void eval_kitti_detections(char *kitti_dir, image im, int num, float thresh, box *boxes, float **probs, char **names, int classes, int image_cnt)
{
	char kitti_path[256];
	sprintf(kitti_path, "%s/%d.txt", kitti_dir, image_cnt);
	FILE *fp_kitti = fopen(kitti_path, "w");
	if (fp_kitti == NULL)
	{
		printf("eval_kitti_detections, fp_kitti == NULL\n");
		exit(0);
	}

	for (int i = 0; i < num; ++i)
	{
		int class_ = max_index(probs[i], classes);
		float prob = probs[i][class_];
		if (prob > thresh &&
			(strcmp(names[class_], "car") == 0 || strcmp(names[class_], "Car") == 0 ||
				strcmp(names[class_], "person") == 0 || strcmp(names[class_], "Person") == 0 ||
				strcmp(names[class_], "pedestrian") == 0 || strcmp(names[class_], "Pedestrian") == 0 ||
				strcmp(names[class_], "cyclist") == 0 || strcmp(names[class_], "Cyclist") == 0))
		{
			box b = boxes[i];

			int left = (b.x - b.w / 2.) * im.w;
			int right = (b.x + b.w / 2.) * im.w;
			int top = (b.y - b.h / 2.) * im.h;
			int bot = (b.y + b.h / 2.) * im.h;

			if (left < 0) left = 0;
			if (right > im.w - 1) right = im.w - 1;
			if (top < 0) top = 0;
			if (bot > im.h - 1) bot = im.h - 1;

			int x = left;
			int y = top;
			int w = right - left;
			int h = bot - top;

			char class_name[256];
			if (strcmp(names[class_], "car") == 0 || strcmp(names[class_], "Car") == 0)
				sprintf(class_name, "Car");
			else if (strcmp(names[class_], "person") == 0 || strcmp(names[class_], "Person") == 0 ||
				strcmp(names[class_], "pedestrian") == 0 || strcmp(names[class_], "Pedestrian") == 0)
				sprintf(class_name, "Pedestrian");
			else if (strcmp(names[class_], "cyclist") == 0 || strcmp(names[class_], "Cyclist") == 0)
				sprintf(class_name, "Cyclist");

			fprintf(fp_kitti, "%s %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n",
				class_name, 0, 0, (float)-10,
				(float)x, (float)y, ((float)x + w), ((float)y + h),
				0, 0, 0, 0,
				0, 0, 0, prob);
		}
	}

	fclose(fp_kitti);
}

void eval_mot17_detections(eval_info *ev_info, image im, int num, float thresh, box *boxes, float **probs, char **names, int classes, int image_cnt)
{
	int mot_train[] = { 1, 3, 6, 7, 8, 12, 14 };
	int mot_image_cnt[] = { 0, 450, 1950, 3144, 3644, 4269, 5169, 5919 };
	int n_mot = sizeof(mot_train) / sizeof(mot_train[0]);

	static int mot_cnt = 0;
	for (int i = 0; i < n_mot; i++)
	{
		if (image_cnt == mot_image_cnt[i])
		{
			char eval_path[CHAR_LENGTH];
			sprintf(eval_path, "%s/MOT17-%02d.txt", ev_info->fp_dt_dir, mot_train[i]);
			ev_info->fp = fopen(eval_path, "w");

			mot_cnt = i;

			printf("%d %s\n", image_cnt, eval_path);
		}
	}

	for (int i = 0; i < num; ++i)
	{
		int class_ = max_index(probs[i], classes);
		float prob = probs[i][class_];

		if (prob > thresh && (strcmp(names[class_], "person") == 0 || strcmp(names[class_], "Pedestrian") == 0))
		{
			box b = boxes[i];

			int left = (b.x - b.w / 2.) * im.w;
			int right = (b.x + b.w / 2.) * im.w;
			int top = (b.y - b.h / 2.) * im.h;
			int bot = (b.y + b.h / 2.) * im.h;

			if (left < 0) left = 0;
			if (right > im.w - 1) right = im.w - 1;
			if (top < 0) top = 0;
			if (bot > im.h - 1) bot = im.h - 1;

			int x = left;
			int y = top;
			int w = right - left;
			int h = bot - top;

			fprintf(ev_info->fp, "%d,%d,%d,%d,%d,%d,%f\n", image_cnt + 1 - mot_image_cnt[mot_cnt], -1, x, y, w, h, prob);
		}
	}

	//printf("%d\n", image_cnt + 1 - mot_image_cnt[mot_cnt]);

	for (int i = 0; i < n_mot; i++)
	{
		if (image_cnt == mot_image_cnt[i] - 1)
		{
			fclose(ev_info->fp);

			//printf("%d\n", image_cnt);
		}
	}
}

void kitti_eval()
{
	char kitti_gt_dir1[CHAR_LENGTH];
	char kitti_dt_dir1[CHAR_LENGTH];
	char kitti_eval_dir1[CHAR_LENGTH];
	sprintf(kitti_gt_dir1, "D:/Database/4) KITTI/object/training/label_2");
	sprintf(kitti_dt_dir1, "D:/Darknet/eval/layer30_pre23_kitti_label3_trainval/layer30 pre23 kitti label3 trainval 200000/set01/data");
	sprintf(kitti_eval_dir1, "D:/Darknet/eval/layer30_pre23_kitti_label3_trainval/layer30 pre23 kitti label3 trainval 200000");
	eval(kitti_gt_dir1, kitti_dt_dir1, kitti_eval_dir1, 0, 3769);
}

int get_file_num(char *file_dir)
{
	char find_file_path[CHAR_LENGTH];
	sprintf_s(find_file_path, CHAR_LENGTH, "%s/%s", file_dir, "*.*");

	struct _finddata_t c_file;
	intptr_t h_file = _findfirst(find_file_path, &c_file);
	if (h_file == NULL)
	{
		printf("get_file_num(), h_file == NULL\n");
		exit(0);
	}

	int cnt = 0;
	do
	{
		if ((c_file.attrib == _A_NORMAL) || (c_file.attrib == _A_ARCH))
		{
			cnt++;
		}
	} while (_findnext(h_file, &c_file) == 0);

	return cnt;
}

image_info image_setting()
{
	image_info in;
	in.n_path = 0;

	char *list_path = LIST_PATH;

	FILE *fp = fopen(list_path, "r");
	while (!feof(fp))
	{
		char tmp[CHAR_LENGTH];
		fgets(tmp, CHAR_LENGTH, fp);
		in.n_path++;
	}
	fclose(fp);

	in.image_path = (char**)calloc(in.n_path, sizeof(char*));
	int path_cnt = 0;
	fp = fopen(list_path, "r");
	while (!feof(fp))
	{
		in.image_path[path_cnt] = (char*)calloc(CHAR_LENGTH, sizeof(char));
		fgets(in.image_path[path_cnt], CHAR_LENGTH, fp);
		find_replace(in.image_path[path_cnt], "\n", "", in.image_path[path_cnt]);
		path_cnt++;
	}
	fclose(fp);

	return in;
}

void free_image_info(image_info in)
{
	for (int i = 0; i < in.n_path; i++)
		free(in.image_path[i]);
	free(in.image_path);
}

eval_info eval_setting(char *weightfile, char *cfgfile)
{
	eval_info ev_info;
	ev_info.fp = NULL;

#if !(INRIA || KITTI_TRAIN || KITTI_TRAIN_SORT || KITTI_TRAIN_VAL || KITTI_TEST || MOT17det_TEST)
	return ev_info;
#endif

	char fp_num[CHAR_LENGTH];
	find_replace(weightfile, ".weights", "", fp_num);

	char *result;
	result = strtok(fp_num, "_");
	while (1)
	{
		result = strtok(NULL, "_");
		if (result == NULL)
			break;
		else
			sprintf(fp_num, "%s", result);
	}

	char fp_base[CHAR_LENGTH];

#if FP_BASE_FIX
	char *base = FP_BASE_NAME;

#else
	char *base = basecfg(cfgfile);
#endif

	sprintf(fp_base, "D:/Darknet/eval/%s", base);
	mkdir(fp_base);

	char fp_name[CHAR_LENGTH];
	find_replace(base, "_", " ", fp_name);
	for (int i = 0; i < 20; i++)
		find_replace(fp_name, "_", " ", fp_name);
	sprintf(fp_name, "%s %s", fp_name, fp_num);

	char fp_name_dir[CHAR_LENGTH];
	sprintf(fp_name_dir, "%s/%s", fp_base, fp_name);
	mkdir(fp_name_dir);

#if INRIA
	char fp_inria_dir[CHAR_LENGTH];
	sprintf(fp_inria_dir, "%s/inria", fp_name_dir);
	mkdir(fp_inria_dir);

	char fp_inria_path[CHAR_LENGTH];
	sprintf(fp_inria_path, "%s/V000.txt", fp_inria_dir);

	ev_info.fp = fopen(fp_inria_path, "w");

#elif KITTI_TRAIN || KITTI_TRAIN_SORT || KITTI_TRAIN_VAL || KITTI_TEST
	char fp_kitti_dir[CHAR_LENGTH];
	sprintf(fp_kitti_dir, "%s/kitti", fp_name_dir);
	mkdir(fp_kitti_dir);

	sprintf(ev_info.fp_dt_dir, "%s", fp_kitti_dir);

#elif MOT17det_TEST
	char fp_mot17det_dir[CHAR_LENGTH];
	sprintf(fp_mot17det_dir, "%s/mot17det", fp_name_dir);
	mkdir(fp_mot17det_dir);

	sprintf(ev_info.fp_dt_dir, "%s", fp_mot17det_dir);

#endif

#if FP_EVAL_MOVE
	sprintf(ev_info.fp_eval_dir, "%s/%s", FP_EVAL_DIR, fp_name);

#else
	sprintf(ev_info.fp_eval_dir, "%s/%s", fp_base, fp_name);
#endif

	return ev_info;
}

