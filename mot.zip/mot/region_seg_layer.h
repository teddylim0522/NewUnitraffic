#ifndef REGION_SEG_LAYER_H
#define REGION_SEG_LAYER_H

#include "darknet.h"
#include "layer.h"
#include "network.h"

layer make_region_seg_layer(int batch, int h, int w, int classes);
void forward_region_seg_layer(const layer l, network net);
void backward_region_seg_layer(const layer l, network net);


#ifdef GPU
void forward_region_seg_layer_gpu(const layer l, network net);
void backward_region_seg_layer_gpu(const layer l, network net);
#endif

#endif