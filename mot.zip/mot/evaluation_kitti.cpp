
#include "evaluation_kitti.h"

//evaluation parameter
const int MIN_HEIGHT[3] = { 40, 25, 25 }; //minimum height for evaluated groundtruth/detections
const int MAX_OCCLUSION[3] = { 0, 1, 2 }; //maximum occlusion level of the groundtruth used for evaluation
const double MAX_TRUNCATION[3] = { 0.15, 0.3, 0.5 }; //maximum truncation level of the groundtruth used for evaluation

													 //parameters varying per class
vector<string> CLASS_NAMES;
const double MIN_OVERLAP[3] = { 0.7, 0.5, 0.5 }; //the minimum overlap required for evaluation

												 //no. of recall steps that should be evaluated (discretized)
const double N_SAMPLE_PTS = 41;

extern "C" bool eval(char *gt_dir_, char *dt_dir_, char *eval_file_name_, int TEST_IMAGE_START, int TEST_IMAGE_END)
{
	string gt_dir = gt_dir_;
	string dt_dir = dt_dir_;
	string eval_file_name = eval_file_name_;

	//set some global parameters
	initGlobals();

	//_mkdir(eval_dir.c_str());

	//hold detections and ground truth in memory
	vector< vector<tGroundtruth> > groundtruth;
	vector< vector<tDetection> > detections;

	//holds wether orientation similarity shall be computed (might be set to false while loading detections)
	//and which labels where provided by this submission
	bool compute_aos = true, eval_car = false, eval_pedestrian = false, eval_cyclist = false;

	//for all images read groundtruth and detections
#if KITTI_TRAIN_VAL
	image_info in;
	in.n_path = 0;

	vector<int> m_idx(TEST_IMAGE_END);
	char *list_path = LIST_PATH;

	int path_cnt = 0;
	FILE *fp = fopen(list_path, "r");
	while (!feof(fp))
	{
		char path[CHAR_LENGTH];
		fgets(path, CHAR_LENGTH, fp);

		string path_tmp = path;
		int end = path_tmp.find(".png", 0);
		int start = path_tmp.find_last_of("/", end);
		string val = path_tmp.substr(start + 1, end - start - 1);
		
		int save_index = atoi(val.c_str());
		m_idx[path_cnt] = save_index;

		path_cnt++;
	}
	fclose(fp);
#endif

	for (int i = TEST_IMAGE_START; i < TEST_IMAGE_END; i++)
	{

#if KITTI_TRAIN_VAL
		char file_name[256];
		sprintf(file_name, "%d.txt", m_idx[i]);

#else
		char file_name[256];
		sprintf(file_name, "%d.txt", i);
#endif

		//read ground truth and result poses
		bool gt_success, det_success;
		vector<tGroundtruth> gt = loadGroundtruth(gt_dir + "/" + file_name, gt_success);
		vector<tDetection> det = loadDetections(dt_dir + "/" + file_name, compute_aos, eval_car, eval_pedestrian, eval_cyclist, det_success);
		groundtruth.push_back(gt);
		detections.push_back(det);

		//check for errors
		if (!gt_success)
		{
			return false;
		}

		if (!det_success)
		{
			return false;
		}
	}

	//holds pointers for result files
	FILE *fp_det = 0, *fp_ori = 0;

	//eval cars
	if (eval_car)
	{
		fp_det = fopen((dt_dir + "/stats_" + CLASS_NAMES[CAR_] + "_detection.txt").c_str(), "w");
		if (compute_aos)
			fp_ori = fopen((dt_dir + "/stats_" + CLASS_NAMES[CAR_] + "_orientation.txt").c_str(), "w");

		vector<double> precision[3], aos[3];
		if (!eval_class(fp_det, fp_ori, CAR_, groundtruth, detections, compute_aos, precision[0], aos[0], EASY)
			|| !eval_class(fp_det, fp_ori, CAR_, groundtruth, detections, compute_aos, precision[1], aos[1], MODERATE)
			|| !eval_class(fp_det, fp_ori, CAR_, groundtruth, detections, compute_aos, precision[2], aos[2], HARD))
		{
			return false;
		}

		fclose(fp_det);

		saveAndPlotPlots(eval_file_name + " Car", precision);
		if (compute_aos)
		{
			fclose(fp_ori);
			saveAndPlotPlots(eval_file_name + " Car", aos);
		}
	}

	//eval pedestrians
	if (eval_pedestrian)
	{
		fp_det = fopen((dt_dir + "/stats_" + CLASS_NAMES[PEDESTRIAN_] + "_detection.txt").c_str(), "w");
		if (compute_aos)
			fp_ori = fopen((dt_dir + "/stats_" + CLASS_NAMES[PEDESTRIAN_] + "_orientation.txt").c_str(), "w");

		vector<double> precision[3], aos[3];
		if (!eval_class(fp_det, fp_ori, PEDESTRIAN_, groundtruth, detections, compute_aos, precision[0], aos[0], EASY)
			|| !eval_class(fp_det, fp_ori, PEDESTRIAN_, groundtruth, detections, compute_aos, precision[1], aos[1], MODERATE)
			|| !eval_class(fp_det, fp_ori, PEDESTRIAN_, groundtruth, detections, compute_aos, precision[2], aos[2], HARD))
		{
			return false;
		}
		fclose(fp_det);

		saveAndPlotPlots(eval_file_name + " Pedestrian", precision);
		if (compute_aos)
		{
			fclose(fp_ori);
			saveAndPlotPlots(eval_file_name + " Pedestrian", aos);
		}
	}

	//eval cyclists
	if (eval_cyclist)
	{
		fp_det = fopen((dt_dir + "/stats_" + CLASS_NAMES[CYCLIST_] + "_detection.txt").c_str(), "w");
		if (compute_aos)
			fp_ori = fopen((dt_dir + "/stats_" + CLASS_NAMES[CYCLIST_] + "_orientation.txt").c_str(), "w");

		vector<double> precision[3], aos[3];
		if (!eval_class(fp_det, fp_ori, CYCLIST_, groundtruth, detections, compute_aos, precision[0], aos[0], EASY)
			|| !eval_class(fp_det, fp_ori, CYCLIST_, groundtruth, detections, compute_aos, precision[1], aos[1], MODERATE)
			|| !eval_class(fp_det, fp_ori, CYCLIST_, groundtruth, detections, compute_aos, precision[2], aos[2], HARD))
		{
			return false;
		}
		fclose(fp_det);

		saveAndPlotPlots(eval_file_name + " Cyclist", precision);
		if (compute_aos)
		{
			fclose(fp_ori);
			saveAndPlotPlots(eval_file_name + " Cyclist", aos);
		}
	}

	//success
	return true;
}

void initGlobals()
{
	CLASS_NAMES.push_back("Car");
	CLASS_NAMES.push_back("Pedestrian");
	CLASS_NAMES.push_back("Cyclist");
}

vector<tGroundtruth> loadGroundtruth(string file_name, bool &success)
{
	//holds all ground truth (ignored ground truth is indicated by an index vector
	vector<tGroundtruth> groundtruth;
	FILE *fp = fopen(file_name.c_str(), "r");
	if (!fp)
	{
		success = false;
		return groundtruth;
	}

	while (!feof(fp))
	{
		tGroundtruth g;
		double trash;
		char str[256];
		if (fscanf(fp, "%s %lf %d %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
			str, &g.truncation, &g.occlusion, &g.box.alpha,
			&g.box.x1, &g.box.y1, &g.box.x2, &g.box.y2,
			&trash, &trash, &trash, &trash,
			&trash, &trash, &trash) == 15)
		{
			g.box.type = str;
			groundtruth.push_back(g);
		}
	}

	fclose(fp);
	success = true;
	return groundtruth;
}

vector<tDetection> loadDetections(string file_name, bool &compute_aos, bool &eval_car, bool &eval_pedestrian, bool &eval_cyclist, bool &success)
{
	//holds all detections (ignored detections are indicated by an index vector
	vector<tDetection> detections;
	FILE *fp = fopen(file_name.c_str(), "r");
	if (!fp)
	{
		success = false;
		return detections;
	}

	while (!feof(fp))
	{
		tDetection d;
		double trash;
		char str[256];
		if (fscanf(fp, "%s %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
			str, &trash, &trash, &d.box.alpha,
			&d.box.x1, &d.box.y1, &d.box.x2, &d.box.y2,
			&trash, &trash, &trash, &trash,
			&trash, &trash, &trash, &d.thresh) == 16)
		{
			d.box.type = str;
			detections.push_back(d);

			//orientation=-10 is invalid, AOS is not evaluated if at least one orientation is invalid
			if (d.box.alpha == -10)
				compute_aos = false;

			//a class is only evaluated if it is detected at least once
			if (!eval_car && !strcmp(d.box.type.c_str(), "Car"))
				eval_car = true;
			if (!eval_pedestrian && !strcmp(d.box.type.c_str(), "Pedestrian"))
				eval_pedestrian = true;
			if (!eval_cyclist && !strcmp(d.box.type.c_str(), "Cyclist"))
				eval_cyclist = true;
		}
	}

	fclose(fp);
	success = true;
	return detections;
}

bool eval_class(FILE *fp_det, FILE *fp_ori, CLASSES current_class, const vector< vector<tGroundtruth> > &groundtruth, const vector< vector<tDetection> > &detections, bool compute_aos, vector<double> &precision, vector<double> &aos, DIFFICULTY difficulty)
{
	//init
	int n_gt = 0; //total no. of gt (denominator of recall)
	vector<double> v, thresholds; //detection scores, evaluated for recall discretization
	vector< vector<int> > ignored_gt, ignored_det; //index of ignored gt detection for current class/difficulty
	vector< vector<tGroundtruth> > dontcare; //index of dontcare areas, included in ground truth

											 //for all test images do
	int n_test = (int)groundtruth.size();
	for (int i = 0; i < n_test; i++)
	{
		//holds ignored ground truth, ignored detections and dontcare areas for current frame
		vector<int> i_gt, i_det;
		vector<tGroundtruth> dc;

		//only evaluate objects of current class and ignore occluded, truncated objects
		cleanData(current_class, groundtruth[i], detections[i], i_gt, dc, i_det, n_gt, difficulty);
		ignored_gt.push_back(i_gt);
		ignored_det.push_back(i_det);
		dontcare.push_back(dc);

		//compute statistics to get recall values
		tPrData pr_tmp = tPrData();
		pr_tmp = computeStatistics(current_class, groundtruth[i], detections[i], dc, i_gt, i_det, false, false, 0, false, i);

		//add detection scores to vector over all images
		for (int j = 0; j < pr_tmp.v.size(); j++)
			v.push_back(pr_tmp.v[j]);
	}

	//get scores that must be evaluated for recall discretization
	thresholds = getThresholds(v, n_gt);

	//compute TP,FP,FN for relevant scores
	vector<tPrData> pr;
	pr.assign(thresholds.size(), tPrData());
	n_test = (int)groundtruth.size();

#if 0
	int m_idx[3769] = { 0 };
	int n_mapping = 3769;
	char *mapping_path = "D:/Database/4) KITTI/object/devkit_object/mapping/val_rand_3769.txt";
	FILE *fp_kitti_map = fopen(mapping_path, "r");
	for (int k = 0; k < n_mapping; k++)
	{
		fscanf(fp_kitti_map, "%d", &m_idx[k]);
	}
	fclose(fp_kitti_map);
#endif

	printf("class: %d / difficulty: %d\n", current_class, difficulty);
	for (int i = 0; i < n_test; i++)
	{
		//for all scores/recall thresholds do:
		for (int t = 0; t < thresholds.size(); t++)
		{
			tPrData tmp = tPrData();
			tmp = computeStatistics(current_class, groundtruth[i], detections[i], dontcare[i], ignored_gt[i], ignored_det[i], true, compute_aos, thresholds[t], t == 38, i);

#if 0
			if ((t == 0 || t == 1) && (tmp.tp > 1000000 || tmp.fp > 0))
			{
				printf("tp: %d  /  fp: %d\n", tmp.tp, tmp.fp);
				char file_name[256];
				sprintf(file_name, "D:/Database/4) KITTI/object/training/image_2/%d.png", m_idx[i]);
				IplImage *im = cvLoadImage(file_name, 1);
				int n_dt = detections[i].size();
				for (int d = 0; d < n_dt; d++)
				{
					if (detections[i][d].thresh >= thresholds[t])
					{
						printf("thresh: %f / dt: %f\n", thresholds[t], detections[i][d].thresh);
						cvRectangle(im, cvPoint(detections[i][d].box.x1, detections[i][d].box.y1), cvPoint(detections[i][d].box.x2, detections[i][d].box.y2), CV_RGB(255, 0, 0));

						int n_gt = detections[i].size();
						for (int g = 0; g < n_gt; g++)
						{
							double overlap = boxoverlap(detections[i][d].box, groundtruth[i][g].box, -1);
							printf("%f\n", overlap);

							cvRectangle(im, cvPoint(groundtruth[i][g].box.x1, groundtruth[i][g].box.y1), cvPoint(groundtruth[i][g].box.x2, groundtruth[i][g].box.y2), CV_RGB(0, 255, 0));
						}
					}
				}



				cvShowImage("test", im);
				cvWaitKey(0);
			}
#endif

			//add no. of TP, FP, FN, AOS for current frame to total evaluation for current threshold
			pr[t].tp += tmp.tp;
			pr[t].fp += tmp.fp;
			pr[t].fn += tmp.fn;
			if (tmp.similarity != -1)
				pr[t].similarity += tmp.similarity;
		}
	}

	//compute recall, precision and AOS
	vector<double> recall;
	precision.assign(N_SAMPLE_PTS, 0);
	if (compute_aos)
		aos.assign(N_SAMPLE_PTS, 0);

	double r = 0;
	for (int i = 0; i < thresholds.size(); i++)
	{
		r = pr[i].tp / (double)(pr[i].tp + pr[i].fn);
		recall.push_back(r);
		precision[i] = pr[i].tp / (double)(pr[i].tp + pr[i].fp);
		if (compute_aos)
			aos[i] = pr[i].similarity / (double)(pr[i].tp + pr[i].fp);
	}

	//filter precision and AOS using max_{i..end}(precision)
	for (int i = 0; i < thresholds.size(); i++)
	{
		precision[i] = *max_element(precision.begin() + i, precision.end());
		if (compute_aos)
			aos[i] = *max_element(aos.begin() + i, aos.end());
	}

	//save statisics and finish with success
	saveStats(precision, aos, fp_det, fp_ori);
	return true;
}

void cleanData(CLASSES current_class, const vector<tGroundtruth> &gt, const vector<tDetection> &det, vector<int> &ignored_gt, vector<tGroundtruth> &dc, vector<int> &ignored_det, int &n_gt, DIFFICULTY difficulty)
{
	//extract ground truth bounding boxes for current evaluation class
	for (int i = 0; i < gt.size(); i++)
	{
		//only bounding boxes with a minimum height are used for evaluation
		double height = gt[i].box.y2 - gt[i].box.y1;

		//neighboring classes are ignored ("van" for "car" and "person_sitting" for "pedestrian")
		//(lower/upper cases are ignored)
		int valid_class;

		//all classes without a neighboring class
		if (!strcmp(gt[i].box.type.c_str(), CLASS_NAMES[current_class].c_str()))
			valid_class = 1;

		//classes with a neighboring class
#if 1
		else if (!strcmp(CLASS_NAMES[current_class].c_str(), "Pedestrian") &&
			!strcmp("Person_sitting", gt[i].box.type.c_str()))
			valid_class = 0;
#else
		else if (!strcmp(CLASS_NAMES[current_class].c_str(), "Pedestrian") &&
			(!strcmp("Person_sitting", gt[i].box.type.c_str()) || !strcmp("Cyclist", gt[i].box.type.c_str())))
			valid_class = 0;
#endif
		else if (!strcmp(CLASS_NAMES[current_class].c_str(), "Car") &&
			!strcmp("Van", gt[i].box.type.c_str()))
			valid_class = 0;
		else //classes not used for evaluation
			valid_class = -1;

		//ground truth is ignored, if occlusion, truncation exceeds the difficulty or ground truth is too small
		//(doesn't count as FN nor TP, although detections may be assigned)
		bool ignore = false;
		if (gt[i].occlusion > MAX_OCCLUSION[difficulty] || gt[i].truncation > MAX_TRUNCATION[difficulty] || height < MIN_HEIGHT[difficulty])
			ignore = true;

		//set ignored vector for ground truth
		//current class and not ignored (total no. of ground truth is detected for recall denominator)
		if (valid_class == 1 && ignore == false)
		{
			ignored_gt.push_back(0);
			n_gt++;
		}

		//current class but ignored or neighboring class
		else if ((ignore == true && valid_class == 1) || valid_class == 0)
			ignored_gt.push_back(1);

		//all other classes which are FN in the evaluation
		else
			ignored_gt.push_back(-1);
	}

	//extract dontcare areas
	for (int i = 0; i < gt.size(); i++)
		if (!strcmp("DontCare", gt[i].box.type.c_str()))
			dc.push_back(gt[i]);

	//extract detections bounding boxes of the current class
	for (int i = 0; i < det.size(); i++)
	{
		//neighboring classes are not evaluated
		int valid_class;
		if (!strcmp(det[i].box.type.c_str(), CLASS_NAMES[current_class].c_str()))
			valid_class = 1;
		else
			valid_class = -1;

		//set ignored vector for detections
		if (valid_class == 1)
			ignored_det.push_back(0);
		else
			ignored_det.push_back(-1);
	}
}

tPrData computeStatistics(CLASSES current_class, const vector<tGroundtruth> &gt, const vector<tDetection> &det, const vector<tGroundtruth> &dc, const vector<int> &ignored_gt, const vector<int> &ignored_det, bool compute_fp, bool compute_aos, double thresh, bool debug, int im_cnt)
{
	tPrData stat = tPrData();
	const double NO_DETECTION = -10000000;
	vector<double> delta; //holds angular difference for TPs (needed for AOS evaluation)
	vector<bool> assigned_detection; //holds wether a detection was assigned to a valid or ignored ground truth
	assigned_detection.assign(det.size(), false);
	vector<bool> ignored_threshold;
	ignored_threshold.assign(det.size(), false); //holds detections with a threshold lower than thresh if FP are computed

												 //detections with a low score are ignored for computing precision (needs FP)

	if (compute_fp)
	{
		for (int i = 0; i < det.size(); i++)
		{
			if (det[i].thresh < thresh)
			{
				ignored_threshold[i] = true;
			}
		}
	}

	//evaluate all ground truth boxes
	for (int i = 0; i < gt.size(); i++)
	{
		//this ground truth is not of the current or a neighboring class and therefore ignored
		if (ignored_gt[i] == -1)
			continue;

		/*=======================================================================
		find candidates (overlap with ground truth > 0.5) (logical len(det))
		=======================================================================*/
		int det_idx = -1;
		double valid_detection = NO_DETECTION;
		double max_overlap = 0;

		//search for a possible detection
		bool assigned_ignored_det = false;
		for (int j = 0; j < det.size(); j++)
		{
			//detections not of the current class, already assigned or with a low threshold are ignored
			if (ignored_det[j] == -1)
				continue;
			if (assigned_detection[j])
				continue;
			if (ignored_threshold[j])
				continue;

			//find the maximum score for the candidates and get idx of respective detection
			double overlap = boxoverlap(det[j].box, gt[i].box, -1);

			//for computing recall thresholds, the candidate with highest score is considered
			if (!compute_fp && overlap > MIN_OVERLAP[current_class] && det[j].thresh > valid_detection)
			{
				det_idx = j;
				valid_detection = det[j].thresh;
			}

			//for computing pr curve values, the candidate with the greatest overlap is considered
			//if the greatest overlap is an ignored detection (min_height), the overlapping detection is used
			else if (compute_fp && overlap > MIN_OVERLAP[current_class] && (overlap > max_overlap || assigned_ignored_det) && ignored_det[j] == 0)
			{
				max_overlap = overlap;
				det_idx = j;
				valid_detection = 1;
				assigned_ignored_det = false;
			}
			else if (compute_fp && overlap > MIN_OVERLAP[current_class] && valid_detection == NO_DETECTION && ignored_det[j] == 1)
			{
				det_idx = j;
				valid_detection = 1;
				assigned_ignored_det = true;
			}
		}

		/*=======================================================================
		compute TP, FP and FN
		=======================================================================*/

		//nothing was assigned to this valid ground truth
		if (valid_detection == NO_DETECTION && ignored_gt[i] == 0)
		{
			stat.fn++;
		}
		//only evaluate valid ground truth <=> detection assignments (considering difficulty level)
		else if (valid_detection != NO_DETECTION && (ignored_gt[i] == 1 || ignored_det[det_idx] == 1))
			assigned_detection[det_idx] = true;

		//found a valid true positive
		else if (valid_detection != NO_DETECTION)
		{
			//write highest score to threshold vector
			stat.tp++;
			stat.v.push_back(det[det_idx].thresh);

			//compute angular difference of detection and ground truth if valid detection orientation was provided
			if (compute_aos)
				delta.push_back(gt[i].box.alpha - det[det_idx].box.alpha);

			//clean up
			assigned_detection[det_idx] = true;
		}
	}

	//if FP are requested, consider stuff area
	if (compute_fp)
	{
		//count fp
		for (int i = 0; i < det.size(); i++)
		{
			//count false positives if required (height smaller than required is ignored (ignored_det==1)
			if (!(assigned_detection[i] || ignored_det[i] == -1 || ignored_det[i] == 1 || ignored_threshold[i]))
				stat.fp++;
		}

		//do not consider detections overlapping with stuff area
		int nstuff = 0;
		for (int i = 0; i < dc.size(); i++)
		{
			for (int j = 0; j < det.size(); j++)
			{
				//detections not of the current class, already assigned, with a low threshold or a low minimum height are ignored
				if (assigned_detection[j])
					continue;
				if (ignored_det[j] == -1 || ignored_det[j] == 1)
					continue;
				if (ignored_threshold[j])
					continue;

				//compute overlap and assign to stuff area, if overlap exceeds class specific value
				double overlap = boxoverlap(det[j].box, dc[i].box, 0);
				if (overlap > MIN_OVERLAP[current_class])
				{
					assigned_detection[j] = true;
					nstuff++;
				}
			}
		}

		//FP = no. of all not to ground truth assigned detections - detections assigned to stuff areas
		stat.fp -= nstuff;

		//if all orientation values are valid, the AOS is computed
		if (compute_aos)
		{
			vector<double> tmp;

			//FP have a similarity of 0, for all TP compute AOS
			tmp.assign(stat.fp, 0);
			for (int i = 0; i < delta.size(); i++)
				tmp.push_back((1.0 + cos(delta[i])) / 2.0);

			//be sure, that all orientation deltas are computed
			//assert(tmp.size() == stat.fp + stat.tp);
			//assert(delta.size() == stat.tp);

			//get the mean orientation similarity for this image
			if (stat.tp > 0 || stat.fp > 0)
				stat.similarity = accumulate(tmp.begin(), tmp.end(), 0.0);

			//there was neither a FP nor a TP, so the similarity is ignored in the evaluation
			else
				stat.similarity = -1;
		}
	}

	return stat;
}

double boxoverlap(tBox a, tBox b, int criterion)
{
	//overlap is invalid in the beginning
	double o = -1;

	//get overlapping area
	double x1 = max(a.x1, b.x1);
	double y1 = max(a.y1, b.y1);
	double x2 = min(a.x2, b.x2);
	double y2 = min(a.y2, b.y2);

	//compute width and height of overlapping area
	double w = x2 - x1;
	double h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
		return 0;

	//get overlapping areas
	double inter = w*h;
	double a_area = (a.x2 - a.x1) * (a.y2 - a.y1);
	double b_area = (b.x2 - b.x1) * (b.y2 - b.y1);

	//intersection over union overlap depending on users choice
	if (criterion == -1) //union
		o = inter / (a_area + b_area - inter);
	else if (criterion == 0) //bbox_a
		o = inter / a_area;
	else if (criterion == 1) //bbox_b
		o = inter / b_area;

	//overlap
	return o;
}

vector<double> getThresholds(vector<double> &v, double n_groundtruth)
{
	//holds scores needed to compute N_SAMPLE_PTS recall values
	vector<double> t;

	//sort scores in descending order
	//(highest score is assumed to give best/most confident detections)
	//sort(v.begin(), v.end(), greater<double>());
	sort(v.begin(), v.end(), std::greater<double>());

	//get scores for linearly spaced recall
	double current_recall = 0;
	for (int i = 0; i < v.size(); i++)
	{
		//check if right-hand-side recall with respect to current recall is close than left-hand-side one
		//in this case, skip the current detection score
		double l_recall, r_recall, recall;
		l_recall = (double)(i + 1) / n_groundtruth;
		if (i < (v.size() - 1))
			r_recall = (double)(i + 2) / n_groundtruth;
		else
			r_recall = l_recall;

		if ((r_recall - current_recall) < (current_recall - l_recall) && i < (v.size() - 1))
			continue;

		//left recall is the best approximation, so use this and goto next recall step for approximation
		recall = l_recall;

		//the next recall step was reached
		t.push_back(v[i]);
		current_recall += 1.0 / (N_SAMPLE_PTS - 1.0);
	}
	return t;
}

void saveStats(const vector<double> &precision, const vector<double> &aos, FILE *fp_det, FILE *fp_ori)
{
	//save precision to file
	if (precision.empty())
		return;
	for (int i = 0; i < precision.size(); i++)
		fprintf(fp_det, "%f ", precision[i]);
	fprintf(fp_det, "\n");

	//save orientation similarity, only if there were no invalid orientation entries in submission (alpha=-10)
	if (aos.empty())
		return;
	for (int i = 0; i < aos.size(); i++)
		fprintf(fp_ori, "%f ", aos[i]);
	fprintf(fp_ori, "\n");
}

void saveAndPlotPlots(string file_name, vector<double> vals[])
{
	//save plot data to file
	FILE *fp = fopen(file_name.c_str(), "w");
	for (int i = 0; i < (int)N_SAMPLE_PTS; i++)
		fprintf(fp, "%f %f %f %f\n", (double)i / (N_SAMPLE_PTS - 1.0), vals[0][i], vals[1][i], vals[2][i]);
	fclose(fp);
}