#include "cuda_runtime.h"
#include "device_launch_parameters.h"
#include "curand.h"
#include "cublas_v2.h"

extern "C" {
#include <stdio.h>
#include "darknet.h"
}

__global__ void unisem_divide_gpu(float *a, float *b, float *c)
{
	int index = blockIdx.x * blockDim.x + threadIdx.x;
	c[index] = a[index] / b[index];
}

__global__ void unisem_add_gpu(int n, float *a, float *b, float *c)
{
	int index = blockIdx.x * blockDim.x + threadIdx.x;
	int stride = blockDim.x * gridDim.x;
	for (int i = index; i < n; i += stride)
		c[i] = a[i] + b[i];
}

void unisem_gpu_calcFeature(int n_channel, int image_size, float sum, float *feature)
{
	for (int ch = 0; ch < n_channel; ch++)
	{
		for (int id = 0; id < image_size; id++)
		{
			printf("A sum = %f feature[%d] = %f (%d, %d)\n", sum, id, feature[ch*image_size + id], n_channel, image_size);

			feature[ch*image_size + id] /= sum;

			int N = 2048*2048;

			float *a, *b, *c;					//host copies of a, b;
			float *dev_a, *dev_b, *dev_c;	//device copies of a, b, c
			float size = N * sizeof(float);		//we need space for an float

			//allocate device copies of a, b, c
			cudaMalloc( (void**)&dev_a, size);
			cudaMalloc( (void**)&dev_b, size);
			cudaMalloc( (void**)&dev_c, size);

			a = (float*)malloc(size);
			b = (float*)malloc(size);
			c = (float*)malloc(size);
		
			for (int i = 0; i < N; i++)
			{
				a[i] = feature[ch*image_size + id];
				b[i] = sum;			
			}

			//copy inputs to device
			cudaMemcpy(dev_a, &a, size, cudaMemcpyHostToDevice);
			cudaMemcpy(dev_b, &b, size, cudaMemcpyHostToDevice);

			//unisem_divide_gpu<<< N/BLOCK, BLOCK >>>(dev_a, dev_b, dev_c);

			//copy device result back to host copy of c
			cudaMemcpy(&c, dev_c, size, cudaMemcpyDeviceToHost);

			feature[ch*image_size + id] = c[0];

			free(a); 
			free(b);
			free(c);

			cudaFree(dev_a);
			cudaFree(dev_b);
			cudaFree(dev_c);

			printf("B sum = %f feature[%d] = %f (%d, %d)\n", sum, id, feature[ch*image_size + id], n_channel, image_size);
		}
	}
}