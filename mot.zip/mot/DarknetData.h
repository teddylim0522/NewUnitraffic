#pragma once

#include "darknet.h"
#include "common.h"
#include "argv.h"
#include <time.h>
#include <iostream>
#include <winsock2.h>
#include <algorithm>//// 2018.09.03
//#include "license.h" // eyw 2018.09.07
#include <fstream> // 2018.12.13 Osan CCTV
#include <string> //eyw 209.01.07
#include <Windows.h>
#include <vector>
#include <ctime>
#include <process.h>

// opencv
#include <opencv2/opencv.hpp>
#include "opencv/cv.h"
#include "opencv/highgui.h"
using namespace cv;
using namespace std;

#include "param_set.h"       //190322 about parameter functions
#include "CCamPosition.h"    //190325 about camera position 
#include "CRegion.h"         //190401 about regions like line and roi(parking area) 
#include "CViolationCheck.h" //190404 about violation check 

//skkang 20181017 - add h264-RTSP module
#include "../CVideoRTSPDLL/CVideoRTSPDLL.h"

//20190508 tensorflow Test
#include "tf_classifier_hai.h"
#include "cam_define.h"

#define AUTOBIKE_VIOLATION_CODE		00
#define SPEED_VIOLATION_CODE		01
#define SIGNAL_VIOLATION_CODE		02
#define LANE_VIOLATION_CODE			03
#define REVERSE_VIOLATION_CODE		04 //20190523 hai reverse violation
#define ILLEGALPARKING_CODE			20
#define ACCIDENT_CODE				21

#define RIGHT_VIOLATION_AREA		0	//2018.10.24 Young
#define LEFT_VIOLATION_AREA			1
#define NO_VIOLATION_AREA			2
#define NO_DEFINE_AREA				3
#define RELEASE_LANE_VIO			4	// 2018.11.09 hai


#define BOX_W					184
#define BOX_H					72
#define BOX_Y					204

#define SEDAN_X					227
#define SUV_X					417
#define TRUCK_X					609
#define BUS_X					799
#define MOTO_X					989
#define WHEL_X					1179

typedef struct __DataInfo {
	int mJigNum;
	int mData;
	char sData[100];
}DINFO, *PINFO;


class DarknetData
{
public:
	DarknetData();
	~DarknetData();
	void mosaic_draw(IplImage* frame, CvRect _rect);
	void convertimgtoBM(Mat & input_img, Size imageSize, HDC hdc, int offsetX, int offsetY);
public:
	
};

//================ From darknet.cpp ======================
//20190627

bool set_class_id(st_det_mot_param *param);
bool get_param_string(FILE *fp, char *q_string, char *a_string);
bool get_param_string_title(FILE *fp, char *q_string, char *a_string);
bool get_param_int(FILE *fp, char *q_string, int &value);
bool get_param_float(FILE *fp, char *q_string, float &value);
bool get_param_int_array(FILE *fp, char *q_string, int *value, int n);


bool alive_message_send();

extern "C" void free_det_mot_param(st_det_mot_param *param);

extern "C" void make_det_mot_param(st_det_mot_param *param);

extern "C" void run_det_mot(IplImage *frame, st_det_mot_param *param, char *strTitle, st_biker_info *biker_info);//hai 2018.12.12

extern "C" void catch_biker_violation(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line, CRegion* pRegion);

extern "C" void make_biker_info_structure(st_det_mot_param *param, st_biker_info &biker_info);

extern "C" void make_vio_status_structure(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line, CRegion* pRegion);

extern "C" float rect_iou(CvRect a, CvRect b, int type); //2018.10.12 hai

extern "C" bool line_touch(CvRect box, int line);

extern "C" int find_num_rider_histogram(IplImage *res_frame, int nTrackID, st_sub_box_info *sub_box_list); //2018.10.12 hai

extern "C" void biker_violation_draw(IplImage *image, st_violation_info &vio_statu);

extern "C" void biker_violation_save_log(FILE *fp, st_biker_info &biker_info, int nVioIdx, st_violation_info &vio_status, int ch_id, char *time, int nMaxRider);

extern "C" void violation_box_draw_save_image(st_det_mot_param *param, IplImage *ori_image, IplImage *res_image, int nVioIdx, st_violation_info &vio_status); // 2018.10.26

extern "C" char* getStringClassID(int nClassID);

extern "C" bool line_touch_forcounting(CvRect box, int line);

extern "C" void release_lane_violation(st_det_mot_param *param, int nTrackID);

extern "C" void release_reverse_violation(st_det_mot_param *param, int nTrackID); //20190523 hai reverse violation

extern void object_flow_save(FILE *fp, st_mot_info *mot_info, int num, int ch_id, char *time);

extern void violation_text_display(IplImage *image, st_det_mot_param *param, int ntrack, int nTrackID);

//=========================================================