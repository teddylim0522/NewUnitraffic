﻿#include "common.h"
#include "argv.h"
#include "darknet.h"
#include <time.h>
#include <iostream>
#include <winsock2.h>
#include <algorithm>//// 2018.09.03
//#include "license.h" // eyw 2018.09.07
#include <fstream> // 2018.12.13 Osan CCTV
#include <string> //eyw 209.01.07
#include <Windows.h>
#include <vector>
#include <ctime>
#include <process.h>

// opencv
#include <opencv2/opencv.hpp>
#include "opencv/cv.h"
#include "opencv/highgui.h"
using namespace cv;
using namespace std;

#include "param_set.h"       //190322 about parameter functions
#include "CCamPosition.h"    //190325 about camera position 
#include "CRegion.h"         //190401 about regions like line and roi(parking area) 
#include "CViolationCheck.h" //190404 about violation check 

//skkang 20181017 - add h264-RTSP module
#define CVideoRTSPDLL_USE
#ifdef CVideoRTSPDLL_USE
#include "../CVideoRTSPDLL/CVideoRTSPDLL.h"
#endif

#define UNS_SavePictureOnDLL
#ifdef UNS_SavePictureOnDLL
#define _DLL_UNSSAVEPICTURE_AS_EXPLICIT_
#include "../UNSSavePicture/UNSSavePicture.h"
//#define DLL_SAVETEST // to test SAVE All Frames
#endif

//20190508 tensorflow Test
#include "tf_classifier_hai.h"
Classifier m_cClassifier;

#ifdef __cplusplus
extern "C" {
#endif
	extern void object_flow_count_Indo(IplImage *image, st_det_mot_param *param, st_mot_info *mot_info, int num, int n_class, int reset, int line, CRegion* pRegion, HANDLE hSaveImageDLL, Classifier* pClassifier); // 20190102 Indo
	extern void object_flow_count_SmartStore(IplImage *image, st_det_mot_param *param, st_mot_info *mot_info, int num, int n_class, int reset, int line, CRegion* pRegion);
	extern void object_flow_count_AreaCheck(IplImage *res_frame, st_det_mot_param *param, st_mot_info *mot_info, int num, int n_class, int reset, int line, CRegion* pRegion); //20190423 hai Daewoo
	extern void draw_Area(IplImage *res_frame, int nPt1, int nPt2, CRegion* pRegion, bool bEmpty);
#ifdef __cplusplus
}
#endif

extern "C" void make_det_mot_param(st_det_mot_param *param);
extern "C" void free_det_mot_param(st_det_mot_param *param);
//extern "C" void run_det_mot(IplImage *frame, st_det_mot_param *param, char *strTitle);//hai 2018.12.12
extern "C" void run_det_mot(IplImage *frame, st_det_mot_param *param, char *strTitle, st_biker_info *biker_info);//hai 2018.12.12
//extern "C" void traffic_application(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status); // 20190104 OSAN
extern "C" void traffic_application(int frame_time, IplImage *frame, IplImage *res_frame, IplImage *clone_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status
                                    , CCamPosition* pCamPosition, CRegion* pRegion, CVilationCheck* pViolationCheck, IplImage * img_count, HANDLE hSaveImageDLL, Classifier* pClassifier); // 20190104 OSAN
extern "C" bool set_class_id(st_det_mot_param *param);
extern "C" bool get_param_string(FILE *fp, char *q_string, char *a_string);
extern "C" bool get_param_int(FILE *fp, char *q_string, int &value);
extern "C" bool get_param_float(FILE *fp, char *q_string, float &value);
extern "C" bool get_param_int_array(FILE *fp, char *q_string, int *value, int n);

// 2018.10.26 hai
//extern "C" void catch_biker_violation(IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line);
extern "C" void catch_biker_violation(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line, CRegion* pRegion);
extern "C" void make_biker_info_structure(st_det_mot_param *param, st_biker_info &biker_info);
//extern "C" void make_vio_status_structure(IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line);
extern "C" void make_vio_status_structure(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line, CRegion* pRegion);

extern "C" void biker_violation_save(IplImage *ori_image, IplImage *res_image, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, char *buff, HANDLE hSaveImageDLL);

//2018.10.24 hai
//extern "C" void biker_violation_save_log(FILE *fp, st_biker_info &biker_info, st_violation_info &vio_status, int ch_id, char *time, int nMaxRider); 
extern "C" void biker_violation_save_log(FILE *fp, st_biker_info &biker_info, int nVioIdx, st_violation_info &vio_status, int ch_id, char *time, int nMaxRider);
//extern "C" void violation_box_draw_save_image(IplImage *ori_image, IplImage *res_image, st_violation_info &vio_status);
//extern "C" void violation_box_draw_save_image(IplImage *ori_image, IplImage *res_image, int nVioIdx, st_violation_info &vio_status);
extern "C" void violation_box_draw_save_image(st_det_mot_param *param, IplImage *ori_image, IplImage *res_image, int nVioIdx, st_violation_info &vio_status); // 2018.10.26
extern "C" void biker_violation_draw(IplImage *image, st_violation_info &vio_statu);

extern "C" float rect_iou(CvRect a, CvRect b, int type); //2018.10.12 hai
extern "C" bool line_touch(CvRect box, int line);
extern "C" bool line_touch_forcounting(CvRect box, int line); ////=== 0629 edited ===////

extern "C" bool alive_message_send();
extern "C" bool get_param_string_title(FILE *fp, char *q_string, char *a_string);

extern "C" static void onMouse(int event, int x, int y, int flags, void* paramcfg);

extern "C" void wrong_lane_violation(IplImage *frame, IplImage *res_frame, IplImage *clone_frame, st_det_mot_param *param, int ntrack, int nEndY, char * strTime
	                                 , CRegion* pRegion, HANDLE hSaveImageDLL); // 2018.08.08

extern "C" void reverse_violation(IplImage *frame, IplImage *res_frame, IplImage *clone_frame, st_det_mot_param *param, int ntrack, int nEndY, char * strTime
									, CRegion* pRegion, HANDLE hSaveImageDLL); //20190523 hai reverse violation

extern "C" void release_lane_violation(st_det_mot_param *param, int nTrackID);

extern "C" void release_reverse_violation(st_det_mot_param *param, int nTrackID); //20190523 hai reverse violation

extern "C" void convert_2D_to_3D_Box(IplImage *res_frame, CvRect box, CvScalar color);	//2018.08.23

extern "C" int find_min_rider(IplImage *res_frame, int nTrackID, st_sub_box_info *sub_box_list); //// 2018.09.03

extern "C" int find_num_rider_histogram(IplImage *res_frame, int nTrackID, st_sub_box_info *sub_box_list); //2018.10.12 hai

extern "C" bool biker_box_overlap(int nbikerIdx, st_biker_info &biker_info, int nTrackID, st_sub_box_info *sub_box_list); //2018.10.24 hai


extern "C" void getGPUDeviceInfoPrint();
extern "C" char* getStringClassID(int nClassID);

extern "C" void get_all_files_names_within_folder(string folder);
extern "C" string getLicenseFileRead(); //2019.01.07 eyw

extern "C" int main_videolist_Osan(st_det_mot_param *param, st_biker_info* biker_info, CCamPosition* pCamPosition, CRegion* pRegion, CVilationCheck* pViolationCheck, Classifier* pClassifier); //20190108 hai
extern "C" int main_camvideo(st_det_mot_param *param, st_biker_info* biker_info, CCamPosition* pCamPosition, CRegion* pRegion, CVilationCheck* pViolationCheck, Classifier* pClassifier); //20190108 hai
extern "C" int main_camvideo_mylist(st_det_mot_param *param, st_biker_info* biker_info, CCamPosition* pCamPosition, CRegion* pRegion, CVilationCheck* pViolationCheck, Classifier* pClassifier); //20190108 hai

extern "C" void accident_detection(IplImage *frame, IplImage *res_frame, IplImage *clone_frame, st_det_mot_param *param, int nTrackCount, int ntrack, char * strTime, clock_t currentClock
                                   , CRegion* pRegion, HANDLE hSaveImageDLL);

extern "C" void startStatusCallBackFunc();
#define IMAGE_LOAD_FROM_VIDEO	1
#define IMAGE_LOAD_FROM_ID		0

#define AUTOBIKE_VIOLATION_CODE		00
#define SPEED_VIOLATION_CODE		01
#define SIGNAL_VIOLATION_CODE		02
#define LANE_VIOLATION_CODE			03
#define REVERSE_VIOLATION_CODE		04 //20190523 hai reverse violation
#define ILLEGALPARKING_CODE			20
#define ACCIDENT_CODE				21

#define RIGHT_VIOLATION_AREA		0	//2018.10.24 Young
#define LEFT_VIOLATION_AREA			1
#define NO_VIOLATION_AREA			2
#define NO_DEFINE_AREA				3
#define RELEASE_LANE_VIO			4	// 2018.11.09 hai


#define BOX_W					184
#define BOX_H					72
#define BOX_Y					204

#define SEDAN_X					227
#define SUV_X					417
#define TRUCK_X					609
#define BUS_X					799
#define MOTO_X					989
#define WHEL_X					1179

float nHSize, nWSize;

//==== making csv file for bicycle counting ===== 2018.12.12 Osan CCTV
std::ofstream OsanBicycleFile;
//int nFrames;
char result_file_folder[300] = "";
vector<string> video_list, video_name_list;
//float fVideotime = 0;
//===========================================


int nBicycleFlowCount = 0;
int nCarFlowCount = 0;
int nVanFlowCount = 0;
int nBusFlowCount = 0;
int nTruckFlowCount = 0;
int nBikesFlowCount = 0;
int nHumanFlowCount = 0;
int nTruckBikeFlowCount = 0; //20190214 hai TruckBike->Bajaj

//20190423 hai Daewoo
int nCarFlowCount_Total = 22; //20190429
int nVanFlowCount_Total = 16; //20190429
int nCarFlowCount_Daewoo = 0;
int nVanFlowCount_Daewoo = 0;
int nArea1Count = 0; //ptArea 1-2
int nArea2Count = 0; //ptArea 2-3
int nArea4Count = 0; //ptArea 4-5
int nArea5Count = 0; //ptArea 5-6
int nArea6Count = 0; //ptArea 6-7

//20190130 hai for MeanSpeed/Overlay Display
float fTotalSpeed = 0.0;
float fMeanSpeed = 0.0; 
bool bSpeedDisplay = true;
int nObjectforSpeed = 0;
float fOverlay_alpha = 0.3;
float fOverlay_alpha_thick = 0.2;

#include "cam_define.h"

//#define CHECK_LISENCE // License using mode 
#if defined( CHECK_LISENCE)

// 묵시적 라이브러리 
#include "license.h"
#pragma comment(lib,"LicenseDll.lib")
#endif


#pragma comment(linker, "/SUBSYSTEM:windows /ENTRY:mainCRTStartup") // skkang 20181207 - do not create own console

typedef struct __DataInfo {
	int mJigNum;
	int mData;
	char sData[100];
}DINFO, *PINFO;

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage)
	{
		case WM_CREATE:
			return 0;
		case WM_COPYDATA:
		{
			COPYDATASTRUCT *cd;
			cd = (COPYDATASTRUCT*)lParam;
			DINFO myDinfo;
			memcpy(&myDinfo, cd->lpData, sizeof(DINFO));
			printf("code %d size %d data %d %d %s", cd->dwData, cd->cbData, myDinfo.mData, myDinfo.mJigNum, myDinfo.sData);

			return 0;
		}
	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}


void startStatusCallBackFunc()
{
	
		CONST char* lpszClass = PROGRAM_TITLE;
		HINSTANCE hInstance;
		HWND hWnd;
		WNDCLASS WndClass;
		hInstance = GetModuleHandle(NULL);

		WndClass.cbClsExtra = 0;
		WndClass.cbWndExtra = 0;
		WndClass.hbrBackground = NULL;
		WndClass.hCursor = NULL;
		WndClass.hIcon = NULL;
		WndClass.hInstance = hInstance;
		WndClass.lpfnWndProc = WndProc;
		WndClass.lpszClassName = lpszClass;
		WndClass.lpszMenuName = NULL;
		WndClass.style = NULL;
		RegisterClass(&WndClass);

		hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
		//ShowWindow(hWnd, SW_MINIMIZE);
}

int main(int argc, char **argv)
{
	

	//============================================================
	CreateMutex(NULL, true, PROGRAM_TITLE);
	if (GetLastError() == ERROR_ALREADY_EXISTS)
		return 0;

	// skkang 20181207 - check process exists then create console for printf()
	AllocConsole();
	freopen("CONOUT$", "w", stdout);// from now on pirntf() will be wirte on this created console
	HWND console = GetConsoleWindow();
	ShowWindow(console, SW_MINIMIZE);
	SetConsoleTitle(PROGRAM_TITLE);
	
	//RECT r;
	//GetWindowRect(console, &r); //stores the console's current dimensions
	//MoveWindow(console, 1408, 960, 0, 0, TRUE); // 0 width, 0 height - skkang
	//MoveWindow(console, 1408, 960, 704, 100, TRUE); // 704 width, 100 height

	getGPUDeviceInfoPrint();

	startStatusCallBackFunc();	

	int nOperationMode = 1;

#if defined( CHECK_LISENCE)
	// 묵시적 라이브러리 lib, h, dll add
	std::string readFileData = getLicenseFileRead();

	int pro_mode_num = CheckKey_Console(readFileData);
	if (pro_mode_num < 10) {
		std::cout << "License Approved. [" << pro_mode_num << "]" << std::endl;
		nOperationMode = pro_mode_num;
	}
	else {
		string Error = ErrorCodeCheck(pro_mode_num);
		std::cout << "License Check Fail. [" << Error << "]" << std::endl;
		system("pause > null");
		return 0;
	}
#endif

	st_det_mot_param *param = new st_det_mot_param;

	if (!get_parameter(param))
	{
		free_det_mot_param(param);
		return 0;
	}

	setMode(param, nOperationMode);

	makeViolationDirectory(param);

	//cvNamedWindow(PROGRAM_TITLE2);
	cvNamedWindow(PROGRAM_TITLE2, CV_WINDOW_NORMAL); //20190117 hai
	//cvResizeWindow(PROGRAM_TITLE2, param->net.w, param->net.h);

	CRegion* pRegion = new CRegion;
	cvSetMouseCallback(PROGRAM_TITLE2, onMouse, (void*)pRegion);

	CVilationCheck* pViolcationCheck = new CVilationCheck(param);
	st_biker_info biker_info;

	make_det_mot_param(param);
	set_class_id(param);

	pRegion->CRegion_setLine(param->ptLine);
	pRegion->CRegion_setROI(param->ptROI);
	pRegion->CRegion_setRtRedSignalArea(param->rtRedSignalArea);
	pRegion->CRegion_setAREA(param->ptAREA); //20190423 Daewoo
	
	if (!getMode(param, OPERATION_MODE_SIGNAL))
	{
		pViolcationCheck->m_nCheckSignalViolation = 0;
	}
	if (!getMode(param, OPERATION_MODE_STOPLINE))
	{
		pViolcationCheck->m_nCheckStoplineViolation = 0;
	}
	if (!getMode(param, OPERATION_MODE_LANE))
	{
		pViolcationCheck->m_nCheckLaneViolation = 0;
	}
	if (!getMode(param, OPERATION_MODE_SPEED))
	{
		pViolcationCheck->m_nCheckSpeedViolation = 0;
	}
	if (!getMode(param, OPERATION_MODE_BIKE))
	{
		pViolcationCheck->m_nCheckBikeViolation = 0;
	}
	//20190523 hai reverse violation
	if (!getMode(param, OPERATION_MODE_REVERSE))
	{
		pViolcationCheck->m_nCheckReverseViolation = 0;
	}

	cvMoveWindow(PROGRAM_TITLE2, param->nWindowXPostion, param->nWindowYPostion);

	//20190117 hai
	HWND hMainWindow = FindWindow(NULL, PROGRAM_TITLE2);
	//ShowWindow(hMainWindow, SW_SHOWMINIMIZED);

	param_initialize(param, &biker_info);

	//20190402
	//cv::Mat img_count = cv::imread("data\\countInfo.png");

	////=== hai edited ===////
	CCamPosition* pCamPosition = new CCamPosition((void*)param);

	int y1 = pRegion->CRegion_getYwithIndex(1, 0);
	int y2 = pRegion->CRegion_getYwithIndex(1, 2);
	pCamPosition->CCamPosition_SetViolationLine(y1, y2, param->net.h, (void*)param);//함수화

	if (TENSORFLOW_CLASSIFY_USE)
	{
		//20190508 Tensorflow Test
		// Setup inputs and outputs:
		

		std::string model_path = "models/vlp_cr_hai.pb";
		std::string ini_path = "models/vlp_cr_hai.ini";
		m_cClassifier.LoadModel(model_path, ini_path, 3);

		int image_height = m_cClassifier.m_nHeight;	//224 299
		int image_width = m_cClassifier.m_nWidth;

		pred_probs_t result;
		cv::Mat test_input = cv::imread("test_images/2.jpg", CV_LOAD_IMAGE_COLOR);
		cv::cvtColor(test_input, test_input, cv::COLOR_BGR2RGB);
		cv::resize(test_input, test_input, cv::Size(image_width, image_height), 0.0, 0.0, CV_INTER_LINEAR);
		result = m_cClassifier.Run(test_input);

		if (result.pred_prob[0] >= 0.5f)
		{
			std::cout << "recog result : " << result.pred_result << std::endl;
			std::cout << "recog prob : " << result.pred_prob << std::endl;
		}
		else
		{
			std::cout << "model feedforward fail" << std::endl;

			std::cout << "recog result : " << result.pred_result << std::endl;
			std::cout << "recog prob : " << result.pred_prob << std::endl;
		}

		test_input.release();
	}

	//20190108 hai
	if (COUNT_MODE_COUNTRY != 2 && VIDEOLIST_MODE == 1)
	{
		main_camvideo_mylist(param, &biker_info, pCamPosition, pRegion, pViolcationCheck, &m_cClassifier);
		//main_camvideo_mylist(param, &biker_info, pCamPosition, pRegion, pViolcationCheck, &m_cClassifier);
	}
	if (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1 || (COUNT_MODE_COUNTRY == 2 && VIDEOLIST_MODE == 0) || COUNT_MODE_COUNTRY == 3 || COUNT_MODE_COUNTRY == 4)
	{
		main_camvideo(param, &biker_info, pCamPosition, pRegion, pViolcationCheck, &m_cClassifier);
	}
	else if (COUNT_MODE_COUNTRY == 2 && VIDEOLIST_MODE == 1)
	{
		main_videolist_Osan(param, &biker_info, pCamPosition, pRegion, pViolcationCheck, &m_cClassifier);
	}

	//cv::Mat temp_display;
	//char strInfoName[MAX_PATH];
	//wsprintf(strInfoName, "countInfo %s", PROGRAM_TITLE);
	//cvNamedWindow(strInfoName, CV_WINDOW_NORMAL);	// auto resized
	/*if (img_count.size)
	{
		cv::resize(img_count, temp_display, cv::Size(param->net.w, 200), 0, .0, CV_INTER_CUBIC);
		cv::imshow(strInfoName, temp_display);
	}*/

	//deallocation for close 
	if (pViolcationCheck)
	{
		delete pViolcationCheck;
		pViolcationCheck = nullptr;
	}


	if (pRegion)
	{
		delete pRegion;
		pRegion = nullptr;
	}

	if (pCamPosition) //
	{
		delete pCamPosition;
		pCamPosition = nullptr;
	}

	free_det_mot_param(param);
	//cvReleaseImage(&img_count);
	//20190402
	//cvDestroyWindow(strInfoName);

	cvDestroyAllWindows();

	//_endthreadex(0);

	return 0;
}

int main_camvideo(st_det_mot_param *param, st_biker_info* biker_info, CCamPosition* pCamPosition, CRegion* pRegion, CVilationCheck* pViolationCheck, Classifier* pClassifier)
{
	IplImage *frame;
	st_violation_info violation_status;


#if IMAGE_LOAD_FROM_VIDEO
	printf("Camera connecting...");

	//check alive
	alive_message_send();

	//2018.10.26 Young
	//timeout
	CvCapture* capture = cvCaptureFromFile(param->camera_addr);
	if (!capture)
	{
		printf("Camera connection failed.\n");
		
		cvDestroyAllWindows();
		return 0;
	}
	else
		printf("Camera connection success.\n");


#elif IMAGE_LOAD_FROM_ID
	char *image_dir = "D:/Umbrella_Mobile_Images/Mobile_200";
#endif
	int image_cnt = 0;

#ifdef CVideoRTSPDLL_USE //VideoRTSPDLL Load
	bool bIsRTSPOpenSuccess = false;
	CVideoRTSPDLL CVideoRTSPDLL;
	if (CVideoRTSPDLL.CVideoRTSPDLL_LoadRTSPDLL() == nullptr)
	{
		printf("[error] Video Send dll load failed!\n");
	}
	else
	{
		printf("[success] Video Send dll load success!\n");
		CVideoRTSPDLL.CVideoRTSPDLL_Open(param->net.w, param->net.h);
		bIsRTSPOpenSuccess = true;
	}
#endif

#ifdef UNS_SavePictureOnDLL
#ifdef DLL_SAVETEST
	char save_path[CHAR_LENGTH];
	char currentPath[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, currentPath);

	sprintf(save_path, "%s/dllsave", currentPath);
	CreateFolder(save_path, sizeof(save_path));

	sprintf(save_path, "%s/dllsave/%s", currentPath, PROGRAM_TITLE);
	CreateFolder(save_path, sizeof(save_path));
#endif
	HMODULE hMSaveImageDll = nullptr;
	hMSaveImageDll = LoadUNSSAVEPICTUREDll();
	if (hMSaveImageDll == nullptr)
	{
		printf("[error] Image Save on dll load failed!\n");
	}

	// queue size 100,
	HANDLE hSaveImageDll = UNSSAVEPICTURE_Start(10); //check can use save image on dll with this handle
#endif

	if (capture)
	{
		frame = cvQueryFrame(capture);

		if (!frame)
		{
			printf("frame is null.\n");

			cvReleaseCapture(&capture);

			cvDestroyAllWindows();
			//cvReleaseImage(&frame);
			return 0;
		}
	}

	IplImage *resize_image = cvCreateImage(cvSize(param->net.w, param->net.h), frame->depth, frame->nChannels);
	IplImage *yuv_image = cvCreateImage(cvSize(param->net.w, (int)(param->net.h * 1.5f)), frame->depth, CV_8UC1);
	IplImage *clone_frame = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);		//20190327 Hai
		
	if (COUNT_MODE_COUNTRY == 2)
	{
		//==== making csv file for bicycle counting ===== 2018.12.12 Osan CCTV
		//std::ofstream OsanBicycleFile;
		char csvfilename[300];
		CreateFolder("D:/OsanCCTV_Results", 255);
		sprintf(result_file_folder, "D:/OsanCCTV_Results/Images");
		CreateFolder(result_file_folder, sizeof(result_file_folder));
		sprintf(csvfilename, "D:/OsanCCTV_Results/Count.csv");

		OsanBicycleFile.open(csvfilename);
		OsanBicycleFile << "Time,Count,Speed,Object\n";
		//OsanBicycleFile.close();
		//===========================================
	}


	//20190108 hai
	int nFrameCount = 0;
	int nLastFrameNum = 0;

	while (1) 
	{
#if IMAGE_LOAD_FROM_VIDEO
		if (capture)
		{
			frame = cvQueryFrame(capture);
			//frame = cvRetrieveFrame(capture, 0);
		}

		if (!frame)
		{
			printf("frame is null.");

			cvReleaseCapture(&capture);

			cvDestroyAllWindows();
			//cvReleaseImage(&frame);
			return 0;
		}

		bool bFramePass = true;
		double fFPS = cvGetCaptureProperty(capture, CV_CAP_PROP_FPS);
		if (std::isnan(fFPS))
		{
			printf("FPS is Nan\n");

			if (nFrameCount++ % 2)
			{
			}
			else
			{
				bFramePass = false;
			}
		}
		else
		{
			printf("streaming fps %.1f\n", fFPS);

			double fDivide = fFPS / 10.0f;
			//double fDivide = fFPS / 25.0f;

			if (fFPS)
			{
				nFrameCount++;
				if (nFrameCount > fFPS)
					nFrameCount = 0;

				int nFrameNum = 0;
				if(fDivide)
					nFrameNum = (int)((double)nFrameCount / fDivide);

				if (nLastFrameNum != nFrameNum)
				{
					nLastFrameNum = nFrameNum;
				}
				else
				{
					bFramePass = false;
				}
			}	
			else
			{
				//20190430 frame is Null
				cvReleaseCapture(&capture);

				cvDestroyAllWindows();
				return 0;
			}
		}

		if (bFramePass)
		{
			if (param->net.h && param->net.w)
			{
				printf("nHSize %.1f, nHSize %.1f\n", nHSize, nWSize);

				nHSize = (float)frame->height / param->net.h; //20190102 Indo
				nWSize = (float)frame->width / param->net.w; //20190102 Indo				
			}
			else
			{
				printf("[Error] param->net.h, param->net.w\n");

				cvReleaseCapture(&capture);

				cvDestroyAllWindows();
				//cvReleaseImage(&frame);
				return 0;
			}

#elif IMAGE_LOAD_FROM_ID
		char image_path[CHAR_LENGTH];
		sprintf(image_path, "%s/%03d.jpg", image_dir, image_cnt + 1);
		frame = cvLoadImage(image_path, 1);
#endif

		cvResize(frame, resize_image);

		printf("start run_det_mot\n");

		//run_det_mot(resize_image, param, PROGRAM_TITLE);
		run_det_mot(resize_image, param, PROGRAM_TITLE, biker_info); //hai 2018.12.12

		IplImage *img_count = NULL;
		//img_count = cvLoadImage("data\\countInfo.png", 1);
			
		int frame_time = 0;
		traffic_application(frame_time, frame, resize_image, clone_frame, param, *biker_info, violation_status, pCamPosition, pRegion, pViolationCheck, img_count, hSaveImageDll, pClassifier);

		//if (param->show_vioInfo_on && img_count)
		//{
		//	char strInfoName[MAX_PATH];
		//	wsprintf(strInfoName, "countInfo %s", PROGRAM_TITLE);
		//	cvNamedWindow(strInfoName, CV_WINDOW_NORMAL);
		//	//cvResizeWindow(strInfoName, img_count->width / 2, img_count->height / 2);
		//	cvShowImage(strInfoName, img_count);
		//	cvWaitKey(WAIT_KEY);
		//	
		//	//cvReleaseImage(&img_count);
		//}	

		if (!cvGetWindowHandle(PROGRAM_TITLE2)) //skkang 20181210 - check opencv image window alive
			break;

		if (param->show_mot_on)
		{
			if (param->show_vioInfo_on && img_count)
			{
				RECT rect;
				GetWindowRect((HWND)cvGetWindowHandle(PROGRAM_TITLE2), &rect);

				int winWidth = rect.right - rect.left;
				double ratio = 0.0;
				if (img_count->width > winWidth)
				{
					ratio = (double)winWidth / (double)img_count->width;
				}
				else
				{
					ratio = (double)img_count->width / (double)winWidth;
				}

				IplImage *img_count_resize = cvCreateImage(cvSize(resize_image->width, (int)(img_count->height*ratio)), img_count->depth, img_count->nChannels); ;
				IplImage *show_frame = cvCreateImage(cvSize(resize_image->width, resize_image->height + (int)(img_count->height*ratio)), resize_image->depth, resize_image->nChannels); ;
				
				cvSetImageROI(show_frame, cvRect(0, 0, resize_image->width, resize_image->height));
				cvCopy(resize_image, show_frame, NULL);
				cvResetImageROI(show_frame);

				cvResize(img_count, img_count_resize);
				//cvSetImageROI(img_count, cvRect(0, 0, resize_image->width, (int)(img_count->height*ratio)));
				cvSetImageROI(show_frame, cvRect(0, resize_image->height, img_count_resize->width, img_count_resize->height));
				cvCopy(img_count_resize, show_frame, NULL);
				cvResetImageROI(show_frame);

				cvShowImage(PROGRAM_TITLE2, show_frame); // show_frame : mot dectected and violation info concatenate
				
				cvReleaseImage(&img_count_resize);
				cvReleaseImage(&show_frame);
			}
			else
			{
				cvShowImage(PROGRAM_TITLE2, resize_image);
			}
			cvWaitKey(WAIT_KEY);
		}
		if (img_count) cvReleaseImage(&img_count);
		
		image_cnt++;

#ifdef CVideoRTSPDLL_USE
		if (bIsRTSPOpenSuccess)
		{
			cvCvtColor(resize_image, yuv_image, CV_RGB2YUV_YV12);
			CVideoRTSPDLL.CVideoRTSPDLL_PushTo(resize_image->width, resize_image->height, (resize_image->width *resize_image->height * 3 / 2), (unsigned char*)yuv_image->imageData, GET_7FFE008CLOCK_MICROSEC);
		}
#endif

#ifdef DLL_SAVETEST
		//if (image_cnt % 3 == 0)
		{
			char name[MAX_PATH];
			sprintf_s(name, "%s/%s_test_%d.jpg", save_path, PROGRAM_TITLE, image_cnt);
			if (hSaveImageDll) UNSSAVEPICTURE_Save(hSaveImageDll, name, resize_image, 0);
		}
#endif

		//check alive
		alive_message_send();

#if IMAGE_LOAD_FROM_VIDEO

#elif IMAGE_LOAD_FROM_ID
		//cvReleaseImage(&frame);
#endif
		}//bFramePass
	}

	cvReleaseImage(&resize_image);
	cvReleaseImage(&yuv_image);
	cvReleaseImage(&clone_frame);	//20190327 Hai

#ifdef UNS_SavePictureOnDLL
	if (hSaveImageDll) UNSSAVEPICTURE_Stop(hSaveImageDll);
	FreeUNSSAVEPICTUREDll(hMSaveImageDll);
#endif

#ifdef CVideoRTSPDLL_USE
	if (bIsRTSPOpenSuccess)
	{
		CVideoRTSPDLL.CVideoRTSPDLL_Stop();
		CVideoRTSPDLL.CVideoRTSPDLL_Close();
		CVideoRTSPDLL.CVideoRTSPDLL_FreeLoadRTSPDLL();
	}
#endif

#if IMAGE_LOAD_FROM_VIDEO
	cvReleaseCapture(&capture);
#elif IMAGE_LOAD_FROM_ID

#endif

	return 1;
}

int main_camvideo_mylist(st_det_mot_param *param, st_biker_info* biker_info, CCamPosition* pCamPosition, CRegion* pRegion, CVilationCheck* pViolationCheck, Classifier* pClassifier)
{
	IplImage *frame;
	st_violation_info violation_status;
	get_all_files_names_within_folder(param->camera_addr);

	printf("Camera connecting...");

	alive_message_send();

	HANDLE hSaveImageDll = nullptr;
#ifdef UNS_SavePictureOnDLL
	HMODULE hMSaveImageDll = nullptr;
	hMSaveImageDll = LoadUNSSAVEPICTUREDll();
	if (hMSaveImageDll == nullptr)
	{
		printf("[error] Image Save on dll load failed!\n");
	}

	hSaveImageDll = UNSSAVEPICTURE_Start(100); //check can use save image on dll with this handle
#endif

	if (video_list.size() == 0)
		return 0;

	for (int i = 0; i < video_list.size(); i++)
	{
		int nFrames = 0;

		for (int i = 0; i < MAX_TRACK; i++)	////=== hai edited ===////
		{
			param->mot_DataSave[i].nDataSave = 0;
			param->mot_DataSave[i].nTrackCount = 0;
			param->mot_DataSave[i].pIplImage = NULL;

			biker_info->rider_violation_confirm[i] = 0;
			biker_info->helmet_violation_confirm[i] = 0;
			biker_info->TO_violation[i] = 0;

			param->mot_info->object_confirm[i] = 0; ////=== 0629 edited ===////

													// light violation 2018.07.27
			param->mot_LightSave[i].nLightViolation = 0;
			param->mot_LightSave[i].nLightTouch = 0;
			param->mot_LightSave[i].nPassLine = 0;
			param->mot_LightSave[i].pIplImage = NULL;

			// light violation 2018.08.06
			param->mot_LaneSave[i].nLaneViolation = 0;
			param->mot_LaneSave[i].nLPR = 0;
			param->mot_LaneSave[i].nLaneVioCnt = 0;
			param->mot_LaneSave[i].pIplImage = NULL;
			param->mot_LaneSave[i].pLPImage = NULL;
			param->mot_LaneSave[i].nTouchBot = 0;
			param->mot_LaneSave[i].nTouchTop = 0;

			//20190102 Indo
			param->mot_info->object_confirm[i] = 0;
			param->mot_info->TO_object[i] = 0;
		}

		for (int c_id = 0; c_id < param->l.classes - BACKGROUND_CLASS; c_id++)
		{
			param->mot_info->object_flow_number[c_id] = 0;
		}

		printf(video_list[i].c_str());
		CvCapture* capture = cvCreateFileCapture(video_list[i].c_str());

		if (!capture)
		{
			printf("Camera connection failed.");
			cvReleaseCapture(&capture);
			continue;
		}
		else
			printf("Camera connection success.");

		double fps = cvGetCaptureProperty(capture, CV_CAP_PROP_FPS);
		double num_frames = cvGetCaptureProperty(capture, CV_CAP_PROP_FRAME_COUNT);
		float fVideotime = float(num_frames) / float(fps);

		if (capture)
		{
			frame = cvQueryFrame(capture);

			if (!frame)
			{
				printf("frame is null.");
				cvReleaseCapture(&capture);
				continue;
			}
		}

		IplImage *resize_image = cvCreateImage(cvSize(param->net.w, param->net.h), frame->depth, frame->nChannels);
		IplImage *yuv_image = cvCreateImage(cvSize(param->net.w, (int)(param->net.h * 1.5f)), frame->depth, CV_8UC1);
		IplImage *clone_frame = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);		//20190327 Hai

		while (1)
		{
			if (capture)
			{
				frame = cvQueryFrame(capture);
			}


			if (!frame)
			{
				printf("frame is null.");
				cvReleaseCapture(&capture);
				OsanBicycleFile.close(); // 2018.12.3 Osan CCTV

				break;
			}


			nHSize = (float)frame->height / param->net.h;
			nWSize = (float)frame->width / param->net.w;

			int nTest = nFrames % 2;
			if (nTest == 0)
			{
				////check alive
				alive_message_send();

				cvResize(frame, resize_image);

				run_det_mot(resize_image, param, PROGRAM_TITLE, biker_info); //hai 2018.12.12

				int frame_time;
				if (fps > 30.0f)
					frame_time = (int)((float)nFrames * fVideotime / (float)num_frames) * (fps / 30.0f);
				else
					frame_time = (int)((float)nFrames * fVideotime / (float)num_frames);

				IplImage *img_count;
				img_count = cvLoadImage("data\\countInfo.png", 1);

				traffic_application(frame_time, frame, resize_image, clone_frame, param, *biker_info, violation_status, pCamPosition, pRegion, pViolationCheck, img_count, hSaveImageDll, pClassifier); //20190104 OSAN

				if (param->show_mot_on)
				{
					if (!cvGetWindowHandle(PROGRAM_TITLE2)) //skkang 20181210 - check opencv image window alive
						break;

					cvShowImage(PROGRAM_TITLE2, resize_image);

					cvWaitKey(WAIT_KEY);
				}
			}

			nFrames++;

		}

		cvReleaseImage(&resize_image);
		cvReleaseImage(&yuv_image);
		cvReleaseImage(&clone_frame);	//20190327 Hai

#if IMAGE_LOAD_FROM_VIDEO
		cvReleaseCapture(&capture);
#elif IMAGE_LOAD_FROM_ID

#endif

		OsanBicycleFile.close();// 2018.12.3 Osan CCTV
	}

#ifdef UNS_SavePictureOnDLL
	if (hSaveImageDll) UNSSAVEPICTURE_Stop(hSaveImageDll);
#endif

	return 1;
}

//20190108 hai
int main_videolist_Osan(st_det_mot_param *param, st_biker_info* biker_info, CCamPosition* pCamPosition, CRegion* pRegion, CVilationCheck* pViolationCheck, Classifier* pClassifier)
{
	IplImage *frame;
	st_violation_info violation_status;
	get_all_files_names_within_folder(param->camera_addr);

	printf("Camera connecting...");

	alive_message_send();

	HANDLE hSaveImageDll = nullptr;
#ifdef UNS_SavePictureOnDLL
	HMODULE hMSaveImageDll = nullptr;
	hMSaveImageDll = LoadUNSSAVEPICTUREDll();
	if (hMSaveImageDll == nullptr)
	{
		printf("[error] Image Save on dll load failed!\n");
	}

	hSaveImageDll = UNSSAVEPICTURE_Start(100); //check can use save image on dll with this handle
#endif

	//OsanCCTV
	if (video_list.size() == 0)
		return 0;

	for (int i = 0; i < video_list.size(); i++)
	{
		int nFrames = 0;
		nBicycleFlowCount = 0;
		nHumanFlowCount = 0;

		for (int i = 0; i < MAX_TRACK; i++)	////=== hai edited ===////
		{
			param->mot_DataSave[i].nDataSave = 0;
			param->mot_DataSave[i].nTrackCount = 0;
			param->mot_DataSave[i].pIplImage = NULL;

			biker_info->rider_violation_confirm[i] = 0;
			biker_info->helmet_violation_confirm[i] = 0;
			biker_info->TO_violation[i] = 0;

			param->mot_info->object_confirm[i] = 0; ////=== 0629 edited ===////

													// light violation 2018.07.27
			param->mot_LightSave[i].nLightViolation = 0;
			param->mot_LightSave[i].nLightTouch = 0;
			param->mot_LightSave[i].nPassLine = 0;
			param->mot_LightSave[i].pIplImage = NULL;

			// light violation 2018.08.06
			param->mot_LaneSave[i].nLaneViolation = 0;
			param->mot_LaneSave[i].nLPR = 0;
			param->mot_LaneSave[i].nLaneVioCnt = 0;
			param->mot_LaneSave[i].pIplImage = NULL;
			param->mot_LaneSave[i].pLPImage = NULL;
			param->mot_LaneSave[i].nTouchBot = 0;
			param->mot_LaneSave[i].nTouchTop = 0;

			//20190102 Indo
			param->mot_info->object_confirm[i] = 0;
			param->mot_info->TO_object[i] = 0;
		}

		for (int c_id = 0; c_id < param->l.classes - BACKGROUND_CLASS; c_id++)
		{
			param->mot_info->object_flow_number[c_id] = 0;
		}

		printf(video_list[i].c_str());
		CvCapture* capture = cvCreateFileCapture(video_list[i].c_str());

		if (!capture)
		{
			printf("Camera connection failed.");
			cvReleaseCapture(&capture);
			continue;
		}
		else
			printf("Camera connection success.");

		double fps = cvGetCaptureProperty(capture, CV_CAP_PROP_FPS);
		double num_frames = cvGetCaptureProperty(capture, CV_CAP_PROP_FRAME_COUNT);
		float fVideotime = float(num_frames) / float(fps);

		if (capture)
		{
			frame = cvQueryFrame(capture);

			if (!frame)
			{
				printf("frame is null.");
				cvReleaseCapture(&capture);
				continue;
			}
		}

		IplImage *resize_image = cvCreateImage(cvSize(param->net.w, param->net.h), frame->depth, frame->nChannels);
		IplImage *yuv_image = cvCreateImage(cvSize(param->net.w, (int)(param->net.h * 1.5f)), frame->depth, CV_8UC1);
		IplImage *clone_frame = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);		//20190327 Hai

		//==== making csv file for bicycle counting ===== 2018.12.12 Osan CCTV
		//std::ofstream OsanBicycleFile;
		char csvfilename[300];
		CreateFolder("D:/OsanCCTV_Results", 255);
		sprintf(result_file_folder, "D:/OsanCCTV_Results/%s_images", video_name_list[i].c_str());
		CreateFolder(result_file_folder, sizeof(result_file_folder));
		sprintf(csvfilename, "D:/OsanCCTV_Results/%s.csv", video_name_list[i].c_str());

		OsanBicycleFile.open(csvfilename);
		OsanBicycleFile << "Time,Count,Speed,Object\n";
		//OsanBicycleFile.close();
		//===========================================

		while (1) 
		{
			if (capture)
			{
				frame = cvQueryFrame(capture);
			}


			if (!frame)
			{
				printf("frame is null.");
				cvReleaseCapture(&capture);
				OsanBicycleFile.close(); // 2018.12.3 Osan CCTV

				break;
			}


			nHSize = (float)frame->height / param->net.h;
			nWSize = (float)frame->width / param->net.w;

			int nTest = nFrames % 2;
			if (nTest == 0)
			{
				////check alive
				alive_message_send();

				cvResize(frame, resize_image);

				run_det_mot(resize_image, param, PROGRAM_TITLE, biker_info); //hai 2018.12.12

				int frame_time;
				if (fps>30.0f)
					frame_time = (int)((float)nFrames * fVideotime / (float)num_frames) * (fps / 30.0f);
				else
					frame_time = (int)((float)nFrames * fVideotime / (float)num_frames);

				IplImage *img_count;
				img_count = cvLoadImage("data\\countInfo.png", 1);
				
				traffic_application(frame_time, frame, resize_image, clone_frame, param, *biker_info, violation_status, pCamPosition, pRegion, pViolationCheck, img_count, hSaveImageDll, pClassifier); //20190104 OSAN

				if (param->show_mot_on)
				{
					if (!cvGetWindowHandle(PROGRAM_TITLE2)) //skkang 20181210 - check opencv image window alive
						break;

					cvShowImage(PROGRAM_TITLE2, resize_image);

					cvWaitKey(WAIT_KEY);
				}
			}

			nFrames++;

		}

		cvReleaseImage(&resize_image);
		cvReleaseImage(&yuv_image);
		cvReleaseImage(&clone_frame);	//20190327 Hai

#ifdef UNS_SavePictureOnDLL
		if (hSaveImageDll) UNSSAVEPICTURE_Stop(hSaveImageDll);
#endif

#if IMAGE_LOAD_FROM_VIDEO
		cvReleaseCapture(&capture);
#elif IMAGE_LOAD_FROM_ID

#endif

		OsanBicycleFile.close();// 2018.12.3 Osan CCTV

	}
	return 1;
}


void get_all_files_names_within_folder(string folder)
{
	string search_path = folder + "/*.*";
	WIN32_FIND_DATA fd;
	HANDLE hFind = ::FindFirstFile(search_path.c_str(), &fd);
	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			// read all (real) files in current folder
			// , delete '!' read other 2 default folder . and ..
			if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
				video_list.push_back(folder + "/" + fd.cFileName);
				video_name_list.push_back(fd.cFileName);
			}
		} while (::FindNextFile(hFind, &fd));
		::FindClose(hFind);
	}
}


static void onMouse(int event, int x, int y, int flags, void* paramcfg)
{	
	if (paramcfg == nullptr)
	{
		return;
	}

	CRegion* pRegion = (CRegion*)paramcfg;
	//int nSelectedPoint = pRegion->m_nSelectedPoint;

	//CvPoint* ptLine = pRegion->CRegion_getLine();
	//CvPoint* ptROI = pRegion->CRegion_getROI();
	//CvRect rtRedSignalArea = pRegion->CRegion_getRtRedSignalArea();

	int nGap = 10;
	switch (event)
	{
	case CV_EVENT_LBUTTONDBLCLK:
	{

	}
	case CV_EVENT_LBUTTONDOWN:
	{
		if (abs(x - pRegion->m_ptLine[0].x) < nGap && abs(y - pRegion->m_ptLine[0].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 0;
		}
		else if (abs(x - pRegion->m_ptLine[1].x) < nGap && abs(y - pRegion->m_ptLine[1].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 1;
		}
		else if (abs(x - pRegion->m_ptLine[2].x) < nGap && abs(y - pRegion->m_ptLine[2].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 2;
		}
		else if (abs(x - pRegion->m_ptLine[3].x) < nGap && abs(y - pRegion->m_ptLine[3].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 3;
		}
		else if (abs(x - pRegion->m_ptLine[4].x) < nGap && abs(y - pRegion->m_ptLine[4].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 4; //2018.08.08
		}
		else if (abs(x - pRegion->m_ptLine[5].x) < nGap && abs(y - pRegion->m_ptLine[5].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 5; //2018.08.08
		}
		else if (abs(x - (pRegion->m_rtRedSignalArea.x + pRegion->m_rtRedSignalArea.width)) < nGap && abs(y - (pRegion->m_rtRedSignalArea.y + pRegion->m_rtRedSignalArea.height)) < nGap)
		{
			pRegion->m_nSelectedPoint = 7; //2018.08.08
		}
		else if (abs(x - pRegion->m_rtRedSignalArea.x) < nGap && abs(y - pRegion->m_rtRedSignalArea.y) < nGap)
		{
			pRegion->m_nSelectedPoint = 6; //2018.08.08
		}
		//20190213 hai Parking
		else if (abs(x - pRegion->m_ptROI[0].x) < nGap && abs(y - pRegion->m_ptROI[0].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 8;
		}
		else if (abs(x - pRegion->m_ptROI[1].x) < nGap && abs(y - pRegion->m_ptROI[1].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 9;
		}
		else if (abs(x - pRegion->m_ptROI[2].x) < nGap && abs(y - pRegion->m_ptROI[2].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 10;
		}
		else if (abs(x - pRegion->m_ptROI[3].x) < nGap && abs(y - pRegion->m_ptROI[3].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 11;
		}
		//20190423 Daewoo
		else if (abs(x - pRegion->m_ptAREA[0].x) < nGap && abs(y - pRegion->m_ptAREA[0].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 12;
		}
		else if (abs(x - pRegion->m_ptAREA[1].x) < nGap && abs(y - pRegion->m_ptAREA[1].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 13;
		}
		else if (abs(x - pRegion->m_ptAREA[2].x) < nGap && abs(y - pRegion->m_ptAREA[2].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 14;
		}
		else if (abs(x - pRegion->m_ptAREA[3].x) < nGap && abs(y - pRegion->m_ptAREA[3].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 15;
		}
		else if (abs(x - pRegion->m_ptAREA[4].x) < nGap && abs(y - pRegion->m_ptAREA[4].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 16;
		}
		else if (abs(x - pRegion->m_ptAREA[5].x) < nGap && abs(y - pRegion->m_ptAREA[5].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 17;
		}
		else if (abs(x - pRegion->m_ptAREA[6].x) < nGap && abs(y - pRegion->m_ptAREA[6].y) < nGap)
		{
			pRegion->m_nSelectedPoint = 18;
		}
	}
	break;

	case CV_EVENT_LBUTTONUP:
	{
		if (pRegion->m_nSelectedPoint == 0)
		{
			pRegion->CRegion_update_line_points(0);
			pRegion->CRegion_update_line_points(1);
			pRegion->CRegion_update_line_points(4);
		}
		else if (pRegion->m_nSelectedPoint == 1)
		{
			pRegion->CRegion_update_line_points(1);
		}
		else if (pRegion->m_nSelectedPoint == 2)
		{
			pRegion->CRegion_update_line_points(2);
			pRegion->CRegion_update_line_points(3);
			pRegion->CRegion_update_line_points(5);
		}
		else if (pRegion->m_nSelectedPoint == 3)
		{
			pRegion->CRegion_update_line_points(3);
		}
		else if (pRegion->m_nSelectedPoint == 4) //2018.08.08
		{
			pRegion->CRegion_update_line_points(4);
		}
		else if (pRegion->m_nSelectedPoint == 5) //2018.08.08
		{
			pRegion->CRegion_update_line_points(5);
		}
		else if (pRegion->m_nSelectedPoint == 6) //2018.08.08
		{
			char currentPath[MAX_PATH], strIniFilePath[MAX_PATH];
			GetCurrentDirectory(MAX_PATH, currentPath);
			wsprintf(strIniFilePath, "%s\\%s.ini", currentPath, PROGRAM_TITLE);

			char tmp[32]; tmp[0] = '\0';
			_itoa(pRegion->m_rtRedSignalArea.x, (LPSTR)(LPCSTR)tmp, 10);
			WritePrivateProfileString("Position", "SIGNALRED_POINT_X", tmp, strIniFilePath);
			_itoa(pRegion->m_rtRedSignalArea.y, (LPSTR)(LPCSTR)tmp, 10);
			WritePrivateProfileString("Position", "SIGNALRED_POINT_Y", tmp, strIniFilePath);
		}
		else if (pRegion->m_nSelectedPoint == 7) //2018.08.08
		{
			char currentPath[MAX_PATH], strIniFilePath[MAX_PATH];
			GetCurrentDirectory(MAX_PATH, currentPath);
			wsprintf(strIniFilePath, "%s\\%s.ini", currentPath, PROGRAM_TITLE);

			char tmp[32]; tmp[0] = '\0';
			_itoa(pRegion->m_rtRedSignalArea.width, (LPSTR)(LPCSTR)tmp, 10);
			WritePrivateProfileString("Position", "SIGNALRED_POINT_WIDTH", tmp, strIniFilePath);
			_itoa(pRegion->m_rtRedSignalArea.height, (LPSTR)(LPCSTR)tmp, 10);
			WritePrivateProfileString("Position", "SIGNALRED_POINT_HEIGHT", tmp, strIniFilePath);
		}
		//20190213 hai Parking
		else if (pRegion->m_nSelectedPoint == 8)
		{
			pRegion->CRegion_update_ROI_points(0);
		}
		else if (pRegion->m_nSelectedPoint == 9)
		{
			pRegion->CRegion_update_ROI_points(1);
		}
		else if (pRegion->m_nSelectedPoint == 10)
		{
			pRegion->CRegion_update_ROI_points(2);
		}
		else if (pRegion->m_nSelectedPoint == 11)
		{
			pRegion->CRegion_update_ROI_points(3);
		}
		//2019423 Daewoo
		else if (pRegion->m_nSelectedPoint == 12)
		{
			pRegion->CRegion_update_AREA_points(0);
		}
		else if (pRegion->m_nSelectedPoint == 13)
		{
			pRegion->CRegion_update_AREA_points(1);
		}
		else if (pRegion->m_nSelectedPoint == 14)
		{
			pRegion->CRegion_update_AREA_points(2);
		}
		else if (pRegion->m_nSelectedPoint == 15)
		{
			pRegion->CRegion_update_AREA_points(3);
		}
		else if (pRegion->m_nSelectedPoint == 16)
		{
			pRegion->CRegion_update_AREA_points(4);
		}
		else if (pRegion->m_nSelectedPoint == 17)
		{
			pRegion->CRegion_update_AREA_points(5);
		}
		else if (pRegion->m_nSelectedPoint == 18)
		{
			pRegion->CRegion_update_AREA_points(6);
		}
		
		pRegion->m_nSelectedPoint = -1;

	}
	break;
	case CV_EVENT_MOUSEMOVE:
	{
		//if (nSelectedPoint >= 0 && nSelectedPoint < 6) // 2018.08.08
		//{
		//	ptLine[nSelectedPoint].x = x;
		//	ptLine[nSelectedPoint].y = y;
		//}
		//else if (nSelectedPoint == 6) // 2018.08.08
		//{
		//	rtRedSignalArea.x = x;
		//	rtRedSignalArea.y = y;
		//}
		//else if (nSelectedPoint == 7) // 2018.08.08
		//{
		//	rtRedSignalArea.width = abs(rtRedSignalArea.x - x);
		//	rtRedSignalArea.height = abs(rtRedSignalArea.y - y);
		//}

		if (pRegion->m_nSelectedPoint == 0) // 2018.08.08
		{
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].x = x;
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].y = y;
			pRegion->m_ptLine[1].y = pRegion->m_ptLine[0].y;
			pRegion->m_ptLine[4].y = pRegion->m_ptLine[0].y;
		}
		else if (pRegion->m_nSelectedPoint == 2)
		{
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].x = x;
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].y = y;
			pRegion->m_ptLine[3].y = pRegion->m_ptLine[2].y;
			pRegion->m_ptLine[5].y = pRegion->m_ptLine[2].y;
		}
		else if (pRegion->m_nSelectedPoint == 1) // 2018.08.08
		{
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].x = x;
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].y = pRegion->m_ptLine[0].y;
		}
		else if (pRegion->m_nSelectedPoint == 3) // 2018.08.08
		{
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].x = x;
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].y = pRegion->m_ptLine[2].y;
		}
		else if (pRegion->m_nSelectedPoint == 4) // 2018.08.08
		{
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].x = x;
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].y = pRegion->m_ptLine[0].y;
		}
		else if (pRegion->m_nSelectedPoint == 5) // 2018.08.08
		{
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].x = x;
			pRegion->m_ptLine[pRegion->m_nSelectedPoint].y = pRegion->m_ptLine[2].y;
		}
		else if (pRegion->m_nSelectedPoint == 6) // 2018.08.08
		{
			pRegion->m_rtRedSignalArea.x = x;
			pRegion->m_rtRedSignalArea.y = y;
		}
		else if (pRegion->m_nSelectedPoint == 7) // 2018.08.08
		{
			pRegion->m_rtRedSignalArea.width = abs(pRegion->m_rtRedSignalArea.x - x);
			pRegion->m_rtRedSignalArea.height = abs(pRegion->m_rtRedSignalArea.y - y);
		}
		//20190213 hai Parking
		else if (pRegion->m_nSelectedPoint == 8)
		{
			pRegion->m_ptROI[0].x = x;
			pRegion->m_ptROI[0].y = y;

			if (pRegion->m_ptROI[0].x >= pRegion->m_ptROI[1].x) pRegion->m_ptROI[0].x = max(0, pRegion->m_ptROI[1].x - nGap);
			if (pRegion->m_ptROI[0].y >= pRegion->m_ptROI[2].y) pRegion->m_ptROI[0].y = max(0, pRegion->m_ptROI[2].y - nGap);

			pRegion->m_ptROI[1].y = pRegion->m_ptROI[0].y;
		}
		else if (pRegion->m_nSelectedPoint == 9)
		{
			pRegion->m_ptROI[1].x = x;
			pRegion->m_ptROI[1].y = pRegion->m_ptROI[0].y;

			if (pRegion->m_ptROI[1].x <= pRegion->m_ptROI[0].x) pRegion->m_ptROI[1].x = pRegion->m_ptROI[0].x + nGap;
		}
		else if (pRegion->m_nSelectedPoint == 10)
		{
			pRegion->m_ptROI[2].x = x;
			pRegion->m_ptROI[2].y = y;

			if (pRegion->m_ptROI[2].x >= pRegion->m_ptROI[3].x) pRegion->m_ptROI[2].x = max(0, pRegion->m_ptROI[3].x - nGap);
			if (pRegion->m_ptROI[2].y <= pRegion->m_ptROI[0].y) pRegion->m_ptROI[2].y = pRegion->m_ptROI[0].y + nGap;

			pRegion->m_ptROI[3].y = pRegion->m_ptROI[2].y;
		}
		else if (pRegion->m_nSelectedPoint == 11)
		{
			pRegion->m_ptROI[3].x = x;
			pRegion->m_ptROI[3].y = pRegion->m_ptROI[2].y;

			if (pRegion->m_ptROI[3].x <= pRegion->m_ptROI[2].x) pRegion->m_ptROI[3].x = pRegion->m_ptROI[2].x + nGap;
		}
		//20190423 Daewoo
		else if (pRegion->m_nSelectedPoint == 12)
		{
			pRegion->m_ptAREA[0].x = x;
			pRegion->m_ptAREA[0].y = y;

			if (pRegion->m_ptAREA[0].x >= pRegion->m_ptAREA[1].x) pRegion->m_ptAREA[0].x = max(0, pRegion->m_ptAREA[1].x - nGap);

		}
		else if (pRegion->m_nSelectedPoint == 13)
		{
			pRegion->m_ptAREA[1].x = x;
			pRegion->m_ptAREA[1].y = y;

			if (pRegion->m_ptAREA[1].x >= pRegion->m_ptAREA[2].x) pRegion->m_ptAREA[1].x = max(0, pRegion->m_ptAREA[2].x - nGap);
			if (pRegion->m_ptAREA[1].x <= pRegion->m_ptAREA[0].x) pRegion->m_ptAREA[1].x = pRegion->m_ptAREA[0].x + nGap;
		}
		else if (pRegion->m_nSelectedPoint == 14)
		{
			pRegion->m_ptAREA[2].x = x;
			pRegion->m_ptAREA[2].y = y;

			if (pRegion->m_ptAREA[2].x <= pRegion->m_ptAREA[1].x) pRegion->m_ptAREA[2].x = pRegion->m_ptAREA[1].x + nGap;
		}
		else if (pRegion->m_nSelectedPoint == 15)
		{
			pRegion->m_ptAREA[3].x = x;
			pRegion->m_ptAREA[3].y = y;

			if (pRegion->m_ptAREA[3].x >= pRegion->m_ptAREA[4].x) pRegion->m_ptAREA[3].x = max(0, pRegion->m_ptAREA[4].x - nGap);
		}
		else if (pRegion->m_nSelectedPoint == 16)
		{
			pRegion->m_ptAREA[4].x = x;
			pRegion->m_ptAREA[4].y = y;

			if (pRegion->m_ptAREA[4].x >= pRegion->m_ptAREA[5].x) pRegion->m_ptAREA[4].x = max(0, pRegion->m_ptAREA[5].x - nGap);
			if (pRegion->m_ptAREA[4].x <= pRegion->m_ptAREA[3].x) pRegion->m_ptAREA[4].x = pRegion->m_ptAREA[3].x + nGap;
		}
		else if (pRegion->m_nSelectedPoint == 17)
		{
			pRegion->m_ptAREA[5].x = x;
			pRegion->m_ptAREA[5].y = y;

			if (pRegion->m_ptAREA[5].x >= pRegion->m_ptAREA[6].x) pRegion->m_ptAREA[5].x = max(0, pRegion->m_ptAREA[6].x - nGap);
			if (pRegion->m_ptAREA[5].x <= pRegion->m_ptAREA[4].x) pRegion->m_ptAREA[5].x = pRegion->m_ptAREA[4].x + nGap;
		}
		else if (pRegion->m_nSelectedPoint == 18)
		{
			pRegion->m_ptAREA[6].x = x;
			pRegion->m_ptAREA[6].y = y;

			if (pRegion->m_ptAREA[6].x <= pRegion->m_ptAREA[5].x) pRegion->m_ptAREA[6].x = pRegion->m_ptAREA[5].x + nGap;
		}
	}
	break;
	default:
		break;
	}
}

bool alive_message_send()
{
	static int m_nProgramAliveCheckCount = 0;
	//300 frames, 10 seconds
	if (m_nProgramAliveCheckCount++ % 300 == 0)
	{
		HWND pFindWnd = ::FindWindow(NULL, "Observer");
		if (pFindWnd)
		{
			PostMessage(pFindWnd, SEND_ALIVE_MESSAGE, m_nProgramAliveCheckCount, 0);
			m_nProgramAliveCheckCount = 1;
		}
	}

	return true;
}


bool set_class_id(st_det_mot_param *param)
{
	FILE *fp = fopen("class_group.ini", "r");
	if (fp == NULL)
	{
		printf("there is invalid class_group.ini file!!!\n");
		return false;
	}
	if (!get_param_int_array(fp, "CLASS_GROUP_ID", param->class_group_id, param->l.classes))
	{
		fclose(fp);
		return false;
	}
	if (!get_param_int_array(fp, "VIOLATION_HEAD_CLASS", param->vio_head_class, param->n_vio_head_class))
	{
		fclose(fp);
		return false;
	}
	// 2018.09.27 hai
	if (!get_param_int(fp, "VIOLATION_UMBRELLA_CLASS", param->vio_umbrella_class))
	{
		fclose(fp);
		return false;
	}
	// 2018.09.27 hai
	if (!get_param_int(fp, "VIOLATION_MOBILE_CLASS", param->vio_mobile_class))
	{
		fclose(fp);
		return false;
	}
	if (!get_param_int(fp, "REAR_BIKER_ID", param->rear_biker_id))
	{
		fclose(fp);
		return false;
	}
	if (!get_param_int(fp, "BIKER_GROUP_ID", param->biker_group_id))
	{
		fclose(fp);
		return false;
	}
	if (!get_param_int(fp, "HEAD_GROUP_ID", param->head_group_id))
	{
		fclose(fp);
		return false;
	}
	// 2018.09.27 hai
	if (!get_param_int(fp, "UMBRELLA_GROUP_ID", param->umbrella_group_id))
	{
		fclose(fp);
		return false;
	}
	// 2018.09.27 hai
	if (!get_param_int(fp, "MOBILE_GROUP_ID", param->mobile_group_id))
	{
		fclose(fp);
		return false;
	}

	fclose(fp);
	return true;
}

bool get_param_string(FILE *fp, char *q_string, char *a_string)
{
	char tbuf[300];
	char tmp[100];
	fscanf(fp, "%s", tbuf);
	if (strcmp(tbuf, q_string))
	{
		printf("Invalid %s\n", tbuf);
		fclose(fp);
		return false;
	}
	fscanf(fp, "%s", tmp);
	fscanf(fp, " %[^\n]", a_string);
	printf("%s%s%s\n", tbuf, tmp, a_string);
	return true;
}

bool get_param_string_title(FILE *fp, char *q_string, char *a_string)
{
	char tmp[100];

	fscanf(fp, "%s", tmp);

	return true;
}

bool get_param_int(FILE *fp, char *q_string, int &value)
{
	char tbuf[300];
	char tmp[100];
	fscanf(fp, "%s", tbuf);
	if (strcmp(tbuf, q_string))
	{
		printf("Invalid %s\n", tbuf);
		fclose(fp);
		return false;
	}
	fscanf(fp, "%s", tmp);
	fscanf(fp, "%d", &value);
	printf("%s%s%d\n", tbuf, tmp, value);
	return true;
}

bool get_param_float(FILE *fp, char *q_string, float &value)
{
	char tbuf[300];
	char tmp[100];
	fscanf(fp, "%s", tbuf);
	if (strcmp(tbuf, q_string))
	{
		printf("Invalid %s\n", tbuf);
		fclose(fp);
		return false;
	}
	fscanf(fp, "%s", tmp);
	fscanf(fp, "%f", &value);
	printf("%s%s%f\n", tbuf, tmp, value);
	return true;
}

bool get_param_int_array(FILE *fp, char *q_string, int *value, int n)
{
	char tbuf[300];
	char tmp[100];
	fscanf(fp, "%s", tbuf);
	if (strcmp(tbuf, q_string))
	{
		printf("Invalid %s\n", tbuf);
		fclose(fp);
		return false;
	}
	fscanf(fp, "%s", tmp);
	printf("%s%s", tbuf, tmp);
	for (int i = 0; i < n; i++)
	{
		fscanf(fp, "%d", &value[i]);
		printf(" %d", value[i]);
	}
	printf("\n");
	return true;
}

//void traffic_application(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status) //20190104 OSAN
void traffic_application(int frame_time, IplImage *frame, IplImage *res_frame, IplImage *clone_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status
	, CCamPosition* pCamPosition, CRegion* pRegion, CVilationCheck* pViolationCheck, IplImage * img_count, HANDLE hSaveImageDLL, Classifier* pClassifier) //20190104 OSAN
{
	static int b_reset_on = 0, b_reset_trigger_done = 0;
	char buff[80];
	char *stats_file_path = param->stats_result_path;
	int nCheckSignalViolation = pViolationCheck->m_nCheckSignalViolation;
	int nCheckStoplineViolation = pViolationCheck->m_nCheckStoplineViolation;
	//	printf("%s\n", file_path);
	int current_time;
	current_time = get_current_data_time(buff, param->statics_duration);

	//	printf("%s\n", full_file_path);

	if ((current_time == 0) && (b_reset_trigger_done == 0)) {
		b_reset_on = 1;
		b_reset_trigger_done = 1;

		if (param->fp_count != NULL)
		{
			//20190212 hai MeanSpeed Log
			if (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1)
			{
				char textTmp[CHAR_LENGTH] = "";
				char chid_time_Tmp[CHAR_LENGTH] = "";
				sprintf(chid_time_Tmp, "%02d,%s", param->channel_id, param->timeBuf);
				for (int c_id = 0; c_id < UMBRELLA_CLASS_ID - BACKGROUND_CLASS; c_id++)
				{		
					sprintf(textTmp, "%s,%02d,%d", textTmp, c_id, param->mot_info->object_flow_total[c_id]);
					param->mot_info->object_flow_total[c_id] = 0;
				}
				if (param->fp_count)
				{
					fprintf(param->fp_count, "%s%s\n", chid_time_Tmp, textTmp);
					//fprintf(param->fp_count, "%s,99,%04d\n", chid_time_Tmp, (int)(fMeanSpeed*10.0));
					fprintf(param->fp_count, "%s,99,%.2f\n", chid_time_Tmp, fMeanSpeed);
				}

				//fprintf(param->fp_count, "%s,99,%d,%04d\n", chid_time_Tmp, nObjectforSpeed, (int)(fMeanSpeed*10.0));
				fTotalSpeed = 0.0;
				fMeanSpeed = 0.0;
				nObjectforSpeed = 0;
			}

			fclose(param->fp_count);
		}

		//20180723
		FILE *fp = fopen(param->fp_count_end_name, "w");
		if (fp != NULL)
		{
			fclose(fp);
		}
		rename(param->full_stats_file_path_temp, param->full_stats_file_path);

		sprintf(param->full_stats_file_path_temp, "%s/stats_%s_%s.logTemp", stats_file_path, param->camera_id, buff);
		sprintf(param->full_stats_file_path, "%s/stats_%s_%s.log", stats_file_path, param->camera_id, buff);
		//sprintf(param->full_stats_file_path, "%s/speed_%s_%s.log", stats_file_path, param->camera_id, buff); //20190212 hai MeanSpeed log
		sprintf(param->fp_count_end_name, "%s/stats_%s_%s.end", stats_file_path, param->camera_id, buff);
		param->fp_count = fopen(param->full_stats_file_path_temp, "w");
		memcpy(param->timeBuf, buff, sizeof(char) * 80);
	}

	if (current_time != 0) {
		b_reset_trigger_done = 0;
	}
	catch_biker_violation(frame, res_frame, param, biker_info, vio_status, (int)((float)res_frame->height * param->touch_line), pRegion);

	//yk 2018.12.03
	//object_flow_count_forTopline(param->mot_info, param->mot_info->n_track_num, param->l.classes, b_reset_on, (int)((float)res_frame->height * param->top_line));
	//20190115 hai
	//IplImage * count_frame = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);
	//cvCopy(frame, count_frame);
	//if (COUNT_MODE_COUNTRY == 0)
	//{
	//	object_flow_count(param->mot_info, param->mot_info->n_track_num, param->l.classes, b_reset_on, (int)((float)res_frame->height * param->touch_line));
	//}
	//else if (COUNT_MODE_COUNTRY == 1)
	if (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1)
	{
		//object_flow_count_Indo(count_frame, param, param->mot_info, param->mot_info->n_track_num, param->l.classes, b_reset_on, (int)((float)res_frame->height * param->touch_line));
		object_flow_count_Indo(frame, param, param->mot_info, param->mot_info->n_track_num, param->l.classes, b_reset_on, (int)((float)res_frame->height * param->touch_line), pRegion, hSaveImageDLL, pClassifier);
	}
	else if (COUNT_MODE_COUNTRY == 2)
	{
		//object_flow_count_Osan(count_frame, param->mot_info, param->mot_info->n_track_num, param->l.classes, b_reset_on, (int)((float)res_frame->height * param->touch_line));
		object_flow_count_Osan(frame, param->mot_info, param->mot_info->n_track_num, param->l.classes, b_reset_on, (int)((float)res_frame->height * param->touch_line));
	}
	else if (COUNT_MODE_COUNTRY == 3)
	{
		object_flow_count_SmartStore(frame, param, param->mot_info, param->mot_info->n_track_num, param->l.classes, b_reset_on, (int)((float)res_frame->height * param->touch_line), pRegion);
	}
	else if (COUNT_MODE_COUNTRY == 4)
	{
		object_flow_count_AreaCheck(res_frame, param, param->mot_info, param->mot_info->n_track_num, param->l.classes, b_reset_on, (int)((float)res_frame->height * param->touch_line), pRegion);
	}

	//if (count_frame) //20190115 hai
	//	cvReleaseImage(&count_frame);

	//20190520 hai Save helmet-overriding Images // Changed order of steps because of red boxes
	if (b_reset_on == 1) {
		b_reset_on = 0;
	}
	if (param->show_mot_on)
	{	
		//yk 2018.12.03
		//object_flow_draw_forTopline(res_frame, param->mot_info, param->l.classes, param->names, (int)((float)res_frame->height * param->top_line));
		object_flow_draw(res_frame, param->mot_info, param->l.classes, param->names, (int)((float)res_frame->height * param->touch_line), img_count);
		biker_violation_draw(res_frame, vio_status);
	}

//	memset(frame->imageData, 0, frame->width * (int)(frame->height * param->top_line) * 3);	//hai 2018.11.30
	
	if (COUNT_MODE_COUNTRY != 3 && COUNT_MODE_COUNTRY != 4) // 20190423 Daewoo
		object_flow_save(param->fp_count, param->mot_info, param->l.classes, param->channel_id, buff);

	//20190115 hai
	//IplImage * biker_violation_frame = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);
	//cvCopy(frame, biker_violation_frame);

	//biker_violation_save(biker_violation_frame, res_frame, param, biker_info, vio_status, buff);
	biker_violation_save(frame, res_frame, param, biker_info, vio_status, buff, hSaveImageDLL);
	//if (biker_violation_frame)//20190115 hai
		//cvReleaseImage(&biker_violation_frame);


#if 0
	if (param->b_vio_end)
	{
		FILE *fp = fopen(param->fp_count_end_name, "w");
		fclose(fp);
		param->b_vio_end = false;
	}

#endif
	if (param->show_mot_on)
	{
		//font
		char textTmp[CHAR_LENGTH];
		CvFont font;
		//cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.7, 0.7, 0, 2, 1);
		cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.5, 0.5, 0, 1, 1); //20190222 hai Class color
		CvFont fontViolation;
		//cvInitFont(&fontViolation, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.7, 0.7, 0, 2, 1);
		cvInitFont(&fontViolation, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.5, 0.5, 0, 2, 1); //20190222 hai Violation color

		//violation line
		int y0 = pRegion->CRegion_getYwithIndex(1, 0);
		int y2 = pRegion->CRegion_getYwithIndex(1, 2);
		pCamPosition->CCamPosition_SetViolationLine(y0, y2, res_frame->height, (void*)param);
		int nStartY = pCamPosition->CCamPosition_GetStartY();//함수화
		int nEndY = pCamPosition->CCamPosition_GetEndY();//함수화
		int nDiffEndYStartY = nEndY - nStartY;
		
		if (COUNT_MODE_COUNTRY != 4) //20190423 hai Daewoo
		{
			cvLine(res_frame, cvPoint(0, nStartY), cvPoint(res_frame->width - 1, nStartY), cvScalar(0, 0, 255, 0), 2, 7, 0);
			cvLine(res_frame, cvPoint(0, nEndY), cvPoint(res_frame->width - 1, nEndY), cvScalar(0, 0, 255, 0), 2, 7, 0);
		}

		CvRect rtSelect[12]; //201902 Parking
		CvRect rtDaewoo[7]; //20190423 Daewoo
		int nIsRedSignal = 0;
		if (pViolationCheck->m_nCheckSignalViolation || pViolationCheck->m_nCheckStoplineViolation)
		{
			//Red Signal			
			CvRect rtRedSignalArea = pRegion->CRegion_getRtRedSignalArea();
			cvRectangleR(res_frame, rtRedSignalArea, cvScalar(0, 0, 255, 0), 1, 1, 0);
			if (rtRedSignalArea.width > 0)
			{
				IplImage* HSVframe = cvCreateImage(cvGetSize(res_frame), res_frame->depth, 3);
				cvCvtColor(res_frame, HSVframe, CV_BGR2HSV);

				int nRedCount = 0;
				int nStartY = rtRedSignalArea.y;
				int nStartX = rtRedSignalArea.x;
				int nEndY = (rtRedSignalArea.y + rtRedSignalArea.height);
				int nEndX = (rtRedSignalArea.x + rtRedSignalArea.width);
				int nAreaSize = rtRedSignalArea.width * rtRedSignalArea.height;
				int nTH = 20;
				int bB = 0, bG = 0, bR = 0;
				int bH = 0, bS = 0, bV = 0;
				for (int nY = nStartY; nY < nEndY; nY++)
					for (int nX = nStartX; nX < nEndX; nX++)
					{
						int nIndex = (res_frame->widthStep)* nY + nX * res_frame->nChannels;

						bB = ((uchar *)(res_frame->imageData))[nIndex + 0];
						bG = ((uchar *)(res_frame->imageData))[nIndex + 1];
						bR = ((uchar *)(res_frame->imageData))[nIndex + 2];

						bH = ((uchar *)(HSVframe->imageData))[nIndex + 0];
						bS = ((uchar *)(HSVframe->imageData))[nIndex + 1];
						bV = ((uchar *)(HSVframe->imageData))[nIndex + 2];
					
						/*int nIndex = (nY * res_frame->width + nX) * res_frame->nChannels;

						bB = (int)res_frame->imageData[nIndex + 0];
						bG = (int)res_frame->imageData[nIndex + 1];
						bR = (int)res_frame->imageData[nIndex + 2];

						bH = (int)HSVframe->imageData[nIndex + 0];
						bS = (int)HSVframe->imageData[nIndex + 1];
						bV = (int)HSVframe->imageData[nIndex + 2];*/

						//BGR
						//if (bR > bG + nTH && bR > bB + nTH)
						//HSV , Red Hue is 160 ~ 10 (Range 0~180)
						if (((bH > 0 && bH < 10) || (bH > 170 && bH < 180)) && bR > bG + nTH && bR > bB + nTH)						
						//if (((bH >= 0 && bH < 10) || (bH > 170 && bH <= 180)) && bR > bG + nTH && bR > bB + nTH)
							//if ((bH > 0 && bH<10) || (bH > 160 && bH<180))
							nRedCount++;
					}

				cvReleaseImage(&HSVframe);
				HSVframe = NULL;

				// if overlap area is 10 percent or more, than Red Signal.			
				if ((nRedCount > nAreaSize / 20 || nRedCount > 100) && nAreaSize > 50)
					nIsRedSignal = 1;

				if (nIsRedSignal)
				{
					sprintf(textTmp, "[Red] %d", nRedCount);
					cvPutText(res_frame, textTmp, cvPoint(rtRedSignalArea.x - 40, rtRedSignalArea.y), &font, cvScalar(0, 0, 255));
				}
				else
				{
					sprintf(textTmp, "%d", nRedCount);
					cvPutText(res_frame, textTmp, cvPoint(rtRedSignalArea.x - 40, rtRedSignalArea.y), &font, cvScalar(255, 255, 255));
				}
			}

			// 2018.08.08
			rtSelect[6].x = rtRedSignalArea.x;
			rtSelect[6].y = rtRedSignalArea.y;
			rtSelect[6].width = 10;
			rtSelect[6].height = 10;
			cvRectangleR(res_frame, rtSelect[6], cvScalar(0, 0, 255, 0), 3, 1, 0);
			cvPutText(res_frame, "6", cvPoint(rtSelect[6].x, rtSelect[6].y - 5), &font, cvScalar(255, 255, 255));

			rtSelect[7].x = rtRedSignalArea.x + rtRedSignalArea.width - 10;
			rtSelect[7].y = rtRedSignalArea.y + rtRedSignalArea.height - 10;
			rtSelect[7].width = 10;
			rtSelect[7].height = 10;
			cvRectangleR(res_frame, rtSelect[7], cvScalar(0, 0, 255, 0), 3, 1, 0);
			cvPutText(res_frame, "7", cvPoint(rtSelect[7].x, rtSelect[7].y - 5), &font, cvScalar(255, 255, 255));
		}
		

		if (COUNT_MODE_COUNTRY != 4) //20190423 hai Daewoo
		{
			cvLine(res_frame, pRegion->CRegion_setPoint(1, 0), pRegion->CRegion_setPoint(1, 2), cvScalar(0, 255, 255, 0), 2, 7, 0);

			cvLine(res_frame, pRegion->CRegion_setPoint(1, 1), pRegion->CRegion_setPoint(1, 3), cvScalar(0, 255, 255, 0), 2, 7, 0); // 2018.08.08

			cvLine(res_frame, pRegion->CRegion_setPoint(1, 4), pRegion->CRegion_setPoint(1, 5), cvScalar(0, 255, 255, 0), 2, 7, 0); // 2018.08.08

			for (int nPtSelect = 0; nPtSelect < 6; nPtSelect++) // 2018.08.08
			{
				rtSelect[nPtSelect].x = pRegion->CRegion_getXwithIndex(1, nPtSelect);
				rtSelect[nPtSelect].y = pRegion->CRegion_getYwithIndex(1, nPtSelect);
				rtSelect[nPtSelect].width = 10;
				rtSelect[nPtSelect].height = 10;

				//if(nPtSelect % 2 == 0) // 2018.08.08
				cvRectangleR(res_frame, rtSelect[nPtSelect], cvScalar(0, 0, 255, 0), 3, 1, 0);

				// kyk 20180813
				if (nPtSelect == 0 || nPtSelect == 2)
					sprintf(textTmp, "M%d", nPtSelect);
				else if (nPtSelect == 1 || nPtSelect == 3)
					sprintf(textTmp, "L%d", nPtSelect);
				else
					sprintf(textTmp, "R%d", nPtSelect);
				cvPutText(res_frame, textTmp, cvPoint(rtSelect[nPtSelect].x, rtSelect[nPtSelect].y - 5), &font, cvScalar(255, 255, 255));
			}
		}
		else
		{
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 0), pRegion->CRegion_setPoint(3, 1), cvScalar(224, 224, 224, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 1), pRegion->CRegion_setPoint(3, 2), cvScalar(224, 224, 224, 0), 2, 7, 0);

			cvLine(res_frame, pRegion->CRegion_setPoint(3, 0), cvPoint((pRegion->CRegion_setPoint(3, 0)).x, 0), cvScalar(224, 224, 224, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 1), cvPoint((pRegion->CRegion_setPoint(3, 1)).x, 0), cvScalar(224, 224, 224, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 2), cvPoint((pRegion->CRegion_setPoint(3, 2)).x, 0), cvScalar(224, 224, 224, 0), 2, 7, 0);

			cvLine(res_frame, pRegion->CRegion_setPoint(3, 3), pRegion->CRegion_setPoint(3, 4), cvScalar(224, 224, 224, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 4), pRegion->CRegion_setPoint(3, 5), cvScalar(224, 224, 224, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 5), pRegion->CRegion_setPoint(3, 6), cvScalar(224, 224, 224, 0), 2, 7, 0);

			cvLine(res_frame, pRegion->CRegion_setPoint(3, 3), cvPoint((pRegion->CRegion_setPoint(3, 3)).x, res_frame->height - 1), cvScalar(224, 224, 224, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 4), cvPoint((pRegion->CRegion_setPoint(3, 4)).x, res_frame->height - 1), cvScalar(224, 224, 224, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 5), cvPoint((pRegion->CRegion_setPoint(3, 5)).x, res_frame->height - 1), cvScalar(224, 224, 224, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(3, 6), cvPoint((pRegion->CRegion_setPoint(3, 6)).x, res_frame->height - 1), cvScalar(224, 224, 224, 0), 2, 7, 0);

			for (int nPtSelect = 0; nPtSelect < 7; nPtSelect++) // 2018.08.08
			{
				rtDaewoo[nPtSelect].x = pRegion->CRegion_getXwithIndex(3, nPtSelect);
				rtDaewoo[nPtSelect].y = pRegion->CRegion_getYwithIndex(3, nPtSelect);
				rtDaewoo[nPtSelect].width = 7;
				rtDaewoo[nPtSelect].height = 7;

				//if(nPtSelect % 2 == 0) // 2018.08.08
				cvRectangleR(res_frame, rtDaewoo[nPtSelect], cvScalar(200, 200, 200, 0), 2, 1, 0);
			}
		}

		//20190213 hai Parking
		if ((COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1) && param->nIllegalTime)
		{
			cvLine(res_frame, pRegion->CRegion_setPoint(2, 0), pRegion->CRegion_setPoint(2, 1), cvScalar(255, 0, 0, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(2, 0), pRegion->CRegion_setPoint(2, 2), cvScalar(255, 0, 0, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(2, 1), pRegion->CRegion_setPoint(2, 3), cvScalar(255, 0, 0, 0), 2, 7, 0);
			cvLine(res_frame, pRegion->CRegion_setPoint(2, 2), pRegion->CRegion_setPoint(2, 3), cvScalar(255, 0, 0, 0), 2, 7, 0);

			for (int nPtSelect = 0; nPtSelect < 4; nPtSelect++)
			{
				rtSelect[nPtSelect + 8].x = pRegion->CRegion_getXwithIndex(2, nPtSelect);
				rtSelect[nPtSelect + 8].y = pRegion->CRegion_getYwithIndex(2, nPtSelect);
				rtSelect[nPtSelect + 8].width = 10;
				rtSelect[nPtSelect + 8].height = 10;

				//if(nPtSelect % 2 == 0) // 2018.08.08
				cvRectangleR(res_frame, rtSelect[nPtSelect + 8], cvScalar(255, 0, 0, 0), 2, 1, 0);
			}
			sprintf(textTmp, "Illegal Area");
			cvPutText(res_frame, textTmp, cvPoint(rtSelect[10].x, rtSelect[10].y - 7), &fontViolation, cvScalar(255, 255, 255));
		}

		char *vio_file_path = param->vio_result_path;
		char strTime[TIME_BUFF_LENGTH];
		char full_save_image_path[CHAR_LENGTH], full_log_file_path[CHAR_LENGTH];
		sprintf(full_log_file_path, "%s/speed/Log", vio_file_path);
		CreateFolder(full_log_file_path, sizeof(full_log_file_path));

		//current time
		int current_time;
		//current_time = get_current_data_time(strTime, param->statics_duration);
		current_time = get_current_data_time(strTime, "M");

		clock_t currentClock = clock();

		static int m_prevTime = 0;
		static int m_nFrameRate = 0;
		static int nFinalFrameRate = 0;
		if (m_nFrameRate++ == 0)
		{
			m_prevTime = current_time;
		}
		else if (m_prevTime != current_time)
		{
			nFinalFrameRate = m_nFrameRate;
			m_prevTime = current_time;
			m_nFrameRate = 0;
		}

		//total track num
		bool bLogSave = false;
		float fFinalDistance = 0.0f;
		float fRealDistanceDirect = param->fRealDistance;
		float fRealDistanceM = pCamPosition->CCamPosition_GetRealDistance();////=== hai edited ===////
		float fTrackPtReal;
		float fViolationSpeed = param->fViolationSpeed;
		float fMinimumSpeed = param->fMinimumSpeed; //20190213 hai Minimum Speed
		int nMaxSpeed = 180;
		int nGap = 100;
		int nTrackNum = param->mot_info->n_track_num;

		int nCheckSpeedViolation = param->nCheckSpeedViolation;
		if (!getMode(param, OPERATION_MODE_SPEED))
		{
			nCheckSpeedViolation = 0;
		}

		int nCheckBikeViolation = param->nCheckBikeViolation;
		if (!getMode(param, OPERATION_MODE_BIKE))
		{
			nCheckBikeViolation = 0;
		}

		// kyk 20180813
		char strText[30];
		memset(strText, 0, sizeof(char) * 30);
		if (pViolationCheck->m_nCheckBikeViolation)
			strcat(strText, "[Bike]");
		if (pViolationCheck->m_nCheckSignalViolation)
			strcat(strText, "[Signal]");
		if (pViolationCheck->m_nCheckStoplineViolation)
			strcat(strText, "[Stopline]");
		if (pViolationCheck->m_nCheckLaneViolation)
			strcat(strText, "[Lane]");
		//20190523 hai reverse violation
		if (pViolationCheck->m_nCheckReverseViolation)
			strcat(strText, "[Reverse]");
		if (pViolationCheck->m_nCheckSpeedViolation)
			strcat(strText, "[Spd]");
		else
			strcat(strText, "[Display]");
		

		//sprintf(textTmp, "%s, fps%d, Dis%.1fm, Spd%.1f", strText, nFinalFrameRate, (fTouchReal - fTopReal), fViolationSpeed); ////=== hai edited ===////

/*		sprintf(textTmp, "%s, fps%d, Spd%.1f", strText, nFinalFrameRate, fViolationSpeed); ////=== hai edited ===////
		CvRect rtDraw;
		rtDraw.x = 0;
		rtDraw.y = res_frame->height - 50;
		rtDraw.width = res_frame->width;
		rtDraw.height = 20;

		IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);
		cvCopy(res_frame, overlay_frame);
		cvRectangleR(res_frame, rtDraw, cvScalar(0, 255, 255), CV_FILLED);
		cvAddWeighted(overlay_frame, fOverlay_alpha, res_frame, 1 - fOverlay_alpha, 0, res_frame);
		if (overlay_frame)
			cvReleaseImage(&overlay_frame);

		cvPutText(res_frame, textTmp, cvPoint(10, res_frame->height - 40), &font, cvScalar(255, 255, 255));
*/
		//sprintf(textTmp, "Human %d", m_nFlowCountTotal);
		//cvPutText(res_frame, textTmp, cvPoint(10, res_frame->height - 80), &font, cvScalar(255, 255, 255));

		CvRect rectArea;
		CvRect fullRect;
		float fXRate, fYRate;
		fXRate = (float)frame->width / (float)res_frame->width;
		fYRate = (float)frame->height / (float)res_frame->height;

		pRegion->CRegion_calculate_line_params(); //20190213 hai
		for (int t = 0; t < nTrackNum; t++)
		{
			//20190115 hai
			//IplImage * clone_frame = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);
			//cvCopy(frame, clone_frame);

			int nClassID = param->mot_info->mot_box_info[t].class_id;
			int nTrackID = param->mot_info->mot_box_info[t].track_id;

			int nTrackCount = param->mot_DataSave[nTrackID].nTrackCount;	////=== hai edited ===////
			int nDataSave = param->mot_DataSave[nTrackID].nDataSave;		////=== hai edited ===////

			int nPtBottomX = param->mot_info->mot_box_info[t].bouding_box.x + (param->mot_info->mot_box_info[t].bouding_box.width / 2);
			int nPtBottomY = param->mot_info->mot_box_info[t].bouding_box.y + (param->mot_info->mot_box_info[t].bouding_box.height);
			int nBoxWidth = param->mot_info->mot_box_info[t].bouding_box.width;
			int nBoxHeight = param->mot_info->mot_box_info[t].bouding_box.height;

			float fScore = param->mot_info->det_box_info[t].score;

			if (param->mot_info->mot_box_info[t].class_id == HUMAN_CLASS_ID)
			{
				//human count
				CvPoint ptDetectLine[2];
				ptDetectLine[0] = pRegion->m_ptLine[0];
				ptDetectLine[1] = pRegion->m_ptLine[2];
				pRegion->CRegion_line_touch_count(param->mot_info->mot_box_info[t].bouding_box, ptDetectLine, nTrackID); //20180904
			}

			//20190108 hai
			if (nBoxHeight < (int)(res_frame->height*0.8f) && nBoxWidth < (int)(res_frame->width*0.8f) &&
				((param->mot_info->mot_box_info[t].class_id != HUMAN_CLASS_ID && param->mot_info->mot_box_info[t].class_id != BICYCLE_CLASS_ID && (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1) && nBoxHeight < LIMITED_WIDTH && nBoxWidth < LIMITED_HEIGHT)
					|| (COUNT_MODE_COUNTRY == 2) || (COUNT_MODE_COUNTRY == 3) || (COUNT_MODE_COUNTRY == 4))) //OSanCCTV, Daewoo
				//&& nBoxHeight < LIMITED_WIDTH && nBoxWidth < LIMITED_HEIGHT)	//indonesia demo
			{
				// wrong lane violation 2018.08.08
				// kyk 20180813
				if (pViolationCheck->m_nCheckLaneViolation && pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) != NO_VIOLATION_AREA)
					wrong_lane_violation(frame, res_frame, clone_frame, param, t, nEndY, strTime, pRegion, hSaveImageDLL); //20190115 hai
				//20190523 hai reverse violation
				if (pViolationCheck->m_nCheckReverseViolation && pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) != NO_VIOLATION_AREA)
					reverse_violation(frame, res_frame, clone_frame, param, t, nEndY, strTime, pRegion, hSaveImageDLL); 

				//else if (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY) == NO_VIOLATION_AREA)
				//{
				//	std::cout << "NO_VIOLATION_AREA " << nPtBottomX << "," << nPtBottomY << std::endl;
				//}

				//20190213 hai accident detection/Illegal Parking 
				accident_detection(frame, res_frame, clone_frame, param, nTrackCount, t, strTime, currentClock, pRegion, hSaveImageDLL);

				// Light signal violation 2018.07.27
				if (nCheckStoplineViolation && pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) != NO_VIOLATION_AREA)
				{
					int nPtTopY = param->mot_info->mot_box_info[t].bouding_box.y;

					if (pRegion->CRegion_line_touch_forLightVio_stop(nPtBottomY, nBoxWidth, nEndY) && param->mot_LightSave[nTrackID].nLightTouch == 0 && nIsRedSignal == 1)
					{
						param->mot_LightSave[nTrackID].nPassLine = 1;
					}

					if (pRegion->CRegion_line_touch_forLightVio_start(nPtTopY, nPtBottomY, nEndY) && param->mot_LightSave[nTrackID].nLightTouch == 0
						&& param->mot_LightSave[nTrackID].nPassLine == 0 && nIsRedSignal == 1)
					{
						std::cout << "touch light" << std::endl;
						param->mot_LightSave[nTrackID].nLightTouch = 1;

						if (!param->mot_LightSave[nTrackID].pIplImage)
							param->mot_LightSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

						cvCopy(frame, param->mot_LightSave[nTrackID].pIplImage);
						param->mot_LightSave[nTrackID].diffTime = currentClock;
					}
					else if (pRegion->CRegion_line_touch_forLightVio_start(nPtTopY, nPtBottomY, nEndY) && param->mot_LightSave[nTrackID].nLightTouch == 0
						&& param->mot_LightSave[nTrackID].nPassLine == 1 && nIsRedSignal == 1)
					{
						param->mot_LightSave[nTrackID].nLightTouch = 0;
						param->mot_LightSave[nTrackID].nPassLine = 0;

					}

					if (param->mot_LightSave[nTrackID].nLightTouch == 1 && param->mot_LightSave[nTrackID].nPassLine == 0 && nIsRedSignal == 1)
					{
						if (pRegion->CRegion_line_touch_forLightVio_stop(nPtBottomY, nBoxWidth, nEndY))
						{
							std::cout << "passed light" << std::endl;
							param->mot_LightSave[nTrackID].nPassLine = 1;
						}
					}
					else if (param->mot_LightSave[nTrackID].nLightTouch == 1 && param->mot_LightSave[nTrackID].nPassLine == 0 && nIsRedSignal == 0)
					{
						param->mot_LightSave[nTrackID].nLightTouch = 0;
						param->mot_LightSave[nTrackID].nPassLine = 0;
						cvReleaseImage(&param->mot_LightSave[nTrackID].pIplImage);
						param->mot_LightSave[nTrackID].pIplImage = NULL;
					}

					if (param->mot_LightSave[nTrackID].nLightTouch == 1 && param->mot_LightSave[nTrackID].nPassLine == 1 && nIsRedSignal == 1)
					{
						int millisecond = (int)((float)(currentClock - param->mot_LightSave[nTrackID].diffTime) / CLOCKS_PER_SEC * 100.0f) % 100;

						int seconds = (int)(currentClock - param->mot_LightSave[nTrackID].diffTime) / CLOCKS_PER_SEC;

						if (seconds <= 90)
						{
							fullRect.x      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.x		* fXRate);
							fullRect.width  = (int)((float)param->mot_info->mot_box_info[t].bouding_box.width	* fXRate);
							fullRect.y      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.y		* fYRate);
							fullRect.height = (int)((float)param->mot_info->mot_box_info[t].bouding_box.height	* fYRate);

							rectArea = fullRect;
							rectArea.y = rectArea.y + rectArea.height * 1 / 3;
							rectArea.height = rectArea.height * 2 / 3;

							//cvRectangleR(frame, rectArea, param->track_color[nTrackID], 2, 1, 0);
							//cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);
							//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

							if (clone_frame)
							{
								//20190327 Hai
								cvCopy(frame, clone_frame);
								//cvRectangleR(clone_frame, rectArea, param->vio_color[SIGNAL_VIOLATION_CLR], 2, 1, 0);
								cvRectangleR(clone_frame, fullRect, param->vio_color[SIGNAL_VIOLATION_CLR], 2, 1, 0);
							}
							else
							{
								//20190222 hai Violation color
								//cvRectangleR(frame, rectArea, param->vio_color[SIGNAL_VIOLATION_CLR], 2, 1, 0);
								cvRectangleR(frame, fullRect, param->vio_color[SIGNAL_VIOLATION_CLR], 2, 1, 0);
							}														

							sprintf(full_save_image_path, "%s/signalTemp/%02d_%s_%02d_000_%s%02d_01.jpg", vio_file_path, SIGNAL_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
							if(JPG_SAVE_ENABLE)
								if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_LightSave[nTrackID].pIplImage, 0);

							cvReleaseImage(&param->mot_LightSave[nTrackID].pIplImage);
							param->mot_LightSave[nTrackID].pIplImage = NULL;

							sprintf(full_save_image_path, "%s/signalTemp/%02d_%s_%02d_000_%s%02d_02.jpg", vio_file_path, SIGNAL_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
							if (clone_frame)
							{
								if (JPG_SAVE_ENABLE)
									if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
							}
							else
							{
								if (JPG_SAVE_ENABLE)
									if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
							}
								
							//CvRect rectArea = param->mot_LightSave[nTrackID].object_box;
							if (fullRect.x > 50 && fullRect.x + fullRect.width < frame->width - 50)
							{
								sprintf(full_save_image_path, "%s/lpr/input/02_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
								if (JPG_SAVE_ENABLE)
									if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
							}
							else
							{
								sprintf(full_save_image_path, "%s/lpr/input/02_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
								if (JPG_SAVE_ENABLE)
									if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
							}

							param->mot_LightSave[nTrackID].nLightTouch = 0;
							param->mot_LightSave[nTrackID].nPassLine = 0;

							std::cout << "light violation" << std::endl;
						}
						else
						{
							cvReleaseImage(&param->mot_LightSave[nTrackID].pIplImage);
							param->mot_LightSave[nTrackID].pIplImage = NULL;
							param->mot_LightSave[nTrackID].nLightTouch = 0;
							param->mot_LightSave[nTrackID].nPassLine = 0;
						}
					}
				}
				//else if (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY) == NO_VIOLATION_AREA)
				//{
				//	std::cout << "NO_VIOLATION_AREA " << nPtBottomX << "," << nPtBottomY << std::endl;
				//}

				//// over speed ////
				//if (param->mot_DataSave[nTrackID].nTrackCount < MAX_TRACK_COUNT && pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) != NO_VIOLATION_AREA)	
				if (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) != NO_VIOLATION_AREA)
				{
					float fSpeed = 0.0f;
					if (nDataSave > 0)
					{
						float fDiffTime = abs((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / (float)CLOCKS_PER_SEC);
						fTrackPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[nTrackCount - 1].y);
						if (nDataSave == 1)
						{
							float fTopPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[0].y);
							fFinalDistance = abs(fTrackPtReal - fTopPtReal);
						}
						else if (nDataSave == 2)
						{
							float fTouchPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[0].y);
							fFinalDistance = abs(fTouchPtReal - fTrackPtReal);
						}
						else
							fFinalDistance = 0;

						fSpeed = fFinalDistance / fDiffTime * 3.6f;
						//display
						if ((int)fSpeed > 0)
						{
							//sprintf(textTmp, "[%s]%dkm/h[%d][%.1f][%.1fs,%.1fm]", getStringClassID(nClassID), (int)fSpeed, nTrackID, fScore, fDiffTime, fFinalDistance);
							//sprintf(textTmp, "[%s]%dkm/h[%.1fm]", getStringClassID(nClassID), (int)fSpeed, fFinalDistance);
	
							if (COUNT_MODE_COUNTRY == 3 || COUNT_MODE_COUNTRY == 4) //20190423
							{
								//20190429
								if (param->mot_info->mot_box_info[t].bouding_box.height >= (res_frame->height/ 5)) 
								{
									sprintf(textTmp, "[%s]", getStringClassID(TRUCK_CLASS_ID));
								}
								else
								{
									sprintf(textTmp, "[%s]", getStringClassID(nClassID));
								}

								//sprintf(textTmp, "[%s]", getStringClassID(nClassID));

								if (nClassID == 2)
									nClassID = 1;

								CvRect rtLabel = param->mot_info->mot_box_info[t].bouding_box;
								rtLabel.y -= 10;
								rtLabel.height = 10;

								if (COUNT_MODE_COUNTRY != 4) //20190423 Daewoo
									if (param->mot_info->mot_box_info[t].bouding_box.height >= (res_frame->height / 5)) //20190429
										cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &fontViolation, param->class_color[TRUCK_CLASS_ID]);
									else
										cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &fontViolation, param->class_color[nClassID]);
							}
							else
							{
								sprintf(textTmp, "[%s]%dkm/h", getStringClassID(nClassID), (int)fSpeed);
							}

							//20190213 hai Minimum Speed
							if (fSpeed <= fMinimumSpeed && (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
							{
								IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);
								cvCopy(res_frame, overlay_frame);
								//cvRectangleR(overlay_frame, param->mot_info->mot_box_info[t].bouding_box, param->track_color[nTrackID], -1);

								//20190222 hai Violaton color
								//cvPutText(res_frame, textTmp, cvPoint(nPtBottomX, nPtBottomY + 20), &fontViolation, param->class_color[param->mot_info->mot_box_info[t].class_id]);
								cvRectangleR(overlay_frame, param->mot_info->mot_box_info[t].bouding_box, param->vio_color[LOW_SPEED_CLR], -1); 
								cvAddWeighted(overlay_frame, fOverlay_alpha, res_frame, 1 - fOverlay_alpha, 0, res_frame);

								param->mot_DataSave[nTrackID].nVioDisplay[LOW_SPEED_CLR] = 1;
								violation_text_display(res_frame, param, t, nTrackID);
								//char textVio[CHAR_LENGTH];
								//sprintf(textVio, "SPEED");
								//cvPutText(res_frame, textVio, cvPoint((int)param->mot_info->mot_box_info[t].bouding_box.x, (int)param->mot_info->mot_box_info[t].bouding_box.y), &fontViolation, param->vio_color[LOW_SPEED_CLR]); //20190222 hai Violation color

								if (overlay_frame)
									cvReleaseImage(&overlay_frame);
							}
							else //20190222
							{
								param->mot_DataSave[nTrackID].nVioDisplay[LOW_SPEED_CLR] = 0;
							}
						}
						else
						{
							//sprintf(textTmp, "[%s][Id%d]", getStringClassID(nClassID), nTrackID);
							//20190429
							if (param->mot_info->mot_box_info[t].bouding_box.height >= (res_frame->height / 5) && (COUNT_MODE_COUNTRY == 3 || COUNT_MODE_COUNTRY == 4))
							{
								sprintf(textTmp, "[%s]", getStringClassID(TRUCK_CLASS_ID));
							}
							else
							{
								sprintf(textTmp, "[%s]", getStringClassID(nClassID));
							}
							//sprintf(textTmp, "[%s]", getStringClassID(nClassID));

							if (COUNT_MODE_COUNTRY == 3 || COUNT_MODE_COUNTRY == 4)
							{
								if (nClassID == 2)
									nClassID = 1;

								CvRect rtLabel = param->mot_info->mot_box_info[t].bouding_box;
								rtLabel.y -= 10;
								rtLabel.height = 10;
								if(COUNT_MODE_COUNTRY != 4) //20190423 Daewoo
									if (param->mot_info->mot_box_info[t].bouding_box.height >= (res_frame->height / 5)) //20190429
										cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &fontViolation, param->class_color[TRUCK_CLASS_ID]);
									else
										cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &fontViolation, param->class_color[nClassID]);
							}

							param->mot_DataSave[nTrackID].nVioDisplay[LOW_SPEED_CLR] = 0; //2019022
							param->mot_DataSave[nTrackID].nVioDisplay[OVER_SPEED_CLR] = 0; //2019022
						}
					}
					else
					{
						//display //yk 2018.12.03
						//sprintf(textTmp, "[%s][Id%d]", getStringClassID(nClassID), nTrackID);
						//20190429
						if(param->mot_info->mot_box_info[t].bouding_box.height >= (res_frame->height / 5) && (COUNT_MODE_COUNTRY == 3 || COUNT_MODE_COUNTRY == 4))
						{
							sprintf(textTmp, "[%s]", getStringClassID(TRUCK_CLASS_ID));
						}
						else
						{
							sprintf(textTmp, "[%s]", getStringClassID(nClassID));
						}
						//sprintf(textTmp, "[%s]", getStringClassID(nClassID));

						if (COUNT_MODE_COUNTRY == 3 || COUNT_MODE_COUNTRY == 4)
						{
							if (nClassID == 2)
								nClassID = 1;

							CvRect rtLabel = param->mot_info->mot_box_info[t].bouding_box;
							rtLabel.y -= 10;
							rtLabel.height = 10;
							if (COUNT_MODE_COUNTRY != 4) //20190423 Daewoo
								if (param->mot_info->mot_box_info[t].bouding_box.height >= (res_frame->height / 5)) //20190429
									cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &fontViolation, param->class_color[TRUCK_CLASS_ID]);
								else
									cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &fontViolation, param->class_color[nClassID]);
						}

						param->mot_DataSave[nTrackID].nVioDisplay[LOW_SPEED_CLR] = 0; //2019022
						param->mot_DataSave[nTrackID].nVioDisplay[OVER_SPEED_CLR] = 0; //2019022
					}

					if (fSpeed >= fViolationSpeed)
					{
						//20180823 test 3D box
						//convert_2D_to_3D_Box(res_frame, param->mot_info->mot_box_info[t].bouding_box, cvScalar(0, 0, 255, 0));
						if (((nClassID == BICYCLE_CLASS_ID || nClassID == HUMAN_CLASS_ID) && COUNT_MODE_COUNTRY == 2) || (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
						{
							//cvPutText(res_frame, textTmp, cvPoint(nPtBottomX, nPtBottomY + 20), &fontViolation, cvScalar(0, 0, 255, 0));
							//cvRectangleR(res_frame, param->mot_info->mot_box_info[t].bouding_box, cvScalar(0, 0, 255, 0), 3, 1, 0);

							//20190222 hai Violation color
							//cvPutText(res_frame, textTmp, cvPoint(nPtBottomX, nPtBottomY + 20), &fontViolation, param->class_color[param->mot_info->mot_box_info[t].class_id]);
							//cvRectangleR(res_frame, param->mot_info->mot_box_info[t].bouding_box, param->vio_color[OVER_SPEED_CLR], 2, 1, 0); 

							IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);
							cvCopy(res_frame, overlay_frame);
							cvRectangleR(overlay_frame, param->mot_info->mot_box_info[t].bouding_box, param->vio_color[OVER_SPEED_CLR], -1); //20190222 hai Violaton color

							CvRect rtLabel = param->mot_info->mot_box_info[t].bouding_box;
							rtLabel.y -= 10;
							rtLabel.height = 10;
							cvRectangleR(overlay_frame, rtLabel, cvScalar(255, 255, 255, 0), -1); //20190402

							cvAddWeighted(overlay_frame, fOverlay_alpha_thick, res_frame, 1 - fOverlay_alpha_thick, 0, res_frame);

							param->mot_DataSave[nTrackID].nVioDisplay[OVER_SPEED_CLR] = 1; //2019022
							violation_text_display(res_frame, param, t, nTrackID);
							//char textVio[CHAR_LENGTH];
							//sprintf(textVio, "SPEED");
							//cvPutText(res_frame, textVio, cvPoint((int)param->mot_info->mot_box_info[t].bouding_box.x, (int)param->mot_info->mot_box_info[t].bouding_box.y), &fontViolation, param->vio_color[OVER_SPEED_CLR]); //20190222 hai Violation color

							if (overlay_frame)
								cvReleaseImage(&overlay_frame);

							//cvPutText(res_frame, textTmp, cvPoint(nPtBottomX, nPtBottomY + 20), &fontViolation, cvScalar(0, 0, 255, 0));
							//cvRectangleR(res_frame, param->mot_info->mot_box_info[t].bouding_box, cvScalar(0, 0, 255, 0), 3, 1, 0);

							//20190222 hai Violation color
							cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &fontViolation, param->class_color[param->mot_info->mot_box_info[t].class_id]);
							//cvRectangleR(res_frame, param->mot_info->mot_box_info[t].bouding_box, param->vio_color[OVER_SPEED_CLR], 2, 1, 0); 

						}
					}
					else
					{
						//20180823 test 3D box
						//convert_2D_to_3D_Box(res_frame, param->mot_info->mot_box_info[t].bouding_box, param->track_color[nTrackID]);

						if (((nClassID == BICYCLE_CLASS_ID || nClassID == HUMAN_CLASS_ID) && COUNT_MODE_COUNTRY == 2) || (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
						{
							IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);
							cvCopy(res_frame, overlay_frame);

							CvRect rtLabel = param->mot_info->mot_box_info[t].bouding_box;
							rtLabel.y -= 10;
							rtLabel.height = 10;
							cvRectangleR(overlay_frame, rtLabel, cvScalar(255, 255, 255, 0), -1); //20190402
							cvAddWeighted(overlay_frame, fOverlay_alpha_thick, res_frame, 1 - fOverlay_alpha_thick, 0, res_frame);

							if (overlay_frame)
								cvReleaseImage(&overlay_frame);

							//cvPutText(res_frame, textTmp, cvPoint(nPtBottomX, nPtBottomY + 20), &font, param->track_color[nTrackID]);
							//cvRectangleR(res_frame, param->mot_info->mot_box_info[t].bouding_box, param->track_color[nTrackID], 1, 1, 0);

							param->mot_DataSave[nTrackID].nVioDisplay[OVER_SPEED_CLR] = 0; //2019022
							//20190222 hai Class color
							if (param->mot_DataSave[nTrackID].nVioDisplay[LOW_SPEED_CLR] || param->mot_DataSave[nTrackID].nVioDisplay[ILLEGAL_PARKING_CLR] || param->mot_DataSave[nTrackID].nVioDisplay[LANE_VIOLATION_CLR])
								cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &fontViolation, param->class_color[param->mot_info->mot_box_info[t].class_id]);
							else
								cvPutText(res_frame, textTmp, cvPoint(rtLabel.x, nPtBottomY + 20), &font, param->class_color[param->mot_info->mot_box_info[t].class_id]);

							cvRectangleR(res_frame, param->mot_info->mot_box_info[t].bouding_box, param->class_color[param->mot_info->mot_box_info[t].class_id], 1, 1, 0);
						}
					}

					if (nStartY < nPtBottomY && nEndY > nPtBottomY)
					{
						//Tracking...
						if (nDataSave > 0)
						{
							if (param->mot_info->mot_box_info[t].class_id == 10 || param->mot_info->mot_box_info[t].class_id == 11) //20190110
								printf("TRACKING for Bicycle/Human nTrackID = %d\n", nTrackID);

							param->mot_DataSave[nTrackID].track_pt[nTrackCount].x = nPtBottomX;		////=== hai edited ===////
							param->mot_DataSave[nTrackID].track_pt[nTrackCount].y = nPtBottomY;		////=== hai edited ===////
							if (nTrackCount >= 1)
								param->mot_DataSave[nTrackID].track_box[nTrackCount] = param->mot_info->mot_box_info[t].bouding_box;

							memcpy(param->mot_DataSave[nTrackID].timeStr[nTrackCount], strTime, sizeof(char) * TIME_BUFF_LENGTH);	////=== hai edited ===////
							param->mot_DataSave[nTrackID].diffTime[nTrackCount] = currentClock;

							//Tracking Count
							param->mot_DataSave[nTrackID].nTrackCount++;					////=== hai edited ===////
							if (param->mot_DataSave[nTrackID].nTrackCount >= MAX_TRACK_COUNT)
								param->mot_DataSave[nTrackID].nTrackCount = MAX_TRACK_COUNT-1;	//20190406

							if (COUNT_MODE_COUNTRY != 3)
							{
								for (int i = 0; i < param->mot_DataSave[nTrackID].nTrackCount; i++)					////=== hai edited ===////
								{
									//cvCircle(res_frame, cvPoint(param->mot_DataSave[nTrackID].track_pt[i].x, param->mot_DataSave[nTrackID].track_pt[i].y), 1, param->track_color[nTrackID], 1, 8, 0);	////=== hai edited ===////
									cvCircle(res_frame, cvPoint(param->mot_DataSave[nTrackID].track_pt[i].x, param->mot_DataSave[nTrackID].track_pt[i].y), 1,
										param->class_color[param->mot_info->mot_box_info[t].class_id], 1, 8, 0);
								}
							}
						}

						//Entry Start
						if (nStartY + nGap > nPtBottomY)
						{
							if (nDataSave == 0)
							{
								if (param->mot_info->mot_box_info[t].class_id == 10 || param->mot_info->mot_box_info[t].class_id == 11) //20190110
									printf("ENTRY START for Bicycle/Human nTrackID = %d\n", nTrackID);
								
								param->mot_DataSave[nTrackID].nDataSave = 1;					////=== hai edited ===////

								fullRect.x      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.x       * fXRate);
								fullRect.width  = (int)((float)param->mot_info->mot_box_info[t].bouding_box.width	* fXRate);
								fullRect.y      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.y       * fYRate);
								fullRect.height = (int)((float)param->mot_info->mot_box_info[t].bouding_box.height	* fYRate);
								//cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);
								//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

								if (clone_frame)
								{
									//20190327 Hai
									cvCopy(frame, clone_frame);
									cvRectangleR(clone_frame, fullRect, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
								}
								else
								{
									//20190222 hai Violation Color
									cvRectangleR(frame, fullRect, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
								}															

								if (!param->mot_DataSave[nTrackID].pIplImage)
									param->mot_DataSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

								if (clone_frame)
									cvCopy(clone_frame, param->mot_DataSave[nTrackID].pIplImage);
								else
									cvCopy(frame, param->mot_DataSave[nTrackID].pIplImage);
							}
						}
						//Exit Start
						else if (nEndY - nGap < nPtBottomY)
						{
							if (nDataSave == 0)
							{
								if (param->mot_info->mot_box_info[t].class_id == 10 || param->mot_info->mot_box_info[t].class_id == 11) //20190110
									printf("EXIT START for Bicycle/Human nTrackID = %d\n", nTrackID);

								param->mot_DataSave[nTrackID].nDataSave = 2;					////=== hai edited ===////

								fullRect.x      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.x		* fXRate);
								fullRect.width  = (int)((float)param->mot_info->mot_box_info[t].bouding_box.width	* fXRate);
								fullRect.y      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.y		* fYRate);
								fullRect.height = (int)((float)param->mot_info->mot_box_info[t].bouding_box.height	* fYRate);
								
								rectArea = fullRect;
								rectArea.y = rectArea.y + rectArea.height * 1 / 3;
								rectArea.height = rectArea.height * 2 / 3;

								param->mot_DataSave[nTrackID].track_box[0] = rectArea;
								param->mot_DataSave[nTrackID].nIsRedSignal = nIsRedSignal;

								//cvRectangleR(frame, rectArea, param->track_color[nTrackID], 2, 1, 0);
								//cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);
								//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

								if (clone_frame)
								{
									//20190327 Hai
									cvCopy(frame, clone_frame);
									//cvRectangleR(clone_frame, rectArea, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
									cvRectangleR(clone_frame, fullRect, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
								}
								{
									//20190222 hai Violation color
									//cvRectangleR(frame, rectArea, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
									cvRectangleR(frame, fullRect, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
								}																		

								if (!param->mot_DataSave[nTrackID].pIplImage)
									param->mot_DataSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

								if (clone_frame)
									cvCopy(clone_frame, param->mot_DataSave[nTrackID].pIplImage);
								else
									cvCopy(frame, param->mot_DataSave[nTrackID].pIplImage);
							}
						}
					}

					//Entry End
					if (nEndY < nPtBottomY && nEndY + nGap > nPtBottomY)
					{
						if (nDataSave == 1)
						{
							if (param->mot_info->mot_box_info[t].class_id == 10 || param->mot_info->mot_box_info[t].class_id == 11) //20190110
								printf("ENTRY END for Bicycle/Human nTrackID = %d\n", nTrackID);

							if (param->mot_DataSave[nTrackID].pIplImage)
							{
								float fDiffTime = (float)(param->mot_DataSave[nTrackID].diffTime[nTrackCount - 1] - param->mot_DataSave[nTrackID].diffTime[0]) / (float)CLOCKS_PER_SEC;
								int nDiffPixel = abs(param->mot_DataSave[nTrackID].track_pt[nTrackCount - 1].y - param->mot_DataSave[nTrackID].track_pt[0].y);

								////=== hai edited ===////
								float fTouchPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[nTrackCount - 1].y);
								float fTopPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[0].y);
								float fDistanceReal = fTouchPtReal - fTopPtReal;
								float fSpeed = fDistanceReal / fDiffTime * 3.6f;

								if (fSpeed < 0)
								{
									printf("SPEED DISPLAY for Bicycle/Human nTrackID = %d, nTrackCount = %d, Speed = %d\n", nTrackID, nTrackCount, (int)fSpeed);
								}

								if (nIsRedSignal && param->mot_DataSave[nTrackID].nIsRedSignal)
								{

								}

								//20190130 hai for MeanSpeed Display
								if (nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT
									&& (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
								{
									nObjectforSpeed++;
									fTotalSpeed += fSpeed;
								}

								//20190213 hai Minimum Speed
								if (nCheckSpeedViolation && fSpeed > 0 && fSpeed <= fMinimumSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT
									&& (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1) && (nTrackNum < 10 || (fTotalSpeed / nObjectforSpeed > fMinimumSpeed && nTrackNum >= 10)))
								{
									fullRect.x      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.x		* fXRate);
									fullRect.width  = (int)((float)param->mot_info->mot_box_info[t].bouding_box.width	* fXRate);
									fullRect.y      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.y		* fYRate);
									fullRect.height = (int)((float)param->mot_info->mot_box_info[t].bouding_box.height	* fYRate);

									//cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);
									//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

									if (clone_frame)
									{
										//20190327 Hai
										cvCopy(frame, clone_frame);
										cvRectangleR(clone_frame, fullRect, param->vio_color[LOW_SPEED_CLR], 2, 1, 0);
									}
									else
									{
										//20190222 hai Violation color
										cvRectangleR(frame, fullRect, param->vio_color[LOW_SPEED_CLR], 2, 1, 0);
									}										
										
									//printf("%.3f, %.3f, %d", (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC, (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f, (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100);
									int currentMs = (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100;

									CvRect rectArea = fullRect;
									rectArea.y = rectArea.y + rectArea.height * 1 / 3;
									rectArea.height = rectArea.height * 2 / 3;

									if (rectArea.x > 50 && rectArea.x + rectArea.width < frame->width - 50)
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}
									else
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}

									sprintf(full_save_image_path, "%s/speedTemp/%02d_%s_%02d_%03d_%s%02d_01.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);

									if (param->mot_DataSave[nTrackID].pIplImage)
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);
										cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
										param->mot_DataSave[nTrackID].pIplImage = NULL;
									}
										

									sprintf(full_save_image_path, "%s/speedTemp/%02d_%s_%02d_%03d_%s%02d_02.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
									if (clone_frame)
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
									}
									else
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}
								}

								//OverSpeed
								if (nCheckSpeedViolation && fSpeed >= fViolationSpeed && nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel 
									&& nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT 
									&& (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1) )
								{
									fullRect.x      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.x		* fXRate);
									fullRect.width  = (int)((float)param->mot_info->mot_box_info[t].bouding_box.width	* fXRate);
									fullRect.y      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.y		* fYRate);
									fullRect.height = (int)((float)param->mot_info->mot_box_info[t].bouding_box.height	* fYRate);

									//cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);
									//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

									if (clone_frame)
									{
										//20190327 Hai
										cvCopy(frame, clone_frame);
										cvRectangleR(clone_frame, fullRect, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
									}
									else
									{
										//20190222 hai Violation Color
										cvRectangleR(frame, fullRect, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
									}																			

									//printf("%.3f, %.3f, %d", (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC, (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f, (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100);
									int currentMs = (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100;

									CvRect rectArea = fullRect;
									rectArea.y = rectArea.y + rectArea.height * 1 / 3;
									rectArea.height = rectArea.height * 2 / 3;

									if (rectArea.x > 50 && rectArea.x + rectArea.width < frame->width - 50)
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}
									else
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}

									sprintf(full_save_image_path, "%s/speedTemp/%02d_%s_%02d_%03d_%s%02d_01.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
										
									if (param->mot_DataSave[nTrackID].pIplImage)
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);
										cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
										param->mot_DataSave[nTrackID].pIplImage = NULL;
									}
										

									sprintf(full_save_image_path, "%s/speedTemp/%02d_%s_%02d_%03d_%s%02d_02.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
									if (clone_frame)
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
									}
									else
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}

									//log
									FILE *fp = NULL;
									if (bLogSave)
									{
										sprintf(full_log_file_path, "%s/%02d_%s_%02d_%03d_%s%02d_02_Tid%d_Entry.log", full_log_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, nTrackID);
										fp = fopen(full_log_file_path, "a");
									}

									for (int i = 1; i < param->mot_DataSave[nTrackID].nTrackCount; i++)					////=== hai edited ===////
									{
										fDiffTime = (float)(param->mot_DataSave[nTrackID].diffTime[i] - param->mot_DataSave[nTrackID].diffTime[0]) / (float)CLOCKS_PER_SEC;
										//fFinalDistance = fRealDistanceM * ((float)(param->mot_DataSave[nTrackID].track_pt[i].y - nStartY) / (float)(nDiffEndYStartY));

										fTrackPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[i].y); ////=== hai edited ===////
										fFinalDistance = fTrackPtReal - fTopPtReal;////=== hai edited ===////

										fSpeed = fFinalDistance / fDiffTime * 3.6f;
										nDiffPixel = abs(param->mot_DataSave[nTrackID].track_pt[i].y - param->mot_DataSave[nTrackID].track_pt[i - 1].y);

										if (bLogSave)
										{
											if (fp)
											{
												sprintf(textTmp, "[%s][Time%.3f][Speed%3.1f][Distance%3.1fm][TrackCount %dof%d](%d %d)[diffPixel %d]",
													param->mot_DataSave[nTrackID].timeStr[i], fDiffTime, fSpeed, fFinalDistance,
													i, param->mot_DataSave[nTrackID].nTrackCount,
													param->mot_DataSave[nTrackID].track_pt[i].x, param->mot_DataSave[nTrackID].track_pt[i].y, nDiffPixel);
												fprintf(fp, "[%d]%s\n", nTrackID, textTmp);
											}
										}

										//cvCircle(res_frame, cvPoint(param->mot_DataSave[nTrackID].track_pt[i].x, param->mot_DataSave[nTrackID].track_pt[i].y), 1, param->track_color[nTrackID], 1, 8, 0);

										if (COUNT_MODE_COUNTRY != 3)
										{
											//20190222 hai Class color
											cvCircle(res_frame, cvPoint(param->mot_DataSave[nTrackID].track_pt[i].x, param->mot_DataSave[nTrackID].track_pt[i].y), 1,
												param->class_color[param->mot_info->mot_box_info[t].class_id], 1, 8, 0);
										}
									}
									if (bLogSave)
									{
										if (fp)
											fclose(fp);
									}
								}
								// 20190104 OSAN
								//else if (fSpeed > 0 && nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 && nTrackCount < MAX_TRACK_COUNT && COUNT_MODE_COUNTRY == 2)
								else if (nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT 
									&& COUNT_MODE_COUNTRY == 2)
								{
									//============2018.12.13 Osan CCTV
									char textCsv[CHAR_LENGTH] = "";
									int nFlowCount = 0;
									if (param->mot_info->mot_box_info[t].class_id == BICYCLE_CLASS_ID)
									{
										param->mot_info->object_flow_number[BICYCLE_CLASS_ID]++;
										nBicycleFlowCount += param->mot_info->object_flow_number[BICYCLE_CLASS_ID];
										nFlowCount = nBicycleFlowCount;
									}
									else if (param->mot_info->mot_box_info[t].class_id == HUMAN_CLASS_ID)
									{
										param->mot_info->object_flow_number[HUMAN_CLASS_ID]++;
										nHumanFlowCount += param->mot_info->object_flow_number[HUMAN_CLASS_ID];
										nFlowCount = nHumanFlowCount;
									}
									if (param->mot_info->mot_box_info[t].class_id == BICYCLE_CLASS_ID || param->mot_info->mot_box_info[t].class_id == HUMAN_CLASS_ID)
									{
										printf("SPEED DISPLAY for Bicycle/Human nTrackID = %d, nTrackCount = %d, Speed = %d\n", nTrackID, nTrackCount, (int)fSpeed);

										if (fSpeed < 0)
										{
											printf("SPEED DISPLAY for Bicycle/Human nTrackID = %d, nTrackCount = %d, Speed = %d\n", nTrackID, nTrackCount, (int)fSpeed);
										}

										char save_proofimage_path[300];

										CvRect rectArea;
										rectArea.x = (int)(param->mot_info->mot_box_info[t].bouding_box.x *nWSize);
										rectArea.y = (int)(param->mot_info->mot_box_info[t].bouding_box.y * nHSize);
										rectArea.width = (int)(param->mot_info->mot_box_info[t].bouding_box.width * nWSize);
										rectArea.height = (int)(param->mot_info->mot_box_info[t].bouding_box.height * nHSize);

										cvRectangleR(frame, rectArea, cvScalar(0, 0, 255), 2, 1, 0);

										//int current_time;
										//current_time = get_current_data_time(buff, "M");
										//current_time = Osan_get_current_data_time(timebuff, "M");

										char buffer_write[32], buffer_name[32];
										int nHH = frame_time / 3600;
										int nMM = (frame_time % 3600) / 60;
										int nSS = frame_time % 60;
										sprintf(buffer_write,"%02d:%02d:%02d", nHH,nMM,nSS);
										sprintf(buffer_name, "%02d%02d%02d", nHH, nMM, nSS);

										sprintf(textCsv, "%s,%d,%d,%d\n", buffer_write, nFlowCount, (int)fSpeed, param->mot_info->mot_box_info[t].class_id);
										printf(textCsv);

										sprintf(save_proofimage_path, "%s/%s_%d_%d_%d.jpg", result_file_folder, buffer_name, nFlowCount, (int)fSpeed, param->mot_info->mot_box_info[t].class_id);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, save_proofimage_path, frame, 0);

										OsanBicycleFile << textCsv;
									}
									//====================
								}
								else
								{
									if (param->mot_DataSave[nTrackID].pIplImage)
									{
										cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
										param->mot_DataSave[nTrackID].pIplImage = NULL;
									}
									
								}
							}

							param->mot_DataSave[nTrackID].nDataSave = 0;	////=== hai edited ===////
							param->mot_DataSave[nTrackID].nTrackCount = 0;	////=== hai edited ===////
							param->mot_DataSave[nTrackID].nIsRedSignal = 0;

						}
					}
					//Exit End
					else if (nStartY > nPtBottomY && nStartY - nGap < nPtBottomY)
					{
						if (nDataSave == 2)
						{
							if (param->mot_info->mot_box_info[nTrackID].class_id == 10 || param->mot_info->mot_box_info[nTrackID].class_id == 11) //20190110
								printf("EXIT END for Bicycle/Human nTrackID = %d\n", nTrackID);

							if (param->mot_DataSave[nTrackID].pIplImage)
							{
								float fDiffTime = (float)(param->mot_DataSave[nTrackID].diffTime[nTrackCount - 1] - param->mot_DataSave[nTrackID].diffTime[0]) / (float)CLOCKS_PER_SEC;
								int nDiffPixel = abs(param->mot_DataSave[nTrackID].track_pt[0].y - param->mot_DataSave[nTrackID].track_pt[nTrackCount - 1].y);
								

								////=== hai edited ===////
								float fTopPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[nTrackCount - 1].y);
								float fTouchPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[0].y);
								float fDistanceReal = fTouchPtReal - fTopPtReal;
								float fSpeed = fDistanceReal / fDiffTime * 3.6f;

								if (fSpeed < 0)
								{
									printf("SPEED DISPLAY for Bicycle/Human nTrackID = %d, nTrackCount = %d, Speed = %d\n", nTrackID, nTrackCount, (int)fSpeed);
								}

								//20190130 hai for MeanSpeed Display
								if (fSpeed >= 5 && nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT
									&& (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
								{
									nObjectforSpeed++;
									fTotalSpeed += fSpeed;
								}

								//20190213 hai Minimum Speed
								if (nCheckSpeedViolation && fSpeed > 0 && fSpeed <= fMinimumSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT
									&& (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1) && (nTrackNum < 10 || (fTotalSpeed / nObjectforSpeed > fMinimumSpeed && nTrackNum >= 10)))
								{
									fullRect.x      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.x		* fXRate);
									fullRect.width  = (int)((float)param->mot_info->mot_box_info[t].bouding_box.width	* fXRate);
									fullRect.y      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.y		* fYRate);
									fullRect.height = (int)((float)param->mot_info->mot_box_info[t].bouding_box.height	* fYRate);

									//cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);
									//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

									if (clone_frame)
									{
										//20190327 Hai
										cvCopy(frame, clone_frame);
										cvRectangleR(clone_frame, fullRect, param->vio_color[LOW_SPEED_CLR], 2, 1, 0);
									}
									else
									{
										//20190222 hai Violation Color
										cvRectangleR(frame, fullRect, param->vio_color[LOW_SPEED_CLR], 2, 1, 0);
									}										
										
									//printf("%.3f, %.3f, %d", (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC, (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f, (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100);
									int currentMs = (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100;

									CvRect rectArea = param->mot_DataSave[nTrackID].track_box[0];
									if (rectArea.x > 50 && rectArea.x + rectArea.width < frame->width - 50)
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);
									}
									else
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);
									}

									sprintf(full_save_image_path, "%s/speedTemp/%02d_%s_%02d_%03d_%s%02d_01.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
									if (JPG_SAVE_ENABLE)
										if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);

									cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
									param->mot_DataSave[nTrackID].pIplImage = NULL;

									sprintf(full_save_image_path, "%s/speedTemp/%02d_%s_%02d_%03d_%s%02d_02.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
									if (clone_frame)
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
									}
									else
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}
								}


								//Signal Violation
								if (pViolationCheck->m_nCheckSignalViolation && nIsRedSignal && param->mot_DataSave[nTrackID].nIsRedSignal &&
									fSpeed >= 5 && nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT
									&& (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
								{
									fullRect.x      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.x		* fXRate);
									fullRect.width  = (int)((float)param->mot_info->mot_box_info[t].bouding_box.width	* fXRate);
									fullRect.y      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.y		* fYRate);
									fullRect.height = (int)((float)param->mot_info->mot_box_info[t].bouding_box.height	* fYRate);

									//cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);
									//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

									if (clone_frame)
									{
										//20190327 Hai
										cvCopy(frame, clone_frame);
										cvRectangleR(clone_frame, fullRect, param->vio_color[SIGNAL_VIOLATION_CLR], 2, 1, 0);
									}
									else
									{
										//20190222 hai Violation color
										cvRectangleR(frame, fullRect, param->vio_color[SIGNAL_VIOLATION_CLR], 2, 1, 0);
									}																		

									//printf("%.3f, %.3f, %d", (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC, (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f, (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100);
									int currentMs = (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100;

									CvRect rectArea = param->mot_DataSave[nTrackID].track_box[0];
									if (rectArea.x > 50 && rectArea.x + rectArea.width < frame->width - 50)
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, SIGNAL_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);
									}
									else
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, SIGNAL_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);
									}

									sprintf(full_save_image_path, "%s/signalTemp/%02d_%s_%02d_%03d_%s%02d_01.jpg", vio_file_path, SIGNAL_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
									if (JPG_SAVE_ENABLE)
										if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);

									sprintf(full_save_image_path, "%s/signalTemp/%02d_%s_%02d_%03d_%s%02d_02.jpg", vio_file_path, SIGNAL_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
									if (clone_frame)
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
									}
									else
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}
								}

								//OverSpeed
								if (nCheckSpeedViolation && fSpeed >= fViolationSpeed && nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT
									&& (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1)) //20190119 hai ???
								{

									
									fullRect.x      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.x		* fXRate);
									fullRect.width  = (int)((float)param->mot_info->mot_box_info[t].bouding_box.width	* fXRate);
									fullRect.y      = (int)((float)param->mot_info->mot_box_info[t].bouding_box.y		* fYRate);
									fullRect.height = (int)((float)param->mot_info->mot_box_info[t].bouding_box.height	* fYRate);

									//cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);
									//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

									if (clone_frame)
									{
										//20190327 Hai
										cvCopy(frame, clone_frame);
										cvRectangleR(clone_frame, fullRect, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
									}
									else
									{
										//20190222 hai Violation Color
										cvRectangleR(frame, fullRect, param->vio_color[OVER_SPEED_CLR], 2, 1, 0);
									}																			

									//printf("%.3f, %.3f, %d", (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC, (float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f, (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100);
									int currentMs = (int)((float)(currentClock - param->mot_DataSave[nTrackID].diffTime[0]) / CLOCKS_PER_SEC * 100.0f) % 100;

									CvRect rectArea = param->mot_DataSave[nTrackID].track_box[0];
									if (rectArea.x > 50 && rectArea.x + rectArea.width < frame->width - 50)
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);
									}
									else
									{
										sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%03d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);
									}

									sprintf(full_save_image_path, "%s/speedTemp/%02d_%s_%02d_%03d_%s%02d_01.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
									if (JPG_SAVE_ENABLE)
										if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImage, 0);

									cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
									param->mot_DataSave[nTrackID].pIplImage = NULL;

									sprintf(full_save_image_path, "%s/speedTemp/%02d_%s_%02d_%03d_%s%02d_02.jpg", vio_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs);
									if (clone_frame)
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
									}
									else
									{
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
									}

									//log
									FILE *fp = NULL;
									if (bLogSave)
									{
										sprintf(full_log_file_path, "%s/%02d_%s_%02d_%03d_%s%02d_02_Tid%d_Exit.log", full_log_file_path, SPEED_VIOLATION_CODE, param->camera_id, nClassID, (int)fSpeed, strTime, currentMs, nTrackID);
										fp = fopen(full_log_file_path, "a");
									}

									for (int i = 1; i < param->mot_DataSave[nTrackID].nTrackCount; i++)					////=== hai edited ===////
									{
										fDiffTime = (float)(param->mot_DataSave[nTrackID].diffTime[i] - param->mot_DataSave[nTrackID].diffTime[0]) / (float)CLOCKS_PER_SEC;
										//fFinalDistance = fRealDistanceM * ((float)(param->mot_DataSave[nTrackID].track_pt[i].y - nEndY) / (float)(nDiffEndYStartY));

										fTrackPtReal = pCamPosition->CCamPosition_distance_calculation(res_frame->height, param->mot_DataSave[nTrackID].track_pt[i].y); ////=== hai edited ===////
										fFinalDistance = fTouchPtReal - fTrackPtReal;////=== hai edited ===////
										fSpeed = fFinalDistance / fDiffTime * 3.6f;
										nDiffPixel = abs(param->mot_DataSave[nTrackID].track_pt[i].y - param->mot_DataSave[nTrackID].track_pt[i - 1].y);

										if (bLogSave)
										{
											if (fp)
											{
												sprintf(textTmp, "[%s][Time%.3f][Speed%3.1f][Distance%3.1fm][TrackCount %dof%d](%d %d)[diffPixel %d]",
													param->mot_DataSave[nTrackID].timeStr[i], fDiffTime, fSpeed, fFinalDistance,
													i, param->mot_DataSave[nTrackID].nTrackCount,
													param->mot_DataSave[nTrackID].track_pt[i].x, param->mot_DataSave[nTrackID].track_pt[i].y, nDiffPixel);
												fprintf(fp, "[%d]%s\n", nTrackID, textTmp);
											}
										}

										if (COUNT_MODE_COUNTRY != 3)
										{
											//cvCircle(res_frame, cvPoint(param->mot_DataSave[nTrackID].track_pt[i].x, param->mot_DataSave[nTrackID].track_pt[i].y), 1, param->track_color[nTrackID], 1, 8, 0);
											cvCircle(res_frame, cvPoint(param->mot_DataSave[nTrackID].track_pt[i].x, param->mot_DataSave[nTrackID].track_pt[i].y), 1,
												param->class_color[param->mot_info->mot_box_info[t].class_id], 1, 8, 0);
										}
									}
									if (bLogSave)
									{
										if (fp)
											fclose(fp);
									}
								}
								// 20190104 OSAN
								//else if (fSpeed > 0 && nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 && nTrackCount < MAX_TRACK_COUNT && COUNT_MODE_COUNTRY == 2)
								else if (nMaxSpeed > fSpeed && nDiffEndYStartY - 100 < nDiffPixel && nTrackCount > 7 //&& nTrackCount < MAX_TRACK_COUNT 
									&& COUNT_MODE_COUNTRY == 2)
								{
									//============2018.12.13 Osan CCTV
									char textCsv[CHAR_LENGTH] = "";
									int nFlowCount = 0;
									if (param->mot_info->mot_box_info[t].class_id == BICYCLE_CLASS_ID)
									{
										param->mot_info->object_flow_number[BICYCLE_CLASS_ID]++;
										nBicycleFlowCount += param->mot_info->object_flow_number[BICYCLE_CLASS_ID];
										nFlowCount = nBicycleFlowCount;
									}
									else if (param->mot_info->mot_box_info[t].class_id == HUMAN_CLASS_ID)
									{
										param->mot_info->object_flow_number[HUMAN_CLASS_ID]++;
										nHumanFlowCount += param->mot_info->object_flow_number[HUMAN_CLASS_ID];
										nFlowCount = nHumanFlowCount;
									}

									if (param->mot_info->mot_box_info[t].class_id == BICYCLE_CLASS_ID || param->mot_info->mot_box_info[t].class_id == HUMAN_CLASS_ID)
									{
										printf("SPEED DISPLAY for Bicycle/Human nTrackID = %d, nTrackCount = %d, Speed = %d\n", nTrackID, nTrackCount, (int)fSpeed);

										if (fSpeed < 0)
										{
											printf("SPEED DISPLAY for Bicycle/Human nTrackID = %d, nTrackCount = %d, Speed = %d\n", nTrackID, nTrackCount, (int)fSpeed);
										}

										char save_proofimage_path[300];

										CvRect rectArea;
										rectArea.x = (int)(param->mot_info->mot_box_info[t].bouding_box.x *nWSize);
										rectArea.y = (int)(param->mot_info->mot_box_info[t].bouding_box.y * nHSize);
										rectArea.width = (int)(param->mot_info->mot_box_info[t].bouding_box.width * nWSize);
										rectArea.height = (int)(param->mot_info->mot_box_info[t].bouding_box.height * nHSize);

										cvRectangleR(frame, rectArea, cvScalar(0, 0, 255), 2, 1, 0);

										char buffer_write[32], buffer_name[32];
										int nHH = frame_time / 3600;
										int nMM = (frame_time % 3600) / 60;
										int nSS = frame_time % 60;
										sprintf(buffer_write, "%02d:%02d:%02d", nHH, nMM, nSS);
										sprintf(buffer_name, "%02d%02d%02d", nHH, nMM, nSS);

										sprintf(textCsv, "%s,%d,%d,%d\n", buffer_write, nFlowCount, (int)fSpeed, param->mot_info->mot_box_info[t].class_id);
										printf(textCsv);

										sprintf(save_proofimage_path, "%s/%s_%d_%d_%d.jpg", result_file_folder, buffer_name, nFlowCount, (int)fSpeed, param->mot_info->mot_box_info[t].class_id);
										if (JPG_SAVE_ENABLE)
											if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, save_proofimage_path, frame, 0);

										OsanBicycleFile << textCsv;
									}
									//====================
								}
								else
								{
									cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
									param->mot_DataSave[nTrackID].pIplImage = NULL;
								}
							}

							param->mot_DataSave[nTrackID].nDataSave = 0;	////=== hai edited ===////
							param->mot_DataSave[nTrackID].nTrackCount = 0;	////=== hai edited ===////
							param->mot_DataSave[nTrackID].nIsRedSignal = 0;

						}
					}
					else if (nEndY + nGap < nPtBottomY || nStartY - nGap > nPtBottomY)
					{
						cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
						param->mot_DataSave[nTrackID].pIplImage = NULL;

						param->mot_DataSave[nTrackID].nDataSave = 0;
						param->mot_DataSave[nTrackID].nTrackCount = 0;
						param->mot_DataSave[nTrackID].nIsRedSignal = 0;
					}
				}
				else
				{
					if (param->mot_DataSave[nTrackID].pIplImage)
					{
						cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
						param->mot_DataSave[nTrackID].pIplImage = NULL;
					}

					param->mot_DataSave[nTrackID].nDataSave = 0;	////=== hai edited ===////
					param->mot_DataSave[nTrackID].nTrackCount = 0;	////=== hai edited ===////
					param->mot_DataSave[nTrackID].nIsRedSignal = 0;

					//if (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY) == NO_VIOLATION_AREA)
					//{
					//	std::cout << "NO_VIOLATION_AREA " << nPtBottomX << "," << nPtBottomY << std::endl;
					//}
				}
			}
			else
			{
				if (param->mot_DataSave[nTrackID].pIplImage)
				{
					cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImage);
					param->mot_DataSave[nTrackID].pIplImage = NULL;
				}

				param->mot_DataSave[nTrackID].nDataSave = 0;	////=== hai edited ===////
				param->mot_DataSave[nTrackID].nTrackCount = 0;	////=== hai edited ===////
				param->mot_DataSave[nTrackID].nIsRedSignal = 0;
			}
			//if (clone_frame) //20190115 hai
			//	cvReleaseImage(&clone_frame);
		}
	}

	
}

//// convert 2D to 3D box 2018.08.23

void convert_2D_to_3D_Box(IplImage *res_frame, CvRect box, CvScalar color)
{
	CvRect rt;
	//just 20% ratio conversion
	//Later, I'll convert it to more scientific.
	float fRatio = 0.2f;
	int nWidthRate = (int)(box.width * fRatio) - 1;
	int nHeightRate = (int)(box.height * fRatio) - 1;
	if (nWidthRate < 0)
		nWidthRate = 0;
	if (nHeightRate < 0)
		nHeightRate = 0;
	rt.x = box.x;
	rt.width = box.width - nWidthRate;
	rt.y = box.y + nHeightRate;
	rt.height = box.height - nHeightRate;
	cvRectangleR(res_frame, rt, color, 1, 1, 0);

	CvPoint pt[2];
	pt[0].x = box.x + nWidthRate;
	pt[0].y = box.y;
	pt[1].x = box.x;
	pt[1].y = box.y + nHeightRate;
	cvLine(res_frame, pt[0], pt[1], color, 2, 7, 0);

	pt[1].x = box.x + box.width;
	pt[1].y = box.y;
	cvLine(res_frame, pt[0], pt[1], color, 2, 7, 0);

	pt[0].x = box.x + box.width - nWidthRate;
	pt[0].y = box.y + nHeightRate;
	cvLine(res_frame, pt[0], pt[1], color, 2, 7, 0);

	pt[0].x = box.x + box.width;
	pt[0].y = box.y + box.height - nHeightRate;
	cvLine(res_frame, pt[0], pt[1], color, 2, 7, 0);

	pt[1].x = box.x + box.width - nWidthRate;
	pt[1].y = box.y + box.height;
	cvLine(res_frame, pt[0], pt[1], color, 2, 7, 0);
}




////20190213 hai Accident Detection/Illegal Parking 
/*
void accident_detection(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, int nTrackCount, int ntrack, char * strTime, clock_t currentClock)
{
	int nClassID = param->mot_info->mot_box_info[ntrack].class_id;
	int nTrackID = param->mot_info->mot_box_info[ntrack].track_id;
	char *vio_file_path = param->vio_result_path;
	char full_save_image_path[CHAR_LENGTH];

	CvRect rtBoundingBox = param->mot_info->mot_box_info[ntrack].bouding_box;

	int nPtBottomX = rtBoundingBox.x + (rtBoundingBox.width / 2);
	int nPtBottomY = rtBoundingBox.y + rtBoundingBox.height;
	int nBoxWidth = param->mot_info->mot_box_info[ntrack].bouding_box.width;
	int nBoxHeight = param->mot_info->mot_box_info[ntrack].bouding_box.height;

	CvRect rectArea;
	CvRect fullRect;

	//20180904 accident check area
	bool bCheckAccident = false;
	if (COUNT_MODE_COUNTRY == 0)
	{
		if (nTrackCount == MAX_TRACK_COUNT)
		{
			if (ptLine[0].y < ptLine[2].y)
			{
				if (ptLine[1].x < nPtBottomX && ptLine[4].x > nPtBottomX)
				{
					if (ptLine[1].y < nPtBottomY && ptLine[3].y > nPtBottomY)
					{
						bCheckAccident = true;
					}
				}
			}
			else
			{
				if (ptLine[3].x < nPtBottomX && ptLine[5].x > nPtBottomX)
				{
					if (ptLine[3].y < nPtBottomY && ptLine[1].y > nPtBottomY)
					{
						bCheckAccident = true;
					}
				}
			}
		}
	}

	if (bCheckAccident)
	{
		float fXRate, fYRate;
		fXRate = (float)frame->width / (float)res_frame->width;
		fYRate = (float)frame->height / (float)res_frame->height;

		bool bIsMove = false;
		int nThresholdMovePixels = 50;
		for (int i = 1; i < param->mot_DataSave[nTrackID].nTrackCount; i++)
		{
			//draw points
			cvCircle(frame, cvPoint((int)(param->mot_DataSave[nTrackID].track_pt[i].x * fXRate), (int)(param->mot_DataSave[nTrackID].track_pt[i].y * fYRate)), 1, param->track_color[nTrackID], 1, 8, 0);

			//object moving check
			if (abs(param->mot_DataSave[nTrackID].track_pt[1].x - param->mot_DataSave[nTrackID].track_pt[i].x) > nThresholdMovePixels
				|| abs(param->mot_DataSave[nTrackID].track_pt[1].y - param->mot_DataSave[nTrackID].track_pt[i].y) > nThresholdMovePixels)
			{
				bIsMove = true;
			}
		}

		if (!bIsMove)
		{
			//20180904 accident confirm
			fullRect.x      = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.x		* fXRate);
			fullRect.width  = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.width	* fXRate);
			fullRect.y      = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.y		* fYRate);
			fullRect.height = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.height	* fYRate);
			cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);

			rectArea = fullRect;
			rectArea.y = rectArea.y + rectArea.height * 1 / 3;
			rectArea.height = rectArea.height * 2 / 3;
			cvRectangleR(frame, rectArea, param->track_color[nTrackID], 2, 1, 0);

			//save result
			int millisecond = (int)((float)(currentClock - param->mot_LightSave[nTrackID].diffTime) / CLOCKS_PER_SEC * 100.0f) % 100;
			sprintf(full_save_image_path, "%s/accidentTemp/%02d_%s_%02d_%s%02d_01.jpg", vio_file_path, ACCIDENT_CODE, param->camera_id, nClassID, strTime, millisecond);
			cvSaveImage(full_save_image_path, frame, 0);

			//save lpdr
			sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, ACCIDENT_CODE,
				param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
			cvSaveImage(full_save_image_path, frame, 0);
		}

		//initialize count for re-check accident.
		param->mot_DataSave[nTrackID].nTrackCount = 0;
	}

}*/

////20190213 hai Accident Detection/Illegal Parking 
void accident_detection(IplImage *frame, IplImage *res_frame, IplImage *clone_frame, st_det_mot_param *param, int nTrackCount, int ntrack, char * strTime, clock_t currentClock
	                    , CRegion* pRegion, HANDLE hSaveImageDLL)
{
	if (pRegion == nullptr) return;
	CvPoint ptLine[6];
	pRegion->CRegion_copy(1, ptLine);
	CvPoint ptROI[4];
	pRegion->CRegion_copy(2, ptROI);

	CvFont font;
	cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.7, 0.7, 0, 2, 1);

	int nClassID = param->mot_info->mot_box_info[ntrack].class_id;
	int nTrackID = param->mot_info->mot_box_info[ntrack].track_id;
	char *vio_file_path = param->vio_result_path;
	char full_save_image_path[CHAR_LENGTH], textTmp[CHAR_LENGTH];

	CvRect rtBoundingBox = param->mot_info->mot_box_info[ntrack].bouding_box;

	int nPtBottomX = rtBoundingBox.x + (rtBoundingBox.width / 2);
	int nPtBottomY = rtBoundingBox.y + rtBoundingBox.height;
	int nBoxWidth = param->mot_info->mot_box_info[ntrack].bouding_box.width;
	int nBoxHeight = param->mot_info->mot_box_info[ntrack].bouding_box.height;

	float fXRate, fYRate;
	fXRate = (float)frame->width / (float)res_frame->width;
	fYRate = (float)frame->height / (float)res_frame->height;

	CvRect rectArea;
	CvRect fullRect;

	//20180904 accident check area
	int nPtROIx02 = pRegion->CRegion_AccidentCheckArea(0, nPtBottomY);
	int nPtROIx13 = pRegion->CRegion_AccidentCheckArea(1, nPtBottomY);

	if (param->mot_DataSave[nTrackID].bCheckAccident == 0)
	{
		//20190215 hai Parking Indonesia
		//if (COUNT_MODE_COUNTRY == 1 && nPtBottomX > nPtROIx02 && nPtBottomX < nPtROIx13
		if ((COUNT_MODE_COUNTRY == 1 || COUNT_MODE_COUNTRY == 0) && nPtBottomX > nPtROIx02 && nPtBottomX < nPtROIx13
			&& (nPtBottomY - nBoxHeight / 2) < ptROI[2].y && (nPtBottomY - nBoxHeight / 2) > ptROI[0].y)
		{
			param->mot_DataSave[nTrackID].bCheckAccident = 1;
			param->mot_DataSave[nTrackID].parkingTime = currentClock;

			fullRect.x = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.x		* fXRate);
			fullRect.width = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.width	* fXRate);
			fullRect.y = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.y		* fYRate);
			fullRect.height = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.height	* fYRate);

			rectArea = fullRect;
			rectArea.y = rectArea.y + rectArea.height * 1 / 3;
			rectArea.height = rectArea.height * 2 / 3;

			if (!param->mot_DataSave[nTrackID].pIplImageParkingStart)
				param->mot_DataSave[nTrackID].pIplImageParkingStart = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);
			
			cvCopy(frame, param->mot_DataSave[nTrackID].pIplImageParkingStart);
			cvRectangleR(param->mot_DataSave[nTrackID].pIplImageParkingStart, fullRect, param->vio_color[ILLEGAL_PARKING_CLR], 2, 1, 0);
		}
		////20190215 hai Parking VietNam
		//else if (COUNT_MODE_COUNTRY == 0)
		//{
		//	if ((ptLine[0].y < ptLine[2].y && ptLine[1].x < nPtBottomX && ptLine[4].x > nPtBottomX && ptLine[1].y < nPtBottomY && ptLine[3].y > nPtBottomY)
		//		|| (ptLine[0].y >= ptLine[2].y && ptLine[3].x < nPtBottomX && ptLine[5].x > nPtBottomX && ptLine[3].y < nPtBottomY && ptLine[1].y > nPtBottomY))
		//	{
		//		param->mot_DataSave[nTrackID].bCheckAccident = 1;
		//	}
		//}
	}

	if (param->mot_DataSave[nTrackID].bCheckAccident)
	{
		//20190215 hai Parking Indonesia
		//if (COUNT_MODE_COUNTRY == 1)
		if (COUNT_MODE_COUNTRY == 1 || COUNT_MODE_COUNTRY == 0)
		{
			if (nPtBottomX > nPtROIx02 && nPtBottomX < nPtROIx13
				&& (nPtBottomY - nBoxHeight / 2) < ptROI[2].y && (nPtBottomY - nBoxHeight / 2) > ptROI[0].y)
			{
				int deltaTime = (int)((double)(currentClock - param->mot_DataSave[nTrackID].parkingTime) / CLOCKS_PER_SEC);
				if (deltaTime >= param->nIllegalTime * SECONDS_PER_ONE_MINUTE && param->mot_DataSave[nTrackID].bSaveAccident == 0) //20190218 hai Test 60->10
				{
					//20180904 accident confirm
					fullRect.x      = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.x		* fXRate);
					fullRect.width  = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.width	* fXRate);
					fullRect.y      = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.y		* fYRate);
					fullRect.height = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.height	* fYRate);				

					rectArea = fullRect;
					rectArea.y = rectArea.y + rectArea.height * 1 / 3;
					rectArea.height = rectArea.height * 2 / 3;

					if (clone_frame)
					{
						//20190327 Hai
						cvCopy(frame, clone_frame);
						cvRectangleR(clone_frame, fullRect, param->vio_color[ILLEGAL_PARKING_CLR], 2, 1, 0);
						//cvRectangleR(clone_frame, rectArea, param->vio_color[ILLEGAL_PARKING_CLR], 2, 1, 0);
					}
					else
					{
						cvRectangleR(frame, fullRect, param->vio_color[ILLEGAL_PARKING_CLR], 2, 1, 0); //20190222 hai Violation color
						//cvRectangleR(frame, rectArea, param->vio_color[ILLEGAL_PARKING_CLR], 2, 1, 0); //20190222 hai Violation color
					}

					//save result
					int millisecond = (int)((float)(currentClock - clock()) / CLOCKS_PER_SEC * 100.0f) % 100;
					sprintf(full_save_image_path, "%s/stopareaTemp/%02d_%s_%02d_%s%02d_01.jpg", vio_file_path, ILLEGALPARKING_CODE, param->camera_id, nClassID, strTime, millisecond);

					if (param->mot_DataSave[nTrackID].pIplImageParkingStart)
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_DataSave[nTrackID].pIplImageParkingStart, 0);
					}
					else
						printf("error pIplImageParkingStart");

					if (param->mot_DataSave[nTrackID].pIplImageParkingStart)
					{
						cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImageParkingStart);
						param->mot_DataSave[nTrackID].pIplImageParkingStart = NULL;
					}				

					sprintf(full_save_image_path, "%s/stopareaTemp/%02d_%s_%02d_%s%02d_02.jpg", vio_file_path, ILLEGALPARKING_CODE, param->camera_id, nClassID, strTime, millisecond);
					if (clone_frame)
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
					}
					else
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}

					//save lpdr
					sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, ILLEGALPARKING_CODE,
						param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);

					param->mot_DataSave[nTrackID].bSaveAccident = 1;
				}
				//Overlay
				else if (deltaTime >= param->nIllegalTime * SECONDS_PER_ONE_MINUTE) //20190218 hai Test 60->10
				{
					IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);
					cvCopy(res_frame, overlay_frame);
					//cvRectangleR(overlay_frame, rtBoundingBox, cvScalar(0,0,255), -1);
					cvRectangleR(overlay_frame, rtBoundingBox, param->vio_color[ILLEGAL_PARKING_CLR], -1); //20190222 hai Violation color
					//cvRectangleR(res_frame, rtBoundingBox, param->vio_color[ILLEGAL_PARKING_CLR], 2,1,0);
					cvAddWeighted(overlay_frame, fOverlay_alpha, res_frame, 1 - fOverlay_alpha, 0, res_frame);

					param->mot_DataSave[nTrackID].nVioDisplay[ILLEGAL_PARKING_CLR] = 1; //2019022

					violation_text_display(res_frame, param, ntrack, nTrackID);
					//sprintf(textTmp, "PARKING");
					//cvPutText(res_frame, textTmp, cvPoint((int)rtBoundingBox.x, (int)rtBoundingBox.y), &font, param->vio_color[ILLEGAL_PARKING_CLR]); //20190222 hai Violation color

					if (overlay_frame)
						cvReleaseImage(&overlay_frame);

				}
			}
			else
			{
				param->mot_DataSave[nTrackID].bCheckAccident = 0;
				param->mot_DataSave[nTrackID].bSaveAccident = 0;
				param->mot_DataSave[nTrackID].parkingTime = currentClock;

				if (param->mot_DataSave[nTrackID].pIplImageParkingStart)
				{
					cvReleaseImage(&param->mot_DataSave[nTrackID].pIplImageParkingStart);
					param->mot_DataSave[nTrackID].pIplImageParkingStart = NULL;
				}				

				param->mot_DataSave[nTrackID].nVioDisplay[ILLEGAL_PARKING_CLR] = 0; //2019022
			}
		}
		////20190215 hai Parking VietNam
		//else if (COUNT_MODE_COUNTRY == 0)
		//{
		//	if ((ptLine[0].y < ptLine[2].y && ptLine[1].x < nPtBottomX && ptLine[4].x > nPtBottomX && ptLine[1].y < nPtBottomY && ptLine[3].y > nPtBottomY)
		//		|| (ptLine[0].y >= ptLine[2].y && ptLine[3].x < nPtBottomX && ptLine[5].x > nPtBottomX && ptLine[3].y < nPtBottomY && ptLine[1].y > nPtBottomY))
		//	{
		//		int deltaTime = (int)((double)(currentClock - param->mot_DataSave[nTrackID].parkingTime) / CLOCKS_PER_SEC);
		//		if (deltaTime >= param->nIllegalTime * SECONDS_PER_ONE_MINUTE && param->mot_DataSave[nTrackID].bSaveAccident == 0)
		//		{
		//			//20180904 accident confirm
		//			fullRect.x      = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.x		* fXRate);
		//			fullRect.width  = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.width	* fXRate);
		//			fullRect.y      = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.y		* fYRate);
		//			fullRect.height = (int)((float)param->mot_info->mot_box_info[ntrack].bouding_box.height	* fYRate);				

		//			rectArea = fullRect;
		//			rectArea.y = rectArea.y + rectArea.height * 1 / 3;
		//			rectArea.height = rectArea.height * 2 / 3;					

		//			if (clone_frame)
		//			{
		//				//20190327 Hai
		//				cvCopy(frame, clone_frame);
		//				cvRectangleR(clone_frame, fullRect, param->vio_color[ACCIDENT_CLR], 2, 1, 0);
		//				//cvRectangleR(clone_frame, rectArea, param->vio_color[ACCIDENT_CLR], 2, 1, 0);
		//			}
		//			else
		//			{
		//				cvRectangleR(frame, fullRect, param->vio_color[ACCIDENT_CLR], 2, 1, 0); //20190222 hai Violation color
		//				//cvRectangleR(frame, rectArea, param->vio_color[ACCIDENT_CLR], 2, 1, 0); //20190222 hai Violation color
		//			}

		//			//save result
		//			int millisecond = (int)((float)(currentClock - clock()) / CLOCKS_PER_SEC * 100.0f) % 100;
		//			sprintf(full_save_image_path, "%s/accidentTemp/%02d_%s_%02d_%s%02d_01.jpg", vio_file_path, ACCIDENT_CODE, param->camera_id, nClassID, strTime, millisecond);
		//			if (clone_frame)
		//			{
		//				if (JPG_SAVE_ENABLE)
		//					if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
		//			}
		//			else
		//			{
		//				if (JPG_SAVE_ENABLE)
		//					if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
		//			}

		//			//save lpdr
		//			sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_%s%02d_01_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, ACCIDENT_CODE,
		//				param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
		//			if (JPG_SAVE_ENABLE)
		//				if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);

		//			param->mot_DataSave[nTrackID].bSaveAccident = 1;
		//		}
		//		//Overlay
		//		else if (deltaTime >= param->nIllegalTime * SECONDS_PER_ONE_MINUTE)
		//		{
		//			IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);
		//			cvCopy(res_frame, overlay_frame);
		//			cvRectangleR(overlay_frame, rtBoundingBox, param->vio_color[ILLEGAL_PARKING_CLR], -1);
		//			cvAddWeighted(overlay_frame, fOverlay_alpha, res_frame, 1 - fOverlay_alpha, 0, res_frame);

		//			violation_text_display(res_frame, param, ntrack, nTrackID);
		//			//sprintf(textTmp, "PARKING");
		//			//cvPutText(res_frame, textTmp, cvPoint((int)rtBoundingBox.x, (int)rtBoundingBox.y), &font, param->vio_color[ILLEGAL_PARKING_CLR]); //20190222 hai Violation color

		//			if (overlay_frame)
		//				cvReleaseImage(&overlay_frame);
		//		}
		//	}
		//	else
		//	{
		//		param->mot_DataSave[nTrackID].bCheckAccident = 0;
		//		param->mot_DataSave[nTrackID].bSaveAccident = 0;
		//		param->mot_DataSave[nTrackID].parkingTime = currentClock;
		//	}
		//}
	}
}



//// wrong lane violation 2018.08.08
//// modify 2018.10.25. Check the movement of the object when the front and rear bike.
void wrong_lane_violation(IplImage *frame, IplImage *res_frame, IplImage *clone_frame, st_det_mot_param *param, int ntrack, int nEndY, char * strTime
	, CRegion* pRegion, HANDLE hSaveImageDLL)
{
	if (pRegion == nullptr) return;
	CvPoint ptLine[6];
	pRegion->CRegion_copy(1, ptLine);
	CvPoint ptROI[4];
	pRegion->CRegion_copy(2, ptROI);

	char *vio_file_path = param->vio_result_path;
	char full_save_image_path[CHAR_LENGTH];

	char textTmp[CHAR_LENGTH];
	CvFont font;
	cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.7, 0.7, 0, 2, 1);

	clock_t currentClock = clock();

	CvPoint ptTop, ptBot;
	if (ptLine[0].y > ptLine[2].y)
	{
		ptTop = ptLine[2];
		ptBot = ptLine[0];
	}
	else
	{
		ptTop = ptLine[0];
		ptBot = ptLine[2];
	}

	//calculate_line_params();

	int nClassID = param->mot_info->mot_box_info[ntrack].class_id;
	int nTrackID = param->mot_info->mot_box_info[ntrack].track_id;
	float fScore = param->mot_info->det_box_info[ntrack].score;
	CvRect rtBoundingBox = param->mot_info->mot_box_info[ntrack].bouding_box;

	int nPtBoxRightX = rtBoundingBox.x + rtBoundingBox.width;
	int nPtBottomX = rtBoundingBox.x + (rtBoundingBox.width / 2);
	int nPtBottomY = rtBoundingBox.y + rtBoundingBox.height;
	int nBoxWidth = rtBoundingBox.width;
	int nPtCenterY = rtBoundingBox.y + rtBoundingBox.height/2;

	CvRect rectArea, fullRect;

	fullRect.x = (int)((float)rtBoundingBox.x		* nWSize);
	fullRect.width = (int)((float)rtBoundingBox.width	* nWSize);
	fullRect.y = (int)((float)rtBoundingBox.y		* nHSize);
	fullRect.height = (int)((float)rtBoundingBox.height	* nHSize);

	rectArea = fullRect;
	rectArea.y = rectArea.y + rectArea.height * 1 / 3;
	rectArea.height = rectArea.height * 2 / 3;

	int nLaneMaxCount = 15;

	if (fullRect.height <= 6 * fullRect.width)
	{
		// ===== [Taking LPR image if exists] =====
		if ((nClassID == REAR_BIKE_CLASS_ID || nClassID == CAR_CLASS_ID || nClassID == BAN_CLASS_ID || nClassID == TRUCK_CLASS_ID || nClassID == REAR_TRUCKBIKE_CLASS_ID)
			&& pRegion->CRegion_line_touch_save_LPImage(nPtBottomY, rtBoundingBox.height, nEndY) && param->mot_LaneSave[nTrackID].nLPR == 0) // 2018.11.12 hai
		{
			std::cout << nTrackID << ": touch LPR line" << std::endl;

			param->mot_LaneSave[nTrackID].lprTime = currentClock;

			if (!param->mot_LaneSave[nTrackID].pLPImage)
				param->mot_LaneSave[nTrackID].pLPImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

			cvCopy(frame, param->mot_LaneSave[nTrackID].pLPImage);

			cvRectangleR(param->mot_LaneSave[nTrackID].pLPImage, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);

			param->mot_LaneSave[nTrackID].LPRect = fullRect;

			sprintf(param->mot_LaneSave[nTrackID].save_LPimage_coordinate, "X%04d_Y%04d_W%04d_H%04d", rectArea.x, rectArea.y, rectArea.width, rectArea.height);

			param->mot_LaneSave[nTrackID].nLPR = 1;
		}

		// ===== [car/van/truck Violation] =====
		if (nClassID == CAR_CLASS_ID || nClassID == BAN_CLASS_ID || nClassID == BUS_CLASS_ID || nClassID == TRUCK_CLASS_ID)
		{
			if (param->mot_LaneSave[nTrackID].nLaneViolation == 0)
			{
			if (pRegion->CRegion_line_touch_forLaneVio_topbot(nPtBottomY, rtBoundingBox.height, ptTop.y, true) == 1 && param->mot_LaneSave[nTrackID].nTouchTop == 0 && param->mot_LaneSave[nTrackID].nTouchBot == 0) // 2018.11.12 hai
				{
					param->mot_LaneSave[nTrackID].nTouchTop = 1;
					param->mot_LaneSave[nTrackID].PtTrackTop.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackTop.y = nPtBottomY;
					param->mot_LaneSave[nTrackID].PtTrackTopCen.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackTopCen.y = nPtCenterY;

					param->mot_LaneSave[nTrackID].startTime = currentClock;

					if (!param->mot_LaneSave[nTrackID].pIplImage)
						param->mot_LaneSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

					cvCopy(frame, param->mot_LaneSave[nTrackID].pIplImage);
					cvRectangleR(param->mot_LaneSave[nTrackID].pIplImage, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);
				}
				else if (pRegion->CRegion_line_touch_forLaneVio_topbot(nPtBottomY, rtBoundingBox.height, ptBot.y, false) == 1 && param->mot_LaneSave[nTrackID].nTouchBot == 0 && param->mot_LaneSave[nTrackID].nTouchTop == 0) // 2018.11.12 hai
				{
					param->mot_LaneSave[nTrackID].nTouchBot = 1;
					param->mot_LaneSave[nTrackID].PtTrackBot.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackBot.y = nPtBottomY;
					param->mot_LaneSave[nTrackID].PtTrackBotCen.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackBotCen.y = nPtCenterY;

					param->mot_LaneSave[nTrackID].startTime = currentClock;

					if (!param->mot_LaneSave[nTrackID].pIplImage)
						param->mot_LaneSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

					cvCopy(frame, param->mot_LaneSave[nTrackID].pIplImage);
					cvRectangleR(param->mot_LaneSave[nTrackID].pIplImage, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);
				}

				// === [from bottom to top] === 
				if (pRegion->CRegion_line_touch_forLaneVio_topbot(nPtBottomY, rtBoundingBox.height, ptTop.y, true) == 1 && param->mot_LaneSave[nTrackID].nTouchTop == 0 && param->mot_LaneSave[nTrackID].nTouchBot == 1)
				{
					param->mot_LaneSave[nTrackID].nTouchTop = 1;
					param->mot_LaneSave[nTrackID].catchTime = currentClock;
					param->mot_LaneSave[nTrackID].PtTrackTop.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackTop.y = nPtBottomY;
					param->mot_LaneSave[nTrackID].PtTrackTopCen.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackTopCen.y = nPtCenterY;

					int nPtLaneBotX02 = pRegion->CRegion_LaneArea(param->mot_LaneSave[nTrackID].PtTrackBot.y);
					int nPtLaneTopX02 = pRegion->CRegion_LaneArea(param->mot_LaneSave[nTrackID].PtTrackTop.y);

					int nPtLaneBotCenX02 = pRegion->CRegion_LaneArea(param->mot_LaneSave[nTrackID].PtTrackBotCen.y);
					int nPtLaneTopCenX02 = pRegion->CRegion_LaneArea(param->mot_LaneSave[nTrackID].PtTrackTopCen.y);

					if ((param->mot_LaneSave[nTrackID].PtTrackBot.x <= nPtLaneBotX02 && param->mot_LaneSave[nTrackID].PtTrackTop.x >= nPtLaneTopX02
						&& (param->mot_LaneSave[nTrackID].PtTrackBotCen.x <= nPtLaneBotCenX02 || param->mot_LaneSave[nTrackID].PtTrackTopCen.x >= nPtLaneTopCenX02))
						|| (param->mot_LaneSave[nTrackID].PtTrackBot.x >= nPtLaneBotX02 && param->mot_LaneSave[nTrackID].PtTrackTop.x <= nPtLaneTopX02
							&& (param->mot_LaneSave[nTrackID].PtTrackBotCen.x >= nPtLaneBotCenX02 || param->mot_LaneSave[nTrackID].PtTrackTopCen.x <= nPtLaneTopCenX02)))
					{
						param->mot_LaneSave[nTrackID].nLaneViolation = 1;
					}

				}
				//  === [from top to bottom] === 
				else if (pRegion->CRegion_line_touch_forLaneVio_topbot(nPtBottomY, rtBoundingBox.height, ptBot.y, false) == 1 && param->mot_LaneSave[nTrackID].nTouchBot == 0 && param->mot_LaneSave[nTrackID].nTouchTop == 1)
				{
					param->mot_LaneSave[nTrackID].nTouchBot = 1;
					param->mot_LaneSave[nTrackID].catchTime = currentClock;
					param->mot_LaneSave[nTrackID].PtTrackBot.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackBot.y = nPtBottomY;
					param->mot_LaneSave[nTrackID].PtTrackBotCen.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackBotCen.y = nPtCenterY;

					int nPtLaneBotX02 = pRegion->CRegion_LaneArea(param->mot_LaneSave[nTrackID].PtTrackBot.y);
					int nPtLaneTopX02 = pRegion->CRegion_LaneArea(param->mot_LaneSave[nTrackID].PtTrackTop.y);

					int nPtLaneBotCenX02 = pRegion->CRegion_LaneArea(param->mot_LaneSave[nTrackID].PtTrackBotCen.y);
					int nPtLaneTopCenX02 = pRegion->CRegion_LaneArea(param->mot_LaneSave[nTrackID].PtTrackTopCen.y);

					if ((param->mot_LaneSave[nTrackID].PtTrackTop.x >= nPtLaneTopX02 && param->mot_LaneSave[nTrackID].PtTrackBot.x <= nPtLaneBotX02
						&& (param->mot_LaneSave[nTrackID].PtTrackTopCen.x >= nPtLaneTopCenX02 || param->mot_LaneSave[nTrackID].PtTrackBotCen.x <= nPtLaneBotCenX02))
						|| (param->mot_LaneSave[nTrackID].PtTrackTop.x <= nPtLaneTopX02 && param->mot_LaneSave[nTrackID].PtTrackBot.x >= nPtLaneBotX02
							&& (param->mot_LaneSave[nTrackID].PtTrackTopCen.x <= nPtLaneTopCenX02 || param->mot_LaneSave[nTrackID].PtTrackBotCen.x >= nPtLaneBotCenX02)))
					{
						param->mot_LaneSave[nTrackID].nLaneViolation = 1;
					}
				}

				if (param->mot_LaneSave[nTrackID].nLaneViolation == 1)
				{
					int millisecond = (int)((float)(currentClock - param->mot_LaneSave[nTrackID].startTime) / CLOCKS_PER_SEC * 100.0f) % 100;

					//int seconds;
					//if (param->mot_LaneSave[nTrackID].pLPImage)
					//	seconds = (int)((float)(currentClock - param->mot_LaneSave[nTrackID].lprTime) / CLOCKS_PER_SEC);

					sprintf(full_save_image_path, "%s/laneTemp/%02d_%s_%02d_000_%s%02d_01.jpg", vio_file_path, LANE_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
					CvPoint ptWronglane[2];
					ptWronglane[0].x = (int)((float)ptTop.x * nWSize);
					ptWronglane[0].y = (int)((float)ptTop.y * nHSize);
					ptWronglane[1].x = (int)((float)ptBot.x * nWSize);
					ptWronglane[1].y = (int)((float)ptBot.y * nHSize);
					cvLine(param->mot_LaneSave[nTrackID].pIplImage, ptWronglane[0], ptWronglane[1], cvScalar(0, 0, 255, 0), 2, 7, 0); //2018.11.12
					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_LaneSave[nTrackID].pIplImage, 0);

					/*cvRectangleR(frame, rectArea, param->track_color[nTrackID], 2, 1, 0);
					cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);*/
					//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

					if (clone_frame)
					{
						//20190327 Hai
						cvCopy(frame, clone_frame);
						cvLine(clone_frame, ptWronglane[0], ptWronglane[1], cvScalar(0, 0, 255, 0), 2, 7, 0);
						cvRectangleR(clone_frame, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);
					}
					else
					{
						//20190222 hai Violation color
						cvLine(frame, ptWronglane[0], ptWronglane[1], cvScalar(0, 0, 255, 0), 2, 7, 0);
						cvRectangleR(frame, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);
					}

					sprintf(full_save_image_path, "%s/laneTemp/%02d_%s_%02d_000_%s%02d_02.jpg", vio_file_path, LANE_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
					if (clone_frame)
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
					}
					else
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}

					sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, LANE_VIOLATION_CODE,
						param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);

					if (param->mot_LaneSave[nTrackID].pLPImage && param->mot_LaneSave[nTrackID].LPRect.x > 20 && param->mot_LaneSave[nTrackID].LPRect.x + param->mot_LaneSave[nTrackID].LPRect.width < frame->width - 20)
					{
						sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_%s.jpg", vio_file_path, LANE_VIOLATION_CODE,
							param->camera_id, nClassID, strTime, millisecond, param->mot_LaneSave[nTrackID].save_LPimage_coordinate);

						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_LaneSave[nTrackID].pLPImage, 0);
					}
					else if (fullRect.x > 10 && (fullRect.x + fullRect.width) < (frame->width - 10) && (nEndY >= nPtBottomY && (nEndY - abs(ptLine[0].y - ptLine[2].y) / 2) < nPtBottomY))
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}
					else
					{
						sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, LANE_VIOLATION_CODE,
							param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}

					cvReleaseImage(&param->mot_LaneSave[nTrackID].pIplImage);
					param->mot_LaneSave[nTrackID].pIplImage = NULL;

					cvReleaseImage(&param->mot_LaneSave[nTrackID].pLPImage);
					param->mot_LaneSave[nTrackID].pLPImage = NULL;

					std::cout << "wrong lane violation" << std::endl;
				}
			}
		}

		// ===== [motobike and truck-bike Violation] =====

		if(nClassID == REAR_BIKE_CLASS_ID || nClassID == REAR_TRUCKBIKE_CLASS_ID || nClassID == FRONT_BIKE_CLASS_ID || nClassID == FRONT_TRUCKBIKE_CLASS_ID 
			|| nClassID == SIDE_BIKE_CLASS_ID || nClassID == SIDE_TRUCKBIKE_CLASS_ID)
		{
			int nBottomStatus = pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth);
			int nCenterStatus = pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtCenterY, nBoxWidth);
			bool bStatus = false;

			if ((nBottomStatus == LEFT_VIOLATION_AREA && (nCenterStatus == LEFT_CENTER_LANE_VIO || nCenterStatus == LEFT_VIOLATION_AREA))
				|| (nBottomStatus == RIGHT_VIOLATION_AREA && (nCenterStatus == RIGHT_CENTER_LANE_VIO || nCenterStatus == RIGHT_VIOLATION_AREA)))
				bStatus = true;

			if (//param->mot_info->mot_box_info[ntrack].n_sub_box > 0 &&
				(((pRegion->CRegion_line_touch_forLaneVio_side(rtBoundingBox.x, nPtBoxRightX, nPtBottomY) == 1 || pRegion->CRegion_line_touch_forLaneVio_side(rtBoundingBox.x, nPtBoxRightX, nPtCenterY) == 1)
					&& param->mot_LaneSave[nTrackID].nLaneVioCnt == 0 && bStatus == true)
					|| param->mot_LaneSave[nTrackID].nLaneVioCnt != 0))
			{
				if (param->mot_LaneSave[nTrackID].nLaneVioCnt == 0)
				{
					param->mot_LaneSave[nTrackID].startTime = currentClock;

					if (!param->mot_LaneSave[nTrackID].pIplImage)
						param->mot_LaneSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

					cvCopy(frame, param->mot_LaneSave[nTrackID].pIplImage);

					cvRectangleR(param->mot_LaneSave[nTrackID].pIplImage, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);

					param->mot_LaneSave[nTrackID].PtTrackTop.x = nPtBottomX;
					param->mot_LaneSave[nTrackID].PtTrackTop.y = nPtBottomY;

					param->mot_LaneSave[nTrackID].rtTrackStart = rtBoundingBox; //2018.10.26 Young

					param->mot_LaneSave[nTrackID].nLaneVioCnt++;
					param->mot_LaneSave[nTrackID].catchTime = currentClock;
					//param->mot_LaneSave[nTrackID].nClass = nClassID;
					//param->mot_LaneSave[nTrackID].nStartStatus = pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth);
					param->mot_LaneSave[nTrackID].nStartStatus = nBottomStatus;

				}
				else
				{
					if (nClassID == REAR_BIKE_CLASS_ID || nClassID == REAR_TRUCKBIKE_CLASS_ID)
					{
						//Check the movement of the object when the rear bike.
						if ((param->mot_LaneSave[nTrackID].PtTrackTop.y - nPtBottomY > 0) && (param->mot_LaneSave[nTrackID].rtTrackStart.y - rtBoundingBox.y > 0))
						{
							param->mot_LaneSave[nTrackID].nLaneVioCnt++;
							param->mot_LaneSave[nTrackID].catchTime = currentClock;
							//param->mot_LaneSave[nTrackID].nEndStatus = pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth);
							param->mot_LaneSave[nTrackID].nEndStatus = nBottomStatus;
						}
					}
					else if (nClassID == FRONT_BIKE_CLASS_ID || nClassID == FRONT_TRUCKBIKE_CLASS_ID)
					{
						//Check the movement of the object when the front bike.
						if ((param->mot_LaneSave[nTrackID].PtTrackTop.y - nPtBottomY < 0) && (param->mot_LaneSave[nTrackID].rtTrackStart.y - rtBoundingBox.y < 0))
						{
							param->mot_LaneSave[nTrackID].nLaneVioCnt++;
							param->mot_LaneSave[nTrackID].catchTime = currentClock;
							//param->mot_LaneSave[nTrackID].nEndStatus = pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth);
							param->mot_LaneSave[nTrackID].nEndStatus = nBottomStatus;
						}
					}
					else
					{
						param->mot_LaneSave[nTrackID].nLaneVioCnt++;
						param->mot_LaneSave[nTrackID].catchTime = currentClock;
						//param->mot_LaneSave[nTrackID].nEndStatus = pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth);
						param->mot_LaneSave[nTrackID].nEndStatus = nBottomStatus;
					}
				}

				std::cout << nTrackID << ":lane vio count: " << param->mot_LaneSave[nTrackID].nLaneVioCnt << std::endl;

				if (param->mot_LaneSave[nTrackID].nLaneVioCnt >= 5 && param->mot_LaneSave[nTrackID].nLaneVioCnt <= nLaneMaxCount && param->mot_LaneSave[nTrackID].nLaneViolation == 0 && bStatus == true
					&& ((param->mot_LaneSave[nTrackID].nStartStatus == LEFT_VIOLATION_AREA && param->mot_LaneSave[nTrackID].nEndStatus == RIGHT_VIOLATION_AREA)
						|| (param->mot_LaneSave[nTrackID].nStartStatus == RIGHT_VIOLATION_AREA && param->mot_LaneSave[nTrackID].nEndStatus == LEFT_VIOLATION_AREA)))
				{
					param->mot_LaneSave[nTrackID].nLaneViolation = 1;

					//std::cout << "Time ===============:" << currentClock << ";============== " << param->mot_LaneSave[nTrackID].startTime << std::endl;

					int millisecond = (int)((float)(currentClock - param->mot_LaneSave[nTrackID].startTime) / CLOCKS_PER_SEC * 100.0f) % 100;

					//int seconds;
					//if (param->mot_LaneSave[nTrackID].pLPImage)
					//	seconds = (int)((float)(currentClock - param->mot_LaneSave[nTrackID].lprTime) / CLOCKS_PER_SEC);

					sprintf(full_save_image_path, "%s/laneTemp/%02d_%s_%02d_000_%s%02d_01.jpg", vio_file_path, LANE_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
					CvPoint ptWronglane[2];
					ptWronglane[0].x = (int)((float)ptTop.x * nWSize);
					ptWronglane[0].y = (int)((float)ptTop.y * nHSize);
					ptWronglane[1].x = (int)((float)ptBot.x * nWSize);
					ptWronglane[1].y = (int)((float)ptBot.y * nHSize);
					cvLine(param->mot_LaneSave[nTrackID].pIplImage, ptWronglane[0], ptWronglane[1], cvScalar(0, 0, 255, 0), 2, 7, 0); //2018.11.12

					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_LaneSave[nTrackID].pIplImage, 0);

					/*cvRectangleR(frame, rectArea, param->track_color[nTrackID], 2, 1, 0);
					cvRectangleR(frame, fullRect, param->track_color[nTrackID], 2, 1, 0);*/
					//convert_2D_to_3D_Box(frame, fullRect, param->track_color[nTrackID]);

					if (clone_frame)
					{
						//20190327 Hai
						cvCopy(frame, clone_frame);
						cvLine(clone_frame, ptWronglane[0], ptWronglane[1], cvScalar(0, 0, 255, 0), 2, 7, 0);
						cvRectangleR(clone_frame, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);
					}
					else
					{
						//20190222 hai Violation color
						cvLine(frame, ptWronglane[0], ptWronglane[1], cvScalar(0, 0, 255, 0), 2, 7, 0);
						cvRectangleR(frame, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);
					}

					//sprintf(textTmp, "[%d] %.2f", nClassID, fScore);
					//cvPutText(frame, textTmp, cvPoint((int)fullRect.x, (int)fullRect.y), &font, param->track_color[nTrackID]);
					//cvPutText(frame, textTmp, cvPoint((int)fullRect.x, (int)fullRect.y), &font, param->vio_color[LANE_VIOLATION_CLR]); //20190222 hai Violation color

					sprintf(full_save_image_path, "%s/laneTemp/%02d_%s_%02d_000_%s%02d_02.jpg", vio_file_path, LANE_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
					if (clone_frame)
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
					}
					else
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}

					sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, LANE_VIOLATION_CODE,
						param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);

					if (param->mot_LaneSave[nTrackID].pLPImage && param->mot_LaneSave[nTrackID].LPRect.x > 20 && param->mot_LaneSave[nTrackID].LPRect.x + param->mot_LaneSave[nTrackID].LPRect.width < frame->width - 20)
					{
						sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_%s.jpg", vio_file_path, LANE_VIOLATION_CODE,
							param->camera_id, nClassID, strTime, millisecond, param->mot_LaneSave[nTrackID].save_LPimage_coordinate);

						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_LaneSave[nTrackID].pLPImage, 0);
					}
					else if (nClassID == REAR_BIKE_CLASS_ID && fullRect.x > 10 && (fullRect.x + fullRect.width) < (frame->width - 10)
						&& (nEndY >= nPtBottomY && (nEndY - abs(ptLine[0].y - ptLine[2].y) / 2) < nPtBottomY))
					{
						cvRectangleR(frame, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}
					else
					{
						sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, LANE_VIOLATION_CODE,
							param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
						cvRectangleR(frame, fullRect, param->vio_color[LANE_VIOLATION_CLR], 2, 1, 0);
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}

					cvReleaseImage(&param->mot_LaneSave[nTrackID].pIplImage);
					param->mot_LaneSave[nTrackID].pIplImage = NULL;

					cvReleaseImage(&param->mot_LaneSave[nTrackID].pLPImage);
					param->mot_LaneSave[nTrackID].pLPImage = NULL;

					std::cout << "wrong lane violation" << std::endl;
				}
			}
		}

		
		//20190130 hai for Overlay Display
		//if (COUNT_MODE_COUNTRY == 1 && param->mot_LaneSave[nTrackID].nLaneViolation == 1)
		if (param->mot_LaneSave[nTrackID].nLaneViolation == 1)
		{
			IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);
			cvCopy(res_frame, overlay_frame);
			cvRectangleR(overlay_frame, rtBoundingBox, param->vio_color[LANE_VIOLATION_CLR], -1); //20190222 hai Violation color
			cvAddWeighted(overlay_frame, fOverlay_alpha, res_frame, 1 - fOverlay_alpha, 0, res_frame);

			param->mot_DataSave[nTrackID].nVioDisplay[LANE_VIOLATION_CLR] = 1; //2019022
			violation_text_display(res_frame, param, ntrack, nTrackID);
			//sprintf(textTmp, "LANE");
			//cvPutText(res_frame, textTmp, cvPoint((int)rtBoundingBox.x, (int)rtBoundingBox.y), &font, param->vio_color[LANE_VIOLATION_CLR]); //20190222 hai Violation color

			if (overlay_frame)
				cvReleaseImage(&overlay_frame);
		}


		int end_seconds = (int)((float)(currentClock - param->mot_LaneSave[nTrackID].endTime) / CLOCKS_PER_SEC);

		// ===== [release violation info] =====
		if (param->mot_LaneSave[nTrackID].nLaneVioCnt > nLaneMaxCount && param->mot_LaneSave[nTrackID].nLaneViolation == 0)
			release_lane_violation(param, nTrackID);
		else if (param->mot_LaneSave[nTrackID].nLaneViolation == 1)
		{
			int seconds = (int)((float)(currentClock - param->mot_LaneSave[nTrackID].catchTime) / CLOCKS_PER_SEC);

			//std::cout << "TimeOut ===============: " << seconds << std::endl;

			if (seconds >= 5) //5초 초과
			{
				release_lane_violation(param, nTrackID);
			}

			//release_lane_violation(param, nTrackID);
		}

		//else if (end_seconds >= 3 && param->mot_LaneSave[nTrackID].nLaneViolation == 0) //3초 초과 //// 2018.09.03
		//{
		//	release_lane_violation(param, nTrackID);
		//}
		//else if (param->mot_LaneSave[nTrackID].nLPR == 1)
		//{
		//	int seconds = (int)((float)(currentClock - param->mot_LaneSave[nTrackID].lprTime) / CLOCKS_PER_SEC);

		//	//std::cout << "TimeOut for other cases ===============: " << seconds << std::endl;

		//	if (seconds >= 30) //30초 초과
		//	{
		//		release_lane_violation(param, nTrackID);
		//	}
		//}

	}

	param->mot_LaneSave[nTrackID].endTime = currentClock; //// 2018.09.03
}

void release_lane_violation(st_det_mot_param *param, int nTrackID)
{
	param->mot_LaneSave[nTrackID].nLaneViolation = 0;
	param->mot_LaneSave[nTrackID].nLaneVioCnt = 0;

	cvReleaseImage(&param->mot_LaneSave[nTrackID].pIplImage);
	param->mot_LaneSave[nTrackID].pIplImage = NULL;

	cvReleaseImage(&param->mot_LaneSave[nTrackID].pLPImage);
	param->mot_LaneSave[nTrackID].pLPImage = NULL;

	param->mot_LaneSave[nTrackID].nLPR = 0;

	param->mot_LaneSave[nTrackID].nTouchBot = 0;
	param->mot_LaneSave[nTrackID].nTouchTop = 0;

	param->mot_LaneSave[nTrackID].nStartStatus = -1;
	param->mot_LaneSave[nTrackID].nEndStatus = -1;

	param->mot_DataSave[nTrackID].nVioDisplay[LANE_VIOLATION_CLR] = 0; //2019022
}


//20190523 hai reverse violation

void release_reverse_violation(st_det_mot_param *param, int nTrackID)
{
	param->mot_ReverseSave[nTrackID].nReverseViolation = 0;
	param->mot_ReverseSave[nTrackID].nReverseVioCnt = 0;

	cvReleaseImage(&param->mot_ReverseSave[nTrackID].pIplImage);
	param->mot_ReverseSave[nTrackID].pIplImage = NULL;

	cvReleaseImage(&param->mot_ReverseSave[nTrackID].pLPImage);
	param->mot_ReverseSave[nTrackID].pLPImage = NULL;

	param->mot_ReverseSave[nTrackID].nLPR = 0;

	param->mot_ReverseSave[nTrackID].nTouchBot = 0;
	param->mot_ReverseSave[nTrackID].nTouchTop = 0;

	param->mot_DataSave[nTrackID].nVioDisplay[REVERSE_VIOLATION_CLR] = 0; //2019022
}


void reverse_violation(IplImage *frame, IplImage *res_frame, IplImage *clone_frame, st_det_mot_param *param, int ntrack, int nEndY, char * strTime, CRegion* pRegion, HANDLE hSaveImageDLL)
{
	if (pRegion == nullptr) return;
	CvPoint ptLine[6];
	pRegion->CRegion_copy(1, ptLine);
	CvPoint ptROI[4];
	pRegion->CRegion_copy(2, ptROI);

	char *vio_file_path = param->vio_result_path;
	char full_save_image_path[CHAR_LENGTH];

	char textTmp[CHAR_LENGTH];
	CvFont font;
	cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.7, 0.7, 0, 2, 1);

	clock_t currentClock = clock();

	CvPoint ptTop, ptBot;
	if (ptLine[0].y > ptLine[2].y)
	{
		ptTop = ptLine[2];
		ptBot = ptLine[0];
	}
	else
	{
		ptTop = ptLine[0];
		ptBot = ptLine[2];
	}

	//calculate_line_params();

	int nClassID = param->mot_info->mot_box_info[ntrack].class_id;
	int nTrackID = param->mot_info->mot_box_info[ntrack].track_id;
	float fScore = param->mot_info->det_box_info[ntrack].score;
	CvRect rtBoundingBox = param->mot_info->mot_box_info[ntrack].bouding_box;

	int nPtBoxRightX = rtBoundingBox.x + rtBoundingBox.width;
	int nPtBottomX = rtBoundingBox.x + (rtBoundingBox.width / 2);
	int nPtBottomY = rtBoundingBox.y + rtBoundingBox.height;
	int nBoxWidth = rtBoundingBox.width;
	int nPtCenterY = rtBoundingBox.y + rtBoundingBox.height / 2;

	CvRect rectArea, fullRect;

	fullRect.x = (int)((float)rtBoundingBox.x		* nWSize);
	fullRect.width = (int)((float)rtBoundingBox.width	* nWSize);
	fullRect.y = (int)((float)rtBoundingBox.y		* nHSize);
	fullRect.height = (int)((float)rtBoundingBox.height	* nHSize);

	rectArea = fullRect;
	rectArea.y = rectArea.y + rectArea.height * 1 / 3;
	rectArea.height = rectArea.height * 2 / 3;

	int nReverseMaxCount = 10;

	if (fullRect.height <= 6 * fullRect.width)
	{
		// ===== [Taking LPR image if exists] =====
		if ((nClassID == REAR_BIKE_CLASS_ID || nClassID == CAR_CLASS_ID || nClassID == BAN_CLASS_ID || nClassID == TRUCK_CLASS_ID || nClassID == REAR_TRUCKBIKE_CLASS_ID)
			&& pRegion->CRegion_line_touch_save_LPImage(nPtBottomY, rtBoundingBox.height, nEndY) && param->mot_ReverseSave[nTrackID].nLPR == 0) // 2018.11.12 hai
		{
			std::cout << nTrackID << ": touch LPR line" << std::endl;

			param->mot_ReverseSave[nTrackID].lprTime = currentClock;

			if (!param->mot_ReverseSave[nTrackID].pLPImage)
				param->mot_ReverseSave[nTrackID].pLPImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

			cvCopy(frame, param->mot_ReverseSave[nTrackID].pLPImage);

			cvRectangleR(param->mot_ReverseSave[nTrackID].pLPImage, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);

			param->mot_ReverseSave[nTrackID].LPRect = fullRect;

			sprintf(param->mot_ReverseSave[nTrackID].save_LPimage_coordinate, "X%04d_Y%04d_W%04d_H%04d", rectArea.x, rectArea.y, rectArea.width, rectArea.height);

			param->mot_ReverseSave[nTrackID].nLPR = 1;
		}

		// ===== [car/van/truck Violation] =====
		if (nClassID == CAR_CLASS_ID || nClassID == BAN_CLASS_ID || nClassID == BUS_CLASS_ID || nClassID == TRUCK_CLASS_ID)
		{
			if (param->mot_ReverseSave[nTrackID].nReverseViolation == 0)
			{
				if (pRegion->CRegion_line_touch_forLaneVio_topbot(nPtBottomY, rtBoundingBox.height, ptTop.y, true) == 1 && param->mot_ReverseSave[nTrackID].nTouchTop == 0 && param->mot_ReverseSave[nTrackID].nTouchBot == 0) // 2018.11.12 hai
				{
					param->mot_ReverseSave[nTrackID].nTouchTop = 1;
					param->mot_ReverseSave[nTrackID].PtTrackTop.x = nPtBottomX;
					param->mot_ReverseSave[nTrackID].PtTrackTop.y = nPtBottomY;
					param->mot_ReverseSave[nTrackID].PtTrackTopCen.x = nPtBottomX;
					param->mot_ReverseSave[nTrackID].PtTrackTopCen.y = nPtCenterY;

					param->mot_ReverseSave[nTrackID].startTime = currentClock;

					if (!param->mot_ReverseSave[nTrackID].pIplImage)
						param->mot_ReverseSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

					cvCopy(frame, param->mot_ReverseSave[nTrackID].pIplImage);
					cvRectangleR(param->mot_ReverseSave[nTrackID].pIplImage, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);
				}
				else if (pRegion->CRegion_line_touch_forLaneVio_topbot(nPtBottomY, rtBoundingBox.height, ptBot.y, false) == 1 && param->mot_ReverseSave[nTrackID].nTouchBot == 0 && param->mot_ReverseSave[nTrackID].nTouchTop == 0) // 2018.11.12 hai
				{
					param->mot_ReverseSave[nTrackID].nTouchBot = 1;
					param->mot_ReverseSave[nTrackID].PtTrackBot.x = nPtBottomX;
					param->mot_ReverseSave[nTrackID].PtTrackBot.y = nPtBottomY;
					param->mot_ReverseSave[nTrackID].PtTrackBotCen.x = nPtBottomX;
					param->mot_ReverseSave[nTrackID].PtTrackBotCen.y = nPtCenterY;

					param->mot_ReverseSave[nTrackID].startTime = currentClock;

					if (!param->mot_ReverseSave[nTrackID].pIplImage)
						param->mot_ReverseSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

					cvCopy(frame, param->mot_ReverseSave[nTrackID].pIplImage);
					cvRectangleR(param->mot_ReverseSave[nTrackID].pIplImage, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);
				}

				// === [from bottom to top] === 
				if (pRegion->CRegion_line_touch_forLaneVio_topbot(nPtBottomY, rtBoundingBox.height, ptTop.y, true) == 1 && param->mot_ReverseSave[nTrackID].nTouchTop == 0 && param->mot_ReverseSave[nTrackID].nTouchBot == 1)
				{
					param->mot_ReverseSave[nTrackID].nTouchTop = 1;
					param->mot_ReverseSave[nTrackID].catchTime = currentClock;
					param->mot_ReverseSave[nTrackID].PtTrackTop.x = nPtBottomX;
					param->mot_ReverseSave[nTrackID].PtTrackTop.y = nPtBottomY;
					param->mot_ReverseSave[nTrackID].PtTrackTopCen.x = nPtBottomX;
					param->mot_ReverseSave[nTrackID].PtTrackTopCen.y = nPtCenterY;

					int nPtLaneBotX02 = pRegion->CRegion_LaneArea(param->mot_ReverseSave[nTrackID].PtTrackBot.y);
					int nPtLaneTopX02 = pRegion->CRegion_LaneArea(param->mot_ReverseSave[nTrackID].PtTrackTop.y);

					int nPtLaneBotCenX02 = pRegion->CRegion_LaneArea(param->mot_ReverseSave[nTrackID].PtTrackBotCen.y);
					int nPtLaneTopCenX02 = pRegion->CRegion_LaneArea(param->mot_ReverseSave[nTrackID].PtTrackTopCen.y);

					if (param->mot_ReverseSave[nTrackID].PtTrackBot.x < nPtLaneBotX02 && param->mot_ReverseSave[nTrackID].PtTrackTop.x < nPtLaneTopX02
						&& (param->mot_ReverseSave[nTrackID].PtTrackBotCen.x < nPtLaneBotCenX02 || param->mot_ReverseSave[nTrackID].PtTrackTopCen.x < nPtLaneTopCenX02))
					{
						param->mot_ReverseSave[nTrackID].nReverseViolation = 1;
					}

				}
				//  === [from top to bottom] === 
				else if (pRegion->CRegion_line_touch_forLaneVio_topbot(nPtBottomY, rtBoundingBox.height, ptBot.y, false) == 1 && param->mot_ReverseSave[nTrackID].nTouchBot == 0 && param->mot_ReverseSave[nTrackID].nTouchTop == 1)
				{
					param->mot_ReverseSave[nTrackID].nTouchBot = 1;
					param->mot_ReverseSave[nTrackID].catchTime = currentClock;
					param->mot_ReverseSave[nTrackID].PtTrackBot.x = nPtBottomX;
					param->mot_ReverseSave[nTrackID].PtTrackBot.y = nPtBottomY;
					param->mot_ReverseSave[nTrackID].PtTrackBotCen.x = nPtBottomX;
					param->mot_ReverseSave[nTrackID].PtTrackBotCen.y = nPtCenterY;

					int nPtLaneBotX02 = pRegion->CRegion_LaneArea(param->mot_ReverseSave[nTrackID].PtTrackBot.y);
					int nPtLaneTopX02 = pRegion->CRegion_LaneArea(param->mot_ReverseSave[nTrackID].PtTrackTop.y);

					int nPtLaneBotCenX02 = pRegion->CRegion_LaneArea(param->mot_ReverseSave[nTrackID].PtTrackBotCen.y);
					int nPtLaneTopCenX02 = pRegion->CRegion_LaneArea(param->mot_ReverseSave[nTrackID].PtTrackTopCen.y);

					if (param->mot_ReverseSave[nTrackID].PtTrackTop.x > nPtLaneTopX02 && param->mot_ReverseSave[nTrackID].PtTrackBot.x > nPtLaneBotX02
						&& (param->mot_ReverseSave[nTrackID].PtTrackTopCen.x > nPtLaneTopCenX02 || param->mot_ReverseSave[nTrackID].PtTrackBotCen.x > nPtLaneBotCenX02))
					{
						param->mot_ReverseSave[nTrackID].nReverseViolation = 1;
					}
				}

				if (param->mot_ReverseSave[nTrackID].nReverseViolation == 1)
				{
					int millisecond = (int)((float)(currentClock - param->mot_ReverseSave[nTrackID].startTime) / CLOCKS_PER_SEC * 100.0f) % 100;

					sprintf(full_save_image_path, "%s/reverseTemp/%02d_%s_%02d_000_%s%02d_01.jpg", vio_file_path, REVERSE_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
					CvPoint ptReverse[2];
					ptReverse[0].x = (int)((float)ptTop.x * nWSize);
					ptReverse[0].y = (int)((float)ptTop.y * nHSize);
					ptReverse[1].x = (int)((float)ptBot.x * nWSize);
					ptReverse[1].y = (int)((float)ptBot.y * nHSize);
					cvLine(param->mot_ReverseSave[nTrackID].pIplImage, ptReverse[0], ptReverse[1], cvScalar(0, 0, 255, 0), 2, 7, 0); //2018.11.12
					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_ReverseSave[nTrackID].pIplImage, 0);

					if (clone_frame)
					{
						//20190327 Hai
						cvCopy(frame, clone_frame);
						cvLine(clone_frame, ptReverse[0], ptReverse[1], cvScalar(0, 0, 255, 0), 2, 7, 0);
						cvRectangleR(clone_frame, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);
					}
					else
					{
						//20190222 hai Violation color
						cvLine(frame, ptReverse[0], ptReverse[1], cvScalar(0, 0, 255, 0), 2, 7, 0);
						cvRectangleR(frame, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);
					}

					sprintf(full_save_image_path, "%s/reverseTemp/%02d_%s_%02d_000_%s%02d_02.jpg", vio_file_path, REVERSE_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
					if (clone_frame)
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
					}
					else
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}

					sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, REVERSE_VIOLATION_CODE,
						param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);

					if (param->mot_ReverseSave[nTrackID].pLPImage && param->mot_ReverseSave[nTrackID].LPRect.x > 20 && param->mot_ReverseSave[nTrackID].LPRect.x + param->mot_ReverseSave[nTrackID].LPRect.width < frame->width - 20)
					{
						sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_%s.jpg", vio_file_path, REVERSE_VIOLATION_CODE,
							param->camera_id, nClassID, strTime, millisecond, param->mot_ReverseSave[nTrackID].save_LPimage_coordinate);

						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_ReverseSave[nTrackID].pLPImage, 0);
					}
					else if (fullRect.x > 10 && (fullRect.x + fullRect.width) < (frame->width - 10) && (nEndY >= nPtBottomY && (nEndY - abs(ptLine[0].y - ptLine[2].y) / 2) < nPtBottomY))
					{
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}
					else
					{
						sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, REVERSE_VIOLATION_CODE,
							param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
						if (JPG_SAVE_ENABLE)
							if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
					}

					cvReleaseImage(&param->mot_ReverseSave[nTrackID].pIplImage);
					param->mot_ReverseSave[nTrackID].pIplImage = NULL;

					cvReleaseImage(&param->mot_ReverseSave[nTrackID].pLPImage);
					param->mot_ReverseSave[nTrackID].pLPImage = NULL;

					std::cout << "reverse violation" << std::endl;
				}
			}
		}

		// ===== [motobike and truck-bike Violation] =====

		if (//param->mot_info->mot_box_info[ntrack].n_sub_box > 0 &&
			 (((nClassID == REAR_BIKE_CLASS_ID || nClassID == REAR_TRUCKBIKE_CLASS_ID) && pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) == LEFT_VIOLATION_AREA 
				&& (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtCenterY, nBoxWidth) == LEFT_CENTER_LANE_VIO || pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtCenterY, nBoxWidth) == LEFT_VIOLATION_AREA))
				|| ((nClassID == FRONT_BIKE_CLASS_ID || nClassID == FRONT_TRUCKBIKE_CLASS_ID) && pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) == RIGHT_VIOLATION_AREA
					&& (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtCenterY, nBoxWidth) == RIGHT_CENTER_LANE_VIO || pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtCenterY, nBoxWidth) == RIGHT_VIOLATION_AREA))))
		{
			if (param->mot_ReverseSave[nTrackID].nReverseVioCnt == 0)
			{
				param->mot_ReverseSave[nTrackID].startTime = currentClock;

				if (!param->mot_ReverseSave[nTrackID].pIplImage)
					param->mot_ReverseSave[nTrackID].pIplImage = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);

				cvCopy(frame, param->mot_ReverseSave[nTrackID].pIplImage);

				cvRectangleR(param->mot_ReverseSave[nTrackID].pIplImage, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);

				param->mot_ReverseSave[nTrackID].PtTrackTop.x = nPtBottomX;
				param->mot_ReverseSave[nTrackID].PtTrackTop.y = nPtBottomY;

				param->mot_ReverseSave[nTrackID].rtTrackStart = rtBoundingBox; //2018.10.26 Young

				param->mot_ReverseSave[nTrackID].nReverseVioCnt++;
				param->mot_ReverseSave[nTrackID].catchTime = currentClock;
			}
			else
			{
				if (nClassID == REAR_BIKE_CLASS_ID || nClassID == REAR_TRUCKBIKE_CLASS_ID)
				{
					//Check the movement of the object when the rear bike.
					if ((param->mot_ReverseSave[nTrackID].PtTrackTop.y - nPtBottomY > 0) && (param->mot_ReverseSave[nTrackID].rtTrackStart.y - rtBoundingBox.y > 0))
					{
						param->mot_ReverseSave[nTrackID].nReverseVioCnt++;
						param->mot_ReverseSave[nTrackID].catchTime = currentClock;
					}
				}
				else if (nClassID == FRONT_BIKE_CLASS_ID || nClassID == FRONT_TRUCKBIKE_CLASS_ID)
				{
					//Check the movement of the object when the front bike.
					if ((param->mot_ReverseSave[nTrackID].PtTrackTop.y - nPtBottomY < 0) && (param->mot_ReverseSave[nTrackID].rtTrackStart.y - rtBoundingBox.y < 0))
					{
						param->mot_ReverseSave[nTrackID].nReverseVioCnt++;
						param->mot_ReverseSave[nTrackID].catchTime = currentClock;
					}
				}
				else
				{

					param->mot_ReverseSave[nTrackID].nReverseVioCnt++;
					param->mot_ReverseSave[nTrackID].catchTime = currentClock;
				}
			}

			std::cout << nTrackID << ":reverse vio count: " << param->mot_ReverseSave[nTrackID].nReverseVioCnt << std::endl;

			if (param->mot_ReverseSave[nTrackID].nReverseVioCnt == nReverseMaxCount && param->mot_ReverseSave[nTrackID].nReverseViolation == 0)
			{
				param->mot_ReverseSave[nTrackID].nReverseViolation = 1;

				int millisecond = (int)((float)(currentClock - param->mot_ReverseSave[nTrackID].startTime) / CLOCKS_PER_SEC * 100.0f) % 100;

				sprintf(full_save_image_path, "%s/reverseTemp/%02d_%s_%02d_000_%s%02d_01.jpg", vio_file_path, REVERSE_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
				CvPoint ptReverse[2];
				ptReverse[0].x = (int)((float)ptTop.x * nWSize);
				ptReverse[0].y = (int)((float)ptTop.y * nHSize);
				ptReverse[1].x = (int)((float)ptBot.x * nWSize);
				ptReverse[1].y = (int)((float)ptBot.y * nHSize);
				cvLine(param->mot_ReverseSave[nTrackID].pIplImage, ptReverse[0], ptReverse[1], cvScalar(0, 0, 255, 0), 2, 7, 0); //2018.11.12

				if (JPG_SAVE_ENABLE)
					if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_ReverseSave[nTrackID].pIplImage, 0);

				if (clone_frame)
				{
					//20190327 Hai
					cvCopy(frame, clone_frame);
					cvLine(clone_frame, ptReverse[0], ptReverse[1], cvScalar(0, 0, 255, 0), 2, 7, 0);
					cvRectangleR(clone_frame, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);
				}
				else
				{
					//20190222 hai Violation color
					cvLine(frame, ptReverse[0], ptReverse[1], cvScalar(0, 0, 255, 0), 2, 7, 0);
					cvRectangleR(frame, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);
				}


				sprintf(full_save_image_path, "%s/reverseTemp/%02d_%s_%02d_000_%s%02d_02.jpg", vio_file_path, REVERSE_VIOLATION_CODE, param->camera_id, nClassID, strTime, millisecond);
				if (clone_frame)
				{
					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, clone_frame, 0);
				}
				else
				{
					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
				}

				sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, REVERSE_VIOLATION_CODE,
					param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);

				if (param->mot_ReverseSave[nTrackID].pLPImage && param->mot_ReverseSave[nTrackID].LPRect.x > 20 && param->mot_ReverseSave[nTrackID].LPRect.x + param->mot_ReverseSave[nTrackID].LPRect.width < frame->width - 20)
				{
					sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_%s.jpg", vio_file_path, REVERSE_VIOLATION_CODE,
						param->camera_id, nClassID, strTime, millisecond, param->mot_ReverseSave[nTrackID].save_LPimage_coordinate);

					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, param->mot_ReverseSave[nTrackID].pLPImage, 0);
				}
				else if (nClassID == REAR_BIKE_CLASS_ID && fullRect.x > 10 && (fullRect.x + fullRect.width) < (frame->width - 10)
					&& (nEndY >= nPtBottomY && (nEndY - abs(ptLine[0].y - ptLine[2].y) / 2) < nPtBottomY))
				{
					cvRectangleR(frame, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);
					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
				}
				else
				{
					sprintf(full_save_image_path, "%s/lpr/input/%02d_%s_%02d_000_%s%02d_02_X%04d_Y%04d_W%04d_H%04d_NoPL.jpg", vio_file_path, REVERSE_VIOLATION_CODE,
						param->camera_id, nClassID, strTime, millisecond, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
					cvRectangleR(frame, fullRect, param->vio_color[REVERSE_VIOLATION_CLR], 2, 1, 0);
					if (JPG_SAVE_ENABLE)
						if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, frame, 0);
				}

				cvReleaseImage(&param->mot_ReverseSave[nTrackID].pIplImage);
				param->mot_ReverseSave[nTrackID].pIplImage = NULL;

				cvReleaseImage(&param->mot_ReverseSave[nTrackID].pLPImage);
				param->mot_ReverseSave[nTrackID].pLPImage = NULL;

				std::cout << "wrong lane violation" << std::endl;
			}
		}


		//20190130 hai for Overlay Display
		//if (COUNT_MODE_COUNTRY == 1 && param->mot_ReverseSave[nTrackID].nReverseViolation == 1)
		if (param->mot_ReverseSave[nTrackID].nReverseViolation == 1)
		{
			IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);
			cvCopy(res_frame, overlay_frame);
			cvRectangleR(overlay_frame, rtBoundingBox, param->vio_color[REVERSE_VIOLATION_CLR], -1); //20190222 hai Violation color
			cvAddWeighted(overlay_frame, fOverlay_alpha, res_frame, 1 - fOverlay_alpha, 0, res_frame);

			param->mot_DataSave[nTrackID].nVioDisplay[REVERSE_VIOLATION_CLR] = 1; //2019022
			violation_text_display(res_frame, param, ntrack, nTrackID);
			//sprintf(textTmp, "LANE");
			//cvPutText(res_frame, textTmp, cvPoint((int)rtBoundingBox.x, (int)rtBoundingBox.y), &font, param->vio_color[LANE_VIOLATION_CLR]); //20190222 hai Violation color

			if (overlay_frame)
				cvReleaseImage(&overlay_frame);
		}


		int end_seconds = (int)((float)(currentClock - param->mot_ReverseSave[nTrackID].endTime) / CLOCKS_PER_SEC);

		// ===== [release violation info] =====
		if (param->mot_ReverseSave[nTrackID].nReverseViolation == 1)
		{
			int seconds = (int)((float)(currentClock - param->mot_ReverseSave[nTrackID].catchTime) / CLOCKS_PER_SEC);

			//std::cout << "TimeOut ===============: " << seconds << std::endl;

			if (seconds >= 5) //5초 초과
			{
				release_reverse_violation(param, nTrackID);
			}
		}

		//else if (end_seconds >= 3 && param->mot_ReverseSave[nTrackID].nReverseViolation == 0) //3초 초과 //// 2018.09.03
		//{
		//	release_reverse_violation(param, nTrackID);
		//}

		else if ((((nClassID == FRONT_BIKE_CLASS_ID || nClassID == FRONT_TRUCKBIKE_CLASS_ID) && (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) == LEFT_VIOLATION_AREA)) // 2018.11.09 hai
			|| ((nClassID == REAR_BIKE_CLASS_ID || nClassID == REAR_TRUCKBIKE_CLASS_ID) && (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) == RIGHT_VIOLATION_AREA)) // 2018.11.09 hai
			|| ((nClassID == SIDE_BIKE_CLASS_ID || nClassID == SIDE_TRUCKBIKE_CLASS_ID) && pRegion->CRegion_line_touch_forLaneVio_side(rtBoundingBox.x, nPtBoxRightX, nPtBottomY) == 0))
			&& param->mot_ReverseSave[nTrackID].nReverseVioCnt > 0 && param->mot_ReverseSave[nTrackID].nReverseVioCnt < nReverseMaxCount)
		{
			release_reverse_violation(param, nTrackID);
		}

		//else if (param->mot_ReverseSave[nTrackID].nLPR == 1)
		//{
		//	int seconds = (int)((float)(currentClock - param->mot_ReverseSave[nTrackID].lprTime) / CLOCKS_PER_SEC);

		//	//std::cout << "TimeOut for other cases ===============: " << seconds << std::endl;

		//	if (seconds >= 30) //30초 초과
		//	{
		//		release_reverse_violation(param, nTrackID);
		//	}
		//}

	}

	param->mot_ReverseSave[nTrackID].endTime = currentClock; //// 2018.09.03
}


void object_flow_count(st_mot_info *mot_info, int num, int n_class, int reset, int line)
{

	if (reset == 1)
	{
		for (int i = 0; i < n_class; i++)
		{
			mot_info->object_flow_number[i] = 0;  //ÃÊ±âÈ­
		}

		////=== 0629 edited ===////
		for (int j = 0; j < MAX_TRACK; j++)
		{
			mot_info->object_confirm[j] = 0;
			mot_info->TO_object[j] = 0;
		}
	}

	for (int i = 0; i < num; i++)
	{
		if (!mot_info->b_counted[mot_info->mot_box_info[i].track_id])
		{
			int nFrameOutCount = 20;
			
			bool bCheck = true;
			//bool bCheck = false;
			if (mot_info->mot_box_info[i].bouding_box.width < LIMITED_WIDTH && mot_info->mot_box_info[i].bouding_box.height < LIMITED_HEIGHT)//indonesia demo
				bCheck = true;

			if (line_touch_forcounting(mot_info->mot_box_info[i].bouding_box, line) && mot_info->object_confirm[mot_info->mot_box_info[i].track_id] == 0 && bCheck)////=== 0629 edited ===////
			{
				mot_info->object_confirm[mot_info->mot_box_info[i].track_id]++; ////=== 0629 edited ===////
				mot_info->TO_object[mot_info->mot_box_info[i].track_id] = 0; ////=== 0629 edited ===////

				//if (mot_info->mot_box_info[i].class_id == HUMAN_CLASS_ID) 
				//	m_nFlowCountTotal++;				

				mot_info->object_flow_number[mot_info->mot_box_info[i].class_id]++;

				//20190102 Counting
				if (mot_info->mot_box_info[i].class_id == BICYCLE_CLASS_ID)
				{
					nBicycleFlowCount += mot_info->object_flow_number[BICYCLE_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == CAR_CLASS_ID)
				{
					nCarFlowCount += mot_info->object_flow_number[CAR_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == BAN_CLASS_ID)
				{
					nVanFlowCount += mot_info->object_flow_number[BAN_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == BUS_CLASS_ID)
				{
					nBusFlowCount += mot_info->object_flow_number[BUS_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == TRUCK_CLASS_ID)
				{
					nTruckFlowCount += mot_info->object_flow_number[TRUCK_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == REAR_BIKE_CLASS_ID)
				{
					nBikesFlowCount += mot_info->object_flow_number[REAR_BIKE_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == FRONT_BIKE_CLASS_ID)
				{
					nBikesFlowCount += mot_info->object_flow_number[FRONT_BIKE_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == SIDE_BIKE_CLASS_ID)
				{
					nBikesFlowCount += mot_info->object_flow_number[SIDE_BIKE_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == SIDE_TRUCKBIKE_CLASS_ID)
				{
					nBikesFlowCount += mot_info->object_flow_number[SIDE_TRUCKBIKE_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == FRONT_TRUCKBIKE_CLASS_ID)
				{
					nBikesFlowCount += mot_info->object_flow_number[FRONT_TRUCKBIKE_CLASS_ID];
				}
				else if (mot_info->mot_box_info[i].class_id == REAR_TRUCKBIKE_CLASS_ID)
				{
					nBikesFlowCount += mot_info->object_flow_number[REAR_TRUCKBIKE_CLASS_ID];
				}
				//==================

				mot_info->b_counted[mot_info->mot_box_info[i].track_id] = true;
				int n_box = mot_info->mot_box_info[i].n_sub_box;
				for (int n = 0; n < n_box; n++)
				{
					mot_info->object_flow_number[mot_info->mot_box_info[i].sub_box_info.class_id]++;
				}


			}
			else ////=== 0629 edited ===////
			{
				if (mot_info->TO_object[mot_info->mot_box_info[i].track_id]++ >= nFrameOutCount)
				{
					mot_info->object_confirm[mot_info->mot_box_info[i].track_id] = 0;
					mot_info->TO_object[mot_info->mot_box_info[i].track_id] = 0;
				}
			}
		}
	}


#if 0
	for (int i = 0; i < n_class; i++)
	{
		printf("%d = %d  ", i, mot_info->object_flow_number[i]);
	}
	printf("\n");
#endif


}

void object_flow_count_SmartStore(IplImage *image, st_det_mot_param *param, st_mot_info *mot_info, int num, int n_class, int reset, int line, CRegion* pRegion)
{

	if (pRegion == nullptr) return;
	CvPoint ptLine[6];
	pRegion->CRegion_copy(1, ptLine);


	bool bIsHand = false;
	for (int i = 0; i < num; i++)
	{
		int nObjectY = mot_info->mot_box_info[i].bouding_box.y + mot_info->mot_box_info[i].bouding_box.height;

		if (mot_info->mot_box_info[i].class_id == TRUCK_CLASS_ID && nObjectY > ptLine[0].y)
		{
			bIsHand = true;
			nTruckFlowCount = 0;
			break;
		}
	}

	if (!bIsHand)
	{
		nTruckFlowCount++;
		if (nTruckFlowCount >= 5)
		{
			nCarFlowCount = 0;
			nVanFlowCount = 0;
			nCarFlowCount_Daewoo = 0;
			nVanFlowCount_Daewoo = 0;
			nTruckFlowCount = 5;

			for (int i = 0; i < num; i++)
			{
				//if (!mot_info->b_counted[mot_info->mot_box_info[i].track_id])
				{

					int nObjectX = mot_info->mot_box_info[i].bouding_box.x + mot_info->mot_box_info[i].bouding_box.width / 2;

					////Remain
					//if (nObjectX <= (int)((ptLine[0].x + ptLine[2].x) / 2))
					//{
					//	if (mot_info->mot_box_info[i].class_id == CAR_CLASS_ID || mot_info->mot_box_info[i].class_id == BAN_CLASS_ID || mot_info->mot_box_info[i].class_id == BUS_CLASS_ID)
					//	{
					//		if (mot_info->mot_box_info[i].class_id == CAR_CLASS_ID)
					//		{
					//			nCarFlowCount++;
					//		}
					//		else if (mot_info->mot_box_info[i].class_id == BAN_CLASS_ID)
					//		{
					//			nVanFlowCount++;
					//		}

					//	}
					//}
					////Count
					//else
					if (nObjectX > (int)((ptLine[0].x + ptLine[2].x) / 2)) //20190429
					{
						if (mot_info->mot_box_info[i].class_id == CAR_CLASS_ID || mot_info->mot_box_info[i].class_id == BAN_CLASS_ID || mot_info->mot_box_info[i].class_id == BUS_CLASS_ID)
						{
							if (mot_info->mot_box_info[i].class_id == CAR_CLASS_ID)
							{
								nCarFlowCount_Daewoo++;
							}
							else if (mot_info->mot_box_info[i].class_id == BAN_CLASS_ID)
							{
								nVanFlowCount_Daewoo++;
							}

						}
					}

				}
			}

			//20190429
			nCarFlowCount = nCarFlowCount_Total - nCarFlowCount_Daewoo;

			nVanFlowCount = nVanFlowCount_Total - nVanFlowCount_Daewoo;
		}
	}


}


void object_flow_count_AreaCheck(IplImage *res_frame, st_det_mot_param *param, st_mot_info *mot_info, int num, int n_class, int reset, int line, CRegion* pRegion)
{

	if (pRegion == nullptr) return;
	CvPoint ptArea[7];
	pRegion->CRegion_copy(3, ptArea);

	bool bIsHand = false;
	for (int i = 0; i < num; i++)
	{
		if (mot_info->mot_box_info[i].class_id == TRUCK_CLASS_ID || mot_info->mot_box_info[i].bouding_box.width >= res_frame->width/7)
		{
			bIsHand = true;
			nTruckFlowCount = 0;
			break;
		}
	}

	if (!bIsHand)
	{
		nTruckFlowCount++;
		if (nTruckFlowCount >= 5)
		{
			nTruckFlowCount = 0;
			nArea1Count = 0; //ptArea 1-2
			nArea2Count = 0; //ptArea 2-3
			nArea4Count = 0; //ptArea 4-5
			nArea5Count = 0; //ptArea 5-6
			nArea6Count = 0; //ptArea 6-7

			for (int i = 0; i < num; i++)
			{
				int nObjectX = mot_info->mot_box_info[i].bouding_box.x + mot_info->mot_box_info[i].bouding_box.width / 2;
				int nObjectY = mot_info->mot_box_info[i].bouding_box.y + mot_info->mot_box_info[i].bouding_box.height / 2;

				//Area 1-2
				if (nObjectX >= ptArea[0].x && nObjectX <= ptArea[1].x && nObjectY <= (ptArea[0].y + ptArea[1].y) / 2 && nObjectY >= 0)
				{
					nArea1Count = 1;
				}
				//Area 2-3
				if (nObjectX >= ptArea[1].x && nObjectX <= ptArea[2].x && nObjectY <= (ptArea[1].y + ptArea[2].y) / 2 && nObjectY >= 0)
				{
					nArea2Count = 1;
				}
				//Area 4-5
				if (nObjectX >= ptArea[3].x && nObjectX <= ptArea[4].x && nObjectY >= (ptArea[3].y + ptArea[4].y) / 2 && nObjectY <= res_frame->height)
				{
					nArea4Count = 1;
				}
				//Area 5-6
				if (nObjectX >= ptArea[4].x && nObjectX <= ptArea[5].x && nObjectY >= (ptArea[4].y + ptArea[5].y) / 2 && nObjectY <= res_frame->height)
				{
					nArea5Count = 1;
				}
				//Area 6-7
				if (nObjectX >= ptArea[5].x && nObjectX <= ptArea[6].x && nObjectY >= (ptArea[5].y + ptArea[6].y) / 2 && nObjectY <= res_frame->height)
				{
					nArea6Count = 1;
				}
			}
		}
	}

	if (nArea1Count > 0)
		draw_Area(res_frame, 0, 1, pRegion, false);
	else
		draw_Area(res_frame, 0, 1, pRegion, true);

	if (nArea2Count > 0)
		draw_Area(res_frame, 1, 2, pRegion, false);
	else
		draw_Area(res_frame, 1, 2, pRegion, true);

	if (nArea4Count > 0)
		draw_Area(res_frame, 3, 4, pRegion, false);
	else
		draw_Area(res_frame, 3, 4, pRegion, true);

	if (nArea5Count > 0)
		draw_Area(res_frame, 4, 5, pRegion, false);
	else
		draw_Area(res_frame, 4, 5, pRegion, true);

	if (nArea6Count > 0)
		draw_Area(res_frame, 5, 6, pRegion, false);
	else
		draw_Area(res_frame, 5, 6, pRegion, true);
}

//20190423 Daewoo
void draw_Area(IplImage *res_frame, int nPt1, int nPt2, CRegion* pRegion, bool bEmpty)
{
	if (pRegion == nullptr) return;
	CvPoint ptArea[7];
	pRegion->CRegion_copy(3, ptArea);

	IplImage * overlay_frame = cvCreateImage(cvSize(res_frame->width, res_frame->height), res_frame->depth, res_frame->nChannels);

	CvRect rtDraw;
	if (!bEmpty)
	{
		
		if (nPt1 < 2 && nPt2 < 3)
		{
			rtDraw.x = ptArea[nPt1].x;
			rtDraw.y = 0;
			rtDraw.width = ptArea[nPt2].x - ptArea[nPt1].x + 1;
			rtDraw.height = (ptArea[nPt1].y + ptArea[nPt2].y) / 2;
		}
		else if (nPt1 > 2 && nPt2 > 3)
		{
			rtDraw.x = ptArea[nPt1].x;
			rtDraw.y = (ptArea[nPt1].y + ptArea[nPt2].y) / 2;
			rtDraw.width = ptArea[nPt2].x - ptArea[nPt1].x + 1;
			rtDraw.height = res_frame->height - (ptArea[nPt1].y + ptArea[nPt2].y) / 2;
		}

		cvCopy(res_frame, overlay_frame);
		cvRectangleR(overlay_frame, rtDraw, cvScalar(0, 0, 255), CV_FILLED);

		cvAddWeighted(overlay_frame, fOverlay_alpha, res_frame, 1 - fOverlay_alpha, 0, res_frame);
		if (overlay_frame)
			cvReleaseImage(&overlay_frame);
	}
	else
	{
		if (nPt1 < 2 && nPt2 < 3)
		{
			rtDraw.x = ptArea[nPt1].x;
			rtDraw.y = 0;
			rtDraw.width = ptArea[nPt2].x - ptArea[nPt1].x + 1;
			rtDraw.height = (ptArea[nPt1].y + ptArea[nPt2].y) / 2;
		}
		else if (nPt1 > 2 && nPt2 > 3)
		{
			rtDraw.x = ptArea[nPt1].x;
			rtDraw.y = (ptArea[nPt1].y + ptArea[nPt2].y) / 2;
			rtDraw.width = ptArea[nPt2].x - ptArea[nPt1].x + 1;
			rtDraw.height = res_frame->height - (ptArea[nPt1].y + ptArea[nPt2].y) / 2;
		}

		cvCopy(res_frame, overlay_frame);
		cvRectangleR(overlay_frame, rtDraw, cvScalar(0, 255, 0), CV_FILLED);

		cvAddWeighted(overlay_frame, fOverlay_alpha, res_frame, 1 - fOverlay_alpha, 0, res_frame);
		if (overlay_frame)
			cvReleaseImage(&overlay_frame);
	}
	
}



//20190102 Indo
void object_flow_count_Indo(IplImage *image, st_det_mot_param *param, st_mot_info *mot_info, int num, int n_class, int reset, int line, CRegion* pRegion, HANDLE hSaveImageDLL, Classifier* pClassifier)
{
	if (pRegion == nullptr) return;
	CvPoint ptLine[6];
	pRegion->CRegion_copy(1, ptLine);

	if (reset == 1)
	{
		for (int i = 0; i < n_class; i++)
		{
			//mot_info->object_flow_number[i] = 0;  //ÃÊ±âÈ­
		}

		//////=== 0629 edited ===////
		//for (int j = 0; j < MAX_TRACK; j++)
		//{
		//	mot_info->object_confirm[j] = 0;
		//	mot_info->TO_object[j] = 0;
		//}
	}

	CvPoint ptLeft, ptRight;
	if (ptLine[1].x > ptLine[3].x)
	{
		ptLeft = ptLine[3];
	}
	else
	{
		ptLeft = ptLine[1];
	}

	if (ptLine[4].x > ptLine[5].x)
	{
		ptRight = ptLine[4];
	}
	else
	{
		ptRight = ptLine[5];
	}

	for (int i = 0; i < num; i++)
	{
		if (!mot_info->b_counted[mot_info->mot_box_info[i].track_id])
		{
			//int nFrameOutCount = 5;
			int nFrameOutCount = 20;//20190102 Indo

			bool bCheck = true;
			//bool bCheck = false;
			if (mot_info->mot_box_info[i].bouding_box.width < LIMITED_WIDTH && mot_info->mot_box_info[i].bouding_box.height < LIMITED_HEIGHT)//indonesia demo
				bCheck = true;

			//if (mot_info->mot_box_info[i].class_id == 12 && mot_info->mot_box_info[i].track_id == 102 && mot_info->object_confirm[mot_info->mot_box_info[i].track_id])
			//if (mot_info->mot_box_info[i].track_id == 102 )//&& mot_info->TO_object[mot_info->mot_box_info[i].track_id] == 19)
			//{
			//	bool bCheckHai = line_touch_forcounting(mot_info->mot_box_info[i].bouding_box, line);
			//	printf("Bajaj %d, %d \n ", bCheckHai, mot_info->object_confirm[mot_info->mot_box_info[i].track_id]);
			//}
			

			if (line_touch_forcounting(mot_info->mot_box_info[i].bouding_box, line) && mot_info->object_confirm[mot_info->mot_box_info[i].track_id] == 0 && bCheck)
				//&& (mot_info->mot_box_info[i].class_id == FRONT_TRUCKBIKE_CLASS_ID || mot_info->mot_box_info[i].class_id == REAR_TRUCKBIKE_CLASS_ID || mot_info->mot_box_info[i].class_id == SIDE_TRUCKBIKE_CLASS_ID))////=== 0629 edited ===////
			{
				mot_info->object_confirm[mot_info->mot_box_info[i].track_id]++; //20190102 Indo
				mot_info->TO_object[mot_info->mot_box_info[i].track_id] = 0; //20190102 Indo

				//if (mot_info->mot_box_info[i].class_id == HUMAN_CLASS_ID) 
				//	m_nFlowCountTotal++;		

				int nObjectX = mot_info->mot_box_info[i].bouding_box.x + mot_info->mot_box_info[i].bouding_box.width / 2;
				bool bInside = false;
				if (nObjectX < ptRight.x && nObjectX > ptLeft.x)
					bInside = true;
				else
					bInside = false;

				if (bInside)
					mot_info->object_flow_number[mot_info->mot_box_info[i].class_id]++;

				//20190102 Indo
				//char *vio_file_path = param->vio_result_path;

				if (mot_info->mot_box_info[i].class_id == CAR_CLASS_ID || mot_info->mot_box_info[i].class_id == BAN_CLASS_ID || mot_info->mot_box_info[i].class_id == BUS_CLASS_ID
					|| mot_info->mot_box_info[i].class_id == TRUCK_CLASS_ID || mot_info->mot_box_info[i].class_id == FRONT_BIKE_CLASS_ID || mot_info->mot_box_info[i].class_id == REAR_BIKE_CLASS_ID
					|| mot_info->mot_box_info[i].class_id == SIDE_BIKE_CLASS_ID || mot_info->mot_box_info[i].class_id == BICYCLE_CLASS_ID
					|| mot_info->mot_box_info[i].class_id == FRONT_TRUCKBIKE_CLASS_ID || mot_info->mot_box_info[i].class_id == REAR_TRUCKBIKE_CLASS_ID || mot_info->mot_box_info[i].class_id == SIDE_TRUCKBIKE_CLASS_ID)
				{
					char buff[80], timebuff[80];
					char save_proofimage_path[300];

					CvRect rectArea;
					rectArea.x = (int)(mot_info->mot_box_info[i].bouding_box.x *nWSize);
					rectArea.y = (int)(mot_info->mot_box_info[i].bouding_box.y * nHSize);
					rectArea.width = (int)(mot_info->mot_box_info[i].bouding_box.width * nWSize);
					rectArea.height = (int)(mot_info->mot_box_info[i].bouding_box.height * nHSize);

					//cvRectangleR(image, rectArea, cvScalar(0, 0, 255), 2, 1, 0);	//20190327

					int current_time;
					current_time = get_current_data_time(buff, "M");
					if (mot_info->mot_box_info[i].class_id == BICYCLE_CLASS_ID)
					{
						nBicycleFlowCount += mot_info->object_flow_number[BICYCLE_CLASS_ID];
					}
					else if (mot_info->mot_box_info[i].class_id == CAR_CLASS_ID)
					{
						nCarFlowCount += mot_info->object_flow_number[CAR_CLASS_ID];
					}
					else if (mot_info->mot_box_info[i].class_id == BAN_CLASS_ID)
					{
						nVanFlowCount += mot_info->object_flow_number[BAN_CLASS_ID];
					}
					else if (mot_info->mot_box_info[i].class_id == BUS_CLASS_ID)
					{
						nBusFlowCount += mot_info->object_flow_number[BUS_CLASS_ID];
					}
					else if (mot_info->mot_box_info[i].class_id == TRUCK_CLASS_ID)
					{
						nTruckFlowCount += mot_info->object_flow_number[TRUCK_CLASS_ID];
					}
					else if (mot_info->mot_box_info[i].class_id == REAR_BIKE_CLASS_ID)
					{
						nBikesFlowCount += mot_info->object_flow_number[REAR_BIKE_CLASS_ID];
					}
					else if (mot_info->mot_box_info[i].class_id == FRONT_BIKE_CLASS_ID)
					{
						nBikesFlowCount += mot_info->object_flow_number[FRONT_BIKE_CLASS_ID];
					}
					else if (mot_info->mot_box_info[i].class_id == SIDE_BIKE_CLASS_ID)
					{
						nBikesFlowCount += mot_info->object_flow_number[SIDE_BIKE_CLASS_ID];
					}
					else if (mot_info->mot_box_info[i].class_id == SIDE_TRUCKBIKE_CLASS_ID)
					{
						nTruckBikeFlowCount += mot_info->object_flow_number[SIDE_TRUCKBIKE_CLASS_ID]; //20190214 hai TruckBike->Bajaj
					}
					else if (mot_info->mot_box_info[i].class_id == FRONT_TRUCKBIKE_CLASS_ID)
					{
						nTruckBikeFlowCount += mot_info->object_flow_number[FRONT_TRUCKBIKE_CLASS_ID]; //20190214 hai TruckBike->Bajaj
					}
					else if (mot_info->mot_box_info[i].class_id == REAR_TRUCKBIKE_CLASS_ID)
					{
						nTruckBikeFlowCount += mot_info->object_flow_number[REAR_TRUCKBIKE_CLASS_ID]; //20190214 hai TruckBike->Bajaj
					}

					//20190508 Tensorflow Test
					if (TENSORFLOW_CLASSIFY_USE)
					{
						if (bInside && (mot_info->mot_box_info[i].class_id == CAR_CLASS_ID || mot_info->mot_box_info[i].class_id == BUS_CLASS_ID
							|| mot_info->mot_box_info[i].class_id == BAN_CLASS_ID || mot_info->mot_box_info[i].class_id == TRUCK_CLASS_ID))
						{					
							rectArea.height += 80;

							cvSetImageROI(image, rectArea);
							IplImage *carbox_img = cvCreateImage(cvSize(rectArea.width, rectArea.height), image->depth, image->nChannels);
							cvCopy(image, carbox_img, NULL);
							//cvAddS(carbox_img, cvScalar(150), carbox_img);
							cvResetImageROI(image);

							cv::Mat carbox_mat = cv::cvarrToMat(carbox_img);

							clock_t currentClock = clock();

							pred_probs_t result;
							//cv::cvtColor(carbox_mat, carbox_mat, cv::COLOR_BGR2RGB);
							int image_height = m_cClassifier.m_nHeight;	//224 299
							int image_width = m_cClassifier.m_nWidth;
							cv::resize(carbox_mat, carbox_mat, cv::Size(image_width, image_height), 0.0, 0.0, CV_INTER_LINEAR);
							//cv::resize(carbox_mat, carbox_mat, cv::Size(224, 224), 0.0, 0.0, CV_INTER_CUBIC);
							result = pClassifier->Run(carbox_mat);
							printf("HAIIIIIIIIIIIIIIIIII TENSORFLOW FASTTTTTTTTTT: Class: %d, Prob: %f\n", result.pred_result[0], result.pred_prob[0]);

							CvFont font;
							cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 1, 1, 0, 1, 1);
							char textTmp[CHAR_LENGTH] = " ";
							sprintf(textTmp, "Type: %d, Prob : %f Class %s", result.pred_result[0], result.pred_prob[0], getStringClassID(mot_info->mot_box_info[i].class_id));
							cvPutText(carbox_img, textTmp, cvPoint(40, 40), &font, cvScalar(120, 140, 0, 0));

							float seconds = (float)(clock() - currentClock) / CLOCKS_PER_SEC;
							std::cout << "time: " << seconds << std::endl;

							float fRatio = (float)rectArea.width / (float)rectArea.height;
							//bool bIsGoodResult = result.pred_prob[0] > (result.pred_prob[1] + 0.1f);
							//if (fRatio > 0.7f && bIsGoodResult)
							//if (fRatio > 0.7f && fRatio < 1.5f && result.pred_prob[0] > 0.5f)
							{
								sprintf(save_proofimage_path, "%s/lpr/input/99_%03d_%s_X%04d_Y%04d_W%04d_H%04d.jpg"
									, param->vio_result_path
									, result.pred_result[0], buff, 0, 0, rectArea.width, rectArea.height);

								if (JPG_SAVE_ENABLE)
									if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, save_proofimage_path, carbox_img, 0);
							}

							cvReleaseImage(&carbox_img);
							carbox_mat.release();
						}
					}
				}

				//====================

				mot_info->b_counted[mot_info->mot_box_info[i].track_id] = true;
				int n_box = mot_info->mot_box_info[i].n_sub_box;
				for (int n = 0; n < n_box; n++)
				{
					mot_info->object_flow_number[mot_info->mot_box_info[i].sub_box_info.class_id]++;
				}
			}
			//else
			/*else if (line_touch_forcounting(mot_info->mot_box_info[i].bouding_box, line) == false) //20190102 Indo
			{
				if (mot_info->mot_box_info[i].track_id == 102)
				{
					printf("102 , %d, %d\n ", mot_info->object_confirm[mot_info->mot_box_info[i].track_id], mot_info->TO_object[mot_info->mot_box_info[i].track_id]);
				}

				if (mot_info->TO_object[mot_info->mot_box_info[i].track_id]++ >= nFrameOutCount)
				{
					mot_info->object_confirm[mot_info->mot_box_info[i].track_id] = 0;
					mot_info->TO_object[mot_info->mot_box_info[i].track_id] = 0;
				}
			}*/
		}
	}


#if 0
	for (int i = 0; i < n_class; i++)
	{
		printf("%d = %d  ", i, mot_info->object_flow_number[i]);
	}
	printf("\n");
#endif


}


void object_flow_count_Osan(IplImage *image, st_mot_info *mot_info, int num, int n_class, int reset, int line)
{
	char textCsv[CHAR_LENGTH];

	if (reset == 1)
	{
		for (int i = 0; i < n_class; i++)
		{
			//mot_info->object_flow_number[i] = 0;  //ÃÊ±âÈ­
		}

		////=== 0629 edited ===////
		/*for (int j = 0; j < MAX_TRACK; j++)
		{
			mot_info->object_confirm[j] = 0;
			mot_info->TO_object[j] = 0;
		}*/
	}

	for (int i = 0; i < num; i++)
	{
		if (!mot_info->b_counted[mot_info->mot_box_info[i].track_id])
		{
			//int nFrameOutCount = 5;
			int nFrameOutCount = 20; // 2018.12.13 Osan CCTV
			
			bool bCheck = true;
			//bool bCheck = false;
			if (mot_info->mot_box_info[i].bouding_box.width < LIMITED_WIDTH && mot_info->mot_box_info[i].bouding_box.height < LIMITED_HEIGHT)//indonesia demo
				bCheck = true;

			//if (line_touch_forcounting(mot_info->mot_box_info[i].bouding_box, line) && mot_info->mot_box_info[i].class_id == BICYCLE_CLASS_ID)
			//	cout << "***********" << mot_info->object_confirm[i] << endl;

			if (line_touch_forcounting(mot_info->mot_box_info[i].bouding_box, line) && mot_info->object_confirm[mot_info->mot_box_info[i].track_id] == 0 && bCheck)////=== 0629 edited ===////
			{
				mot_info->object_confirm[mot_info->mot_box_info[i].track_id]++; ////=== 0629 edited ===////
				mot_info->TO_object[mot_info->mot_box_info[i].track_id] = 0; ////=== 0629 edited ===////

				//if (mot_info->mot_box_info[i].class_id == HUMAN_CLASS_ID) 
				//	m_nFlowCountTotal++;				

				//mot_info->object_flow_number[mot_info->mot_box_info[i].class_id]++; //20190104 OSAN

				////============2018.12.13 Osan CCTV
				//if (mot_info->mot_box_info[i].class_id == BICYCLE_CLASS_ID)
				//{
				//	char buff[80], timebuff[80];
				//	char save_proofimage_path[300];

				//	CvRect rectArea;
				//	rectArea.x = (int)(mot_info->mot_box_info[i].bouding_box.x *nWSize);
				//	rectArea.y = (int)(mot_info->mot_box_info[i].bouding_box.y * nHSize);
				//	rectArea.width = (int)(mot_info->mot_box_info[i].bouding_box.width * nWSize);
				//	rectArea.height = (int)(mot_info->mot_box_info[i].bouding_box.height * nHSize);

				//	cvRectangleR(image, rectArea, cvScalar(0, 0, 255), 2, 1, 0);
				//	
				//	int current_time;
				//	current_time = get_current_data_time(buff, "M");
				//	current_time = Osan_get_current_data_time(timebuff, "M");
				//	nBicycleFlowCount += mot_info->object_flow_number[BICYCLE_CLASS_ID];

				//	sprintf(textCsv, "%s,%d\n", timebuff, nBicycleFlowCount);
				//	printf(textCsv);

				//	sprintf(save_proofimage_path, "%s/%s_%d.jpg", result_file_folder, buff, nBicycleFlowCount);
				//	cvSaveImage(save_proofimage_path, image, 0);

				//	OsanBicycleFile << textCsv;
				//}
				////====================


				mot_info->b_counted[mot_info->mot_box_info[i].track_id] = true;
				int n_box = mot_info->mot_box_info[i].n_sub_box;
				for (int n = 0; n < n_box; n++)
				{
					mot_info->object_flow_number[mot_info->mot_box_info[i].sub_box_info.class_id]++;
				}
			}
			else ////=== 0629 edited ===////
			{
				if (mot_info->TO_object[mot_info->mot_box_info[i].track_id]++ >= nFrameOutCount)
				{
					mot_info->object_confirm[mot_info->mot_box_info[i].track_id] = 0;
					mot_info->TO_object[mot_info->mot_box_info[i].track_id] = 0;
				}
			}
		}
	}


#if 0
	for (int i = 0; i < n_class; i++)
	{
		printf("%d = %d  ", i, mot_info->object_flow_number[i]);
	}
	printf("\n");
#endif


}

//yk 2018.12.03
void object_flow_count_forTopline(st_mot_info *mot_info, int num, int n_class, int reset, int line)
{

	if (reset == 1)
	{
		for (int i = 0; i < n_class; i++)
		{
			mot_info->object_flow_number_forTopline[i] = 0;  //ÃÊ±âÈ­
		}

		////=== 0629 edited ===////
		for (int j = 0; j < MAX_TRACK; j++)
		{
			mot_info->object_confirm_forTopline[j] = 0;
			mot_info->TO_object_forTopline[j] = 0;
		}
	}

	for (int i = 0; i < num; i++)
	{
		if (!mot_info->b_counted_forTopline[mot_info->mot_box_info[i].track_id])
		{
			int nFrameOutCount = 5;

			if (line_touch_forcounting(mot_info->mot_box_info[i].bouding_box, line) && mot_info->object_confirm_forTopline[i] == 0) //hai 2018.12.03
			{
				mot_info->object_confirm_forTopline[i]++; ////=== 0629 edited ===////
				mot_info->TO_object_forTopline[i] = 0; ////=== 0629 edited ===////

				//if (mot_info->mot_box_info[i].class_id == HUMAN_CLASS_ID) 
				//	m_nFlowCountTotal++;				

				mot_info->object_flow_number_forTopline[mot_info->mot_box_info[i].class_id]++;
				mot_info->b_counted_forTopline[mot_info->mot_box_info[i].track_id] = true;
				int n_box = mot_info->mot_box_info[i].n_sub_box;
				for (int n = 0; n < n_box; n++)
				{
					mot_info->object_flow_number_forTopline[mot_info->mot_box_info[i].sub_box_info.class_id]++;
				}
			}
			else ////=== 0629 edited ===////
			{
				if (mot_info->TO_object_forTopline[i]++ >= nFrameOutCount)
				{
					mot_info->object_confirm_forTopline[i] = 0;
					mot_info->TO_object_forTopline[i] = 0;
				}
			}
		}
	}


#if 0
	for (int i = 0; i < n_class; i++)
	{
		printf("%d = %d  ", i, mot_info->object_flow_number[i]);
	}
	printf("\n");
#endif


}

void object_flow_draw(IplImage *image, st_mot_info *mot_info, int num, char **names, int line, IplImage * img_count)
{
	char textTmp[CHAR_LENGTH] = " ",
		textTmp_Sedan[CHAR_LENGTH] = "",
		textTmp_SUV[CHAR_LENGTH] = "",
		textTmp_Truck[CHAR_LENGTH] = "",
		textTmp_Bus[CHAR_LENGTH] = "",
		textTmp_Motor[CHAR_LENGTH] = "",
		textTmp_Whel[CHAR_LENGTH] = "",
		textTmp_SmartStore[CHAR_LENGTH] = "";

	int textX_Sedan, textX_SUV, textX_Truck, textX_Bus, textX_Motor, textX_Whel;
	int textY_Sedan, textY_SUV, textY_Truck, textY_Bus, textY_Motor, textY_Whel;

	CvFont font;
	cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.5, 0.5, 0, 2, 1);

	int nGapY = 20, nGapX = 110;
	CvRect rtDraw;

	//20190423 Daewoo
	if (COUNT_MODE_COUNTRY == 4)
	{
		rtDraw.x = 0;
		rtDraw.y = image->height/2 - 40;
		rtDraw.width = image->width /2 + 40;
		rtDraw.height = 30;
	}
	else
	{
		rtDraw.x = 0;
		rtDraw.y = image->height - 40;
		rtDraw.width = image->width ;
		rtDraw.height = 30;
	}

	bool bUseInfo = true;
	if (bUseInfo)
	{
		IplImage * overlay_frame = cvCreateImage(cvSize(image->width, image->height), image->depth, image->nChannels);
		cvCopy(image, overlay_frame);
		cvRectangleR(image, rtDraw, cvScalar(255, 255, 255), CV_FILLED);

		cvAddWeighted(overlay_frame, fOverlay_alpha, image, 1 - fOverlay_alpha, 0, image);
		if (overlay_frame)
			cvReleaseImage(&overlay_frame);
	}

	CvScalar textClr[17];
	textClr[CAR_CLASS_ID] = cvScalar(255, 0, 0, 0);
	textClr[BAN_CLASS_ID] = cvScalar(0, 0, 255, 0);
	textClr[BUS_CLASS_ID] = cvScalar(0, 128, 0, 0);
	textClr[TRUCK_CLASS_ID] = cvScalar(128, 0, 255, 0);
	textClr[FRONT_BIKE_CLASS_ID] = cvScalar(0, 128, 255, 0);
	textClr[HUMAN_CLASS_ID] = cvScalar(255, 0, 128, 255);
	textClr[BICYCLE_CLASS_ID] = cvScalar(255, 128, 0, 0);
	textClr[FRONT_TRUCKBIKE_CLASS_ID] = cvScalar(255, 255, 128, 0);

	for (int c_id = 0; c_id < num - BACKGROUND_CLASS + 5; c_id++)
	{	
		if (COUNT_MODE_COUNTRY == 3) //20190423 Daewoo Counting
		{
			//Remain
			if (c_id == 0)
			{
				if (nTruckFlowCount < 5)
				{
					sprintf(textTmp_SmartStore, "%s[Selecting]    Remain: A:%d ", textTmp_SmartStore, nCarFlowCount);
				}
				else if (nTruckFlowCount >= 5)
				{
					sprintf(textTmp_SmartStore, "%s[Finished]     Remain: A:%d ", textTmp_SmartStore, nCarFlowCount);
				}

				if (bUseInfo)
						cvPutText(image, textTmp_SmartStore, cvPoint(10, rtDraw.y + nGapY), &font, cvScalar(120, 140, 0, 0));
			}
			else if (c_id == 1)
			{
				sprintf(textTmp_SmartStore, "%s B:%d                        Count: ", textTmp_SmartStore, nVanFlowCount);
				if (bUseInfo)
					cvPutText(image, textTmp_SmartStore, cvPoint(10, rtDraw.y + nGapY), &font, cvScalar(120, 140, 0, 0));
			}
			/*else if (c_id == 3)
			{
				sprintf(textTmp, "%sHand:%d ", textTmp, nTruckFlowCount);
				if (bUseInfo)
					cvPutText(image, textTmp, cvPoint(10, rtDraw.y + nGapY), &font, textClr[3]);
			}*/

			//Count
			if (c_id == 4)
			{
				sprintf(textTmp_SmartStore, "%s A:%d ", textTmp_SmartStore, nCarFlowCount_Daewoo);
				if (bUseInfo)
					cvPutText(image, textTmp_SmartStore, cvPoint(10, rtDraw.y + nGapY), &font, cvScalar(120, 140, 0, 0));
			}
			else if (c_id == 5)
			{
				sprintf(textTmp_SmartStore, "%s B:%d ", textTmp_SmartStore, nVanFlowCount_Daewoo);
				if (bUseInfo)
					cvPutText(image, textTmp_SmartStore, cvPoint(10, rtDraw.y + nGapY), &font, cvScalar(120, 140, 0, 0));
			}
			/*
			else if (c_id == 6)
			{
			if (nTruckFlowCount < 5)
			{
			sprintf(textTmp_SmartStore, "%s   [Selecting]", textTmp_SmartStore);
			if (bUseInfo)
			cvPutText(image, textTmp_SmartStore, cvPoint(10, rtDraw.y + nGapY), &font, cvScalar(120, 140, 0, 0));
			}

			{
			sprintf(textTmp_SmartStore, "%s   [Finished]", textTmp_SmartStore);
			if (bUseInfo)
			cvPutText(image, textTmp_SmartStore, cvPoint(10, rtDraw.y + nGapY), &font, cvScalar(120, 140, 0, 0));
			}
			}
			*/

		}
		else if (COUNT_MODE_COUNTRY == 4) //20190423 Daewoo Area Checking
		{
			int nFilled = nArea1Count + nArea2Count + nArea4Count + nArea5Count + nArea6Count;
			if (c_id == 0)
			{
				sprintf(textTmp, "%s Available Areas: %d ", textTmp, (5- nFilled));
				if (bUseInfo)
					cvPutText(image, textTmp, cvPoint(10, rtDraw.y + nGapY), &font, cvScalar(120, 140, 0, 0));
			}
			else if (c_id == 1)
			{
				sprintf(textTmp, "%s Unavailable Areas: %d ", textTmp, nFilled);
				if (bUseInfo)
					cvPutText(image, textTmp, cvPoint(10, rtDraw.y + nGapY), &font, cvScalar(120, 140, 0, 0));
			}
		}
		else if ((c_id == CAR_CLASS_ID) && (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
		{
			//20190213 hai Car->Sedan
			if(COUNT_MODE_COUNTRY == 0)
				sprintf(textTmp, "%sCar:%d ", textTmp, nCarFlowCount);
			else if (COUNT_MODE_COUNTRY == 1)
				sprintf(textTmp, "%sSedan:%d ", textTmp, nCarFlowCount);

			if (bUseInfo)
				cvPutText(image, textTmp, cvPoint(10, rtDraw.y + nGapY), &font, textClr[CAR_CLASS_ID]);
			sprintf(textTmp, "  ");

			sprintf(textTmp_Sedan, "%d", nCarFlowCount);
			cv::Size nTextSize_Sedan = getTextSize(textTmp_Sedan, cv::FONT_HERSHEY_SIMPLEX, 0.5, 2, 0);
			textX_Sedan = SEDAN_X + (BOX_W - nTextSize_Sedan.width) / 2;
			textY_Sedan = BOX_Y + BOX_H / 2;

			if(img_count)
				cvPutText(img_count, textTmp_Sedan, cvPoint(textX_Sedan, textY_Sedan), &font, cvScalar(255, 255, 255));

		}
		else if (c_id == BAN_CLASS_ID && COUNT_MODE_COUNTRY != 3 && COUNT_MODE_COUNTRY != 4) //20190214
		{
			sprintf(textTmp, "%sSUV:%d ", textTmp, nVanFlowCount);

			if (bUseInfo)
				cvPutText(image, textTmp, cvPoint(nGapX, rtDraw.y + nGapY), &font, textClr[BAN_CLASS_ID]);
			sprintf(textTmp, "  ");

			sprintf(textTmp_SUV, "%d", nVanFlowCount);
			cv::Size nTextSize_SUV = getTextSize(textTmp_SUV, cv::FONT_HERSHEY_SIMPLEX, 0.5, 2, 0);
			textX_SUV = SUV_X + (BOX_W - nTextSize_SUV.width) / 2;
			textY_SUV = BOX_Y + BOX_H / 2;

			if (img_count)
				cvPutText(img_count, textTmp_SUV, cvPoint(textX_SUV, textY_SUV), &font, cvScalar(255, 255, 255));

		}
		else if (c_id == BUS_CLASS_ID && (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
		{
			sprintf(textTmp, "%sBus:%d ", textTmp, nBusFlowCount);

			if (bUseInfo)
				cvPutText(image, textTmp, cvPoint(nGapX + nGapX, rtDraw.y + nGapY), &font, textClr[BUS_CLASS_ID]);
			sprintf(textTmp, "  ");

			sprintf(textTmp_Bus, "%d", nBusFlowCount);
			cv::Size nTextSize_Bus = getTextSize(textTmp_Bus, cv::FONT_HERSHEY_SIMPLEX, 0.5, 2, 0);
			textX_Bus = BUS_X + (BOX_W - nTextSize_Bus.width) / 2;
			textY_Bus = BOX_Y + BOX_H / 2;

			if (img_count)
				cvPutText(img_count, textTmp_Bus, cvPoint(textX_Bus, textY_Bus), &font, cvScalar(255, 255, 255));
		}
		else if (c_id == TRUCK_CLASS_ID && (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
		{			
			sprintf(textTmp, "%sTruck:%d ", textTmp, nTruckFlowCount);

			if (bUseInfo)
				cvPutText(image, textTmp, cvPoint(nGapX + nGapX + nGapX, rtDraw.y + nGapY), &font, textClr[TRUCK_CLASS_ID]);
			sprintf(textTmp, "  ");

			sprintf(textTmp_Truck, "%d", nTruckFlowCount);
			cv::Size nTextSize_Truck = getTextSize(textTmp_Truck, cv::FONT_HERSHEY_SIMPLEX, 0.5, 2, 0);
			textX_Truck = TRUCK_X + (BOX_W - nTextSize_Truck.width) / 2;
			textY_Truck = BOX_Y + BOX_H / 2;

			if (img_count)
				cvPutText(img_count, textTmp_Truck, cvPoint(textX_Truck, textY_Truck), &font, cvScalar(255, 255, 255));
		}
		else if ((c_id == FRONT_BIKE_CLASS_ID) && (COUNT_MODE_COUNTRY == 0 || COUNT_MODE_COUNTRY == 1))
		{
			sprintf(textTmp, "%sBike:%d ", textTmp, nBikesFlowCount);

			if (bUseInfo)
				cvPutText(image, textTmp, cvPoint(20 + nGapX + nGapX + nGapX + nGapX, rtDraw.y + nGapY), &font, textClr[FRONT_BIKE_CLASS_ID]);
			sprintf(textTmp, "  ");

			sprintf(textTmp_Motor, "%d", nBikesFlowCount);
			cv::Size nTextSize_Motor = getTextSize(textTmp_Motor, cv::FONT_HERSHEY_SIMPLEX, 0.5, 2, 0);
			textX_Motor = MOTO_X + (BOX_W - nTextSize_Motor.width) / 2;
			textY_Motor = BOX_Y + BOX_H / 2;

			if (img_count)
				cvPutText(img_count, textTmp_Motor, cvPoint(textX_Motor, textY_Motor), &font, cvScalar(255, 255, 255));

		}
		else if (c_id == HUMAN_CLASS_ID && COUNT_MODE_COUNTRY == 2)
		{
			sprintf(textTmp, "%sHuman:%d ", textTmp, nHumanFlowCount);
		}
		else if (c_id == BICYCLE_CLASS_ID && COUNT_MODE_COUNTRY == 2) // 2018.12.13 Osan CCTV
		{
			sprintf(textTmp, "%sBicycle: %d ", textTmp, nBicycleFlowCount);
		}
		//20190214 hai TruckBike->Bajaj
		else if (c_id == FRONT_TRUCKBIKE_CLASS_ID && COUNT_MODE_COUNTRY == 1)
		{
			sprintf(textTmp, "%sBajaj:%d ", textTmp, nTruckBikeFlowCount);
			//sprintf(textTmp, "%sBa gac:%d ", textTmp, nTruckBikeFlowCount);

			if (bUseInfo)
				cvPutText(image, textTmp, cvPoint(20 + nGapX + nGapX + nGapX + nGapX + nGapX, rtDraw.y + nGapY), &font, textClr[FRONT_TRUCKBIKE_CLASS_ID]);
			sprintf(textTmp, "  ");

			sprintf(textTmp_Whel, "%d", nTruckBikeFlowCount);
			cv::Size nTextSize_Whel = getTextSize(textTmp_Whel, cv::FONT_HERSHEY_SIMPLEX, 0.5, 2, 0);
			textX_Whel = WHEL_X + (BOX_W - nTextSize_Whel.width) / 2;
			textY_Whel = BOX_Y + BOX_H / 2;

			if (img_count)
				cvPutText(img_count, textTmp_Whel, cvPoint(textX_Whel, textY_Whel), &font, cvScalar(255, 255, 255));

		}
		else if (c_id == FRONT_TRUCKBIKE_CLASS_ID && COUNT_MODE_COUNTRY == 0)
		{
			sprintf(textTmp, "%sBa gac:%d ", textTmp, nTruckBikeFlowCount);

			if (bUseInfo)
				cvPutText(image, textTmp, cvPoint(20 + nGapX + nGapX + nGapX + nGapX + nGapX, rtDraw.y + nGapY), &font, textClr[FRONT_TRUCKBIKE_CLASS_ID]);
			sprintf(textTmp, "  ");

			sprintf(textTmp_Whel, "%d", nTruckBikeFlowCount);
			cv::Size nTextSize_Whel = getTextSize(textTmp_Whel, cv::FONT_HERSHEY_SIMPLEX, 0.5, 2, 0);
			textX_Whel = WHEL_X + (BOX_W - nTextSize_Whel.width) / 2;
			textY_Whel = BOX_Y + BOX_H / 2;

			if (img_count)
				cvPutText(img_count, textTmp_Whel, cvPoint(textX_Whel, textY_Whel), &font, cvScalar(255, 255, 255));

		}
		// 20190130 hai for MeanSpeed Display
		else if (c_id == 15 && bSpeedDisplay == true && COUNT_MODE_COUNTRY != 3 && COUNT_MODE_COUNTRY != 4)
		{
			if (nObjectforSpeed > 0)
				fMeanSpeed = fTotalSpeed / nObjectforSpeed;
			else
				fMeanSpeed = 0.0;
			sprintf(textTmp, "%sSpeed: %.1f ", textTmp, fMeanSpeed);
		}
	}
}

//yk 2018.12.03
int nCarFlowCount_forTopline = 0;
int nVanFlowCount_forTopline = 0;
int nBusFlowCount_forTopline = 0;
int nTruckFlowCount_forTopline = 0;
int nBikesFlowCount_forTopline = 0;
int nHumanFlowCount_forTopline = 0;
int nBicycleFlowCount_forTopline = 0;
void object_flow_draw_forTopline(IplImage *image, st_mot_info *mot_info, int num, char **names, int line)
{
	char textTmp[CHAR_LENGTH] = "";
	for (int c_id = 0; c_id < num - BACKGROUND_CLASS; c_id++)
	{
		//sprintf(textTmp, "%s%d:%d ", textTmp, c_id, mot_info->object_flow_number[c_id]);

		if (c_id == CAR_CLASS_ID)
		{
			nCarFlowCount_forTopline += mot_info->object_flow_number_forTopline[CAR_CLASS_ID] + mot_info->object_flow_number_forTopline[BAN_CLASS_ID];
			//sprintf(textTmp, "%sCar:%d ", textTmp, nCarFlowCount_forTopline);

			//20190213 hai Car->Sedan
			if (COUNT_MODE_COUNTRY == 0)
				sprintf(textTmp, "%sCar:%d ", textTmp, nCarFlowCount_forTopline);
			else if (COUNT_MODE_COUNTRY == 1)
				sprintf(textTmp, "%sSedan:%d ", textTmp, nCarFlowCount_forTopline);

		}
		//else if (c_id == BAN_CLASS_ID)
		//{
		//	nVanFlowCount_forTopline += mot_info->object_flow_number_forTopline[BAN_CLASS_ID];
		//	sprintf(textTmp, "%sVan:%d ", textTmp, nVanFlowCount_forTopline);
		//}
		else if (c_id == BUS_CLASS_ID)
		{
			nBusFlowCount_forTopline += mot_info->object_flow_number_forTopline[BUS_CLASS_ID];
			sprintf(textTmp, "%sBus:%d ", textTmp, nBusFlowCount_forTopline);
		}
		else if (c_id == TRUCK_CLASS_ID)
		{
			nTruckFlowCount_forTopline += mot_info->object_flow_number_forTopline[TRUCK_CLASS_ID];
			sprintf(textTmp, "%sTruck:%d ", textTmp, nTruckFlowCount_forTopline);
		}
		else if (c_id == FRONT_BIKE_CLASS_ID)
		{
			nBikesFlowCount_forTopline += mot_info->object_flow_number_forTopline[FRONT_BIKE_CLASS_ID] + mot_info->object_flow_number_forTopline[REAR_BIKE_CLASS_ID] + mot_info->object_flow_number_forTopline[SIDE_BIKE_CLASS_ID]
				+ mot_info->object_flow_number_forTopline[FRONT_TRUCKBIKE_CLASS_ID] + mot_info->object_flow_number_forTopline[REAR_TRUCKBIKE_CLASS_ID] + mot_info->object_flow_number_forTopline[SIDE_TRUCKBIKE_CLASS_ID];
			sprintf(textTmp, "%sBike:%d ", textTmp, nBikesFlowCount_forTopline);
		}
		else if (c_id == HUMAN_CLASS_ID)
		{
			nHumanFlowCount_forTopline += mot_info->object_flow_number_forTopline[HUMAN_CLASS_ID];
			sprintf(textTmp, "%sHuman:%d ", textTmp, nHumanFlowCount_forTopline);
		}
		else if (c_id == BICYCLE_CLASS_ID) 
		{
			nBicycleFlowCount_forTopline += mot_info->object_flow_number_forTopline[BICYCLE_CLASS_ID];
			sprintf(textTmp, "%sBicycle: %d ", textTmp, nBicycleFlowCount_forTopline);
		}

		CvFont font;
		cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.5, 0.5, 0, 2, 1);
		cvPutText(image, textTmp, cvPoint(100, line + 30), &font, cvScalar(0, 255, 0));
	}
}

void biker_violation_draw(IplImage *image, st_violation_info &vio_status)
{
	//	printf("vio_status.n_violation = %d\n", vio_status.n_violation);
	for (int v = 0; v < vio_status.n_violation; v++)
	{
		//		printf("%d)type = (%d %d)\n", v, vio_status.violation_box_info[v].max_rider_violation, vio_status.violation_box_info[v].helmet_violation);
		//		printf("box = (%d %d %d %d)\n", v, vio_status.violation_box_info[v].bouding_box.x, vio_status.violation_box_info[v].bouding_box.y,
		//			vio_status.violation_box_info[v].bouding_box.width, vio_status.violation_box_info[v].bouding_box.height);

		cvRectangleR(image, vio_status.violation_box_info[v].bouding_box, cvScalar(0, 0, 255), 4, 1, 0);
		//convert_2D_to_3D_Box(image, vio_status.violation_box_info[v].bouding_box, cvScalar(0, 0, 255));
	}

}

/*
void violation_box_draw_save_image(IplImage *ori_image, IplImage *res_image, st_violation_info &vio_status)
{
	//	printf("vio_status.n_violation = %d\n", vio_status.n_violation);
	float x_scale = (float)ori_image->width / res_image->width;
	float y_scale = (float)ori_image->height / res_image->height;
	CvRect box;
	for (int v = 0; v < vio_status.n_violation; v++)
	{
		box.x = (int)(vio_status.violation_box_info[v].bouding_box.x * x_scale);
		box.y = (int)(vio_status.violation_box_info[v].bouding_box.y * y_scale);
		box.width = (int)(vio_status.violation_box_info[v].bouding_box.width * x_scale);
		box.height = (int)(vio_status.violation_box_info[v].bouding_box.height * y_scale);

		cvRectangleR(ori_image, box, cvScalar(0, 0, 255), 1, 1, 0);
		//convert_2D_to_3D_Box(ori_image, box, cvScalar(0, 0, 255));

		//// 2018.09.03 
		// draw_head_box


		CvRect RectUMHead;
		if(vio_status.violation_box_info[v].umbrella_violation == 1)
		{
			RectUMHead.x = (int)(vio_status.violation_box_info[v].Um_bouding_box.x * x_scale);
			RectUMHead.y = (int)(vio_status.violation_box_info[v].Um_bouding_box.y * y_scale);
			RectUMHead.width = (int)(vio_status.violation_box_info[v].Um_bouding_box.width * x_scale);
			RectUMHead.height = (int)(vio_status.violation_box_info[v].Um_bouding_box.height * y_scale);

			//std::cout << "============= rectHead.x: " << RectUMHead.x << "============= rectHead.y: " << RectUMHead.y << std::endl;

			cvRectangleR(ori_image, RectUMHead, cvScalar(0, 0, 255), 2, 1, 0);
		}
		if(vio_status.violation_box_info[v].mobile_violation == 1)
		{
			RectUMHead.x = (int)(vio_status.violation_box_info[v].Mo_bouding_box.x * x_scale);
			RectUMHead.y = (int)(vio_status.violation_box_info[v].Mo_bouding_box.y * y_scale);
			RectUMHead.width = (int)(vio_status.violation_box_info[v].Mo_bouding_box.width * x_scale);
			RectUMHead.height = (int)(vio_status.violation_box_info[v].Mo_bouding_box.height * y_scale);

			//std::cout << "============= rectHead.x: " << RectUMHead.x << "============= rectHead.y: " << RectUMHead.y << std::endl;

			cvRectangleR(ori_image, RectUMHead, cvScalar(0, 0, 255), 2, 1, 0);
		}
	}

	

}*/

void violation_box_draw_save_image(st_det_mot_param *param, IplImage *ori_image, IplImage *res_image, int nVioIdx, st_violation_info &vio_status)
{
	//	printf("vio_status.n_violation = %d\n", vio_status.n_violation);
	float x_scale = (float)ori_image->width / res_image->width;
	float y_scale = (float)ori_image->height / res_image->height;
	CvRect box;
	int v = nVioIdx;

	// 2018.10.26 hai
	int nTrackID = vio_status.violation_box_info[v].track_id;
	int nHisIdx = param->sub_box_list[nTrackID].n_his_rider_index;

	std::cout << "n_head_box: " << param->sub_box_list[nTrackID].n_box_list[nHisIdx] << std::endl;

	if (param->sub_box_list[nTrackID].vio_image[nHisIdx])
	{
		for (int n = 0; n < param->sub_box_list[nTrackID].n_box_list[nHisIdx]; n++)
		{
			CvRect RectHead;
			RectHead.x = (int)(param->sub_box_list[nTrackID].head_box_list[nHisIdx].head_box_info[n].bouding_box.x * x_scale);
			RectHead.y = (int)(param->sub_box_list[nTrackID].head_box_list[nHisIdx].head_box_info[n].bouding_box.y * y_scale);
			RectHead.width = (int)(param->sub_box_list[nTrackID].head_box_list[nHisIdx].head_box_info[n].bouding_box.width * x_scale);
			RectHead.height = (int)(param->sub_box_list[nTrackID].head_box_list[nHisIdx].head_box_info[n].bouding_box.height * y_scale);

			cvRectangleR(param->sub_box_list[nTrackID].vio_image[nHisIdx], RectHead, cvScalar(0, 0, 255, 0), 2, 1, 0);

			char textTmp[CHAR_LENGTH];
			sprintf(textTmp, "[%d]", param->sub_box_list[nTrackID].head_box_list[nHisIdx].head_box_info[n].class_id);
			CvFont font;
			cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.5, 0.5, 0, 0, 1);
			cvPutText(param->sub_box_list[nTrackID].vio_image[nHisIdx], textTmp, cvPoint((int)RectHead.x, (int)RectHead.y), &font, cvScalar(0, 0, 255, 0));
		}
	}

	//for (int v = 0; v < vio_status.n_violation; v++)
	{
		box.x = (int)(vio_status.violation_box_info[v].bouding_box.x * x_scale);
		box.y = (int)(vio_status.violation_box_info[v].bouding_box.y * y_scale);
		box.width = (int)(vio_status.violation_box_info[v].bouding_box.width * x_scale);
		box.height = (int)(vio_status.violation_box_info[v].bouding_box.height * y_scale);

		cvRectangleR(ori_image, box, cvScalar(0, 0, 255), 1, 1, 0);
		//convert_2D_to_3D_Box(ori_image, box, cvScalar(0, 0, 255));

		CvRect RectUMHead;
		if(vio_status.violation_box_info[v].umbrella_violation == 1)
		{
			RectUMHead.x = (int)(vio_status.violation_box_info[v].Um_bouding_box.x * x_scale);
			RectUMHead.y = (int)(vio_status.violation_box_info[v].Um_bouding_box.y * y_scale);
			RectUMHead.width = (int)(vio_status.violation_box_info[v].Um_bouding_box.width * x_scale);
			RectUMHead.height = (int)(vio_status.violation_box_info[v].Um_bouding_box.height * y_scale);

			//std::cout << "============= rectHead.x: " << RectUMHead.x << "============= rectHead.y: " << RectUMHead.y << std::endl;

			cvRectangleR(ori_image, RectUMHead, cvScalar(0, 0, 255), 2, 1, 0);
		}
		if(vio_status.violation_box_info[v].mobile_violation == 1)
		{
			RectUMHead.x = (int)(vio_status.violation_box_info[v].Mo_bouding_box.x * x_scale);
			RectUMHead.y = (int)(vio_status.violation_box_info[v].Mo_bouding_box.y * y_scale);
			RectUMHead.width = (int)(vio_status.violation_box_info[v].Mo_bouding_box.width * x_scale);
			RectUMHead.height = (int)(vio_status.violation_box_info[v].Mo_bouding_box.height * y_scale);

			//std::cout << "============= rectHead.x: " << RectUMHead.x << "============= rectHead.y: " << RectUMHead.y << std::endl;

			cvRectangleR(ori_image, RectUMHead, cvScalar(0, 0, 255), 2, 1, 0);
		}
	}

}

//void biker_violation_save(IplImage *ori_image, IplImage *res_image, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, char *buff)
//{
//	char full_vio_file_path[300], full_vio_file_path_end[300], full_save_image_path[300];
//	char *vio_file_path = param->vio_result_path;
//	static char prev_buff[80] = "";
//	static int number = 1;
//
//	if (vio_status.n_violation)
//	{
//		if (strcmp(buff, prev_buff) == 0)
//		{
//			number++;
//		}
//		else
//		{
//			strcpy(prev_buff, buff);
//			number = 1;
//		}
//
//		sprintf(full_vio_file_path, "%s/bike/%02d_%s_%s_%03d.log", vio_file_path, AUTOBIKE_VIOLATION_CODE, param->camera_id, buff, number);
//		sprintf(full_vio_file_path_end, "%s/bike/%02d_%s_%s_%03d.end", vio_file_path, AUTOBIKE_VIOLATION_CODE, param->camera_id, buff, number);
//		sprintf(full_save_image_path, "%s/bike/%02d_%s_%s_%03d.jpg", vio_file_path, AUTOBIKE_VIOLATION_CODE, param->camera_id, buff, number);
//		FILE *fp_vio = fopen(full_vio_file_path, "w");
//		biker_violation_save_log(fp_vio, biker_info, vio_status, param->channel_id, buff, param->max_rider);
//		fclose(fp_vio);
//		violation_box_draw_save_image(ori_image, res_image, vio_status);
//		cvSaveImage(full_save_image_path, ori_image);
//
//		//20180711
//		int nViolationCode = 0;	//0 autobike, 1 speed, 2 signal, 3 lane, etc
//		float x_scale = (float)ori_image->width / res_image->width;
//		float y_scale = (float)ori_image->height / res_image->height;
//		CvRect rectArea;
//		for (int v = 0; v < vio_status.n_violation; v++)
//		{
//			rectArea.x = (int)(vio_status.violation_box_info[v].bouding_box.x * x_scale);
//			rectArea.y = (int)(vio_status.violation_box_info[v].bouding_box.y * y_scale);
//			rectArea.width = (int)(vio_status.violation_box_info[v].bouding_box.width * x_scale);
//			rectArea.height = (int)(vio_status.violation_box_info[v].bouding_box.height * y_scale);
//
//			rectArea.y = rectArea.y + rectArea.height * 1 / 3;
//			rectArea.height = rectArea.height * 2 / 3;
//
//			cvRectangleR(ori_image, rectArea, cvScalar(0, 0, 255), 2, 1, 0);
//			//convert_2D_to_3D_Box(ori_image, rectArea, cvScalar(0, 0, 255));
//
//			sprintf(full_save_image_path, "%s/lpr/input/00_%s_%s_%03d_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, param->camera_id, buff, number, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
//			cvSaveImage(full_save_image_path, ori_image, 0);
//		}
//
//#if 0
//		IplImage *disp_image = cvCreateImage(cvGetSize(res_image), res_image->depth, res_image->nChannels);
//		cvResize(ori_image, disp_image, 1);
//		for (int d = 0; d < param->mot_info->n_detect_num; d++) {
//			cvRectangleR(disp_image, param->mot_info->det_box_info[d].bouding_box, param->track_color[param->mot_info->det_box_info[d].class_id], 2, 1, 0);
//			//			printf("%d) (%d %d %d %d)\n", d, param->mot_info->det_box_info[d].bouding_box.x, param->mot_info->det_box_info[d].bouding_box.y, param->mot_info->det_box_info[d].bouding_box.width, param->mot_info->det_box_info[d].bouding_box.height);
//
//			char textTmp[CHAR_LENGTH];
//			sprintf(textTmp, "%d", param->mot_info->det_box_info[d].class_id);
//			CvFont font;
//			cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 1, 1, 0, 0, 1);
//			cvPutText(disp_image, textTmp, cvPoint((int)param->mot_info->det_box_info[d].bouding_box.x, (int)param->mot_info->det_box_info[d].bouding_box.y), &font, param->track_color[param->mot_info->det_box_info[d].class_id]);
//
//		}
//		char save_image[300];
//		sprintf(save_image, "%s/%s_%s_%03d.bmp", vio_file_path, param->camera_id, buff, number);
//		cvSaveImage(save_image, disp_image);
//#endif
//		FILE *fp_vio_end = fopen(full_vio_file_path_end, "w");
//		fclose(fp_vio_end);
//	}
//}


void biker_violation_save(IplImage *ori_image, IplImage *res_image, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, char *buff
	                      , HANDLE hSaveImageDLL)
{
	char full_vio_file_path[300], full_vio_file_path_end[300], full_save_image_path[300], full_his_image_path[300]; // 2018.10.26 hai
	char *vio_file_path = param->vio_result_path;
	static char prev_buff[80] = "";
	static int number = 1;

	if (vio_status.n_violation)
	{
		
		//20180711
		int nViolationCode = 0;	//0 autobike, 1 speed, 2 signal, 3 lane, etc
		float x_scale = (float)ori_image->width / res_image->width;
		float y_scale = (float)ori_image->height / res_image->height;

		for (int v = 0; v < vio_status.n_violation; v++)
		{
			if (strcmp(buff, prev_buff) == 0)
			{
				number++;
			}
			else
			{
				strcpy(prev_buff, buff);
				number = 1;
			}

			sprintf(full_vio_file_path, "%s/bikeTemp/%02d_%s_%s_%03d.log", vio_file_path, AUTOBIKE_VIOLATION_CODE, param->camera_id, buff, number);
			sprintf(full_vio_file_path_end, "%s/bikeTemp/%02d_%s_%s_%03d.end", vio_file_path, AUTOBIKE_VIOLATION_CODE, param->camera_id, buff, number);
			sprintf(full_save_image_path, "%s/bikeTemp/%02d_%s_%s_%03d.jpg", vio_file_path, AUTOBIKE_VIOLATION_CODE, param->camera_id, buff, number);

			sprintf(full_his_image_path, "%s/bikeMonitering/%02d_%s_%s_%03d_HIS.jpg", vio_file_path, AUTOBIKE_VIOLATION_CODE, param->camera_id, buff, number); // 2018.10.26 hai

			FILE *fp_vio = fopen(full_vio_file_path, "w");
			biker_violation_save_log(fp_vio, biker_info, v, vio_status, param->channel_id, buff, param->max_rider);
			fclose(fp_vio);
			violation_box_draw_save_image(param, ori_image, res_image, v, vio_status);
			if (JPG_SAVE_ENABLE)
				if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, ori_image, 0);
			
			// 2018.10.26 hai
			int nTrackID = vio_status.violation_box_info[v].track_id;
			int nHisIdx = param->sub_box_list[nTrackID].n_his_rider_index;

			if (param->show_det_on && param->sub_box_list[nTrackID].vio_image[nHisIdx])
			{
				if (JPG_SAVE_ENABLE)
					if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_his_image_path, param->sub_box_list[nTrackID].vio_image[nHisIdx], 0); // 2018.10.26 hai
			}

			for (int n = 0; n < MAX_FRAME_NUM; n++)
			{
				if (param->sub_box_list[nTrackID].vio_image[n]) 
					cvReleaseImage(&param->sub_box_list[nTrackID].vio_image[n]);
			}

			CvRect rectArea;
			rectArea.x = (int)(vio_status.violation_box_info[v].bouding_box.x * x_scale);
			rectArea.y = (int)(vio_status.violation_box_info[v].bouding_box.y * y_scale);
			rectArea.width = (int)(vio_status.violation_box_info[v].bouding_box.width * x_scale);
			rectArea.height = (int)(vio_status.violation_box_info[v].bouding_box.height * y_scale);

			rectArea.y = rectArea.y + rectArea.height * 1 / 3;
			rectArea.height = rectArea.height * 2 / 3;

			//cvRectangleR(ori_image, rectArea, cvScalar(0, 0, 255), 2, 1, 0);
			//convert_2D_to_3D_Box(ori_image, rectArea, cvScalar(0, 0, 255));

			sprintf(full_save_image_path, "%s/lpr/input/00_%s_%s_%03d_X%04d_Y%04d_W%04d_H%04d.jpg", vio_file_path, param->camera_id, buff, number, rectArea.x, rectArea.y, rectArea.width, rectArea.height);
			if (JPG_SAVE_ENABLE)
				if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, ori_image, 0);

			/*//20190520 hai Save helmet_overriding images
			CvRect rectHead;
			rectHead.x = (int)(vio_status.violation_box_info[v].bouding_box.x * x_scale);
			rectHead.y = (int)(vio_status.violation_box_info[v].bouding_box.y * y_scale);
			rectHead.width = (int)(vio_status.violation_box_info[v].bouding_box.width * x_scale);
			rectHead.height = (int)(vio_status.violation_box_info[v].bouding_box.height * y_scale);
			rectHead.y = std::max(0, rectHead.y - rectHead.height * 1 / 16);
			if (rectHead.y - rectHead.height * 1 / 16 >= 0)
			{
				rectHead.height = rectHead.height * 1 / 3 + rectHead.height * 1 / 16;
			}
			else
			{
				rectHead.height = rectHead.height * 1 / 3;
			}

			cvSetImageROI(ori_image, rectHead);
			IplImage *headbox_img = cvCreateImage(cvSize(rectHead.width, rectHead.height), ori_image->depth, ori_image->nChannels);
			cvCopy(ori_image, headbox_img, NULL);
			cvResetImageROI(ori_image);

			if (vio_status.violation_box_info[v].max_rider_violation)
			{
				sprintf(full_save_image_path, "%s/lpr/helmet_over/00_%s_%s_%03d_O.jpg", vio_file_path, param->camera_id, buff, number);
				if (JPG_SAVE_ENABLE)
					if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, headbox_img, 0);
			}
			else if (vio_status.violation_box_info[v].helmet_violation)
			{
				sprintf(full_save_image_path, "%s/lpr/helmet_over/00_%s_%s_%03d_H.jpg", vio_file_path, param->camera_id, buff, number);
				if (JPG_SAVE_ENABLE)
					if (hSaveImageDLL) UNSSAVEPICTURE_Save(hSaveImageDLL, full_save_image_path, headbox_img, 0);
			}

			cvReleaseImage(&headbox_img);*/
			//============================================

			FILE *fp_vio_end = fopen(full_vio_file_path_end, "w");
			fclose(fp_vio_end);
		}

#if 0
		IplImage *disp_image = cvCreateImage(cvGetSize(res_image), res_image->depth, res_image->nChannels);
		cvResize(ori_image, disp_image, 1);
		for (int d = 0; d < param->mot_info->n_detect_num; d++) {
			cvRectangleR(disp_image, param->mot_info->det_box_info[d].bouding_box, param->track_color[param->mot_info->det_box_info[d].class_id], 2, 1, 0);
			//			printf("%d) (%d %d %d %d)\n", d, param->mot_info->det_box_info[d].bouding_box.x, param->mot_info->det_box_info[d].bouding_box.y, param->mot_info->det_box_info[d].bouding_box.width, param->mot_info->det_box_info[d].bouding_box.height);

			char textTmp[CHAR_LENGTH];
			sprintf(textTmp, "%d", param->mot_info->det_box_info[d].class_id);
			CvFont font;
			cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 1, 1, 0, 0, 1);
			cvPutText(disp_image, textTmp, cvPoint((int)param->mot_info->det_box_info[d].bouding_box.x, (int)param->mot_info->det_box_info[d].bouding_box.y), &font, param->track_color[param->mot_info->det_box_info[d].class_id]);

		}
		char save_image[300];
		sprintf(save_image, "%s/%s_%s_%03d.bmp", vio_file_path, param->camera_id, buff, number);
		cvSaveImage(save_image, disp_image);
#endif
		
	}
}

/*
void biker_violation_save_log(FILE *fp, st_biker_info &biker_info, st_violation_info &vio_status, int ch_id, char *time, int nMaxRider)
{
	char textTmp[CHAR_LENGTH] = "";
	char chid_time_Tmp[CHAR_LENGTH] = "";
	char saveTmp[CHAR_LENGTH] = "";
	sprintf(chid_time_Tmp, "%02d,%s", ch_id, time);

	for (int i = 0; i < vio_status.n_violation; i++)
	{
		int class_id = vio_status.violation_box_info[i].class_id;
		char *vio_type = vio_status.violation_box_info[i].vio_type;
		int n_person = vio_status.violation_box_info[i].n_person;
		int n_person_helmet = vio_status.violation_box_info[i].n_person_helmet;

		int nTrackID = vio_status.violation_box_info[i].track_id;

		int n_person_over = n_person - nMaxRider + 1;
		if (n_person_over < 0) n_person_over = 0;

		//if (vio_status.violation_box_info[i].max_rider_violation)
		//	sprintf(textTmp, "%s,%02d,%s,%d,%d,%d", textTmp, class_id, "O", n_person, n_person_helmet, n_person_over);
		//if (vio_status.violation_box_info[i].helmet_violation)
		//	sprintf(textTmp, "%s,%02d,%s,%d,%d,%d", textTmp, class_id, "H", n_person, n_person_helmet, n_person_over);
		
		if (vio_status.violation_box_info[i].max_rider_violation)
		{
			//sprintf(textTmp, "%s,%02d,%s,%d,%d,%d\n", chid_time_Tmp, class_id, "O", n_person, n_person_helmet, n_person_over);
			sprintf(textTmp, "%s%s,%02d,%s,%d,%d,%d,%d\n", textTmp, chid_time_Tmp, class_id, "O", n_person, n_person_helmet, n_person_over, nTrackID);
		}
		if (vio_status.violation_box_info[i].helmet_violation)
		{
			//sprintf(textTmp, "%s,%02d,%s,%d,%d,%d\n", chid_time_Tmp, class_id, "H", n_person, n_person_helmet, n_person_over);
			sprintf(textTmp, "%s%s,%02d,%s,%d,%d,%d,%d\n", textTmp, chid_time_Tmp, class_id, "H", n_person, n_person_helmet, n_person_over, nTrackID);
		}
		if (vio_status.violation_box_info[i].umbrella_violation)
		{
			if (n_person == 0)
			{
				n_person = 1;
				n_person_helmet = 1;
			}
			//sprintf(textTmp, "%s,%02d,%s,%d,%d,%d\n", chid_time_Tmp, class_id, "U", n_person, n_person_helmet, n_person_over);
			sprintf(textTmp, "%s%s,%02d,%s,%d,%d,%d,%d\n", textTmp, chid_time_Tmp, class_id, "U", n_person, n_person_helmet, n_person_over, nTrackID);
		}
		if (vio_status.violation_box_info[i].mobile_violation)
		{
			if (n_person == 0)
			{
				n_person = 1;
				n_person_helmet = 1;
			}
			//sprintf(textTmp, "%s,%02d,%s,%d,%d,%d\n", chid_time_Tmp, class_id, "M", n_person, n_person_helmet, n_person_over);
			sprintf(textTmp, "%s%s,%02d,%s,%d,%d,%d,%d\n", textTmp, chid_time_Tmp, class_id, "M", n_person, n_person_helmet, n_person_over, nTrackID);
		}
	}
	if (fp)
	{
		fprintf(fp, "%s\n", textTmp);
	}
}*/


void biker_violation_save_log(FILE *fp, st_biker_info &biker_info, int nVioIdx, st_violation_info &vio_status, int ch_id, char *time, int nMaxRider)
{
	char textTmp[CHAR_LENGTH] = "";
	char chid_time_Tmp[CHAR_LENGTH] = "";
	char saveTmp[CHAR_LENGTH] = "";
	sprintf(chid_time_Tmp, "%02d,%s", ch_id, time);

	int i = nVioIdx;

	//for (int i = 0; i < vio_status.n_violation; i++)
	{
		int class_id = vio_status.violation_box_info[i].class_id;
		char *vio_type = vio_status.violation_box_info[i].vio_type;
		int n_person = vio_status.violation_box_info[i].n_person;
		int n_person_helmet = vio_status.violation_box_info[i].n_person_helmet;

		int nTrackID = vio_status.violation_box_info[i].track_id;

		int n_person_over = n_person - nMaxRider + 1;
		if (n_person_over < 0) n_person_over = 0;

		if (vio_status.violation_box_info[i].max_rider_violation)
		{
			sprintf(textTmp, "%s%s,%02d,%s,%d,%d,%d,%d\n", textTmp, chid_time_Tmp, class_id, "O", n_person, n_person_helmet, n_person_over, nTrackID);
		}
		if (vio_status.violation_box_info[i].helmet_violation)
		{
			sprintf(textTmp, "%s%s,%02d,%s,%d,%d,%d,%d\n", textTmp, chid_time_Tmp, class_id, "H", n_person, n_person_helmet, n_person_over, nTrackID);
		}
		if (vio_status.violation_box_info[i].umbrella_violation)
		{
			if (n_person == 0)
			{
				n_person = 1;
				n_person_helmet = 1;
			}
			sprintf(textTmp, "%s%s,%02d,%s,%d,%d,%d,%d\n", textTmp, chid_time_Tmp, class_id, "U", n_person, n_person_helmet, n_person_over, nTrackID);
		}
		if (vio_status.violation_box_info[i].mobile_violation)
		{
			if (n_person == 0)
			{
				n_person = 1;
				n_person_helmet = 1;
			}
			sprintf(textTmp, "%s%s,%02d,%s,%d,%d,%d,%d\n", textTmp, chid_time_Tmp, class_id, "M", n_person, n_person_helmet, n_person_over, nTrackID);
		}
	}
	if (fp)
	{
		fprintf(fp, "%s\n", textTmp);
	}
}


void object_flow_save(FILE *fp, st_mot_info *mot_info, int num, int ch_id, char *time)
{
	char textTmp[CHAR_LENGTH] = "";
	char chid_time_Tmp[CHAR_LENGTH] = "";
	char saveTmp[CHAR_LENGTH] = "";
	sprintf(chid_time_Tmp, "%02d,%s", ch_id, time);
	num = UMBRELLA_CLASS_ID;	//20180814 Do not use classId 15, 16, 17 for statistics.
	for (int c_id = 0; c_id < num - BACKGROUND_CLASS; c_id++)
	{

		//		printf("(%02d : %d) ", c_id, mot_info->object_flow_number[c_id]);		
		//sprintf(textTmp, "%s,%02d,%d", textTmp, c_id, mot_info->object_flow_number[c_id]); //20190214 hai Status Log

		mot_info->object_flow_total[c_id] += mot_info->object_flow_number[c_id]; //20190214 hai Status Log

		//20180719 Request Yun, edited kyk, count for 1 second 
		mot_info->object_flow_number[c_id] = 0;
		//mot_info->object_flow_number_forTopline[c_id] = 0;//yk 2018.12.03
	}
	if (fp)
	{
		//fprintf(fp, "%s%s\n", chid_time_Tmp, textTmp); //20190214 hai Status Log
	}
}

/*
void make_biker_info_structure(st_det_mot_param *param, st_biker_info &biker_info)
{
	int n_track = param->mot_info->n_track_num;
	int n_detect = param->mot_info->n_detect_num;
	int n_biker_box = 0;
	st_mot_box_info *mot_info = param->mot_info->mot_box_info;
	st_det_box_info *det_info = param->mot_info->det_box_info;
	int group_id = param->biker_group_id;
	int sub_group_id = param->head_group_id;
	float iou_thresh = param->head_nms;

	for (int t = 0; t < n_track; t++)
	{
		mot_info[t].n_sub_box = 0;

		if (mot_info[t].class_group_id == group_id) //biker, cyclist¿¡ ÇØ´çµÇ´Â class
		{
			biker_info.biker_box_info[n_biker_box].class_id = mot_info[t].class_id;
			biker_info.biker_box_info[n_biker_box].track_id = mot_info[t].track_id;
			biker_info.biker_box_info[n_biker_box].bouding_box = mot_info[t].bouding_box;
			int n_head_box = 0;

			for (int d = 0; d < n_detect; d++)
			{
				if (det_info[d].class_group_id == sub_group_id) //head¿¡ ÇØ´çµÇ´Â class
				{

					CvRect roi_box; //biker ¿µ¿ªÁß¿¡¼­ headºÎºÐ¿¡ ÇØ´çµÇ´Â °ü½É ¿µ¿ª
					roi_box.x = mot_info[t].bouding_box.x + mot_info[t].bouding_box.width / 6;
					roi_box.y = mot_info[t].bouding_box.y;
					roi_box.width = mot_info[t].bouding_box.width * 2 / 3;
					roi_box.height = mot_info[t].bouding_box.height / 4;
					float iou = rect_iou(roi_box, det_info[d].bouding_box, 1);
					if (iou > iou_thresh)
					{
						mot_info[t].sub_box_info.bouding_box = biker_info.biker_box_info[n_biker_box].head_box_info[n_head_box].bouding_box = det_info[d].bouding_box;
						mot_info[t].sub_box_info.class_id = biker_info.biker_box_info[n_biker_box].head_box_info[n_head_box].class_id = det_info[d].class_id;
						n_head_box++;
					}
				}
			}
			mot_info[t].n_sub_box = biker_info.biker_box_info[n_biker_box].n_box = n_head_box;
			n_biker_box++;
		}
	}
	biker_info.n_biker_box = n_biker_box;

}

void make_vio_status_structure(st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line)
{
	int max_rider = param->max_rider;
	const int n_violation_class = param->n_vio_head_class;
	int *violation_class = param->vio_head_class;
	int n_violation = 0;
	int n_violation_confirm = param->n_vio_confirm;
	for (int t = 0; t < biker_info.n_biker_box; t++)
	{
		//		printf("%d)n_head_box = %d\n", t, biker_info.biker_box_info[t].n_box);
		bool b_violation = false;
		vio_status.violation_box_info[n_violation].max_rider_violation = 0;
		vio_status.violation_box_info[n_violation].helmet_violation = 0;
		sprintf(vio_status.violation_box_info[n_violation].vio_type, "N");
		vio_status.violation_box_info[n_violation].n_person = biker_info.biker_box_info[t].n_box;

		if ((!line_touch(biker_info.biker_box_info[t].bouding_box, line)) || (biker_info.biker_box_info[t].class_id != param->rear_biker_id))
		{
			if (biker_info.TO_violation[biker_info.biker_box_info[t].track_id]++ >= n_violation_confirm)
			{
				biker_info.rider_violation_confirm[biker_info.biker_box_info[t].track_id] = 0;		////=== hai edited ===////
				biker_info.helmet_violation_confirm[biker_info.biker_box_info[t].track_id] = 0;		////=== hai edited ===////
				biker_info.TO_violation[biker_info.biker_box_info[t].track_id] = 0;
			}
			std::cout << "no touch: trackid: " << biker_info.biker_box_info[t].track_id << "no touch: count: " << biker_info.TO_violation[biker_info.biker_box_info[t].track_id] << std::endl;
			continue;
		}
		int track_id = biker_info.biker_box_info[t].track_id;
		//		printf("%d = %d\n", track_id, param->mot_info->n_violated[track_id]);

		std::cout << "touched: trackid: " << track_id << "confirm: " << biker_info.rider_violation_confirm[track_id] << ";" << biker_info.helmet_violation_confirm[track_id] << std::endl;

		//if (biker_info.biker_box_info[t].n_box > max_rider && biker_info.rider_violation_confirm[track_id] < n_violation_confirm) ////=== hai edited ===////
		{
			biker_info.rider_violation_confirm[track_id]++;							////=== hai edited ===////
																					//biker_info.TO_violation[track_id]--;

			b_violation = true;
			vio_status.violation_box_info[n_violation].max_rider_violation = 1;
			sprintf(vio_status.violation_box_info[n_violation].vio_type, "O");
			vio_status.violation_box_info[n_violation].class_id = biker_info.biker_box_info[t].class_id;
			vio_status.violation_box_info[n_violation].bouding_box = biker_info.biker_box_info[t].bouding_box;
		}
		vio_status.violation_box_info[n_violation].n_person_helmet = vio_status.violation_box_info[n_violation].n_person;

		bool b_helmet_violation = false;

		std::cout << "helmet_violation_confirm " << biker_info.helmet_violation_confirm[track_id] << std::endl;

		for (int n = 0; n < biker_info.biker_box_info[t].n_box; n++)
		{
			//			printf("%d)head_box_class = %d\n", n, biker_info.biker_box_info[t].head_box_info[n].class_id);
			for (int v = 0; v < n_violation_class; v++)
			{
				if (biker_info.biker_box_info[t].head_box_info[n].class_id == violation_class[v] && biker_info.helmet_violation_confirm[track_id] < n_violation_confirm) ////=== hai edited ===////
				{
					////=== hai edited ===////
					b_helmet_violation = true;
					b_violation = true;
					vio_status.violation_box_info[n_violation].helmet_violation = 1;
					sprintf(vio_status.violation_box_info[n_violation].vio_type, "H");

					vio_status.violation_box_info[n_violation].n_person_helmet--;
					vio_status.violation_box_info[n_violation].class_id = biker_info.biker_box_info[t].class_id;
					vio_status.violation_box_info[n_violation].bouding_box = biker_info.biker_box_info[t].bouding_box;
				}
			}
		}

		if (b_helmet_violation == true)
		{
			biker_info.helmet_violation_confirm[track_id] ++;
			//biker_info.TO_violation[track_id]--;
		}

		//if (b_violation == true) param->mot_info->n_violated[track_id]++;

		//std::cout << n_violation_confirm << "; " << param->mot_info->n_violated[track_id] << std::endl;

		//if (param->mot_info->n_violated[track_id] >= n_violation_confirm)
		//{

		//	param->mot_info->n_violated[track_id] = 0;
		//	n_violation++;
		//}
		////		if (b_violation == true) n_violation++;

		if (b_violation == true)
		{
			param->mot_info->n_violated[track_id]++;

			biker_info.TO_violation[track_id] = 0;

			std::cout << n_violation_confirm << "; " << param->mot_info->n_violated[track_id] << std::endl;

			if (param->mot_info->n_violated[track_id] >= n_violation_confirm)
			{

				param->mot_info->n_violated[track_id] = 0;
				n_violation++;
			}
			//		if (b_violation == true) n_violation++;
		}

	}

	vio_status.n_violation = n_violation;


} */


//// 2018.09.03

void make_biker_info_structure(st_det_mot_param *param, st_biker_info &biker_info)
{
	int n_track = param->mot_info->n_track_num;
	int n_detect = param->mot_info->n_detect_num;
	int n_biker_box = 0;
	st_mot_box_info *mot_info = param->mot_info->mot_box_info;
	st_det_box_info *det_info = param->mot_info->det_box_info;
	int group_id = param->biker_group_id;
	int sub_group_id = param->head_group_id;
	float iou_thresh = param->head_nms;

	int umbrella_group_id = param->umbrella_group_id; // 2018.09.27 hai
	int mobile_group_id = param->mobile_group_id; // 2018.09.27 hai

	//std::cout << "umbrella_group_id: " << umbrella_group_id << "; mobile_group_id: " << mobile_group_id << std::endl;

	for (int t = 0; t < n_track; t++)
	{
		mot_info[t].n_sub_box = 0;

		if (mot_info[t].class_group_id == group_id) //biker, cyclist¿¡ ÇØ´çµÇ´Â class
		{
			biker_info.biker_box_info[n_biker_box].class_id = mot_info[t].class_id;
			biker_info.biker_box_info[n_biker_box].track_id = mot_info[t].track_id;
			biker_info.biker_box_info[n_biker_box].bouding_box = mot_info[t].bouding_box;

			param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].n_box_idx++;
			param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].n_box_idx = param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].n_box_idx % MAX_FRAME_NUM;
			int sub_idx = param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].n_box_idx;

			param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].bouding_box[sub_idx] = mot_info[t].bouding_box;

			int n_head_box = 0;
			float mean_score = 0; //2018.10.12 hai

			param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].nIsMobile = 0;
			param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].nIsUmbrella = 0;

			for (int d = 0; d < n_detect; d++)
			{
				if (det_info[d].class_group_id == sub_group_id) //head¿¡ ÇØ´çµÇ´Â class
				{

					CvRect roi_box; //biker ¿µ¿ªÁß¿¡¼­ headºÎºÐ¿¡ ÇØ´çµÇ´Â °ü½É ¿µ¿ª
					roi_box.x = mot_info[t].bouding_box.x + mot_info[t].bouding_box.width / 6;
					roi_box.y = mot_info[t].bouding_box.y;
					roi_box.width = mot_info[t].bouding_box.width * 2 / 3;

					if (mot_info[t].class_id == FRONT_TRUCKBIKE_CLASS_ID || mot_info[t].class_id == REAR_TRUCKBIKE_CLASS_ID || mot_info[t].class_id == SIDE_TRUCKBIKE_CLASS_ID)
					{						
						roi_box.height = mot_info[t].bouding_box.height / 3;	
					}
					else
					{
						roi_box.height = mot_info[t].bouding_box.height / 4;
					}

					float iou = rect_iou(roi_box, det_info[d].bouding_box, 1);
					if (iou > iou_thresh)
					{
						mot_info[t].sub_box_info.bouding_box = biker_info.biker_box_info[n_biker_box].head_box_info[n_head_box].bouding_box = det_info[d].bouding_box;
						mot_info[t].sub_box_info.class_id = biker_info.biker_box_info[n_biker_box].head_box_info[n_head_box].class_id = det_info[d].class_id;

						param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].head_box_list[sub_idx].head_box_info[n_head_box].class_id = det_info[d].class_id;
						param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].head_box_list[sub_idx].head_box_info[n_head_box].bouding_box = det_info[d].bouding_box;

						mean_score += det_info[d].score; //2018.10.12 hai
						n_head_box++;
					}
				}

				// 2018.09.27 hai - umbrella
				if (det_info[d].class_group_id == umbrella_group_id) //head¿¡ ÇØ´çµÇ´Â class
				{
					//std::cout << "-------------------------------------------det_info[d].class_group_id == umbrella_group_id" << std::endl;

					CvRect roi_box; //biker ¿µ¿ªÁß¿¡¼­ headºÎºÐ¿¡ ÇØ´çµÇ´Â °ü½É ¿µ¿ª
					roi_box.x = mot_info[t].bouding_box.x ;
					roi_box.y = mot_info[t].bouding_box.y;
					roi_box.width = mot_info[t].bouding_box.width;
					roi_box.height = mot_info[t].bouding_box.height;
					float iou = rect_iou(roi_box, det_info[d].bouding_box, 1);
					if (iou > iou_thresh)
					{
						/*mot_info[t].umbrella_box_info.bouding_box = biker_info.biker_box_info[n_biker_box].umbrella_box_info.bouding_box = det_info[d].bouding_box;
						mot_info[t].umbrella_box_info.class_id = biker_info.biker_box_info[n_biker_box].umbrella_box_info.class_id = det_info[d].class_id;*/

						param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].umbrella_box_info.class_id = det_info[d].class_id;
						param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].umbrella_box_info.bouding_box = det_info[d].bouding_box;

						param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].nIsUmbrella = 1;
					}
				}

				// 2018.09.27 hai - mobile
				if (det_info[d].class_group_id == mobile_group_id) //head¿¡ ÇØ´çµÇ´Â class
				{
					//std::cout << "-------------------------------------------det_info[d].class_group_id == mobile_group_id" << std::endl;
					CvRect roi_box; //biker ¿µ¿ªÁß¿¡¼­ headºÎºÐ¿¡ ÇØ´çµÇ´Â °ü½É ¿µ¿ª
					roi_box.x = mot_info[t].bouding_box.x;
					roi_box.y = mot_info[t].bouding_box.y;
					roi_box.width = mot_info[t].bouding_box.width;
					roi_box.height = mot_info[t].bouding_box.height / 2;
					float iou = rect_iou(roi_box, det_info[d].bouding_box, 1);
					if (iou > iou_thresh)
					{
						/*mot_info[t].mobile_box_info.bouding_box = biker_info.biker_box_info[n_biker_box].mobile_box_info.bouding_box = det_info[d].bouding_box;
						mot_info[t].mobile_box_info.class_id = biker_info.biker_box_info[n_biker_box].mobile_box_info.class_id = det_info[d].class_id;*/

						param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].mobile_box_info.class_id = det_info[d].class_id;
						param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].mobile_box_info.bouding_box = det_info[d].bouding_box;

						param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].nIsMobile = 1;
					}
				}

			}
			mot_info[t].n_sub_box = biker_info.biker_box_info[n_biker_box].n_box = n_head_box;
	
			//20190406
			if (n_head_box > 0)
			{
				param->sub_box_list[mot_info[t].track_id].mean_score[sub_idx] = mean_score / n_head_box;
				//param->sub_box_list[biker_info.biker_box_info[n_biker_box].track_id].mean_score[sub_idx] = mean_score / n_head_box; //2018.10.12 hai
			}
			//20190406
			n_biker_box++;
		}
	}
	biker_info.n_biker_box = n_biker_box;

}


//// 2018.09.03

void make_vio_status_structure(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line, CRegion* pRegion)
{
	int max_rider = param->max_rider;
	const int n_violation_class = param->n_vio_head_class;
	int *violation_class = param->vio_head_class;
	int n_violation = 0;
	int n_violation_confirm = param->n_vio_confirm;

	// 2018.09.27 hai
	int umbrella_violation_class = param->vio_umbrella_class;
	int mobile_violation_class = param->vio_mobile_class;

	bool bIsTruckBike = false;


	int nCheckBikeViolation = param->nCheckBikeViolation;
	if (!getMode(param, OPERATION_MODE_BIKE))
	{
		nCheckBikeViolation = 0;
	}

	//std::cout << "umbrella_violation_class: " << umbrella_violation_class << "; mobile_violation_class: " << mobile_violation_class << std::endl;

	for (int t = 0; t < biker_info.n_biker_box; t++)
	{
		//		printf("%d)n_head_box = %d\n", t, biker_info.biker_box_info[t].n_box);

		if ((biker_info.biker_box_info[t].class_id == FRONT_TRUCKBIKE_CLASS_ID) || (biker_info.biker_box_info[t].class_id == REAR_TRUCKBIKE_CLASS_ID))
			bIsTruckBike = true;
		else
			bIsTruckBike = false;

		bool b_violation = false;
		vio_status.violation_box_info[n_violation].max_rider_violation = 0;
		vio_status.violation_box_info[n_violation].helmet_violation = 0;

		// 2018.09.27 hai
		vio_status.violation_box_info[n_violation].umbrella_violation = 0;
		vio_status.violation_box_info[n_violation].mobile_violation = 0;

		sprintf(vio_status.violation_box_info[n_violation].vio_type, "N");

		int nTrackID = biker_info.biker_box_info[t].track_id; //2018.10.12 hai
		int sub_idx = param->sub_box_list[nTrackID].n_box_idx;
		param->sub_box_list[nTrackID].n_box_list[sub_idx] = biker_info.biker_box_info[t].n_box;

		// 2018.10.26 hai
		if (param->sub_box_list[nTrackID].vio_image[sub_idx]) 
			cvReleaseImage(&param->sub_box_list[nTrackID].vio_image[sub_idx]);

		if (param->show_det_on)
		{
			param->sub_box_list[nTrackID].vio_image[sub_idx] = cvCreateImage(cvSize(frame->width, frame->height), frame->depth, frame->nChannels);
			cvCopy(frame, param->sub_box_list[nTrackID].vio_image[sub_idx]);
		}
		

		//2018.10.12 hai [making histogram of number head boxes]
		int nPad = 20;
		for (int m = 0; m < MAX_SUB_BOX; m++)
		{
			if (((param->sub_box_list[nTrackID].bouding_box[sub_idx].x > nPad)
				&& (param->sub_box_list[nTrackID].bouding_box[sub_idx].x + param->sub_box_list[nTrackID].bouding_box[sub_idx].width < res_frame->width - nPad)
				&& (param->sub_box_list[nTrackID].bouding_box[sub_idx].y + param->sub_box_list[nTrackID].bouding_box[sub_idx].height < res_frame->height - nPad))
				|| ((param->sub_box_list[nTrackID].bouding_box[sub_idx].x > nPad)
					&& (param->sub_box_list[nTrackID].bouding_box[sub_idx].x + param->sub_box_list[nTrackID].bouding_box[sub_idx].width < res_frame->width - nPad)
					&& (param->sub_box_list[nTrackID].bouding_box[sub_idx].height >= param->sub_box_list[nTrackID].bouding_box[sub_idx].width)))
			{
				if (biker_info.biker_box_info[t].n_box == m)
					param->sub_box_list[nTrackID].n_rider_histogram[m]++;
			}
		}

		//2018.10.24 Young
		int nPtBottomX = biker_info.biker_box_info[t].bouding_box.x + (biker_info.biker_box_info[t].bouding_box.width / 2);
		int nPtBottomY = biker_info.biker_box_info[t].bouding_box.y + (biker_info.biker_box_info[t].bouding_box.height);
		int nBoxWidth = biker_info.biker_box_info[t].bouding_box.width; // 2018.11.09 hai

		if ((!line_touch(biker_info.biker_box_info[t].bouding_box, line)) || 
			((biker_info.biker_box_info[t].class_id != REAR_BIKE_CLASS_ID) && (biker_info.biker_box_info[t].class_id != FRONT_BIKE_CLASS_ID)
				&& (biker_info.biker_box_info[t].class_id != FRONT_TRUCKBIKE_CLASS_ID) && (biker_info.biker_box_info[t].class_id != REAR_TRUCKBIKE_CLASS_ID)) )
		//	if ((!line_touch(biker_info.biker_box_info[t].bouding_box, line)) || (biker_info.biker_box_info[t].class_id != 4))
		{
			//hai 2018.12.12 
			//if (biker_info.TO_violation[nTrackID]++ >= n_violation_confirm)
			//{
			//	biker_info.rider_violation_confirm[nTrackID] = 0;		////=== hai edited ===////
			//	biker_info.helmet_violation_confirm[nTrackID] = 0;		////=== hai edited ===////
			//	biker_info.TO_violation[nTrackID] = 0;

			//	biker_info.umbrella_violation_confirm[nTrackID] = 0;		// 2018.09.27 hai
			//	biker_info.mobile_violation_confirm[nTrackID] = 0;		// 2018.09.27 hai

			//	biker_info.violation_confirm[nTrackID] = 0;				// 2018.10.22 hai
			//}
			//std::cout << "no touch: trackid: " << nTrackID << "no touch: count: " << biker_info.TO_violation[nTrackID] << std::endl;
			continue;
		}
		else if ((line_touch(biker_info.biker_box_info[t].bouding_box, line) && biker_info.violation_confirm[nTrackID] == 1))
		{
			continue;
		}
		else if (pRegion->CRegion_LaneVio_Isleftside(nPtBottomX, nPtBottomY, nBoxWidth) == NO_VIOLATION_AREA)	//2018.10.24 Young
		{
			std::cout << "NO_VIOLATION_AREA " << nPtBottomX << "," << nPtBottomY << std::endl;
			continue;
		}

		int track_id = nTrackID;
		//		printf("%d = %d\n", track_id, param->mot_info->n_violated[track_id]);

		std::cout << "touched: trackid: " << track_id << "confirm: " << biker_info.rider_violation_confirm[track_id] << ";" << biker_info.helmet_violation_confirm[track_id] << std::endl;

		//2018.10.23 hai
		/*int n_min_rider = find_min_rider(res_frame, track_id, param->sub_box_list);
		int n_min_idx = param->sub_box_list[track_id].n_min_rider_idx;*/
		int n_min_rider = find_num_rider_histogram(res_frame, track_id, param->sub_box_list);
		int n_min_idx = param->sub_box_list[track_id].n_his_rider_index;

		std::cout << "============= n_min_rider_idx: " << n_min_idx << "=========== n_min_rider: " << n_min_rider << " ===== current n_box: " << biker_info.biker_box_info[t].n_box << std::endl;

		if (nCheckBikeViolation && n_min_rider >= max_rider && biker_info.rider_violation_confirm[track_id] < n_violation_confirm && !bIsTruckBike)
		{
			biker_info.rider_violation_confirm[track_id]++;							

			b_violation = true;
			vio_status.violation_box_info[n_violation].max_rider_violation = 1;
			sprintf(vio_status.violation_box_info[n_violation].vio_type, "O");

			vio_status.violation_box_info[n_violation].class_id = biker_info.biker_box_info[t].class_id;
			vio_status.violation_box_info[n_violation].bouding_box = biker_info.biker_box_info[t].bouding_box;

			vio_status.violation_box_info[n_violation].track_id = biker_info.biker_box_info[t].track_id; // 2018.10.23

		}

		vio_status.violation_box_info[n_violation].n_person = param->sub_box_list[track_id].n_box_list[n_min_idx];
		vio_status.violation_box_info[n_violation].n_person_helmet = vio_status.violation_box_info[n_violation].n_person;

		bool b_helmet_violation = false;

		std::cout << "rider_violation_confirm " << biker_info.rider_violation_confirm[track_id] << std::endl;
		std::cout << "helmet_violation_confirm " << biker_info.helmet_violation_confirm[track_id] << std::endl;

		for (int n = 0; n < param->sub_box_list[track_id].n_box_list[n_min_idx]; n++)
		{
			//			printf("%d)head_box_class = %d\n", n, biker_info.biker_box_info[t].head_box_info[n].class_id);
			for (int v = 0; v < n_violation_class; v++)
			{
				if (nCheckBikeViolation && param->sub_box_list[track_id].head_box_list[n_min_idx].head_box_info[n].class_id == violation_class[v] && biker_info.helmet_violation_confirm[track_id] < n_violation_confirm) ////=== hai edited ===////
				{
					////=== hai edited ===////
					b_helmet_violation = true;
					b_violation = true;
					vio_status.violation_box_info[n_violation].helmet_violation = 1;
					sprintf(vio_status.violation_box_info[n_violation].vio_type, "H");

					vio_status.violation_box_info[n_violation].n_person_helmet--;
					vio_status.violation_box_info[n_violation].class_id = biker_info.biker_box_info[t].class_id;
					vio_status.violation_box_info[n_violation].bouding_box = biker_info.biker_box_info[t].bouding_box;

					vio_status.violation_box_info[n_violation].track_id = biker_info.biker_box_info[t].track_id; // 2018.10.23
				}
			}
		}

		if (b_helmet_violation == true)
		{
			biker_info.helmet_violation_confirm[track_id] ++;
		}

		// 2018.09.27 hai - umbrella
		bool b_umbrella_violation = false;

		//std::cout << "umbrella_violation_confirm " << biker_info.umbrella_violation_confirm[track_id] << std::endl;
		//std::cout << "biker_info.biker_box_info[track_id].umbrella_box_info.class_id: " << param->sub_box_list[track_id].umbrella_box_info.class_id << std::endl;

		//if(biker_info.biker_box_info[track_id].umbrella_box_info.class_id == umbrella_violation_class && biker_info.umbrella_violation_confirm[track_id] < n_violation_confirm)
		if (nCheckBikeViolation && param->sub_box_list[track_id].umbrella_box_info.class_id == umbrella_violation_class && biker_info.umbrella_violation_confirm[track_id] < n_violation_confirm
			&& param->sub_box_list[track_id].nIsUmbrella == 1 && !bIsTruckBike)
		{
			biker_info.umbrella_violation_confirm[track_id]++;

			b_umbrella_violation = true;
			b_violation = true;
			vio_status.violation_box_info[n_violation].umbrella_violation = 1;
			sprintf(vio_status.violation_box_info[n_violation].vio_type, "U");

			vio_status.violation_box_info[n_violation].class_id = biker_info.biker_box_info[t].class_id;
			vio_status.violation_box_info[n_violation].bouding_box = biker_info.biker_box_info[t].bouding_box;
			vio_status.violation_box_info[n_violation].Um_bouding_box = param->sub_box_list[track_id].umbrella_box_info.bouding_box; //2018.10.12 hai

			vio_status.violation_box_info[n_violation].track_id = biker_info.biker_box_info[t].track_id; // 2018.10.23

		}
		//param->sub_box_list[track_id].nIsUmbrella = 0;

		// 2018.09.27 hai - mobile
		bool b_mobile_violation = false;

		//std::cout << "mobile_violation_confirm " << biker_info.mobile_violation_confirm[track_id] << std::endl;
		//std::cout << "biker_info.biker_box_info[track_id].mobile_box_info.class_id: " << param->sub_box_list[track_id].mobile_box_info.class_id << std::endl;

		//if (biker_info.biker_box_info[track_id].mobile_box_info.class_id == mobile_violation_class && biker_info.mobile_violation_confirm[track_id] < n_violation_confirm)
		if (nCheckBikeViolation && param->sub_box_list[track_id].mobile_box_info.class_id == mobile_violation_class && biker_info.mobile_violation_confirm[track_id] < n_violation_confirm
			&& param->sub_box_list[track_id].nIsMobile == 1 && !bIsTruckBike)
		{
			biker_info.mobile_violation_confirm[track_id]++;

			b_mobile_violation = true;
			b_violation = true;
			vio_status.violation_box_info[n_violation].mobile_violation = 1;
			sprintf(vio_status.violation_box_info[n_violation].vio_type, "M");

			vio_status.violation_box_info[n_violation].class_id = biker_info.biker_box_info[t].class_id;
			vio_status.violation_box_info[n_violation].bouding_box = biker_info.biker_box_info[t].bouding_box;
			vio_status.violation_box_info[n_violation].Mo_bouding_box = param->sub_box_list[track_id].mobile_box_info.bouding_box;

			vio_status.violation_box_info[n_violation].track_id = biker_info.biker_box_info[t].track_id; // 2018.10.23

		}
		//param->sub_box_list[track_id].nIsMobile = 0;

		if (biker_info.rider_violation_confirm[nTrackID] >= n_violation_confirm || biker_info.helmet_violation_confirm[nTrackID] >= n_violation_confirm
			|| biker_info.umbrella_violation_confirm[nTrackID] >= n_violation_confirm || biker_info.mobile_violation_confirm[nTrackID] >= n_violation_confirm)
		{
			biker_info.violation_confirm[nTrackID] = 1;
		}
		else 
		{
			biker_info.violation_confirm[nTrackID] = 0;
		}

		if (b_violation == true)
		{
			param->mot_info->n_violated[track_id]++;

			biker_info.TO_violation[track_id] = 0;

			std::cout << n_violation_confirm << "; " << param->mot_info->n_violated[track_id] << std::endl;

			if (param->mot_info->n_violated[track_id] >= n_violation_confirm)
			{

				param->mot_info->n_violated[track_id] = 0;
				n_violation++;
			}
			//		if (b_violation == true) n_violation++;
		}

	}

	vio_status.n_violation = n_violation;


}

//2018.10.24 hai
bool biker_box_overlap(int nbikerIdx, st_biker_info &biker_info, int nTrackID, st_sub_box_info *sub_box_list)
{
	bool bOverlap = false;
	float fThreshold = 0.5;

	for (int t = 0; t < biker_info.n_biker_box; t++)
	{
		if (t != nbikerIdx)
		{
			float iou = rect_iou(biker_info.biker_box_info[nbikerIdx].bouding_box, biker_info.biker_box_info[t].bouding_box, 1);
			if (iou >= fThreshold)
			{
				bOverlap = true;
				break;
			}
		}
	}

	return bOverlap;
}


//2018.10.12 hai
int find_num_rider_histogram(IplImage *res_frame, int nTrackID, st_sub_box_info *sub_box_list)
{
	sub_box_list[nTrackID].n_his_rider = -1;

	int max_hisvalue = sub_box_list[nTrackID].n_rider_histogram[1];
	//if (max_hisvalue > 0) sub_box_list[nTrackID].n_his_rider = 1;

	for (int m = 2; m < MAX_SUB_BOX; m++)
	{
		if (sub_box_list[nTrackID].n_rider_histogram[m] > max_hisvalue)
		{
			max_hisvalue = sub_box_list[nTrackID].n_rider_histogram[m];
			sub_box_list[nTrackID].n_his_rider = m;
		}
	}

	float max_score = 0;
	
	if (sub_box_list[nTrackID].n_his_rider > 0)
	{
		for (int i = 0; i < MAX_FRAME_NUM; i++)
		{
			if (sub_box_list[nTrackID].n_box_list[i] == sub_box_list[nTrackID].n_his_rider && sub_box_list[nTrackID].mean_score[i] > max_score)
			{
				sub_box_list[nTrackID].n_his_rider_index = i;
				max_score = sub_box_list[nTrackID].mean_score[i];
			}
		}
	}

	if (sub_box_list[nTrackID].n_his_rider == -1)
	{
		sub_box_list[nTrackID].n_his_rider = sub_box_list[nTrackID].n_box_list[sub_box_list[nTrackID].n_box_idx];
		sub_box_list[nTrackID].n_his_rider_index = sub_box_list[nTrackID].n_box_idx;
	}
	
	return sub_box_list[nTrackID].n_his_rider;
}


//// 2018.09.10 
int find_min_rider(IplImage *res_frame, int nTrackID, st_sub_box_info *sub_box_list)
{
	sub_box_list[nTrackID].n_min_rider_idx = -1;

	int nPad = 30;

	int min_rider = MAX_SUB_BOX;
	float max_score = 0;
	
	for (int i = 0; i < MAX_FRAME_NUM; i++)
	{
		if (sub_box_list[nTrackID].n_box_list[i] >= 1)
		{
			//if ((sub_box_list[nTrackID].bouding_box[i].height >= sub_box_list[nTrackID].bouding_box[i].width && sub_box_list[nTrackID].bouding_box[i].y + sub_box_list[nTrackID].bouding_box[i].height >= res_frame->height - nPad)
			//	|| (sub_box_list[nTrackID].bouding_box[i].y + sub_box_list[nTrackID].bouding_box[i].height < res_frame->height - nPad))
			if ((sub_box_list[nTrackID].bouding_box[i].x > nPad) 
				&& (sub_box_list[nTrackID].bouding_box[i].x + sub_box_list[nTrackID].bouding_box[i].width < res_frame->width - nPad) 
				&& (sub_box_list[nTrackID].bouding_box[i].y + sub_box_list[nTrackID].bouding_box[i].height < res_frame->height - nPad))
			{
				//if (sub_box_list[nTrackID].n_box_list[i] < min_rider || sub_box_list[nTrackID].n_box_list[i] == 2)
				if (sub_box_list[nTrackID].n_box_list[i] <= min_rider && sub_box_list[nTrackID].mean_score[i]> max_score) // 2018.10.23 hai
				{
					min_rider = sub_box_list[nTrackID].n_box_list[i];
					sub_box_list[nTrackID].n_min_rider_idx = i;
					max_score = sub_box_list[nTrackID].mean_score[i];
				}
			}
		}
	}

	//if (min_rider == MAX_SUB_BOX || sub_box_list[nTrackID].n_min_rider_idx == -1)
	if (min_rider == 10 || sub_box_list[nTrackID].n_min_rider_idx == -1)
	{
		min_rider = sub_box_list[nTrackID].n_box_list[sub_box_list[nTrackID].n_box_idx];
		sub_box_list[nTrackID].n_min_rider_idx = sub_box_list[nTrackID].n_box_idx;
	}

	return min_rider;
}

void catch_biker_violation(IplImage *frame, IplImage *res_frame, st_det_mot_param *param, st_biker_info &biker_info, st_violation_info &vio_status, int line, CRegion* pResion)
{

	make_biker_info_structure(param, biker_info);
	make_vio_status_structure(frame, res_frame, param, biker_info, vio_status, line, pResion);

#if 0		
	printf("vio_status.n_violation = %d\n", vio_status.n_violation);
	for (int v = 0; v < n_violation; v++)
	{
		printf("%d)type = (%d %d)\n", v, vio_status.violation_box_info[v].max_rider_violation, vio_status.violation_box_info[v].helmet_violation);
		printf("box = (%d %d %d %d)\n", v, vio_status.violation_box_info[v].bouding_box.x, vio_status.violation_box_info[v].bouding_box.y,
			vio_status.violation_box_info[v].bouding_box.width, vio_status.violation_box_info[v].bouding_box.height);

	}
#endif

}

bool line_touch(CvRect box, int line)
{
	int y1 = box.y;
	int y2 = box.y + box.height - 1;
	//if ((line > y1) && (line < y2))	//kyk
	if ((line > y2) && (line < y2 + 100))
	{
		return true;
	}
	else
	{
		return false;
	}
}


bool line_touch_forcounting(CvRect box, int line)
{
	int y1 = box.y;
	int y2 = box.y + box.height - 1;
	//if ((line > y1) && (line < y2))
	if ((line > (y2 - 50)) && (line < (y2 + 50))) // 2018.12.13
	{
		return true;
	}
	else
	{
		return false;
	}
}


float rect_iou(CvRect a, CvRect b, int type)
{
	//overlap is invalid in the beginning
	float o = -1;

	float aPointX1 = (float)a.x;
	float aPointY1 = (float)a.y;
	float aPointX2 = (float)(a.x + a.width - 1);
	float aPointY2 = (float)(a.y + a.height - 1);

	float bPointX1 = (float)b.x;
	float bPointY1 = (float)b.y;
	float bPointX2 = (float)(b.x + b.width - 1);
	float bPointY2 = (float)(b.y + b.height - 1);

	//get overlapping area
	float x1 = MAX(aPointX1, bPointX1);
	float y1 = MAX(aPointY1, bPointY1);
	float x2 = MIN(aPointX2, bPointX2);
	float y2 = MIN(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
		return 0;

	//get overlapping areas
	float inter = w * h;
	float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
	float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

	//intersection over union overlap depending on users choice
	if (type == 0)
	{
		o = inter / (a_area + b_area - inter);
	}
	else
	{
		o = (a_area > b_area) ? inter / b_area : inter / a_area;
	}

	//overlap
	return o;
}

void getGPUDeviceInfoPrint()
{
	cudaDeviceProp prop;

	int count;
	cudaGetDeviceCount(&count);

	for (int i = 0; i< count; i++)
	{
		cudaGetDeviceProperties(&prop, i);
		printf("   --- General Information for device %d ---\n", i);
		printf("Name:  %s\n", prop.name);
		printf("Compute capability:  %d.%d\n", prop.major, prop.minor);
		printf("Clock rate:  %d\n", prop.clockRate);
		printf("Device copy overlap:  ");
		if (prop.deviceOverlap)
			printf("Enabled\n");
		else
			printf("Disabled\n");
		printf("Kernel execution timeout :  ");
		if (prop.kernelExecTimeoutEnabled)
			printf("Enabled\n");
		else
			printf("Disabled\n");
		printf("\n");

		printf("   --- Memory Information for device %d ---\n", i);
		printf("Total global mem:  %ld\n", prop.totalGlobalMem);
		printf("Total constant Mem:  %ld\n", prop.totalConstMem);
		printf("Max mem pitch:  %ld\n", prop.memPitch);
		printf("Texture Alignment:  %ld\n", prop.textureAlignment);
		printf("\n");

		printf("   --- MP Information for device %d ---\n", i);
		printf("Multiprocessor count:  %d\n", prop.multiProcessorCount);
		printf("Shared mem per mp:  %ld\n", prop.sharedMemPerBlock);
		printf("Registers per mp:  %d\n", prop.regsPerBlock);
		printf("Threads in warp:  %d\n", prop.warpSize);
		printf("Max threads per block:  %d\n", prop.maxThreadsPerBlock);
		printf("Max thread dimensions:  (%d, %d, %d)\n", prop.maxThreadsDim[0], prop.maxThreadsDim[1], prop.maxThreadsDim[2]);
		printf("Max grid dimensions:  (%d, %d, %d)\n", prop.maxGridSize[0], prop.maxGridSize[1], prop.maxGridSize[2]);
		printf("\n");
	}
}

char* getStringClassID(int nClassID)
{
	switch (nClassID)
	{
		case CAR_CLASS_ID:
			if (COUNT_MODE_COUNTRY == 0) return "Car";
			else if (COUNT_MODE_COUNTRY == 1) return "Sedan"; //20190213 hai Car->Sedan
			else if (COUNT_MODE_COUNTRY == 3) return "A";
			else if (COUNT_MODE_COUNTRY == 4) return "A";
			break;
		case BAN_CLASS_ID:
			if (COUNT_MODE_COUNTRY == 3) return "B";
			if (COUNT_MODE_COUNTRY == 4) return "B";
			return "Suv"; //20190214
			break;
		case BUS_CLASS_ID:
			if (COUNT_MODE_COUNTRY == 3) return "B";
			if (COUNT_MODE_COUNTRY == 4) return "B";
			return "Bus";
			break;
		case TRUCK_CLASS_ID:
			if (COUNT_MODE_COUNTRY == 3) return "Human";
			if (COUNT_MODE_COUNTRY == 4) return "Human";
			return "Truck";
			break;
		case FRONT_BIKE_CLASS_ID:
		case REAR_BIKE_CLASS_ID:
		case SIDE_BIKE_CLASS_ID:
			return "Bike";
			break;
		case HUMAN_CLASS_ID:
			return "Human";
			break;
		case BICYCLE_CLASS_ID:
			return "Bicycle";
			break;
		case FRONT_TRUCKBIKE_CLASS_ID:
		case REAR_TRUCKBIKE_CLASS_ID:
		case SIDE_TRUCKBIKE_CLASS_ID:
			if (COUNT_MODE_COUNTRY == 0) return "TruckBike";
			else if(COUNT_MODE_COUNTRY == 1) return "Bajaj"; //20190214 hai TruckBike->Bajaj
			//else if (COUNT_MODE_COUNTRY == 1) return "Bagac"; //20190214 hai TruckBike->Bajaj
			break;
		default:
			break;
	}

	return "";
}

//eyw 2019.01.07 License File(ini) Read Function
std::string getLicenseFileRead() { 
	TCHAR currentPath[MAX_PATH], filename[MAX_PATH];
#if 1
	DWORD dwLength = GetModuleFileName(nullptr, currentPath, MAX_PATH);
	if (0 != dwLength) {
		TCHAR* string = currentPath + dwLength;
		while (--string != currentPath && *string != L'\\');
		if (*string == L'\\') {
			*string = L'\0'; // nullptr 
							 //return (string - m_iniPath); // 
		}
	}
#else
	TCHAR currentPath[MAX_PATH], filename[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, currentPath);
	wsprintf(filename, L"%s\\License.ini", currentPath);
#endif
	wsprintf(filename, "%s\\License.ini", currentPath);



	std::string readtext;
	std::ifstream in(filename);

	if (in.is_open()) {
		getline(in, readtext);
	}
	else {
		std::cout << "Licence Key Read Fail. Check Your Licence Key File" << std::endl;
		system("pause > null");
		return 0;
	}

	return readtext;
}


//20190222 hai Violation Color
void violation_text_display(IplImage *image, st_det_mot_param *param, int ntrack, int nTrackID)
{
	char textTmp[CHAR_LENGTH] = "";
	int nViolation = 0;
	for (int c_id = 0; c_id < ACCIDENT_CLR + 1; c_id++)
	{

		if (c_id == OVER_SPEED_CLR && param->mot_DataSave[nTrackID].nVioDisplay[OVER_SPEED_CLR])
		{		
			sprintf(textTmp, "%sSPEED ", textTmp);
			nViolation++;
		}
		else if (c_id == LOW_SPEED_CLR && param->mot_DataSave[nTrackID].nVioDisplay[LOW_SPEED_CLR])
		{
			sprintf(textTmp, "%sSPEED ", textTmp);
			nViolation++;
		}
		else if (c_id == LANE_VIOLATION_CLR && param->mot_DataSave[nTrackID].nVioDisplay[LANE_VIOLATION_CLR])
		{
			sprintf(textTmp, "%sLANE ", textTmp);
			nViolation++;
		}
		else if (c_id == ILLEGAL_PARKING_CLR && param->mot_DataSave[nTrackID].nVioDisplay[ILLEGAL_PARKING_CLR])
		{
			sprintf(textTmp, "%sPARKING ", textTmp);
			nViolation++;
		}
		//20190523 hai reverse violation
		else if (c_id == REVERSE_VIOLATION_CLR && param->mot_DataSave[nTrackID].nVioDisplay[REVERSE_VIOLATION_CLR])
		{
			sprintf(textTmp, "%sREVERSE ", textTmp);
			nViolation++;
		}

		CvFont font;
		cvInitFont(&font, CV_FONT_HERSHEY_SIMPLEX | CV_FONT_ITALIC, 0.5, 0.5, 0, 2, 1);
		int x = param->mot_info->mot_box_info[ntrack].bouding_box.x;
		int y = param->mot_info->mot_box_info[ntrack].bouding_box.y;

		if (nViolation == 1)
		{
			if(param->mot_DataSave[nTrackID].nVioDisplay[OVER_SPEED_CLR]) cvPutText(image, textTmp, cvPoint(x,y), &font, param->vio_color[OVER_SPEED_CLR]);
			if (param->mot_DataSave[nTrackID].nVioDisplay[LOW_SPEED_CLR]) cvPutText(image, textTmp, cvPoint(x, y), &font, param->vio_color[LOW_SPEED_CLR]);
			if (param->mot_DataSave[nTrackID].nVioDisplay[LANE_VIOLATION_CLR]) cvPutText(image, textTmp, cvPoint(x, y), &font, param->vio_color[LANE_VIOLATION_CLR]);
			if (param->mot_DataSave[nTrackID].nVioDisplay[ILLEGAL_PARKING_CLR]) cvPutText(image, textTmp, cvPoint(x, y), &font, param->vio_color[ILLEGAL_PARKING_CLR]);
			//20190523 hai reverse violation
			if (param->mot_DataSave[nTrackID].nVioDisplay[REVERSE_VIOLATION_CLR]) cvPutText(image, textTmp, cvPoint(x, y), &font, param->vio_color[REVERSE_VIOLATION_CLR]);
		}
		else
			cvPutText(image, textTmp, cvPoint(x, y), &font, cvScalar(0, 255, 255, 0));
	}
}