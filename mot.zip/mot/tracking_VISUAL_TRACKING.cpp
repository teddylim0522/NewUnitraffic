
#include "tracking.h"

//st_feature feature;
cl_tracking tracking[24];

int max_index_(float *a, int n)
{
	if (n <= 0) return -1;
	int i, max_i = 0;
	float max = a[0];
	for (i = 1; i < n; ++i)
	{
		if (a[i] > max)
		{
			max = a[i];
			max_i = i;
		}
	}
	return max_i;
}

int tracking_function(int nCameraIndex, IplImage *image, int num, box *boxes, float **probs, int classes, st_mot_info *mot_info, st_sub_box_info *sub_box_list, st_biker_info *biker_info, st_mot_DataSave *mot_datasave, st_det_mot_param *param) //hai 2019.01.14
{
	//vector<Rect_f> roi;
	//vector<float> roi_weight;

	int n_trackable_detect = 0;
	int lu_pt_x, lu_pt_y, rd_pt_x, rd_pt_y;	//2018.10.24 Young. Apply Digist Tracking
	CvRect rtTemp;
	int nMinBoxSize = 2;
	for (int i = 0; i < mot_info->n_detect_num; i++)
	{
		if (mot_info->det_box_info[i].class_group_id < 0) 
			continue;

		//young 20190406
		rtTemp = mot_info->det_box_info[i].bouding_box;

		if (rtTemp.x < 0)
			rtTemp.x = 0;
		if (rtTemp.y < 0)
			rtTemp.y = 0;
		if (rtTemp.x >= image->width - nMinBoxSize)
			rtTemp.x = image->width - nMinBoxSize;
		if (rtTemp.y >= image->height - nMinBoxSize)
			rtTemp.y = image->height - nMinBoxSize;

		if (rtTemp.width < nMinBoxSize)
			rtTemp.width = nMinBoxSize;
		if (rtTemp.height < nMinBoxSize)
			rtTemp.height = nMinBoxSize;

		if (rtTemp.x + rtTemp.width >= image->width - nMinBoxSize)
			rtTemp.width = image->width - rtTemp.x - 1;
		if (rtTemp.y + rtTemp.height >= image->height - nMinBoxSize)
			rtTemp.height = image->height - rtTemp.y - 1;

		mot_info->det_box_info[i].bouding_box = rtTemp;

	//	lu_pt_x = (mot_info->det_box_info[i].bouding_box.x < 0) ? 0 : mot_info->det_box_info[i].bouding_box.x;
	//	lu_pt_y = (mot_info->det_box_info[i].bouding_box.y < 0) ? 0 : mot_info->det_box_info[i].bouding_box.y;
	//	rd_pt_x = ((mot_info->det_box_info[i].bouding_box.x + mot_info->det_box_info[i].bouding_box.width) >= image->width) ? (image->width - 1) : (mot_info->det_box_info[i].bouding_box.x + mot_info->det_box_info[i].bouding_box.width - 1);
	//	rd_pt_y = ((mot_info->det_box_info[i].bouding_box.y + mot_info->det_box_info[i].bouding_box.height) >= image->height) ? (image->height - 1) : (mot_info->det_box_info[i].bouding_box.y + mot_info->det_box_info[i].bouding_box.height - 1);

	//	tracking.detect[n_trackable_detect].detectROI.x = (float)lu_pt_x;
	//	tracking.detect[n_trackable_detect].detectROI.y = (float)lu_pt_y;
	//	tracking.detect[n_trackable_detect].detectROI.width = (float)(rd_pt_x - lu_pt_x);
	//	tracking.detect[n_trackable_detect].detectROI.height = (float)(rd_pt_y - lu_pt_y);

		tracking[nCameraIndex].detect[n_trackable_detect].detectROI.x = (float)rtTemp.x;
		tracking[nCameraIndex].detect[n_trackable_detect].detectROI.y = (float)rtTemp.y;
		tracking[nCameraIndex].detect[n_trackable_detect].detectROI.width = (float)rtTemp.width;
		tracking[nCameraIndex].detect[n_trackable_detect].detectROI.height = (float)rtTemp.height;


		tracking[nCameraIndex].detect[n_trackable_detect].detectScore = mot_info->det_box_info[i].score;
		tracking[nCameraIndex].detect[n_trackable_detect].class_id = mot_info->det_box_info[i].class_id;
		tracking[nCameraIndex].detect[n_trackable_detect].class_group_id = mot_info->det_box_info[i].class_group_id;

		n_trackable_detect++;
	}
	tracking[nCameraIndex].nDetect = n_trackable_detect;

	Mat left_image = cvarrToMat(image);

	//roi_score_probability(roi_weight, dt.pt.weight_sum);

#if (VISUAL_TRACKING == 1) || (APPEARANCE_MODEL == 1)

//	Mat yc_image ;
//	cvtColor(left_image, yc_image, CV_BGR2YCrCb);
	double min_value, max_value;

#ifdef GM_CHANNEL
	Mat *tmp_channel_image = new Mat[N_CHANNEL];
	get_channel_image(left_image, tmp_channel_image, NULL, feature);
	for (int ch = N_BIN; ch < N_CHANNEL; ch++)
	{
		tracking.mkcf_tracker.channel_image[ch - N_BIN] = tmp_channel_image[ch].clone();
		minMaxLoc(tracking.mkcf_tracker.channel_image[ch - N_BIN], &min_value, &max_value);
		tracking.mkcf_tracker.channel_image[ch - N_BIN] /= max_value;
	}
	delete[] tmp_channel_image;
#else
	for (int ch = 0; ch < TRACK_CHANNEL; ch++)
		tracking[nCameraIndex].mkcf_tracker.channel_image[ch].create(left_image.rows, left_image.cols, CV_32F);

	image_to_ch_image(left_image, tracking[nCameraIndex].mkcf_tracker.channel_image);
	for (int ch = 0; ch < TRACK_CHANNEL; ch++)
	{
		minMaxLoc(tracking[nCameraIndex].mkcf_tracker.channel_image[ch], &min_value, &max_value);
		if (max_value)
			tracking[nCameraIndex].mkcf_tracker.channel_image[ch] /= max_value;
		else
			tracking[nCameraIndex].mkcf_tracker.channel_image[ch] = 0;
	}

#endif
#endif 
	printf("state_update \n");
	tracking[nCameraIndex].state_update(left_image, sub_box_list); //// 2018.09.03
	//tracking.display(left_image, track_num, track_id, track_roi);
	//display¿ë	
	int track_cnt = 0;
	for (int i = 0; i < tracking[nCameraIndex].nMapping; i++)
	{
		printf("[%d]nMapping %d \n", i, tracking[nCameraIndex].nMapping);

		int id = tracking[nCameraIndex].mapping[i];

		printf("[%d]TC %d, id %d->%d \n", tracking[nCameraIndex].nMapping, track_cnt, mot_info->mot_box_info[track_cnt].track_id, id);

		if (tracking[nCameraIndex].track[id].state == TRACK_NULL || tracking[nCameraIndex].track[id].state == TRACK_INIT)
		{
			printf("stracking tate %d \n", tracking[nCameraIndex].track[id].state);
			continue;
		}

		//20190406 young. modify convert_rectf_to_rect
		tracking[nCameraIndex].track[id].i_prevROI = convert_rectf_to_rect(tracking[nCameraIndex].track[id].f_prevROI);
		mot_info->mot_box_info[track_cnt].bouding_box = tracking[nCameraIndex].track[id].i_prevROI;

		printf("rect %d %d %d %d \n", tracking[nCameraIndex].track[id].i_prevROI.x, tracking[nCameraIndex].track[id].i_prevROI.y, tracking[nCameraIndex].track[id].i_prevROI.width, tracking[nCameraIndex].track[id].i_prevROI.height);

		mot_info->mot_box_info[track_cnt].track_id = id;	

		mot_info->mot_box_info[track_cnt].class_id = tracking[nCameraIndex].track[id].class_id;
		mot_info->mot_box_info[track_cnt].class_group_id = tracking[nCameraIndex].track[id].class_group_id;

		if (tracking[nCameraIndex].track[id].b_checked == false) //track_id inactive, have to initialize
		{
			printf("b_checked \n");

			mot_info->b_counted[id] = false;
			mot_info->b_counted_forTopline[id] = false; //hai 2018.12.03
			tracking[nCameraIndex].track[id].b_checked = true;
			mot_info->n_violated[id] = 0;
			//20190214 hai Counting
			mot_info->object_confirm[id] = 0;
			mot_info->TO_object[id] = 0;

			//mot_DataSave
			mot_datasave[id].nDataSave = 0;	
			mot_datasave[id].nTrackCount = 0;	

			//20200128 BacNinh Signal/Lane
			mot_datasave[id].nIsExitStart = 0;
			mot_datasave[id].bSaveLane = 0;
			mot_datasave[id].bSaveSignal = 0;
			mot_datasave[id].nIsRedSignal = 0;
			mot_datasave[id].nIsLeftRedSignal = 0;
			mot_datasave[id].nLaneNumber = 0;
			mot_datasave[id].nTouchedTop = 0;
			mot_datasave[id].nTouchedLeft = 0;
			mot_datasave[id].nTouchedRight = 0;
			mot_datasave[id].bCheckGreenSignal = 0; //200310 check signal violation for 2nd touched line - green signal

			if (mot_datasave[id].pIplImageSLStart)
			{
				cvReleaseImage(&mot_datasave[id].pIplImageSLStart);
				mot_datasave[id].pIplImageSLStart = NULL;
			}

			//bike vio 191213
			for (int j = 0; j<MAX_SUB_BOX; j++)
			{
				sub_box_list[id].n_rider_histogram[j] = 0;
			}

			for (int sub_idx = 0; sub_idx < MAX_FRAME_NUM; sub_idx++)
			{
				sub_box_list[id].n_box_list[sub_idx] = 0;
				if (param->sub_box_list[id].vio_image[sub_idx])
					cvReleaseImage(&param->sub_box_list[id].vio_image[sub_idx]);
			}
			sub_box_list[id].n_box_idx = -1;
			sub_box_list[id].n_min_rider_idx = -1;
			sub_box_list[id].n_his_rider = -1; 


			//radar speed
			for (int nTcnt = 0; nTcnt < MAX_TRACK_COUNT; nTcnt++)
			{
				mot_datasave[id].fRadarSpeed[nTcnt] = 0.0;
			}
			mot_datasave[id].nRadarCount = 0.0;
			mot_datasave[id].fTotalRadarSpeed = 0.0;
			mot_datasave[id].fMeanRadarSpeed = 0.0;

			if (mot_datasave[id].pIplImage)
			{
				cvReleaseImage(&mot_datasave[id].pIplImage);
				mot_datasave[id].pIplImage = NULL;
			}

			//20190215 hai Parking
			mot_datasave[id].bCheckAccident = 0;
			mot_datasave[id].bSaveAccident = 0;
			mot_datasave[id].parkingTime = 0;
			if (mot_datasave[id].pIplImageParkingStart)
			{
				cvReleaseImage(&mot_datasave[id].pIplImageParkingStart);
				mot_datasave[id].pIplImageParkingStart = NULL;
			}

			//20190222 hai Violation color
			for (int j = 0; j < REVERSE_VIOLATION_CLR + 1; j++)
			{
				mot_datasave[id].nVioDisplay[j] = 0; //2019022
			}

			//hai 2018.12.12 reset all violation parameters for biker
			if (biker_info)
			{
				biker_info->rider_violation_confirm[id] = 0;
				biker_info->helmet_violation_confirm[id] = 0;
				biker_info->TO_violation[id] = 0;

				biker_info->umbrella_violation_confirm[id] = 0;
				biker_info->mobile_violation_confirm[id] = 0;

				biker_info->violation_confirm[id] = 0;

				biker_info->n_touched_count[id] = 0;
			}

			printf("Violation color init id %d\n", id);

			//20190406
			if (param)
			{
				//wrong lane violation
				{
					if (param->mot_LaneSave[id].pIplImage)
					{
						cvReleaseImage(&param->mot_LaneSave[id].pIplImage);
						param->mot_LaneSave[id].pIplImage = NULL;
					}

					if (param->mot_LaneSave[id].pLPImage)
					{
						cvReleaseImage(&param->mot_LaneSave[id].pLPImage);
						param->mot_LaneSave[id].pLPImage = NULL;
					}

					memset(&param->mot_LaneSave[id], 0, sizeof(st_lane_DataSave));

					param->mot_LaneSave[id].nStartStatus = -1;
					param->mot_LaneSave[id].nEndStatus = -1;
					param->mot_LaneSave[id].nLaneViolation = 0;
					param->mot_LaneSave[id].nLPR = 0;
					param->mot_LaneSave[id].nLaneVioCnt = 0;
					param->mot_LaneSave[id].pIplImage = NULL;
					param->mot_LaneSave[id].pLPImage = NULL;
					param->mot_LaneSave[id].nTouchBot = 0;
					param->mot_LaneSave[id].nTouchTop = 0;

					param->mot_LaneSave[id].nFirstClass = -1;
					
					param->mot_DataSave[id].nVioDisplay[LANE_VIOLATION_CLR] = 0;
				}

				//reverse violation
				{
					if (param->mot_ReverseSave[id].pIplImage)
					{
						cvReleaseImage(&param->mot_ReverseSave[id].pIplImage);
						param->mot_ReverseSave[id].pIplImage = NULL;
					}

					if (param->mot_ReverseSave[id].pLPImage)
					{
						cvReleaseImage(&param->mot_ReverseSave[id].pLPImage);
						param->mot_ReverseSave[id].pLPImage = NULL;
					}

					memset(&param->mot_ReverseSave[id], 0, sizeof(st_reverse_DataSave));
					param->mot_ReverseSave[id].nReverseViolation = 0;
					param->mot_ReverseSave[id].nLPR = 0;
					param->mot_ReverseSave[id].nReverseVioCnt = 0;
					param->mot_ReverseSave[id].pIplImage = NULL;
					param->mot_ReverseSave[id].pLPImage = NULL;
					param->mot_ReverseSave[id].nTouchBot = 0;
					param->mot_ReverseSave[id].nTouchTop = 0;
					
					param->mot_ReverseSave[id].nFirstClass = -1;

					param->mot_DataSave[id].nVioDisplay[REVERSE_VIOLATION_CLR] = 0;
				}

				//light violation 1 line touched
				param->mot_LightSave[id].nLightViolation = 0;
				param->mot_LightSave[id].nLightTouch = 0;
				param->mot_LightSave[id].nPassLine = 0;
				if (param->mot_LightSave[id].pIplImage)
				{
					cvReleaseImage(&param->mot_LightSave[id].pIplImage);
					param->mot_LightSave[id].pIplImage = NULL;
				}
			}
		}

		track_cnt++;
	}

	printf("track_cnt %d\n", track_cnt);
	return track_cnt;
}

void cl_tracking::display(Mat &image, int *track_num, int *track_id, CvRect *track_roi)
{
	Mat src = image.clone();
	Mat dst;

	if (image.channels() == 3)
		dst = src.clone();
	else
		cvtColor(src, dst, CV_GRAY2BGR);

	track_num[0] = 0;
	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];						////=== hai edited ===////

		//int id = mapID[i];							////=== hai edited ===////

		if (track[id].state == TRACK_NULL)
			continue;

		if (track[id].state == TRACK_INIT)
			continue;

		track_num[0]++;
	}

	track_roi = new CvRect[track_num[0]];
	track_id = new int[track_num[0]];
	int track_cnt = 0;
	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];						////=== hai edited ===////

		//int id = mapID[i];							////=== hai edited ===////

		//printf("(%d %d) track state = %d \n", i, id, track[id].state) ;
		//if ((track[id].state != TRACK_INIT) && (track[id].state != TRACK_ACTIVE))
		//if ((track[id].state == TRACK_NULL) || (track[id].state == TRACK_INIT))
		if (track[id].state == TRACK_NULL)
			continue;

		/*CvRect rectTmp;
		rectTmp.x = (int)track[id].f_prevROI.x;
		rectTmp.y = (int)track[id].f_prevROI.y;
		rectTmp.width = (int)track[id].f_prevROI.width;
		rectTmp.height = (int)track[id].f_prevROI.height;*/

		if (track[id].state == TRACK_INIT)
		{
			//rectangle(dst, rectTmp, cvScalar(255, 255, 255), 2);
			continue;
		}
		else
		{
			track_roi[track_cnt].x = (int)track[id].f_prevROI.x;
			track_roi[track_cnt].y = (int)track[id].f_prevROI.y;
			track_roi[track_cnt].width = (int)track[id].f_prevROI.width;
			track_roi[track_cnt].height = (int)track[id].f_prevROI.height;

			track_id[track_cnt] = id;				////=== hai edited ===////

			//track_id[track_cnt] = mapping[i];		////=== hai edited ===////

			track_cnt++;

			//rectangle(dst, rectTmp, track[id].color, 3);
		}

		if (track[id].b_tracking_success == TRUE)
		{
			//rectangle(dst, track[id].i_predROI, cvScalar(128, 128, 128), 2);
		}

		//rectangle(dst, convert_rectf_to_rect(detect[track[id].detectID].detectROI), cvScalar(0, 0, 0), 1);

		//char textTmp[CHAR_LENGTH];
		//sprintf(textTmp, "%d %d", id, track[id].cnt);
		//putText(dst, textTmp, Point((int)track[id].f_prevROI.x, (int)track[id].f_prevROI.y), FONT_HERSHEY_PLAIN, 1, track[id].color, 2);
	}
	//imshow("tracking result", dst);
	//waitKey(1);

#if SHOW_IMAGE_SAVE
	char *window_name = "tracking result";
	_mkdir(window_name);

	char file_name[CHAR_LENGTH];
	static int image_cnt = START_FRAME;
	sprintf(file_name, "%s/%d.png", window_name, image_cnt);
	imwrite(file_name, dst);
	image_cnt += SKIP;
#endif

	int test = 0;
}

void cl_tracking::state_update(Mat &image, st_sub_box_info *sub_box_list) //// 2018.09.03
{
	//2018.10.24 Young. Apply Digist Tracking
	if (nDetect > MAX_TRACK)
	{
		printf("The number of detect objects is more than the MAX_TRACK!!!!!!!!!!\n");
		exit(0);
		return;
	}

#if APPEARANCE_MODEL == 1
	for (int i = 0; i < nDetect; i++)
	{
		//detectµÇ´õ¶óµµ DETECT_SCORE_LOW º¸´Ù ÀÛÀ¸¸é initial µÇÁö ¾Ê´Â´Ù...

		//vector<float> feature;
		Mat *ch_image = mkcf_tracker.channel_image;

		get_feat_from_ch_image(ch_image, TRACK_CHANNEL, detect[i].detectROI, detect[i].appearance_feature);
	}
#endif
	if (nTrack == 0)
	{
		//nTrack = nDetect;
		//nMapping = nDetect;
		//for (int i = 0; i < nDetect; i++)
		//{
		//	//track
		//	track_initialize(i, i);
		//	mapping[i] = i;
		//}

		////=== hai edited ===////
		//nTrack = nDetect;
		//nMapping = nDetect;
		//for (int i = 0; i < nDetect; i++)
		//{
		//	//track
		//	nTrackID++;
		//	nTrackID %= MAX_TRACK;

		//	track_initialize(nTrackID, i);
		//	mapping[i] = nTrackID;
		//}

		std::cout << nTrack << std::endl;

		nTrack = nDetect;
		//nMapping = nDetect;

		int nTrackID_tmp = nTrackID;
		for (int i = 0; i < nDetect; i++)
		{
			//track
			nTrackID_tmp++;
			nTrackID_tmp %= MAX_TRACK;

			track_initialize(nTrackID_tmp, i);
		}

		nMapping = 0;

		for (int i = 0; i < MAX_TRACK; i++)
		{
			if (track[i].IsActive)
			{
				nTrackID = i;
				mapping[nMapping] = i;
				nMapping++;

				//for (int j = 0; j < MAX_FRAME_NUM; j++) //// 2018.10.24
				//{
				//	sub_box_list[nTrackID].n_box_list[j] = 0;
				//	//sub_box_list[nTrackID].bOverlap[j] = 0;
				//	if(sub_box_list[nTrackID].vio_image[j])
				//		cvReleaseImage(&sub_box_list[nTrackID].vio_image[j]); // 2018.10.26
				//}

				////2018.10.23 hai
				//for (int j = 0; j<MAX_SUB_BOX; j++)
				//{
				//	sub_box_list[nTrackID].n_rider_histogram[j] = 0;
				//}

				//sub_box_list[nTrackID].n_box_idx = -1;
				//sub_box_list[nTrackID].n_min_rider_idx = -1;

				//sub_box_list[nTrackID].n_his_rider = -1; //2018.10.12 hai
			}
		}

	}
	else
	{

		std::cout << nTrack << std::endl;

		visual_tracking(image);
		data_association();
		track_update();
		new_track_create(sub_box_list); //// 2018.09.03
		/*nMapping = 0; 
		for (int i = 0; i < MAX_TRACK; i++)
		{
			if (track[i].IsActive)
			{
				mapping[nMapping] = i;
				nMapping++;
			}
		}*/

		////=== hai edited ===////
		nMapping = 0;

		for (int i = 0; i < MAX_TRACK; i++)
		{
			if (track[i].IsActive)
			{
				//nTrackID = i;
				mapping[nMapping] = i;
				//mapID[nMapping] = i;
				nMapping++;
			}
		}
	}
}


////=== hai edited ===////

void cl_tracking::track_initialize(int track_id, int detect_id)
{
	Mat *ch_image = mkcf_tracker.channel_image;
	track[track_id].IsActive = TRUE;
	track[track_id].b_checked = false;

	track[track_id].class_id = detect[detect_id].class_id;
	track[track_id].class_group_id = detect[detect_id].class_group_id;

//	track[track_id].m_nDataSave = detect[detect_id].m_nDataSave; ////=== hai edited ===////
//	track[track_id].m_nTrackCount = detect[detect_id].m_nTrackCount; ////=== hai edited ===////

//	printf("TID %d, DID %d Save %d, TC %d \n", track_id, detect_id, track[track_id].m_nDataSave, track[track_id].m_nTrackCount);

	track[track_id].f_prevROI = detect[detect_id].detectROI; //floating roi
	track[track_id].i_prevROI = convert_rectf_to_rect(detect[detect_id].detectROI); //integer roi

	track[track_id].detectScore = detect[detect_id].detectScore;
	track[track_id].detect_score_array[0] = detect[detect_id].detectScore;
	track[track_id].sum_detect_score = detect[detect_id].detectScore;
	track[track_id].mean_detect_score = detect[detect_id].detectScore;
#if APPEARANCE_MODEL == 1
	memcpy(track[track_id].prevFeature, detect[detect_id].appearance_feature, sizeof(float)*N_APPEARANCE_FEATURE);
#endif

	if ((track[track_id].detectScore > DETECT_PROBABILITY_HIGH) || (track[track_id].cnt >= TRACK_INIT_COUNT))
//	if (track[track_id].detectScore > DETECT_PROBABILITY_HIGH) 
	{
		track[track_id].state = TRACK_ACTIVE;
		track[track_id].color = textColorTmp[track_id];
		track[track_id].cnt = 0;
	}
	else if (track[track_id].detectScore > DETECT_PROBABILITY_LOW)
	{
		track[track_id].state = TRACK_INIT;
		track[track_id].cnt = 1;
		track[track_id].color = Scalar(255, 255, 255);
	}
	else //detectµÇ´õ¶óµµ detect_score_low º¸´Ù ÀÛÀ¸¸é initial  µÇÁö ¾Ê´Â´Ù.
	{
		track[track_id].state = TRACK_NULL;
		track[track_id].IsActive = FALSE;
		nTrack--;
		nMapping--;
		track[track_id].cnt = 0;
	}
#if VISUAL_TRACKING == 1
	mkcf_tracker.train_kernel_alpha(ch_image, mkcf_tracker.Hann_filter, track[track_id].i_prevROI, mkcf_tracker.Y, TRUE, mkcf_tracker.ALPHA[track_id], mkcf_tracker.channel_roi_img[track_id]);
#endif
}


////=== hai edited ===////

//void cl_tracking::track_initialize(int track_id, int track_label, int detect_id)
//{
//	Mat *ch_image = mkcf_tracker.channel_image;
//	track[track_id].IsActive = TRUE;
//	track[track_id].b_checked = false;
//
//	track[track_id].nTrackLabel = track_label;			////=== hai edited ===////
//
//	track[track_id].class_id = detect[detect_id].class_id;
//	track[track_id].class_group_id = detect[detect_id].class_group_id;
//
//	track[track_id].f_prevROI = detect[detect_id].detectROI; //floating roi
//	track[track_id].i_prevROI = convert_rectf_to_rect(detect[detect_id].detectROI); //integer roi
//
//	track[track_id].detectScore = detect[detect_id].detectScore;
//#if APPEARANCE_MODEL == 1
//	memcpy(track[track_id].prevFeature, detect[detect_id].appearance_feature, sizeof(float)*N_APPEARANCE_FEATURE);
//#endif
//
//	if ((track[track_id].detectScore > DETECT_PROBABILITY_HIGH) || (track[track_id].cnt >= TRACK_INIT_COUNT))
//		//	if (track[track_id].detectScore > DETECT_PROBABILITY_HIGH) 
//	{
//		track[track_id].state = TRACK_ACTIVE;
//		track[track_id].color = textColorTmp[track_id];
//		track[track_id].cnt = 0;
//	}
//	else if (track[track_id].detectScore > DETECT_PROBABILITY_LOW)
//	{
//		track[track_id].state = TRACK_INIT;
//		track[track_id].cnt = 1;
//		track[track_id].color = Scalar(255, 255, 255);
//	}
//	else //detectµÇ´õ¶óµµ detect_score_low º¸´Ù ÀÛÀ¸¸é initial  µÇÁö ¾Ê´Â´Ù.
//	{
//		track[track_id].state = TRACK_NULL;
//		track[track_id].IsActive = FALSE;
//		nTrack--;
//		nMapping--;
//		track[track_id].cnt = 0;
//	}
//#if VISUAL_TRACKING == 1
//	mkcf_tracker.train_kernel_alpha(ch_image, mkcf_tracker.Hann_filter, track[track_id].i_prevROI, mkcf_tracker.Y, TRUE, mkcf_tracker.ALPHA[track_id], mkcf_tracker.channel_roi_img[track_id]);
//#endif
//}


vector<float> cl_tracking::get_feat_from_detect(Mat &image, Rect_f &ROI)
{
	vector<float> feature;
	//feature = ROI in image
	return feature;
}

bool cl_tracking::get_feat_from_ch_image(Mat *ch_image, int n_channel, Rect_f &ROI, float *feature)
{
	int image_rows = N_TRACK_GRID_Y, image_cols = N_TRACK_GRID_X;
	int image_size = image_rows * image_cols;
	Mat resize_image(TRACK_SAMPLE_HEIGHT, TRACK_SAMPLE_WIDTH, CV_32FC1);
	Mat feat_image(image_rows, image_cols, CV_32FC1);

	Rect roi = convert_rectf_to_rect(ROI);
	
	if (roi.x < 0) roi.x = 0;
	if (roi.y < 0) roi.y = 0;
	if (roi.x + roi.width >= ch_image[0].cols) roi.width = ch_image[0].cols - roi.x;
	if (roi.y + roi.height >= ch_image[0].rows) roi.height = ch_image[0].rows - roi.y;


//	if ((roi.width < 10) || (roi.height < 10))
//	{
//		return false;
//	}

	int f_id = 0;
	float sum = 0;
	for (int ch = 0; ch < n_channel; ch++)
	{
		Mat roi_image = ch_image[ch](roi);

		resize(roi_image, resize_image, Size(TRACK_SAMPLE_WIDTH, TRACK_SAMPLE_HEIGHT));
		pooling_block(resize_image, feat_image, N_FEAT_GRID, N_FEAT_GRID, "average_pooling");

		memcpy(&feature[ch*image_size], feat_image.data, sizeof(float)*image_size);
		for (int id = 0; id < image_size; id++)
		{
			sum += feature[ch*image_size + id];
		}
#if 0
		for (int y = 0; y < image_rows; y++)
		{
			for (int x = 0; x < image_cols; x++)
			{
				float *data = (float *)feat_image.data;
				printf("feature[%d] = %f feat_image(%d %d) = %f\n", f_id, feature[f_id], x, y, data[y*image_cols + x]);
				f_id++;
			}

		}
#endif
	}

	for (int ch = 0; ch < n_channel; ch++)
	{
		for (int id = 0; id < image_size; id++)
		{
			//float norm;
			if(sum)
				feature[ch*image_size + id] /= sum;
			//printf("Be sum = %f feature[%d] = %f (%d, %d)\n", sum, id, feature[ch*image_size + id], n_channel, image_size);
		}
	}
	
	//unisem_gpu_calcFeature(n_channel, image_size, sum, feature);

	return true;
}

void cl_tracking::visual_tracking(Mat &image)
{
	
	Mat *ch_image = mkcf_tracker.channel_image;
	float feat_update_weight = 0.9;
	for (int i = 0; i < nTrack; i++)
	{
		int tr_id = mapping[i];				////=== hai edited ===////

		//int tr_id = mapID[i];					////=== hai edited ===////

#if VISUAL_TRACKING	== 1
		track[tr_id].i_prevROI = convert_rectf_to_rect(track[tr_id].f_prevROI);
//		printf("prev(%d %d %d %d)\n", track[tr_id].i_prevROI.x, track[tr_id].i_prevROI.y, track[tr_id].i_prevROI.width, track[tr_id].i_prevROI.height);
		track[tr_id].predScore = mkcf_tracker.predict_roi(track[tr_id].i_prevROI, tr_id, track[tr_id].i_predROI);
//		printf("pred(%d %d %d %d) = %f \n", track[tr_id].i_predROI.x, track[tr_id].i_predROI.y, track[tr_id].i_predROI.width, track[tr_id].i_predROI.height, track[tr_id].predScore);
		//track[tr_id].predScore = 0;
		if (track[tr_id].predScore > TRACK_SUCCESS_SCORE)
		{
			//ninolyc6.2018.0615. tracking? ? ?? ??? ???? fail? ???.
			//CvPoint lt_pt, rd_pt;
			//lt_pt.x = (track[tr_id].i_predROI.x < 0) ? 0 : track[tr_id].i_predROI.x;
			//lt_pt.y = (track[tr_id].i_predROI.y < 0) ? 0 : track[tr_id].i_predROI.y;
			//rd_pt.x = ((track[tr_id].i_predROI.x + track[tr_id].i_predROI.width) > image.cols) ? image.cols - 1 : track[tr_id].i_predROI.x + track[tr_id].i_predROI.width - 1;
			//rd_pt.y = ((track[tr_id].i_predROI.y + track[tr_id].i_predROI.height) > image.rows) ? image.rows - 1 : track[tr_id].i_predROI.y + track[tr_id].i_predROI.height - 1;
			//if (((rd_pt.x - lt_pt.x) < 4) || ((rd_pt.y - lt_pt.y) < 4))
			//{
			//	track[tr_id].b_tracking_success = FALSE;
			//}
			//else
			//{
			//	track[tr_id].b_tracking_success = TRUE;
			//}

			//2018.10.24 Young. Apply Digist Tracking. ninolyc.2018.0615. small area is fail.
			CvPoint lt_pt, rd_pt;
			lt_pt.x = (track[tr_id].i_predROI.x < 0) ? 0 : track[tr_id].i_predROI.x;
			lt_pt.y = (track[tr_id].i_predROI.y < 0) ? 0 : track[tr_id].i_predROI.y;
			rd_pt.x = ((track[tr_id].i_predROI.x + track[tr_id].i_predROI.width) > image.cols) ? image.cols - 1 : track[tr_id].i_predROI.x + track[tr_id].i_predROI.width - 1;
			rd_pt.y = ((track[tr_id].i_predROI.y + track[tr_id].i_predROI.height) > image.rows) ? image.rows - 1 : track[tr_id].i_predROI.y + track[tr_id].i_predROI.height - 1;
			track[tr_id].i_predROI.x = lt_pt.x;
			track[tr_id].i_predROI.y = lt_pt.y;
			track[tr_id].i_predROI.width = rd_pt.x - lt_pt.x + 1;
			track[tr_id].i_predROI.height = rd_pt.y - lt_pt.y + 1;

			if (((rd_pt.x - lt_pt.x) < 4) || ((rd_pt.y - lt_pt.y) < 4))
			{
				track[tr_id].i_predROI = track[tr_id].i_prevROI;  //tracking error. using previous ROI
				track[tr_id].b_tracking_success = FALSE;
			}
			else
			{
				track[tr_id].b_tracking_success = TRUE;
			}

			//track roi update ?? track parameter update ??.
			//mkcf_tracker.train_kernel_alpha(ch_image, mkcf_tracker.Hann_filter, track[tr_id].i_predROI, mkcf_tracker.Y, FALSE, mkcf_tracker.ALPHA[tr_id], mkcf_tracker.channel_roi_img[tr_id]);
			track[tr_id].f_predROI = convert_rect_to_rect_f(track[tr_id].i_predROI);
		}
		else
		{
			track[tr_id].i_predROI = track[tr_id].i_prevROI;
			track[tr_id].f_predROI = convert_rect_to_rect_f(track[tr_id].i_predROI);
			track[tr_id].b_tracking_success = FALSE;

		}
#endif
#if APPEARANCE_MODEL == 1
		if ((track[tr_id].predScore > TRACK_SUCCESS_SCORE) && (track[tr_id].b_tracking_success == TRUE))  //ninolyc6.2018.0616. tracking ??? ? ????.
		{
			if (get_feat_from_ch_image(ch_image, TRACK_CHANNEL, track[tr_id].f_predROI, track[tr_id].predFeature))
			{
				update_feature(track[tr_id].prevFeature, track[tr_id].predFeature, N_APPEARANCE_FEATURE, feat_update_weight);
			}
			else
			{
				track[tr_id].b_tracking_success = false;
				memcpy(track[tr_id].predFeature, track[tr_id].prevFeature, sizeof(float)*N_APPEARANCE_FEATURE);
			}
		}
		else
		{
			memcpy(track[tr_id].predFeature, track[tr_id].prevFeature, sizeof(float)*N_APPEARANCE_FEATURE);

		}
#endif
#if VISUAL_TRACKING	 == 0

		track[tr_id].i_predROI = track[tr_id].i_prevROI;
		track[tr_id].f_predROI = convert_rect_to_rect_f(track[tr_id].i_predROI);
		track[tr_id].b_tracking_success = FALSE;
#endif
#if APPEARANCE_MODEL == 0
		memcpy(track[tr_id].predFeature, track[tr_id].prevFeature, sizeof(float)*N_APPEARANCE_FEATURE);
#endif
	}

}

void cl_tracking::update_feature(float *feat1, float *feat2, int n_feat, float w)
{
	for (int f = 0; f < n_feat; f++)
	{
		feat1[f] = w * feat1[f] + (1 - w) * feat2[f];
	}
}

//void cl_tracking::data_association()
//{
//
//	float **cost_matrix = similarity_calculate();
//	int** data_matrix = new int*[nMapping];
//	for (int i = 0; i < nMapping; i++)
//		data_matrix[i] = new int[nDetect];
//	Hungarian_algorithm(nMapping, nDetect, cost_matrix, data_matrix);
//
//	for (int i = 0; i < nMapping; i++)
//		for (int j = 0; j < nDetect; j++)
//			if ((data_matrix[i][j] == 1) && (cost_matrix[i][j] > MIN_SIMILARITY))
//				data_matrix[i][j] = 0;
//
//	//i : trackID, j : detectID
//	for (int i = 0; i < nMapping; i++)
//	{
//		int id = mapping[i];
//		track[id].IsAssociation = FALSE;
//		track[id].detectID = -1;
//	}
//
//	for (int j = 0; j < nDetect; j++)
//	{
//		detect[j].IsAssociation = FALSE;
//		detect[j].trackID = -1;
//	}
//
//	for (int i = 0; i < nMapping; i++)
//	{
//		for (int j = 0; j < nDetect; j++)
//		{
//			if (data_matrix[i][j] == 1)
//			{
//				int id = mapping[i];
//				track[id].IsAssociation = TRUE;
//				track[id].detectID = j;
//				detect[j].IsAssociation = TRUE;
//				detect[j].trackID = id;
//				track[id].class_id = detect[j].class_id;
//			}
//		}
//	}
//
//	for (int i = 0; i < nMapping; i++)
//		delete[] cost_matrix[i];
//	delete[] cost_matrix;
//
//	for (int i = 0; i < nMapping; i++)
//		delete[] data_matrix[i];
//	delete[] data_matrix;
//}


void cl_tracking::data_association()
{

	float **cost_matrix = similarity_calculate();
	int** data_matrix = new int*[nMapping];
	for (int i = 0; i < nMapping; i++)
		data_matrix[i] = new int[nDetect];
	Hungarian_algorithm(nMapping, nDetect, cost_matrix, data_matrix);

	for (int i = 0; i < nMapping; i++)
		for (int j = 0; j < nDetect; j++)
			if ((data_matrix[i][j] == 1) && (cost_matrix[i][j] > MIN_SIMILARITY))
				data_matrix[i][j] = 0;

	//i : trackID, j : detectID
	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];			

		track[id].IsAssociation = FALSE;
		//track[id].detectID = -1;
		track[id].detectID = 0;	//20190406
	}

	for (int j = 0; j < nDetect; j++)
	{
		detect[j].IsAssociation = FALSE;
		detect[j].trackID = -1;
	}

	for (int i = 0; i < nMapping; i++)
	{
		for (int j = 0; j < nDetect; j++)
		{
			if (data_matrix[i][j] == 1)
			{
				int id = mapping[i];		

				track[id].IsAssociation = TRUE;
				track[id].detectID = j;
				detect[j].IsAssociation = TRUE;
				detect[j].trackID = id;		
				track[id].class_id = detect[j].class_id;
			}
		}
	}

	for (int i = 0; i < nMapping; i++)
		delete[] cost_matrix[i];
	delete[] cost_matrix;

	for (int i = 0; i < nMapping; i++)
		delete[] data_matrix[i];
	delete[] data_matrix;
}




float cl_tracking::calulate_Bhattacharyya(float *hist1, float *hist2, int n_bin)
{
	double distance = 0.0;


	for (int i = 0; i < n_bin; i++)
	{
		distance += sqrt(hist1[i] * hist2[i]);
//		printf("%d) hist1 = %f, hist2 = %f, distance = %f\n", i, hist1[i], hist2[i], sqrt(hist1[i] * hist2[i])) ;
	}
	//	printf("distance = %f\n", distance);

	return distance;
}

float cl_tracking::calulate_Euclidean(float *hist1, float *hist2, int n_bin)
{
	double distance = 0.0;


	for (int i = 0; i < n_bin; i++)
	{
		distance += (hist1[i] - hist2[i])*(hist1[i] - hist2[i]);
		//		printf("%d) hist1 = %f, hist2 = %f, distance = %f\n", i, hist1[i], hist2[i], (hist1[i] - hist2[i])*(hist1[i] - hist2[i]));
	}
	//	printf("distance = %f\n", distance);

	return sqrt(distance);
}

/*float** cl_tracking::similarity_calculate()
{
	float** cost_matrix = new float*[nMapping];
	float iou_ratio;
	float weighted_iou_distance;
	float detect_score_weight;
	float Bhattacharyya_distance = 0;
	float Bhattacharyya_probability = 0;
	float ramda = 500;
	for (int i = 0; i < nMapping; i++)
		cost_matrix[i] = new float[nDetect];
//	detect_score_weight = 0.5*detect[j].detectScore + 0.5;
	detect_score_weight = 1;
	for (int j = 0; j < nDetect; j++)
	{
		for (int i = 0; i < nMapping; i++)
		{
			if (track[mapping[i]].class_group_id == detect[j].class_group_id)
			{

				iou_ratio = rectOverlapRatio_2x(track[mapping[i]].f_predROI, detect[j].detectROI, 0);
//				printf("d[%d] = (%f %f %f %f)\n", j, detect[j].detectROI.x, detect[j].detectROI.y, detect[j].detectROI.width, detect[j].detectROI.height);
//				printf("t[%d] = (%f %f %f %f)\n", i, track[mapping[i]].f_predROI.x, track[mapping[i]].f_predROI.y, track[mapping[i]].f_predROI.width, track[mapping[i]].f_predROI.height);
#if APPEARANCE_MODEL == 1
				Bhattacharyya_distance = calulate_Bhattacharyya(track[mapping[i]].predFeature, detect[j].appearance_feature, N_APPEARANCE_FEATURE);
				Bhattacharyya_probability = exp(-ramda * (1 - Bhattacharyya_distance));
				weighted_iou_distance = 1 - detect_score_weight*(0.7*iou_ratio + 0.3 * Bhattacharyya_probability);
#else
				weighted_iou_distance = 1 - detect_score_weight*iou_ratio;
#endif

				cost_matrix[i][j] = weighted_iou_distance;
//				printf("%d) cost_matrix[%d][%d] = %f, iou_ratio = %f, Bhattacharyya_probability = %f detect_score_weight = %f\n", mapping[i], i, j, cost_matrix[i][j], iou_ratio, Bhattacharyya_probability, detect_score_weight);
			}
			else
			{
				cost_matrix[i][j] = 1;
			}
//			printf("(%d %d) = %f\n", i, j, cost_matrix[i][j]);
		}		
	}
	return cost_matrix;
}
*/

//2018.10.24 Young. Apply Digist Tracking
float** cl_tracking::similarity_calculate()
{
	float** cost_matrix = new float*[nMapping];
	float iou_ratio;
	float weighted_iou_distance;
	float detect_score_weight = 1, track_score_weight = 1;
	float Bhattacharyya_distance = 0;
	float Bhattacharyya_probability = 0;
	float ramda = 100;
	float iou_weight = 0.8;
	for (int i = 0; i < nMapping; i++)
		cost_matrix[i] = new float[nDetect];

	for (int j = 0; j < nDetect; j++)
	{
		detect_score_weight = 0.5*detect[j].detectScore + 0.5;
		for (int i = 0; i < nMapping; i++)
		{
			track_score_weight = 0.5*track[mapping[i]].mean_detect_score + 0.5;
			//			printf("%f\n", track[mapping[i]].sum_detect_score);
			if (track[mapping[i]].class_group_id == detect[j].class_group_id)
			{

				iou_ratio = rectOverlapRatio_2x(track[mapping[i]].f_predROI, detect[j].detectROI, 0);//20191111
				//iou_ratio = rectOverlapRatio_2x(track[mapping[i]].f_predROI, detect[j].detectROI, 1);
				//				printf("d[%d] = (%f %f %f %f)\n", j, detect[j].detectROI.x, detect[j].detectROI.y, detect[j].detectROI.width, detect[j].detectROI.height);
				//				printf("t[%d] = (%f %f %f %f)\n", i, track[mapping[i]].f_predROI.x, track[mapping[i]].f_predROI.y, track[mapping[i]].f_predROI.width, track[mapping[i]].f_predROI.height);
#if APPEARANCE_MODEL == 1
				Bhattacharyya_distance = calulate_Bhattacharyya(track[mapping[i]].prevFeature, detect[j].appearance_feature, N_APPEARANCE_FEATURE);
				Bhattacharyya_probability = exp(-ramda * (1 - Bhattacharyya_distance));
				//				weighted_iou_distance = 1 - track_score_weight*detect_score_weight*(iou_weight*iou_ratio + (1-iou_weight) * Bhattacharyya_probability);
				//				weighted_iou_distance = 1 - (iou_weight*iou_ratio + (1 - iou_weight) * Bhattacharyya_probability);
				weighted_iou_distance = 1 - track_score_weight * detect_score_weight*iou_ratio*Bhattacharyya_probability;//20191111
				//if (iou_ratio > NMS_IOU) //20191111
				//	iou_ratio = 1.0;
				//weighted_iou_distance = 1 - iou_ratio * Bhattacharyya_probability;//20191111
#else
				weighted_iou_distance = 1 - detect_score_weight * iou_ratio;
#endif

				cost_matrix[i][j] = weighted_iou_distance;
				//				printf("%d) c_M[%d][%d] = %f, iou_ratio = %f, Bhatt_prob = %f det_weight = %f\n", mapping[i], i, j, cost_matrix[i][j], iou_ratio, Bhattacharyya_probability, detect_score_weight);
			}
			else
			{
				cost_matrix[i][j] = 1;
			}
			//			printf("(%d %d) = %f\n", i, j, cost_matrix[i][j]);
		}
	}
	return cost_matrix;
}

float cl_tracking::rectOverlapRatio(Rect_f a, Rect_f b, int type)
{
	//overlap is invalid in the beginning
	float o = -1;

	float aPointX1 = a.x;
	float aPointY1 = a.y;
	float aPointX2 = a.x + a.width - 1;
	float aPointY2 = a.y + a.height - 1;

	float bPointX1 = b.x;
	float bPointY1 = b.y;
	float bPointX2 = b.x + b.width - 1;
	float bPointY2 = b.y + b.height - 1;

	//get overlapping area
	float x1 = max(aPointX1, bPointX1);
	float y1 = max(aPointY1, bPointY1);
	float x2 = min(aPointX2, bPointX2);
	float y2 = min(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
		return 0;

	//get overlapping areas
	float inter = w*h;
	float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
	float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

	//intersection over union overlap depending on users choice
	if (type == 0)
	{
		o = inter / (a_area + b_area - inter);
	}
	else
	{
		o = (a_area > b_area) ? inter / b_area : inter / a_area;
	}

	//overlap
	return o;
}

float cl_tracking::rectOverlapRatio_2x(Rect_f a, Rect_f b, int type)
{
	//overlap is invalid in the beginning
	float o = -1;

	float aPointX1 = a.x - a.width*0.5;
	float aPointY1 = a.y - a.height*0.5;;
	float aPointX2 = a.x + 2 * a.width - 1;
	float aPointY2 = a.y + 2 * a.height - 1;

	float bPointX1 = b.x - b.width*0.5;
	float bPointY1 = b.y - b.height*0.5;
	float bPointX2 = b.x + 2 * b.width - 1;
	float bPointY2 = b.y + 2 * b.height - 1;

	//get overlapping area
	float x1 = max(aPointX1, bPointX1);
	float y1 = max(aPointY1, bPointY1);
	float x2 = min(aPointX2, bPointX2);
	float y2 = min(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
		return 0;

	//get overlapping areas
	float inter = w*h;
	float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
	float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

	//intersection over union overlap depending on users choice
	if (type == 0)
	{
		o = inter / (a_area + b_area - inter);
	}
	else
	{
		if (a_area == 0 || b_area == 0)
			o = 0;
		else
			o = (a_area > b_area) ? inter / b_area : inter / a_area;
	}

	//overlap
	return o;
}

void cl_tracking::new_track_create(st_sub_box_info *sub_box_list) //// 2018.09.03
{
	//Da_Matrix º¸°í
	for (int j = 0; j < nDetect; j++)
	{
		if (detect[j].IsAssociation == FALSE)
		{
			//			printf("%d detect\n", j) ;
			creat(j, sub_box_list); //// 2018.09.03
		}
	}
}

void cl_tracking::track_update()
{
	float feat_update_weight = FEATURE_UPDATE_WEIGHT;
	float track_weight, detect_weight, predict_weight;
	float prior_detect_weight = 0.9;
	predict_weight = 0.1;
	float sum_predict_weight;
	float sum_detect_score, mean_detect_score;
	
	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];			////=== hai edited ===////

		//int id = mapID[i];				////=== hai edited ===////
		if (track[id].state == TRACK_NULL)	//2018.10.24
			continue;

		track_weight = track[id].predScore;
		float sum_predict_weight = predict_weight + track_weight;

		predict_weight = predict_weight / sum_predict_weight;
		track_weight = track_weight / sum_predict_weight;


		if (track[id].IsAssociation == TRUE)
		{

			track_weight = track_weight * (1 - prior_detect_weight);
			//detect_weight = prior_detect_weight * detect[track[id].detectID].detectScore;
			detect_weight = prior_detect_weight; //2018.10.24
			predict_weight = predict_weight * (1 - prior_detect_weight);

			float weight_sum = track_weight + detect_weight + predict_weight;
			track_weight /= weight_sum;
			detect_weight /= weight_sum;
			predict_weight /= weight_sum;

	
		}
		else
		{
			detect_weight = 0;
		}

//		printf("%d) (%f %f %f )\n", track[id].detectID, track_weight, detect_weight, predict_weight);

		if (track[id].state == TRACK_NULL)
			continue;

		if (track[id].state == TRACK_INIT)
		{
			if (track[id].IsAssociation == TRUE)
			{
				if (detect[track[id].detectID].detectScore > DETECT_PROBABILITY_LOW)
					track[id].cnt++;
				else
					terminate(id);

				
				//f_prevROI = 0.2*f_predROI + 0.8*detectROI
				if (track[id].b_tracking_success == TRUE)
					track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);
				else
					track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);


				if ((track[id].cnt > TRACK_INIT_COUNT) || (detect[track[id].detectID].detectScore > DETECT_PROBABILITY_HIGH))
				{
					track[id].state = TRACK_ACTIVE;
					track[id].cnt = 0;

					track[id].color = textColorTmp[id];

					//prevFeature = 0.3*prevFeature + 0.7*detectFeature
#if APPEARANCE_MODEL == 1
					int nFeature = N_APPEARANCE_FEATURE;
					for (int k = 0; k < nFeature; k++)
						track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*detect[track[id].detectID].appearance_feature[k]);
#endif
				}
			}
			else
			{
				terminate(id);
			}
		}
		else if (track[id].state == TRACK_ACTIVE)
		{
			if (track[id].IsAssociation == TRUE)
			{
				track[id].cnt = 0;

				//f_prevROI = 0.2*f_predROI + 0.8*detectROI
				if (track[id].b_tracking_success == TRUE)
					track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);
				else
					track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);


				//prevFeature = 0.3*prevFeature + 0.7*detectFeature
#if APPEARANCE_MODEL == 1
				int nFeature = N_APPEARANCE_FEATURE;
				for (int k = 0; k < nFeature; k++)
					track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*detect[track[id].detectID].appearance_feature[k]);
#endif
			}
			else
			{
				track[id].cnt--;
				if (track[id].cnt < TRACK_TERM_COUNT)
				{
					terminate(id);
				}
				else
				{
					track[id].state = TRACK_TERMINATE;
					//20190406
					if (track[id].detectID >= 0)
					{
						if (track[id].b_tracking_success == TRUE)
							track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);
						else
							track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);
					}
				}
			}
		}
		else if (track[id].state == TRACK_TERMINATE)
		{
			if (track[id].IsAssociation == TRUE)
			{
				if (detect[track[id].detectID].detectScore > DETECT_PROBABILITY_LOW) //track tereminate »óÅÂ¿¡¼­ ´Ù½Ã active »óÅÂ·Î °¥·Á¸é score low ÀÌ»óÀÌ µÇ¾î¾ßµÈ´Ù.
				{
					track[id].cnt = 0;
					track[id].state = TRACK_ACTIVE;
					//f_prevROI = 0.2*f_predROI + 0.8*detectROI
					if (track[id].b_tracking_success == TRUE)
						track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);
					else
						track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);


#if APPEARANCE_MODEL == 1
					//prevFeature = 0.3*prevFeature + 0.7*detectFeature
					int nFeature = N_APPEARANCE_FEATURE;
					for (int k = 0; k < nFeature; k++)
						track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*detect[track[id].detectID].appearance_feature[k]);
#endif

				}
				else //track tereminate »óÅÂ¿¡¼­ ´Ù½Ã active »óÅÂ·Î °¥·Á¸é score low ÀÌÇÏ°¡ µÇ¸é, track cnt¸¦ °¨¼Ò½ÃÅ²´Ù..
				{
					track[id].cnt--;
					if (track[id].cnt < TRACK_TERM_COUNT)
					{
						terminate(id);
						//track[id].trackState = TRACK_TERMINATE;
					}
				}
			}
			else
			{
				track[id].cnt--;

				if (track[id].cnt < TRACK_TERM_COUNT)
				{
					terminate(id);
					//track[id].trackState = TRACK_TERMINATE;
				}
				else
				{
					//f_prevROI = f_predROI
					if (track[id].b_tracking_success == TRUE)
						track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);
					else
						track[id].f_prevROI = track_roi_update(track[id].f_predROI, detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, predict_weight);

					//prevFeature = prevFeature


				}
			}
		}
#if VISUAL_TRACKING == 1
		//visual tracking update
		if ((track[id].state != TRACK_NULL) && ((track[id].IsAssociation == TRUE) || (track[id].b_tracking_success == TRUE)))
		{
			Rect i_roi = convert_rectf_to_rect(track[id].f_prevROI);
			//printf("(%d %d %d %d)\n", i_roi.x, i_roi.y, i_roi.width, i_roi.height);
			mkcf_tracker.train_kernel_alpha(mkcf_tracker.channel_image, mkcf_tracker.Hann_filter, i_roi, mkcf_tracker.Y, FALSE, mkcf_tracker.ALPHA[id], mkcf_tracker.channel_roi_img[id]);
		}
#endif
	}

}


Rect_f cl_tracking::track_roi_update(Rect_f src_roi1, Rect_f src_roi2, Rect_f src_roi3, float weight1, float weight2, float weight3)
{
	Rect_f dst_roi;
	float w1 = weight1;
	float w2 = weight2;
	float w3 = weight3;
	dst_roi.x = (float)(w1*src_roi1.x + w2*src_roi2.x + w3*src_roi3.x);
	dst_roi.y = (float)(w1*src_roi1.y + w2*src_roi2.y + w3*src_roi3.y);
	dst_roi.width = (float)(w1*src_roi1.width + w2*src_roi2.width + w3*src_roi3.width);
	dst_roi.height = (float)(w1*src_roi1.height + w2*src_roi2.height + w3*src_roi3.height);
	return dst_roi;
}

void cl_tracking::creat(int detectID, st_sub_box_info *sub_box_list) //// 2018.09.03
{
	
	/*for (int i = 0; i < MAX_TRACK; i++)
	{

		if (!track[i].IsActive)
		{
			track_initialize(i, detectID);
			nTrack++;
			break;
		}
	}*/

	////=== hai edited ===////
	
		/*nTrackID++;
		nTrackID %= MAX_TRACK;

		track_initialize(nTrackID, detectID);
		nTrack++;*/

	//nTrackID++;
	//nTrackID %= MAX_TRACK;

	int nTrackID_tmp = nTrackID;

	for (int i = 0; i < MAX_TRACK; i++)
	{
		nTrackID_tmp++;
		nTrackID_tmp %= MAX_TRACK;

		if (!track[nTrackID_tmp].IsActive)
		{
			track_initialize(nTrackID_tmp, detectID);
			nTrackID = nTrackID_tmp;
			nTrack++;

			//for (int j = 0; j < MAX_FRAME_NUM; j++) //// 2018.10.24
			//{
			//	sub_box_list[nTrackID].n_box_list[j] = 0;
			//	//sub_box_list[nTrackID].bOverlap[j] = 0;
			//	
			//	if(sub_box_list[nTrackID].vio_image[j])
			//		cvReleaseImage(&sub_box_list[nTrackID].vio_image[j]); // 2018.10.26
			//}

			////2018.10.23 hai
			//for (int j = 0; j<MAX_SUB_BOX; j++)
			//{
			//	sub_box_list[nTrackID].n_rider_histogram[j] = 0;
			//}

			//sub_box_list[nTrackID].n_box_idx = -1;
			//sub_box_list[nTrackID].n_min_rider_idx = -1;

			//sub_box_list[nTrackID].n_his_rider = -1; //2018.10.12 hai

			break;
		}
	}

}

void cl_tracking::terminate(int id)
{
	track[id].IsActive = FALSE;
	track[id].state = TRACK_NULL;
	track[id].cnt = 0;
	track[id].color = Scalar(255, 255, 255);

	//previous
	track[id].f_prevROI.clear();
	track[id].detectScore = 0;

	for (int i = 0; i < TRACK_ARRAY_N; i++)
		track[id].detect_score_array[i] = 0;

	track[id].sum_detect_score = 0;
	track[id].mean_detect_score = 0;
	//next
	track[id].f_predROI.clear();
	track[id].predScore = 0;


	//association
	track[id].IsAssociation = FALSE;
	//track[id].detectID = -1;
	track[id].detectID = 0;	//20190406

	nTrack--;
}

void mKCF_Track::generate_prob_out(dg_complex *Y)
{
	Mat image(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
	CvPoint2D32f center;
	float band_width2 = (float)(TRACK_LEARNING_WIDTH*TRACK_LEARNING_HEIGHT) / 256;
	center.x = (TRACK_LEARNING_WIDTH) / 2.;
	center.y = (TRACK_LEARNING_HEIGHT) / 2.;
	for (int y = 0; y < TRACK_LEARNING_HEIGHT; y++)
	{
		float *value = image.ptr<float>(y);
		for (int x = 0; x < TRACK_LEARNING_WIDTH; x++)
		{
			value[x] = exp(-((center.x - x)*(center.x - x) + (center.y - y)*(center.y - y)) / band_width2);
		}
	}
	mat_to_complex(image, Y);
#ifdef _2D_FFT_USE
	_fft2D(Y, image.cols, image.rows, FFT_FORWARD_MOT);
	//_fft(Y, FFT_POINT, FFT_FORWARD);
#else
	fft(Y, FFT_POINT);
#endif
}

void mKCF_Track::generate_Hann_filter(Mat &filter)
{
	int n_pixel = filter.rows * filter.cols;
	for (int y = 0; y < filter.rows; y++)
	{
		float *pixel = filter.ptr<float>(y);
		for (int x = 0; x < filter.cols; x++)
		{
			//pixel[x] = sin(CV_PI*x/(filter.cols-1))*sin(CV_PI*y/(filter.rows-1));
			//pixel[x] = 0.5 - 0.5 * cos (2*CV_PI*x/filter.cols);
			pixel[x] = 0.25 * (1 - cos(2 * CV_PI*x / (filter.cols - 1))) * (1 - cos(2 * CV_PI*y / (filter.rows - 1)));
		}
	}
}

void mKCF_Track::train_kernel_alpha(Mat *image, Mat &hann_filter, Rect src_roi, dg_complex *Y, bool init, dg_complex *ALPHA, Mat *ch_roi)
{
	Mat resize_roi_image;
	Mat periodic_roi_img(TRACK_SAMPLE_HEIGHT, TRACK_SAMPLE_WIDTH, CV_32FC1);
	Mat *pooling_img = new Mat[KCF_TRACK_CHANNEL];
	Mat k(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
	dg_complex *C_ALPHA = new dg_complex[FFT_POINT];
	int n_gm_channel;
#ifdef GM_CHANNEL
	n_gm_channel = 1;
#else
	n_gm_channel = 0;
#endif

	for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
	{
		pooling_img[ch].create(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
		get_searching_roi(image[ch], src_roi, resize_roi_image, TRACK_SEARCHING_SCALE);
//		if (ch >= n_gm_channel)
		{
			resize_roi_image = resize_roi_image - 0.5;
		}
		periodic_roi_img = resize_roi_image.mul(hann_filter);
		pooling_block(periodic_roi_img, pooling_img[ch], TRACK_CELL_WIDTH, TRACK_CELL_HEIGHT, "average_pooling");
	}
	get_gaussian_correlation(pooling_img, pooling_img, k);
	get_kernel_alpha(k, Y, C_ALPHA);

#if 0
	Mat disp_image1;
	convertScaleAbs(k, disp_image1, 255, 0);
	imshow("output_image1", disp_image1);
	cvWaitKey(0);
#endif

	for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
	{
		if (init)
		{
			ch_roi[ch] = pooling_img[ch].clone();
			memcpy(ALPHA, C_ALPHA, sizeof(dg_complex)*FFT_POINT);
		}
		else
		{
			ch_roi[ch] = (1.0 - FILTER_LEARNING_RATE) * ch_roi[ch] + FILTER_LEARNING_RATE * pooling_img[ch];
			alpha_update(C_ALPHA, ALPHA, FFT_POINT, FILTER_LEARNING_RATE);
		}
	}

	delete[] C_ALPHA;
	delete[] pooling_img;
}

void mKCF_Track::alpha_update(dg_complex *C_ALPHA, dg_complex *U_ALPHA, int n_point, float update_rate)
{
	for (int k = 0; k < n_point; k++)
	{
		U_ALPHA[k].Im = update_rate * C_ALPHA[k].Im + (1 - update_rate) * U_ALPHA[k].Im;
		U_ALPHA[k].Re = update_rate * C_ALPHA[k].Re + (1 - update_rate) * U_ALPHA[k].Re;
		//printf("%d) re = %f im = %f\n", k, C_ALPHA[k].Re, C_ALPHA[k].Im);
	}
}

void mKCF_Track::get_gaussian_correlation(Mat *x1, Mat *x2, Mat &k)
{
	dg_complex *X1 = new dg_complex[FFT_POINT];
	dg_complex *X2 = new dg_complex[FFT_POINT];
	dg_complex *X1_X2 = new dg_complex[FFT_POINT];
	dg_complex *SUM_X1_X2 = new dg_complex[FFT_POINT];
	float sum_x1_2 = 0, sum_x2_2 = 0;

	Mat sum_x1_x2(x1[0].rows, x1[0].cols, CV_32FC1, Scalar(0));
	Mat d(x1[0].rows, x1[0].cols, CV_32FC1);
	float sigma = 0.2;

	for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
	{
		sum_x1_2 += sum(x1[ch].mul(x1[ch]))[0];
		sum_x2_2 += sum(x2[ch].mul(x2[ch]))[0];

		mat_to_complex(x1[ch], X1);
		mat_to_complex(x2[ch], X2);
#ifdef _2D_FFT_USE
		_fft2D(X1, x1[0].cols, x1[0].rows, FFT_FORWARD_MOT);
		_fft2D(X2, x2[0].cols, x2[0].rows, FFT_FORWARD_MOT);
		//_fft(X1, FFT_POINT, FFT_FORWARD);
		//_fft(X2, FFT_POINT, FFT_FORWARD);
#else
		fft(X1, FFT_POINT);
		fft(X2, FFT_POINT);
#endif
		complex_conjugate_vector(X1, FFT_POINT, X1);
		complex_multiplier_vector(X1, X2, FFT_POINT, X1_X2);
		if (ch == 0)
		{
			memcpy(SUM_X1_X2, X1_X2, sizeof(dg_complex)*FFT_POINT);
		}
		else
		{
			for (int p = 0; p < FFT_POINT; p++)
			{
				SUM_X1_X2[p].Im += X1_X2[p].Im;
				SUM_X1_X2[p].Re += X1_X2[p].Re;
			}
		}
	}
#ifdef _2D_FFT_USE
	_fft2D(SUM_X1_X2, x1[0].cols, x1[0].rows, FFT_BACKWARD);
#else
	ifft(SUM_X1_X2, FFT_POINT);
#endif
	complex_to_mat(SUM_X1_X2, FFT_POINT, sum_x1_x2);
	//rearrange(sum_x1_x2);

	max(((sum_x1_2 + sum_x2_2) - 2. * sum_x1_x2) / (x1[0].rows * x1[0].cols), 0, d);
	exp((-d / (sigma * sigma)), k);

	delete[] SUM_X1_X2;
	delete[] X1;
	delete[] X2;
	delete[] X1_X2;
	}

void mKCF_Track::get_searching_roi(Mat &image, Rect src_roi, Mat &resize_roi_image, float searching_scale)
{
	Mat roi_image;
	Mat roi_padding_image;
	bool b_padding = FALSE;

	int img_width = image.cols;
	int img_height = image.rows;
	CvPoint lt_pt, rb_pt;
	int left_border = 0, right_border = 0, up_border = 0, down_border = 0;
	float searching_margin = (searching_scale - 1) / 2.0;

	get_candidate_region(image, src_roi, searching_margin, lt_pt, rb_pt);
	if (lt_pt.x < 0)
	{
		left_border = -lt_pt.x;
		lt_pt.x = 0;
		b_padding = TRUE;
	}
	if (lt_pt.y < 0)
	{
		up_border = -lt_pt.y;
		lt_pt.y = 0;
		b_padding = TRUE;
	}

	if (rb_pt.x >= img_width)
	{
		right_border = rb_pt.x - img_width + 1;
		rb_pt.x = img_width - 1;
		b_padding = TRUE;
	}

	if (rb_pt.y >= img_height)
	{
		down_border = rb_pt.y - img_height + 1;
		rb_pt.y = img_height - 1;
		b_padding = TRUE;
	}
	Rect searching_region;
	searching_region.x = lt_pt.x;
	searching_region.y = lt_pt.y;
	searching_region.width = rb_pt.x - lt_pt.x + 1;
	searching_region.height = rb_pt.y - lt_pt.y + 1;
	roi_image = image(searching_region);
	if (b_padding == FALSE)
	{
		roi_padding_image = image(searching_region);
	}
	else
	{
		roi_image = image(searching_region);
		copyMakeBorder(roi_image, roi_padding_image, up_border, down_border, left_border, right_border, BORDER_REPLICATE);
	}

	//why error
	if(roi_padding_image.data)
		resize(roi_padding_image, resize_roi_image, Size(TRACK_SAMPLE_WIDTH, TRACK_SAMPLE_HEIGHT));
}

void mKCF_Track::get_candidate_region(Mat &src_image, Rect src_roi, float factor, CvPoint &lt_pt, CvPoint &rb_pt)
{
	lt_pt.x = src_roi.x - src_roi.width*factor;
	lt_pt.y = src_roi.y - src_roi.height*factor;

	rb_pt.x = src_roi.x + src_roi.width - 1 + src_roi.width*factor;
	rb_pt.y = src_roi.y + src_roi.height - 1 + src_roi.height*factor;
}

void mKCF_Track::get_kernel_alpha(Mat &k, dg_complex *Y, dg_complex *A)
{
	dg_complex *K = new dg_complex[FFT_POINT];
	mat_to_complex(k, K);
#ifdef _2D_FFT_USE
	_fft2D(K, k.cols, k.rows, FFT_FORWARD_MOT);
	//_fft(K, FFT_POINT, FFT_FORWARD);
#else
	fft(K, FFT_POINT);
#endif
	complex_division_vector(Y, K, FFT_POINT, A);

	delete[] K;
}


#define N_SCALE_STEP   1
float mKCF_Track::predict_roi(Rect src_roi, int tr_id, Rect &dst_roi)
{

#if N_SCALE_STEP == 1
	float score;
	Rect tmp_roi;
	tmp_roi = src_roi;
	score = get_kernel_correlation_out(channel_image, Hann_filter, ALPHA[tr_id], channel_roi_img[tr_id], Y, tmp_roi);

	dst_roi = tmp_roi;

	return score;

#else

	float score[N_SCALE_STEP];
	Rect multi_scale_roi[N_SCALE_STEP];
	float multi_scale_factor[N_SCALE_STEP] = { 0.9, 1.0, 1.1 };
	float multi_scale_prior[N_SCALE_STEP] = { 0.95, 1.0, 0.95 };
	get_kernel_correlation_out(channel_image, Hann_filter, ALPHA[tr_id], channel_roi_img[tr_id], Y, src_roi);
	get_multi_scale_roi(src_roi, multi_scale_roi, multi_scale_factor, N_SCALE_STEP);

	float max_score = -1.0;
	int max_score_id = 0;
	for (int scale_step = 0; scale_step < N_SCALE_STEP; scale_step++)
	{
		score[scale_step] = multi_scale_prior[scale_step] * get_kernel_correlation_out(channel_image, Hann_filter, ALPHA[tr_id], channel_roi_img[tr_id], Y, multi_scale_roi[scale_step]);
		if (score[scale_step] > max_score)
		{
			max_score = score[scale_step];
			max_score_id = scale_step;
		}

		//		printf("score[%d] = %f\n", scale_step, score[scale_step]);
	}

	dst_roi = multi_scale_roi[max_score_id];

	return max_score;

#endif
}





void mKCF_Track::get_multi_scale_roi(Rect src_roi, Rect *multi_scale_roi, float *multi_scale_factor, int n_multi_roi)
{
	CvPoint2D32f cent_point;
	cent_point.x = src_roi.x + src_roi.width / 2.0;
	cent_point.y = src_roi.y + src_roi.height / 2.0;
	float f_width, f_height;
	for (int sc = 0; sc < n_multi_roi; sc++)
	{
		f_width = src_roi.width * multi_scale_factor[sc];
		f_height = src_roi.height * multi_scale_factor[sc];
		//¹Ý¿Ã¸²
		multi_scale_roi[sc].x = cent_point.x - f_width / 2 + 0.5;
		multi_scale_roi[sc].y = cent_point.y - f_height / 2 + 0.5;
		multi_scale_roi[sc].width = f_width + 0.5;
		multi_scale_roi[sc].height = f_height + 0.5;
	}
}

float mKCF_Track::get_kernel_correlation_out(Mat *image, Mat &hann_filter, dg_complex *ALPHA, Mat *ch_roi_image, dg_complex *Y, Rect &roi)
{
	Mat resize_roi_image;
	Mat periodic_roi_img(TRACK_SAMPLE_HEIGHT, TRACK_SAMPLE_WIDTH, CV_32FC1);
	Mat *pooling_img = new Mat[KCF_TRACK_CHANNEL];
	Mat k(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
	Mat prob_map(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
	int n_gm_channel;
#ifdef GM_CHANNEL
	n_gm_channel = 1;
#else
	n_gm_channel = 0;
#endif

	for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
	{
		pooling_img[ch].create(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
		get_searching_roi(image[ch], roi, resize_roi_image, TRACK_SEARCHING_SCALE);
//		if (ch >= n_gm_channel)
		{
			resize_roi_image = resize_roi_image - 0.5;
		}
		if (resize_roi_image.data)
			periodic_roi_img = resize_roi_image.mul(hann_filter);
		pooling_block(periodic_roi_img, pooling_img[ch], TRACK_CELL_WIDTH, TRACK_CELL_HEIGHT, "average_pooling");

#if 0
		cv::Mat disp_image1, disp_image2, disp_image3, disp_image4;
		convertScaleAbs(ch_roi_image[ch], disp_image1, 255, 0);
		convertScaleAbs(resize_roi_image, disp_image2, 255, 0);
		convertScaleAbs(periodic_roi_img, disp_image3, 255, 0);
		convertScaleAbs(pooling_img[ch], disp_image4, 255, 0);

		imshow("output_image1", disp_image1);
		imshow("output_image2", disp_image2);
		imshow("output_image3", disp_image3);
		imshow("output_image4", disp_image3);

		cvWaitKey(0);
#endif
	}
	get_gaussian_correlation(ch_roi_image, pooling_img, k);

	get_prob_out_map(k, ALPHA, prob_map);

#if 0
	cv::Mat disp_image1, disp_image2;
	convertScaleAbs(k, disp_image1, 255, 0);
	convertScaleAbs(prob_map, disp_image2, 255, 0);

	imshow("output_image1", disp_image1);
	imshow("output_image2", disp_image2);

	cvWaitKey(0);

#endif

	CvPoint2D32f max_peak;
	float max_value;
	max_peak.x = TRACK_LEARNING_WIDTH / 2;
	max_peak.y = TRACK_LEARNING_HEIGHT / 2;
	max_value = 0.0;

	get_max_peak_and_value(prob_map, max_peak, max_value);
	Rect src_roi = roi;
	get_roi_from_peak(max_peak, src_roi, roi);

	delete[] pooling_img;

	return max_value;
}

void mKCF_Track::get_prob_out_map(Mat &k, dg_complex *A, Mat &prob_map)
{
	dg_complex *K = new dg_complex[FFT_POINT];
	dg_complex *G = new dg_complex[FFT_POINT];

	mat_to_complex(k, K);
#ifdef _2D_FFT_USE
	_fft2D(K, k.cols, k.rows, FFT_FORWARD_MOT);
	//_fft(K, FFT_POINT, FFT_FORWARD);
#else
	fft(K, FFT_POINT);
#endif
	complex_multiplier_vector(K, A, FFT_POINT, G);
#ifdef _2D_FFT_USE
	_fft2D(G, k.cols, k.rows, FFT_BACKWARD);
	//_fft(G, FFT_POINT, FFT_BACKWARD);
#else
	ifft(G, FFT_POINT);
#endif
	complex_to_mat(G, FFT_POINT, prob_map);

	delete[] K;
	delete[] G;
}

bool mKCF_Track::get_max_peak_and_value(Mat &prob_map, CvPoint2D32f &max_peak, float &max_value)
{
	for (int y = 0; y < TRACK_LEARNING_HEIGHT; y++)
	{
		float *value = prob_map.ptr<float>(y);
		for (int x = 0; x < TRACK_LEARNING_WIDTH; x++)
		{
			if (value[x] > max_value)
			{
				max_value = value[x];
				max_peak.x = (float)x;
				max_peak.y = (float)y;
			}
			//if (((x==31) && (y==31)) || ((x==31) && (y==32)) || ((x==31) && (y==33)) || ((x==32) && (y==31)) || ((x==32) && (y==32)) || ((x==32) && (y==33)) || ((x==33) && (y==31)) || ((x==33) && (y==32)) || ((x==33) && (y==33)))
			//printf("(%d %d) = %f\n", x, y, value[x]);
		}
	}

	return TRUE;
}

void mKCF_Track::get_roi_from_peak(CvPoint2D32f peak, Rect src_roi, Rect &dst_roi)
{
	CvPoint2D32f center, roi_center;
	float resize_factor_x = (float)src_roi.width*TRACK_SEARCHING_SCALE / TRACK_SAMPLE_WIDTH;
	float resize_factor_y = (float)src_roi.height*TRACK_SEARCHING_SCALE / TRACK_SAMPLE_HEIGHT;

	center.x = peak.x*TRACK_CELL_WIDTH*resize_factor_x;
	center.y = peak.y*TRACK_CELL_HEIGHT*resize_factor_y;

	roi_center.x = center.x - (TRACK_SEARCHING_SCALE - 1)*src_roi.width / 2.0;
	roi_center.y = center.y - (TRACK_SEARCHING_SCALE - 1)*src_roi.height / 2.0;

	dst_roi.x = roi_center.x - (float)(src_roi.width) / 2.0 + src_roi.x + 0.5;
	dst_roi.y = roi_center.y - (float)(src_roi.height) / 2.0 + src_roi.y + 0.5;

	dst_roi.width = src_roi.width;
	dst_roi.height = src_roi.height;
	//printf("x = %f, y = %f \n", center.x, center.y);
}

void roi_score_probability(vector<float> &roi_score, float MIN_SCOREscore_sum)
{
#if 0
	float quarter_max_score = score_sum / 4;
	float hit_threshold_score = abs(DT_HIT_THRESHOLD);
	for (int id = 0; id < (int)roi_score.size(); id++)
	{
		//		printf("1) roi_score[%d] = %f \n", id, roi_score[id]);
		roi_score[id] = MIN(MAX(0.0, (hit_threshold_score + roi_score[id]) / quarter_max_score), 1.0);
		//		printf("2) roi_score[%d] = %f \n", id, roi_score[id]);
}
#else

	return;

	int max_score = DETECT_SCORE_HIGH;
	int min_score = DETECT_SCORE_LOW;
	float score_bias = 0.5;

	for (int id = 0; id < (int)roi_score.size(); id++)
	{
		if (roi_score[id] > 0)
		{
			roi_score[id] = score_bias + (1 - score_bias) * MIN(1.0, roi_score[id] / max_score);
		}
		else
		{
			roi_score[id] = score_bias - score_bias * MIN(1.0, roi_score[id] / min_score);
		}

		//		printf("2) norm_score = %f roi_score[%d] = %f \n", norm_score, id, roi_score[id]);
	}

#endif
}

Rect convert_rectf_to_rect(Rect_f rect_f)
{
	Rect rect;
//	rect.x = rect_f.x + 0.5;
//	rect.y = rect_f.y + 0.5;
//	rect.width = rect_f.width + 0.5;
//	rect.height = rect_f.height + 0.5;

	//20190406 young. Be careful not to exceed the maximum width or height.
	rect.x = rect_f.x;
	rect.y = rect_f.y;
	rect.width = rect_f.width;
	rect.height = rect_f.height;

	return rect;
}

Rect_f convert_rect_to_rect_f(Rect rect)
{
	Rect_f rect_f;
	rect_f.x = rect.x;
	rect_f.y = rect.y;
	rect_f.width = rect.width;
	rect_f.height = rect.height;

	return rect_f;
}

void get_track_channel_image(Mat &image, Mat *ch_image, st_feature &feature)
{
	int n_bin = feature.n_bin;
	int n_grad_channel = feature.n_bin + feature.n_grad_mag;
	int n_channel = feature.n_channel;

	for (int k = 0; k < TRACK_CHANNEL; k++)
	{
		ch_image[k].create(image.rows, image.cols, CV_32F);
		ch_image[k].setTo(Scalar(0.0));
	}

	if (feature.use_color_channel)
	{
#if YCBCR444
		if (image.type() == CV_32FC3)
		{
			yc_to_ch_image_32F(image, &ch_image[TRACK_CHANNEL - 3]);
		}
		else if (image.type() == CV_8UC3)
		{
			yc_to_ch_image(image, &ch_image[TRACK_CHANNEL - 3]);
		}
		else
		{
			printf("Áö¿øÇÏÁö ¾Ê´Â ÄÃ·¯ Æ÷¸ËÀÔ´Ï´Ù.!!!!!!!!!\n");
	}
#else
		_luv_to_ch_image(image, &ch_image[TRACK_CHANNEL - 3]);
#endif
}
	else
		image.convertTo(ch_image[TRACK_CHANNEL - 1], CV_32FC1);

#ifdef GM_CHANNEL
	if (feature.use_color_channel)
	{
		Mat grad_image, mag_image;
		grad_image.create(image.rows, image.cols, CV_32F);
		mag_image = ch_image[0];

		Mat grad_image_tmp[3], mag_image_tmp[3];
		for (int ch = 0; ch < 3; ch++)
		{
			grad_image_tmp[ch].create(image.rows, image.cols, CV_32F);
			mag_image_tmp[ch].create(image.rows, image.cols, CV_32F);
			get_mag_grad_image(ch_image[ch + 1], grad_image_tmp[ch], mag_image_tmp[ch]);
		}

		max_mag_grad_image(grad_image_tmp, mag_image_tmp, grad_image, mag_image);
	}
	else
	{
		Mat grad_image, mag_image;
		grad_image.create(image.rows, image.cols, CV_32F);
		mag_image = ch_image[0];
		get_mag_grad_image(ch_image[1], grad_image, mag_image);
	}
#endif

	for (int ch = 0; ch < TRACK_CHANNEL; ch++)
	{
		double min_value, max_value;
		minMaxLoc(ch_image[ch], &min_value, &max_value);
		ch_image[ch] /= max_value;
	}
}


void cl_tracking::write_track_result(FILE *eval_fp, int frame_id)
{
	for (int i = 0; i < nMapping; i++)
	{
		int track_id = mapping[i];
		if ((track[track_id].state == TRACK_NULL) || (track[track_id].state == TRACK_INIT))
			continue;

		CvRect rectTmp;
		rectTmp.x = (int)track[track_id].f_prevROI.x;
		rectTmp.y = (int)track[track_id].f_prevROI.y;
		rectTmp.width = (int)track[track_id].f_prevROI.width;
		rectTmp.height = (int)track[track_id].f_prevROI.height;

		track_id += 1;  //1ºÎÅÍ id¸¦ ÀúÀåÇÏ±â À§ÇØ¼­..for matlab evaluation

		fprintf(eval_fp, "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", frame_id, track_id, rectTmp.x, rectTmp.y, rectTmp.width, rectTmp.height, 1, -1, -1, -1);
	}
}

int get_current_data_time(char *buff, char *type)
{
	std::time_t rawtime;
	std::tm* timeinfo;
	std::time(&rawtime);
	int result = 0;

	timeinfo = std::localtime(&rawtime);
	std::strftime(buff, 80, "%Y%m%d%H%M%S", timeinfo);
//	printf("11111111111)%d\n", timeinfo->tm_sec);
	if (strcmp(type, "M") == 0)
	{
		result = timeinfo->tm_sec;
	}
	if (strcmp(type, "H") == 0)
	{
		result = timeinfo->tm_min;
	}
	if (strcmp(type, "D") == 0)
	{
		result = timeinfo->tm_hour;
	}

	return result;
}


int Osan_get_current_data_time(char *buff, char *type)
{
	std::time_t rawtime;
	std::tm* timeinfo;
	std::time(&rawtime);
	int result = 0;

	timeinfo = std::localtime(&rawtime);
	std::strftime(buff, 80, "%Y.%m.%d %H:%M:%S", timeinfo);
	//	printf("11111111111)%d\n", timeinfo->tm_sec);
	if (strcmp(type, "M") == 0)
	{
		result = timeinfo->tm_sec;
	}
	if (strcmp(type, "H") == 0)
	{
		result = timeinfo->tm_min;
	}
	if (strcmp(type, "D") == 0)
	{
		result = timeinfo->tm_hour;
	}

	return result;
}


