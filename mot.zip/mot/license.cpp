#define _CRT_SECURE_NO_WARNINGS
#define _WIN32_DCOM

#include "license.h"
#include <string>
#include <ctime>
#include <fstream>
#include <iostream>
#include <comdef.h>
#include <vector>
#include <Wbemidl.h>
#pragma comment(lib, "wbemuuid.lib") //file link
//#pragma comment(lib, "cryptlib.lib")
#pragma comment(lib, "cryptlib_MD.lib")
#include "cryptlib.h"
#include "modes.h"
#include "aes.h"
#include "filters.h"
#include "base64.h"



typedef unsigned int uint;
using namespace std;


enum class WmiQueryError {
	None,
	BadQueryFailure,
	PropertyExtractionFailure,
	ComInitializationFailure,
	SecurityInitializationFailure,
	IWbemLocatorFailure,
	IWbemServiceConnectionFailure,
	BlanketProxySetFailure,
};

struct WmiQueryResult
{
	std::vector<std::wstring> ResultList;
	WmiQueryError Error = WmiQueryError::None;
	std::wstring ErrorDescription;
};



void hex2byte(const char *in, uint len, byte *out)
{
	for (uint i = 0; i < len; i += 2) {
		char c0 = in[i + 0];
		char c1 = in[i + 1];
		byte c = (
			((c0 & 0x40 ? (c0 & 0x20 ? c0 - 0x57 : c0 - 0x37) : c0 - 0x30) << 4) |
			((c1 & 0x40 ? (c1 & 0x20 ? c1 - 0x57 : c1 - 0x37) : c1 - 0x30))
			);
		out[i / 2] = c;
	}
	//std::cout << "out : " << out << std::endl;
}

char* timeToString(struct tm *t) {
	static char s[20];

	sprintf_s(s, "%04d%02d%02d%02d%02d%02d",
		t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
		t->tm_hour, t->tm_min, t->tm_sec
	);

	return s;
}

string getCurrentTime() {
	string current_time;

	time_t curr_time;
	struct tm *curr_tm;

	curr_time = time(NULL);
	curr_tm = localtime(&curr_time);

	current_time = timeToString(curr_tm);
	return current_time;
}

string fileRead() {
	char currentPath[MAX_PATH], filename[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, currentPath);
	wsprintf(filename, "%s\\License.ini", currentPath);
	//string filename = "License.ini"; //license path
	string readtext;
	ifstream in(filename);

	if (in.is_open()) {
		getline(in, readtext);
	}
	else {
		cout << "Licence Key Read Fail. Check Your Licence Key File" << endl;
		exit(0);
	}

	return readtext;
}

WmiQueryResult getWmiQueryResult(std::wstring wmiQuery, std::wstring propNameOfResultObject, bool allowEmptyItems = false) {
	WmiQueryResult retVal;
	retVal.Error = WmiQueryError::None;
	retVal.ErrorDescription = L"";

	HRESULT hres;


	IWbemLocator *pLoc = NULL;
	IWbemServices *pSvc = NULL;
	IEnumWbemClassObject* pEnumerator = NULL;
	IWbemClassObject *pclsObj = NULL;
	VARIANT vtProp;


	// 1. init

	hres = CoInitializeEx(0, COINIT_MULTITHREADED);
	if (FAILED(hres))
	{
		retVal.Error = WmiQueryError::ComInitializationFailure;
		retVal.ErrorDescription = L"Failed to initialize COM library. Error code : " + std::to_wstring(hres);
	}
	else
	{
		// 2. Set general COM security level

		hres = CoInitializeSecurity(
			NULL,
			-1,                          // COM authentication
			NULL,                        // Authentication services
			NULL,                        // Reserved
			RPC_C_AUTHN_LEVEL_DEFAULT,   // Default authentication 
			RPC_C_IMP_LEVEL_IMPERSONATE, // Default Impersonation  
			NULL,                        // Authentication info
			EOAC_NONE,                   // Additional capabilities 
			NULL                         // Reserved
		);


		if (FAILED(hres))
		{
			retVal.Error = WmiQueryError::SecurityInitializationFailure;
			retVal.ErrorDescription = L"Failed to initialize security. Error code : " + std::to_wstring(hres);
		}
		else
		{
			// 3. Getting the initial locator for WMI
			pLoc = NULL;

			hres = CoCreateInstance(
				CLSID_WbemLocator,
				0,
				CLSCTX_INPROC_SERVER,
				IID_IWbemLocator, (LPVOID *)&pLoc);

			if (FAILED(hres))
			{
				retVal.Error = WmiQueryError::IWbemLocatorFailure;
				retVal.ErrorDescription = L"Failed to create IWbemLocator object. Error code : " + std::to_wstring(hres);
			}
			else
			{
				// 4. Connect to WMI through the IWbemLocator :: ConnectServer method

				pSvc = NULL;

				//root\cimv2 namespace connect , IWbemServices call with user pSvc get pointer

				hres = pLoc->ConnectServer(
					_bstr_t(L"ROOT\\CIMV2"), // Object path of WMI namespace
					NULL,                    // User name. NULL = current user
					NULL,                    // User password. NULL = current
					0,                       // Locale. NULL indicates current
					NULL,                    // Security flags.
					0,                       // Authority (for example, Kerberos)
					0,                       // Context object 
					&pSvc                    // pointer to IWbemServices proxy
				);

				// root\\cimv2 namespace connect

				if (FAILED(hres))
				{
					retVal.Error = WmiQueryError::IWbemServiceConnectionFailure;
					retVal.ErrorDescription = L"Could not connect to Wbem service.. Error code : " + std::to_wstring(hres);
				}
				else
				{
					// 5. Set security on the proxy

					hres = CoSetProxyBlanket(
						pSvc,                        // Indicates the proxy to set
						RPC_C_AUTHN_WINNT,           // RPC_C_AUTHN_xxx
						RPC_C_AUTHZ_NONE,            // RPC_C_AUTHZ_xxx
						NULL,                        // Server principal name 
						RPC_C_AUTHN_LEVEL_CALL,      // RPC_C_AUTHN_LEVEL_xxx 
						RPC_C_IMP_LEVEL_IMPERSONATE, // RPC_C_IMP_LEVEL_xxx
						NULL,                        // client identity
						EOAC_NONE                    // proxy capabilities 
					);

					if (FAILED(hres))
					{
						retVal.Error = WmiQueryError::BlanketProxySetFailure;
						retVal.ErrorDescription = L"Could not set proxy blanket. Error code : " + std::to_wstring(hres);
					}
					else
					{
						// 6. WMI request using the IWbemServices pointer

						// Get the hard disk serial number.
						pEnumerator = NULL;
						hres = pSvc->ExecQuery(
							bstr_t("WQL"),
							bstr_t(wmiQuery.c_str()),
							WBEM_FLAG_FORWARD_ONLY | WBEM_FLAG_RETURN_IMMEDIATELY,
							NULL,
							&pEnumerator);

						if (FAILED(hres))
						{
							retVal.Error = WmiQueryError::BadQueryFailure;
							retVal.ErrorDescription = L"Bad query. Error code : " + std::to_wstring(hres);
						}
						else
						{
							// 7. Import query data from step 6

							pclsObj = NULL;
							ULONG uReturn = 0;

							while (pEnumerator)
							{
								HRESULT hr = pEnumerator->Next(WBEM_INFINITE, 1,
									&pclsObj, &uReturn);

								if (0 == uReturn)
								{
									break;
								}

								// VARIANT vtProp;

								// Gets the value of the desired property (propNameOfResultObject).
								hr = pclsObj->Get(propNameOfResultObject.c_str(), 0, &vtProp, 0, 0);
								if (S_OK != hr) {
									retVal.Error = WmiQueryError::PropertyExtractionFailure;
									retVal.ErrorDescription = L"Couldn't extract property: " + propNameOfResultObject + L" from result of query. Error code : " + std::to_wstring(hr);
								}
								else {
									BSTR val = vtProp.bstrVal;

									// Sometimes val might be NULL even when result is S_OK
									// Convert NULL to empty string (otherwise "std::wstring(val)" would throw exception)
									if (NULL == val) {
										if (allowEmptyItems) {
											retVal.ResultList.push_back(std::wstring(L""));
										}
									}
									else {
										retVal.ResultList.push_back(std::wstring(val));
									}
								}
							}
						}
					}
				}
			}
		}
	}

	// Cleanup
	// ========

	VariantClear(&vtProp);
	if (pclsObj)
		pclsObj->Release();

	if (pSvc)
		pSvc->Release();

	if (pLoc)
		pLoc->Release();

	if (pEnumerator)
		pEnumerator->Release();

	CoUninitialize();

	return retVal;
}

string WMI() {
	string result = "";
	WmiQueryResult res;
	wstring query = L"SELECT SerialNumber FROM Win32_PhysicalMedia WHERE Tag LIKE \"%PHYSICALDRIVE0%\"";
	wstring propNameOfResultObject = L"SerialNumber";

	res = getWmiQueryResult(query, propNameOfResultObject);
	if (res.Error != WmiQueryError::None) {
		//std::wcout << "Got this error while executing query: " << std::endl;
		//std::wcout << res.ErrorDescription << std::endl;
		return 0; // Exitting function
	}
	for (const auto& item : res.ResultList) {
		//std::wcout << item << std::endl;
		result.assign(item.begin(), item.end());
		//std::cout << str << std::endl;
	}

	return result;
}

string AES256_Decryption(string text) {
	string sn = WMI();
	//key set
	byte key[CryptoPP::AES::DEFAULT_KEYLENGTH];
	memset(key, 0x00, CryptoPP::AES::DEFAULT_KEYLENGTH);
	string rawKey = sn + "unisemunisem";
	hex2byte(rawKey.c_str(), strlen(rawKey.c_str()), key);

	// Initial Vector Allocation
	byte iv[CryptoPP::AES::BLOCKSIZE];
	memset(iv, 0x00, CryptoPP::AES::BLOCKSIZE);
	string rawIv = sn + "yellowpencil";
	//std::cout << "rawlv ���� : " << rawIv.length() << std::endl;
	hex2byte(rawIv.c_str(), strlen(rawIv.c_str()), iv);

	string base64decryptedciphertext;
	string decryptedtext;
	string base64encodedciphertext = text;
	// Base64 decode
	

	CryptoPP::StringSource(base64encodedciphertext, true,
		new CryptoPP::Base64Decoder(
			new CryptoPP::StringSink(base64decryptedciphertext)
		) // Base64Encoder
	); // StringSource

	   // AES Decryption
	CryptoPP::AES::Decryption aesDecryption(key,
		CryptoPP::AES::DEFAULT_KEYLENGTH);
	CryptoPP::CBC_Mode_ExternalCipher::Decryption
		cbcDecryption(aesDecryption, iv);

	CryptoPP::StreamTransformationFilter
		stfDecryptor(cbcDecryption, new CryptoPP::StringSink(decryptedtext));
	//stfDecryptor.Put(reinterpret_cast<const unsigned = "" char *= "">
	stfDecryptor.Put(reinterpret_cast<const unsigned char *>
		(base64decryptedciphertext.c_str()), base64decryptedciphertext.size());
	try {
		stfDecryptor.MessageEnd();
	}
	catch(CryptoPP::Exception e) {
	}
	return decryptedtext;
}

bool LicenseCheck(string cL) {

	if (cL.size() != 32) {
		return false;
	}
	if ((cL.substr(0, 6).compare("unisem") == 0)& (cL.substr(22, 10).compare("bluepencil") == 0)) {
		return true;
	}
	return false;
}

bool LicenseTimeCheck(string aD, string cD) {
	int aD_day = atoi(aD.substr(0, 8).c_str());
	int cD_day = atoi(cD.substr(0, 8).c_str());

	int aD_time = atoi(aD.substr(8).c_str());
	int cD_time = atoi(cD.substr(8).c_str());

	if (aD_day < cD_day) {
		return FALSE;
	}
	else {
		if (aD_day == cD_day) {
			if (aD_time >= cD_time) {
				return TRUE;
			}
			else {
				return FALSE;
			}
		}
		else {
			return TRUE;
		}
	}
}

