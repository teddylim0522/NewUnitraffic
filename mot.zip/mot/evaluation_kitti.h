#include <string>
#include <vector>
#include <io.h>
#include <math.h>
#include <direct.h>
#include <algorithm> //�ø���������
#include <functional> //������������
#include <numeric>

#include "darknet.h"
#include "argv.h"

#include "opencv2/highgui/highgui_c.h"
#include "opencv2/imgproc/imgproc_c.h"
#include "opencv2/core/version.hpp"

//#include <assert.h>
using namespace std;

#define CHAR_LENGTH 255

struct Rect_f
{
	float x;
	float y;
	float width;
	float height;

	Rect_f()
	{
		x = 0;
		y = 0;
		width = 0;
		height = 0;
	}
	Rect_f(float x_, float y_, float width_, float height_)
	{
		x = x_;
		y = y_;
		width = width_;
		height = height_;
	}

	void clear()
	{
		x = (float)0;
		y = (float)0;
		width = (float)0;
		height = (float)0;
	}
};

//easy, moderate and hard evaluation level
enum DIFFICULTY { EASY = 0, MODERATE = 1, HARD = 2 };

//evaluated object classes
enum CLASSES { CAR_ = 0, PEDESTRIAN_ = 1, CYCLIST_ = 2 };

struct tPrData
{
	vector<double> v; //detection score for computing score thresholds
	double similarity; //orientation similarity
	int tp; //true positives
	int fp; //false positives
	int fn; //false negatives
	tPrData() :
		similarity(0), tp(0), fp(0), fn(0) {}
};

struct tBox
{
	string type; //object type as car, pedestrian or cyclist,...
	double x1; //left corner
	double y1; //top corner
	double x2; //right corner
	double y2; //bottom corner
	double alpha; //image orientation
	tBox(string type, double x1, double y1, double x2, double y2, double alpha) :
		type(type), x1(x1), y1(y1), x2(x2), y2(y2), alpha(alpha) {}
};

struct tGroundtruth
{
	tBox box; //object type, box, orientation
	double truncation; //truncation 0..1
	int occlusion; //occlusion 0,1,2 (non, partly, fully)
	tGroundtruth() :
		box(tBox("invalild", -1, -1, -1, -1, -10)), truncation(-1), occlusion(-1) {}
	tGroundtruth(tBox box, double truncation, int occlusion) :
		box(box), truncation(truncation), occlusion(occlusion) {}
	tGroundtruth(string type, double x1, double y1, double x2, double y2, double alpha, double truncation, int occlusion) :
		box(tBox(type, x1, y1, x2, y2, alpha)), truncation(truncation), occlusion(occlusion) {}
};

struct tDetection
{
	tBox box; //object type, box, orientation
	double thresh; //detection score
	tDetection() :
		box(tBox("invalid", -1, -1, -1, -1, -10)), thresh(-1000) {}
	tDetection(tBox box, double thresh) :
		box(box), thresh(thresh) {}
	tDetection(string type, double x1, double y1, double x2, double y2, double alpha, double thresh) :
		box(tBox(type, x1, y1, x2, y2, alpha)), thresh(thresh) {}
};

extern "C" bool eval(char *gt_dir_, char *dt_dir_, char *eval_file_name_, int TEST_IMAGE_START, int TEST_IMAGE_END);
void initGlobals();
vector<tGroundtruth> loadGroundtruth(string file_name, bool &success);
vector<tDetection> loadDetections(string file_name, bool &compute_aos, bool &eval_car, bool &eval_pedestrian, bool &eval_cyclist, bool &success);
bool eval_class(FILE *fp_det, FILE *fp_ori, CLASSES current_class, const vector< vector<tGroundtruth> > &groundtruth, const vector< vector<tDetection> > &detections, bool compute_aos, vector<double> &precision, vector<double> &aos, DIFFICULTY difficulty);
void cleanData(CLASSES current_class, const vector<tGroundtruth> &gt, const vector<tDetection> &det, vector<int> &ignored_gt, vector<tGroundtruth> &dc, vector<int> &ignored_det, int &n_gt, DIFFICULTY difficulty);
tPrData computeStatistics(CLASSES current_class, const vector<tGroundtruth> &gt, const vector<tDetection> &det, const vector<tGroundtruth> &dc, const vector<int> &ignored_gt, const vector<int> &ignored_det, bool compute_fp, bool compute_aos, double thresh, bool debug, int im_cnt);
inline double boxoverlap(tBox a, tBox b, int criterion);
vector<double> getThresholds(vector<double> &v, double n_groundtruth);
void saveStats(const vector<double> &precision, const vector<double> &aos, FILE *fp_det, FILE *fp_ori);
void saveAndPlotPlots(string file_name, vector<double> vals[]);