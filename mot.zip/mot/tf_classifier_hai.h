#pragma once
#define TF_CLASSIFIER_API __declspec(dllimport)

#include <string>
#include <algorithm>
#include "common.h"

//#include <opencv2/core.hpp>

#include "tensorflow/core/public/session.h"
#include "tensorflow/core/protobuf/meta_graph.pb.h"

//const int IMAGE_HEIGHT = 224;
//const int IMAGE_WIDTH = 224;

struct pred_probs_t
{
	bool isFeedforward = false;
	int num_of_class;
	float* probs;						// confidence - probability that the object was found correctly
	int pred_result[4];     // argmax value
	float pred_prob[4];  // argmax prob
};

class Classifier
{
public:
	TF_CLASSIFIER_API Classifier();
	TF_CLASSIFIER_API ~Classifier();
	// TF_CLASSIFIER_API void LoadModel(std::string _model_path, std::string _ini_path, int image_height, int image_width);
	TF_CLASSIFIER_API void LoadModel(std::string _model_path, std::string _ini_path, int nModelType);
	TF_CLASSIFIER_API pred_probs_t Run(const cv::Mat& _input_8UC1);

private:
	TF_CLASSIFIER_API bool _InitSession();
	TF_CLASSIFIER_API bool _ReadProtobufFile(std::string _model_path);
	TF_CLASSIFIER_API bool _InitNodeName(const char* _ini_path);
	TF_CLASSIFIER_API bool _CreateSession();
	TF_CLASSIFIER_API void _MappingInputTensor_Color(const cv::Mat& _input_image_uchar_color);

private:
	// status messege
	std::string _m_status_messege = "";
	tensorflow::Status _m_status;
	bool _m_isInitializeWeights;

	// graph and sesstion
	tensorflow::GraphDef _m_graph_def;
	tensorflow::Session* _m_session;

	// read node name
	std::string _m_input_node_name = "input";
	std::string _m_output_node_name = "InceptionV1/Logits/Predictions/Softmax";

	// inputs and outputs
	tensorflow::Tensor* _m_input_tensor;
	std::vector<std::pair<std::string, tensorflow::Tensor>> _m_feedDict;
	std::vector<tensorflow::Tensor> _m_output_probs;

public:
	int m_nModelType;  // 0: vgg_16; 1: inception_v1; 2: inception_v2; 3:
					   // inception_v3; 4: inception_v4
	int m_nHeight;
	int m_nWidth;
};

