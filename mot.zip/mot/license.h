#pragma once
#define LICENSEDLL_EXPORTS
#ifdef LICENSEDLL_EXPORTS
#define LICENSEDLL_API __declspec(dllexport)
#else
#define LICENSEDLL_API __declspec(dllimport)
#endif


#include <string>
using namespace std;


extern "C" LICENSEDLL_API int CheckKey_MDI(string cryptogram);
extern "C" LICENSEDLL_API int CheckKey_Console(string cryptogram);
extern "C" LICENSEDLL_API string ErrorCodeCheck(int ErrorCode);