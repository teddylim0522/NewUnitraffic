﻿#include "region_seg_layer.h"
#include "utils.h"
#include "cuda.h"
#include "blas.h"
#include "gemm.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

layer make_region_seg_layer(int batch, int w, int h, int classes)
{
	layer l = { 0 };
	l.type = REGION_SEG;

	l.batch = batch;
	l.h = h;
	l.w = w;
	l.c = classes;
	l.out_w = l.w;
	l.out_h = l.h;
	l.out_c = l.c;
	l.classes = classes;
	l.cost = calloc(1, sizeof(float));
	l.outputs = h*w*classes;
	l.inputs = l.outputs;
	//l.seg_truths = h*w*1;
	l.truths = h*w * 1;
	l.delta = calloc(batch*l.outputs, sizeof(float));
	l.output = calloc(batch*l.outputs, sizeof(float));

	l.forward = forward_region_seg_layer;
	l.backward = backward_region_seg_layer;
#ifdef GPU
	l.forward_gpu = forward_region_seg_layer_gpu;
	l.backward_gpu = backward_region_seg_layer_gpu;
	l.output_gpu = cuda_make_array(l.output, batch*l.outputs);
	l.delta_gpu = cuda_make_array(l.delta, batch*l.outputs);
#endif

	fprintf(stderr, "segmentation\n");
	srand(0);

	return l;
}

void resize_region_seg_layer(layer *l, int w, int h)
{
	l->w = w;
	l->h = h;

	l->outputs = h*w*l->classes;
	l->inputs = l->outputs;

	l->output = realloc(l->output, l->batch*l->outputs * sizeof(float));
	l->delta = realloc(l->delta, l->batch*l->outputs * sizeof(float));

#ifdef GPU
	cuda_free(l->delta_gpu);
	cuda_free(l->output_gpu);

	l->delta_gpu = cuda_make_array(l->delta, l->batch*l->outputs);
	l->output_gpu = cuda_make_array(l->output, l->batch*l->outputs);
#endif
}

void delta_seg_class(float *output, float *delta, int index, int class_id, int classes, float scale[], float *avg_cat, float *avg_back, int stride)
{
	for (int n = 0; n < classes; ++n)
	{
		delta[index + stride*n] = scale[n] * (((n == class_id) ? 1 : 0) - output[index + stride*n]);
		if (n == class_id)
		{
			*avg_cat += output[index + stride*n];
		}
		else
		{
			*avg_back += output[index + stride*n];
		}
	}
}

int seg_entry_index(layer l, int batch, int location, int entry)
{
	int n = location / (l.w*l.h);
	int loc = location % (l.w*l.h);
	return batch*l.outputs + n*l.w*l.h*l.classes + entry*l.w*l.h + loc;
}

void forward_region_seg_layer(const layer l, network state)
{
	int size = l.classes;

	memcpy(l.output, state.input, l.outputs*l.batch * sizeof(float));

#ifndef GPU
	flatten(l.output, l.w*l.h, size, l.batch, 1); //l.n : anchor box ����
	for (int b = 0; b < l.batch; ++b)
	{
		for (int i = 0; i < l.h*l.w; ++i)
		{
			int index = size*i + b*l.outputs;
			softmax(l.output + index, l.classes, 1, l.output + index); //6��° ��忡�� class ���� ��ŭ
		}
	}
#endif

	if (!state.train) return;
	memset(l.delta, 0, l.outputs * l.batch * sizeof(float));

	float avg_fg_cat1 = 0;
	float avg_bg_cat1 = 0;
	float sum_cat1 = 0;

	int count = 0;
	*(l.cost) = 0;

	float scale[34] = {0.412099842, 0.004035021, 0.002821546, 0.002497353, 0.003067344, 0.014886067, 0.002951754, 0.00013784, 0.000968016,
		0.009327696, 0.014858701, 0.000209906,	0.006660854, 0.005333653, 0.311828166, 0.014115331, 0.112510937, 0.003952863, 1,
		0.024924103, 0.012361698, 0.000318497, 0.003167044, 0.002089849, 0.005028101, 0.050864704, 0.00067182, 0.016071386, 0.027014641,
		0.140187504, 0.225392913, 0.014951153, 0.058378968, 0.011603678};

	for (int b = 0; b < l.batch; ++b)
	{
		for (int j = 0; j < l.h; ++j)
		{
			int index = b*l.w*l.h + j*l.w;
			for (int i = 0; i < l.w; ++i)
			{
				int class_id = state.truth[index + i];

				delta_seg_class(l.output, l.delta, (index + i) *l.classes, class_id, l.classes, scale, &avg_fg_cat1, &avg_bg_cat1, 1);
				++count;
			}
		}
	}

#ifndef GPU
	flatten(l.delta, l.w*l.h, size, l.batch, 0);
#endif

	*(l.cost) = pow(mag_array(l.delta, l.outputs * l.batch), 2);

#if GT_VIEW
	//gt
	image im_gt = make_image(l.w, l.h, 3);
	for (int g = 0; g < l.w*l.h; g++)
	{
		im_gt.data[g + 0 * l.w*l.h] = state.truth[g];
		im_gt.data[g + 1 * l.w*l.h] = state.truth[g];
		im_gt.data[g + 2 * l.w*l.h] = state.truth[g];
	}

	image im_gt_rgb = seg_gt_to_rgb(im_gt, l.classes);
	
	//output
	image im_output = make_image(l.w, l.h, l.classes);
	memcpy(im_output.data, l.output, l.outputs * sizeof(float));

	image im_output_rgb = make_image(l.w, l.h, 3);
	mask_to_rgb2(im_output, im_output_rgb);

	//diff
	image im_diff = make_image(l.w, l.h, 3);
	for (int d = 0; d < l.w*l.h; d++)
	{
		if (im_gt_rgb.data[d] != im_output_rgb.data[d])
		{
			im_diff.data[d + 0 * l.w*l.h] = 1;
			im_diff.data[d + 1 * l.w*l.h] = 1;
			im_diff.data[d + 2 * l.w*l.h] = 1;
		}
		else
		{
			im_diff.data[d + 0 * l.w*l.h] = 0;
			im_diff.data[d + 1 * l.w*l.h] = 0;
			im_diff.data[d + 2 * l.w*l.h] = 0;
		}
	}

	show_image(im_gt_rgb, "gt_disp");
	show_image(im_output_rgb, "mask");
	show_image(im_diff, "im_diff");
	cvWaitKey(1);

	free_image(im_gt);
	free_image(im_gt_rgb);
	free_image(im_output);
	free_image(im_output_rgb);
	free_image(im_diff);
#endif

	printf("FG_Class: %f ,BG_Class: %f ,sum_Class: %f count: %d\n", avg_fg_cat1 / count, avg_bg_cat1 / count, avg_fg_cat1 / count + avg_bg_cat1 / count, count);
}

void backward_region_seg_layer(const layer l, network net)
{
	axpy_cpu(l.batch*l.inputs, 1, l.delta, 1, net.delta, 1);
}

#ifdef GPU
void forward_region_seg_layer_gpu(const layer l, network net)
{
	copy_gpu(l.batch*l.inputs, net.input_gpu, 1, l.output_gpu, 1);

	int index = seg_entry_index(l, 0, 0, 0);
	softmax_gpu(net.input_gpu + index, l.classes, l.batch, l.inputs, l.w*l.h, 1, l.w*l.h, 1, l.output_gpu + index);

	flatten_gpu(l.output_gpu, l.h*l.w, l.classes, l.batch, 1, net.workspace);
	copy_gpu(l.batch*l.outputs, net.workspace, 1, net.output_gpu, 1);

	if (!net.train || l.onlyforward)
	{
		cuda_pull_array(net.output_gpu, l.output, l.batch*l.outputs);
		return;
	}

	cuda_pull_array(net.output_gpu, net.input, l.batch*l.inputs);
	forward_region_seg_layer(l, net);

	if (!net.train)
		return;

	cuda_push_array(l.delta_gpu, l.delta, l.batch*l.outputs);
}

void backward_region_seg_layer_gpu(const layer l, network net)
{
	flatten_gpu(l.delta_gpu, l.h*l.w, l.classes, l.batch, 0, net.delta_gpu);
}
#endif