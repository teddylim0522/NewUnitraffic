extern "C" {
#include <stdio.h>
#include <time.h>
}

//#define N 256

__global__ void kernel_test(int *a, int* b, int*c)
{
	*c = *a + *b;
}

/*
__global__ void kernel_block_test(int *a, int* b, int*c)
{
	c[blockIdx.x] = a[blockIdx.x] + b[blockIdx.x];
}*/

__global__ void feature_calculate_gpu(int n_channel, int image_size, float* feature, float sum)
{
	for (int ch = 0; ch < n_channel; ch++)
	{
		for (int id = 0; id < image_size; id++)
		{
			feature[ch*image_size + id] /= sum;
		}
	}
}

void test_gpu(void)
{
	printf("____ go\n");

	int a, b, c;
	int *dev_a, *dev_b, *dev_c;
	int size = sizeof(int);

	cudaMalloc( (void**)&dev_a, size );
	cudaMalloc( (void**)&dev_b, size );
	cudaMalloc( (void**)&dev_c, size );

	a = 2;
	b = 7;

	cudaMemcpy( dev_a, &a, size, cudaMemcpyHostToDevice );
	cudaMemcpy( dev_b, &b, size, cudaMemcpyHostToDevice );

	clock_t start_time = clock();
	kernel_test<<<1,1>>>(dev_a, dev_b, dev_c);
	float span_time = abs((float)(clock() - start_time)/(float)CLOCKS_PER_SEC);

	printf("go_go time: %.3f", span_time);

	cudaMemcpy( &c, dev_c, size, cudaMemcpyDeviceToHost);

	printf("out: %d", c);

	cudaFree( dev_a );
	cudaFree( dev_b );
	cudaFree( dev_c );

}

/*
void test_gpu_thread(void)
{
	printf("____ go");

	int *a, *b, *c;
	int *dev_a, *dev_b, *dev_c;
	int size = N*sizeof(int);

	cudaMalloc((void**)&dev_a, size);
	cudaMalloc((void**)&dev_b, size);
	cudaMalloc((void**)&dev_c, size);

	a = 2;
	b = 7;

	cudaMemcpy(dev_a, &a, size, cudaMemcpyHostToDevice);
	cudaMemcpy(dev_b, &b, size, cudaMemcpyHostToDevice);


	kernel_test <<<N, 1 >>>(dev_a, dev_b, dev_c);

	printf("go_go");

	cudaMemcpy(&c, dev_c, size, cudaMemcpyDeviceToHost);

	printf("out: %d", c);

	cudaFree(dev_a);
	cudaFree(dev_b);
	cudaFree(dev_c);

}*/


void feature_calculate(int n_channel, int image_size, float* feature, float sum)
{
	printf("feature start\n");

	float* feature_tmp;

	int N = n_channel*image_size;

	cudaMalloc( (void**)&feature_tmp, N*sizeof(float));

	cudaMemcpy( feature_tmp, feature, N*sizeof(float), cudaMemcpyHostToDevice );

	feature_calculate_gpu<<<1,256>>>(n_channel, image_size, feature_tmp, sum);

	cudaDeviceSynchronize();

	cudaMemcpy( feature, feature_tmp, N*sizeof(float), cudaMemcpyDeviceToHost);

	printf("feature end\n");

	cudaFree(feature_tmp);

	
}