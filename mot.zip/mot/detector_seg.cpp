#include "darknet.h"
#include "argv.h"

static int coco_ids[] = { 1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,27,28,31,32,33,34,35,36,37,38,39,40,41,42,43,44,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,67,70,72,73,74,75,76,77,78,79,80,81,82,84,85,86,87,88,89,90 };

void train_detector_seg(char *datacfg, char *cfgfile, char *weightfile, int *gpus, int ngpus, int clear, int train_test)
{
	srand((unsigned int)time(NULL));

	list *options = read_data_cfg(datacfg);
	char *train_images = option_find_str(options, "train", "");
	char *backup_dir = "D:/darknet/weights";

	char *base = basecfg(cfgfile);
	printf("%s\n", base);

	network *nets = calloc(ngpus, sizeof(network));

	int seed = rand();
	for (int i = 0; i < ngpus; ++i)
	{
		srand(seed);

#ifdef GPU
		cuda_set_device(gpus[i]);
#endif

		nets[i] = load_network(cfgfile, weightfile, clear);
		nets[i].learning_rate *= ngpus;
	}

	char cfgfile_test[CHAR_LENGTH];
	network net_test;
	if (train_test)
	{
		find_replace(cfgfile, ".cfg", "_test.cfg", cfgfile_test);
		net_test = parse_network_cfg(cfgfile_test, 0, 0);
	}

	network net = nets[0];

	int imgs = net.batch * net.subdivisions * ngpus;
	printf("Learning Rate: %g, Momentum: %g, Decay: %g\n", net.learning_rate, net.momentum, net.decay);
	data train, buffer;

	layer l = net.layers[net.n - 1];

	int classes = l.classes;
	float jitter = l.jitter;

	list *plist = get_paths(train_images);
	char **paths = (char **)list_to_array(plist);

	load_args args = get_base_args(net);
	args.paths = paths;
	args.n = imgs;
	args.m = plist->size;
	args.out_w = l.out_w;
	args.out_h = l.out_h;
	printf("%d\n", args.m);
	args.classes = classes;
	args.jitter = jitter;
	args.d = &buffer;
	args.type = SEGMENTATION_DATA;
	args.threads = TRAIN_DETECTOR_THREADS;

	pthread_t load_thread = load_data(args);
	clock_t time;
	int count = 0;
	int save_cnt = -1;
	float avg_loss = -1;
	while (get_current_batch(net) < net.max_batches + ngpus)
	{
		if (l.random && count++ % 10 == 0)
		{
			printf("Resizing\n");
			int dim = (rand() % 10 + 10) * 32;
			if (get_current_batch(net) + 200 > net.max_batches)
				dim = 608;
			printf("%d\n", dim);
			args.w = dim;
			args.h = dim;

			pthread_join(load_thread, 0);
			train = buffer;
			free_data(train);
			load_thread = load_data(args);

			for (int i = 0; i < ngpus; ++i)
			{
				resize_network(nets + i, dim, dim);
			}
			net = nets[0];
		}

		time = clock();
		pthread_join(load_thread, 0);
		train = buffer;
		load_thread = load_data(args);
		printf("Loaded: %lf seconds\n", sec(clock() - time));

		time = clock();
		float loss = 0;

#ifdef GPU
		if (ngpus == 1)
		{
			loss = train_network(net, train);
		}
		else
		{
			loss = train_networks(nets, ngpus, train, 4);
		}
#else
		loss = train_network(net, train);
#endif

		if (avg_loss < 0)
			avg_loss = loss;
		avg_loss = avg_loss*.9 + loss*.1;

		int i = get_current_batch(net);
		printf("%ld: %f, %f avg, %f rate, %lf seconds, %d images\n", get_current_batch(net), loss, avg_loss, get_current_rate(net), sec(clock() - time), i*imgs);

		if (save_cnt == -1)
			save_cnt = i / 1000;

		if (i / 1000 > save_cnt)
		{
			i /= 1000;
			i *= 1000;
			save_cnt++;

#ifdef GPU
			if (ngpus != 1)
				sync_nets(nets, ngpus, 0);
#endif

			char buff[256];
			sprintf(buff, "%s/%s", backup_dir, base);
			mkdir(buff);

			sprintf(buff, "%s/%s_%d.weights", buff, base, i);
			save_weights(net, buff);

			if (train_test)
			{
				test_detector(datacfg, cfgfile_test, net_test, buff, 0, 0, 0, 0, 0);
			}
		}
		free_data(train);
	}

#ifdef GPU
	if (ngpus != 1)
		sync_nets(nets, ngpus, 0);
#endif

	char buff[256];
	sprintf(buff, "%s/%s/%s_%d.weights", backup_dir, base, base, net.max_batches);
	save_weights(net, buff);
}

void test_detector_seg(char *datacfg, char *cfgfile, network net, char *weightfile, char *filename, float thresh, float hier_thresh, char *outfile, int fullscreen)
{
	srand((unsigned int)time(NULL));

	list *options = read_data_cfg(datacfg);
	char *name_list = option_find_str(options, "names", "");
	char **names = get_labels(name_list);

	if (weightfile)
	{
		//LoadLowpWeightsAsFloatUpto(&net, weightfile, 0, net.n);
		load_weights(&net, weightfile);
	}

	float forward_time = 0, detection_time = 0, total_time = 0;
	clock_t forward_time_c, detection_time_c, total_time_c;
	image **alphabet = load_alphabet();

#if WEBCAM
	IplImage *webcam = 0;
	CvCapture *capture = cvCaptureFromCAM(0);
	cvNamedWindow("WebCam Frame Capture", 0);
	cvResizeWindow("WebCam Frame Capture", 640, 480);

#else
	image_info in = image_setting();

#ifdef IMAGE_LOAD_THREAD
	image im_buffer, sized_buffer;

	load_args args = { 0 };
	args.w = net.w;
	args.h = net.h;
	args.im = &im_buffer;
	args.resized = &sized_buffer;
	args.type = IMAGE_DATA;
	args.threads = 1;

	args.path = calloc(CHAR_LENGTH, sizeof(char));
	args.path = in.image_path[IMAGE_START];

	pthread_t load_thread = load_data_in_thread(args);
#endif
#endif

#if EVAL
	eval_info ev_info = eval_setting(weightfile, cfgfile);
#endif

	for (int i = IMAGE_START; i < in.n_path; i++)
	{
		total_time_c = clock();

#if WEBCAM
		cvGrabFrame(capture);
		webcam = cvRetrieveFrame(capture, 1);
		cvCvtColor(webcam, webcam, CV_RGB2BGR);

		//cvShowImage("WebCam Frame Capture", webcam);
		//cvWaitKey(1);
		//continue;

		image im = make_image(640, 480, 3);
		ipl_into_image(webcam, im);
		image sized = resize_image(im, net.layers[0].w, net.layers[0].h);

#else
#ifdef IMAGE_LOAD_THREAD
		pthread_join(load_thread, 0);

		image im = im_buffer;
		image sized = sized_buffer;

		int path_index = (i + 1 < in.n_path) ? i + 1 : i;
		args.path = in.image_path[path_index];
		load_thread = load_data_in_thread(args);

#else
		image im = load_image_color(in.image_path[i], 0, 0);
		image sized = resize_image(im, net.layers[0].w, net.layers[0].h);
#endif
#endif

		float *X = sized.data;
		forward_time_c = clock();
		network_predict(net, X);
		forward_time = sec(clock() - forward_time_c);

		layer l = net.layers[net.n - 1];

		image im_output = make_image(l.out_w, l.out_h, l.classes);
		memcpy(im_output.data, l.output, l.outputs * sizeof(float));

		//image im_output_resize = resize_image(im_output, net.w, net.h);

		image im_output_rgb = make_image(im_output.w, im_output.h, 3);
		mask_to_rgb3(im_output, im_output_rgb);

		//image im_output_rgb = make_image(im_output.w, im_output.h, 3);
		mask_to_rgb3(im_output, sized);

		sized = resize_image(sized, sized.w * 4, sized.h * 4);

		/*char *gt_path = in.image_path[in.image_index[image_cnt]];
		image im_gt = get_segmentation_image3(gt_path, im.w, im.h, 1);
		image im_gt_rgb = seg_gt_to_rgb(im_gt, l.classes);*/
		
#if IMAGE_SAVE
		char save_image_path[CHAR_LENGTH];
		sprintf(save_image_path, "%s/%d", SAVE_DIR, i);
		save_image(im_output_rgb, save_image_path);
#endif

		show_image(im, "im");
		show_image(sized, "sized");
		show_image(im_output_rgb, "im_output_rgb");
		//show_image(im_gt_rgb, "im_gt_rgb");

		free_image(im);
		free_image(sized);
		free_image(im_output);
		//free_image(im_output_resize);
		free_image(im_output_rgb);
		//free_image(im_gt);
		//free_image(im_gt_rgb);

		total_time = sec(clock() - total_time_c);
#if WEBCAM
		printf("%f / %f / %f\n", forward_time, detection_time, total_time);
#else
		printf("%d: %f / %f / %f\n", i, forward_time, detection_time, total_time);
#endif

		cvWaitKey(WAIT_KEY);
	}
	printf("while done\n");

	free_image_info(in);

	cvDestroyAllWindows();
	printf("cvDestroyAllWindows doen\n");
}

void run_detector_seg(int argc, char **argv)
{
	char *prefix = find_char_arg(argc, argv, "-prefix", 0);
	float thresh = find_float_arg(argc, argv, "-thresh", .20);
	float hier_thresh = find_float_arg(argc, argv, "-hier", .5);
	int cam_index = find_int_arg(argc, argv, "-c", 0);
	int frame_skip = find_int_arg(argc, argv, "-s", 0);
	int avg = find_int_arg(argc, argv, "-avg", 3);
	if (argc < 4)
	{
		fprintf(stderr, "usage: %s %s [train/test/valid] [cfg] [weights (optional)]\n", argv[0], argv[1]);
		return;
	}
	char *gpu_list = find_char_arg(argc, argv, "-gpus", 0);
	char *outfile = find_char_arg(argc, argv, "-out", 0);
	int *gpus = 0;
	int gpu = 0;
	int ngpus = 0;
	if (gpu_list)
	{
		printf("%s\n", gpu_list);
		int len = strlen(gpu_list);
		ngpus = 1;
		int i;
		for (i = 0; i < len; ++i)
		{
			if (gpu_list[i] == ',') ++ngpus;
		}
		gpus = calloc(ngpus, sizeof(int));
		for (i = 0; i < ngpus; ++i)
		{
			gpus[i] = atoi(gpu_list);
			gpu_list = strchr(gpu_list, ',') + 1;
		}
	}
	else
	{
		gpu = 0;
		gpus = &gpu;
		ngpus = 1;
	}

	int clear = find_arg(argc, argv, "-clear");
	int fullscreen = find_arg(argc, argv, "-fullscreen");
	int width = find_int_arg(argc, argv, "-w", 0);
	int height = find_int_arg(argc, argv, "-h", 0);
	int fps = find_int_arg(argc, argv, "-fps", 0);

	char *datacfg = argv[3];
	char *cfg = argv[4];
	char *weights = (argc > 5) ? argv[5] : 0;
	char *filename = (argc > 6) ? argv[6] : 0;
	if (0 == strcmp(argv[2], "train"))
	{
		train_detector_seg(datacfg, cfg, weights, gpus, ngpus, clear, 0);
	}
	else if (0 == strcmp(argv[2], "test"))
	{
		network net = parse_network_cfg(cfg, 1, 0);
		test_detector_seg(datacfg, cfg, net, weights, filename, thresh, hier_thresh, outfile, fullscreen);
	}
}