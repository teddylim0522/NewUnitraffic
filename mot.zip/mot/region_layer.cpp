﻿#include "region_layer.h"
#include "activations.h"
#include "blas.h"
#include "box.h"
#include "cuda.h"
#include "utils.h"

#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>


#define CROSS_ENTROPY 
//#define USING_DONTCARE_CLASS
layer make_region_layer(int batch, int w, int h, int n, int classes, int coords)
{
	layer l = { 0 };
	l.type = REGION;

	l.n = n;
	l.batch = batch;
	l.h = h;
	l.w = w;
	l.c = n*(classes + coords + 1);
	l.out_w = l.w;
	l.out_h = l.h;
	l.out_c = l.c;
	l.classes = classes;
	l.coords = coords;
	l.cost = calloc(1, sizeof(float));
	l.biases = calloc(n * 2, sizeof(float));
	l.bias_updates = calloc(n * 2, sizeof(float));
	l.outputs = h*w*n*(classes + coords + 1);
	l.inputs = l.outputs;
	l.truths = 101 * (l.coords + 1);
	l.delta = calloc(batch*l.outputs, sizeof(float));
	l.output = calloc(batch*l.outputs, sizeof(float));
	int i;
	for (i = 0; i < n * 2; ++i)
	{
		l.biases[i] = .5;
	}

	l.forward = forward_region_layer;
	l.backward = backward_region_layer;
#ifdef GPU
	l.forward_gpu = forward_region_layer_gpu;
	l.backward_gpu = backward_region_layer_gpu;
	l.output_gpu = cuda_make_array(l.output, batch*l.outputs);
	l.delta_gpu = cuda_make_array(l.delta, batch*l.outputs);
#endif

	fprintf(stderr, "detection\n");
	srand(0);

	return l;
}

void resize_region_layer(layer *l, int w, int h)
{
	l->w = w;
	l->h = h;

	l->outputs = h*w*l->n*(l->classes + l->coords + 1);
	l->inputs = l->outputs;

	l->output = realloc(l->output, l->batch*l->outputs * sizeof(float));
	l->delta = realloc(l->delta, l->batch*l->outputs * sizeof(float));

#ifdef GPU
	cuda_free(l->delta_gpu);
	cuda_free(l->output_gpu);

	l->delta_gpu = cuda_make_array(l->delta, l->batch*l->outputs);
	l->output_gpu = cuda_make_array(l->output, l->batch*l->outputs);
#endif
}

box get_region_box(float *x, float *biases, int n, int index, int i, int j, int w, int h, int stride)
{
	box b;
	b.x = (i + x[index + 0 * stride]) / w;
	b.y = (j + x[index + 1 * stride]) / h;
	b.w = exp(x[index + 2 * stride]) * biases[2 * n] / w;
	b.h = exp(x[index + 3 * stride]) * biases[2 * n + 1] / h;
	return b;
}

float delta_region_box(box truth, float *x, float *biases, int n, int index, int i, int j, int w, int h, float *delta, float scale, int stride)
{
	box pred = get_region_box(x, biases, n, index, i, j, w, h, stride);
	float iou = box_iou(pred, truth);

	float tx = (truth.x*w - i);
	float ty = (truth.y*h - j);
	float tw = log(truth.w*w / biases[2 * n]);
	float th = log(truth.h*h / biases[2 * n + 1]);

	delta[index + 0 * stride] = scale * (tx - x[index + 0 * stride]);
	delta[index + 1 * stride] = scale * (ty - x[index + 1 * stride]);
	delta[index + 2 * stride] = scale * (tw - x[index + 2 * stride]);
	delta[index + 3 * stride] = scale * (th - x[index + 3 * stride]);
	return iou;
}

void delta_region_mask(float *truth, float *x, int n, int index, float *delta, int stride, int scale)
{
	int i;
	for (i = 0; i < n; ++i)
	{
		delta[index + i*stride] = scale*(truth[i] - x[index + i*stride]);
	}
}

float smooth_l1_gradient(float target, float output)
{
	float results, abs_dif;
	int sign;
	float dif = target - output;
	if (dif > 0)
	{
		sign = 1;
	}
	else
	{
		sign = -1;
	}
	abs_dif = sign * dif;


	if (abs_dif < 1)
	{
		results = target - output;
	}
	else
	{

		results = sign;
	}
	return results;
}


float _delta_region_box(box truth, float *x, float *biases, int n, int index, int i, int j, int w, int h, float *delta, float scale, int stride)
{

	box pred = get_region_box(x, biases, n, index, i, j, w, h, stride);
	float iou = box_iou(pred, truth);

	float tx = (truth.x*w - i);
	float ty = (truth.y*h - j);
	float tw = log(truth.w*w / biases[2 * n]);
	float th = log(truth.h*h / biases[2 * n + 1]);

	delta[index + 0 * stride] = scale * (tx - x[index + 0 * stride]);
	delta[index + 1 * stride] = scale * (ty - x[index + 1 * stride]);
	delta[index + 2 * stride] = scale * smooth_l1_gradient(tw, x[index + 2 * stride]);
	delta[index + 3 * stride] = scale * smooth_l1_gradient(th, x[index + 3 * stride]);

	return iou;
}


void delta_region_class(float *output, float *delta, int index, int class, int classes, tree *hier, float scale, float *avg_cat, int stride)
{
	int i, n;
	if (hier)
	{
		float pred = 1;
		while (class >= 0)
		{
			pred *= output[index + stride*class];
			int g = hier->group[class];
			int offset = hier->group_offset[g];
			for (i = 0; i < hier->group_size[g]; ++i)
			{
				delta[index + stride*(offset + i)] = scale * (0 - output[index + stride*(offset + i)]);
			}
			delta[index + stride*class] = scale * (1 - output[index + stride*class]);

			class = hier->parent[class];
		}
		*avg_cat += pred;
	}
	else
	{
		for (n = 0; n < classes; ++n)
		{
			delta[index + stride*n] = scale * (((n == class) ? 1 : 0) - output[index + stride*n]);
			if (n == class) *avg_cat += output[index + stride*n];
		}
	}
}

float logit(float x)
{
	return log(x / (1. - x));
}

float tisnan(float x)
{
	return (x != x);
}

typedef struct
{
	int index;
	float probs;
	box bb_box;
} sortable_score;

int prob_comparator_ascending(const void *pa, const void *pb)
{
	sortable_score a = *(sortable_score *)pa;
	sortable_score b = *(sortable_score *)pb;
	float diff = a.probs - b.probs;
	if (diff < 0) return -1;
	else if (diff > 0) return 1;
	return 0;
}

int prob_comparator_descending(const void *pa, const void *pb)
{
	sortable_score a = *(sortable_score *)pa;
	sortable_score b = *(sortable_score *)pb;
	float diff = a.probs - b.probs;
	if (diff < 0) return 1;
	else if (diff > 0) return -1;
	return 0;
}

float get_max_class_prob(float *output, int n_class)
{
	float max_prob = output[0];
	for (int c = 1; c < n_class; c++)
	{
		if (output[c] > max_prob)
		{
			max_prob = output[c];
		}
	}
	return max_prob;
}

int nms_sort_hard_negative(sortable_score *s, int total, float thresh)
{
	int i, j, n_valid = total;

	qsort(s, total, sizeof(sortable_score), prob_comparator_descending);

	for (i = 0; i < total; ++i)
	{
		if (s[i].probs == 0)
		{
			n_valid--;
			continue;
		}

		box a = s[i].bb_box;
		for (j = i + 1; j < total; ++j)
		{
			if (s[j].probs == 0)
			{
				continue;
			}

			box b = s[j].bb_box;
			if (box_iou(a, b) > thresh)
			{
				s[j].probs = 0;
			}
		}
	}

	qsort(s, total, sizeof(sortable_score), prob_comparator_descending);

	return n_valid;
}

int get_gt_info(float *truth, int n_batch, int n_truth, box **truthbox)
{
	int n_gt = 0;
	for (int b = 0; b < n_batch; ++b)
	{
		for (int t = 0; t < 101; ++t)
		{
			truthbox[b][t] = float_to_box(truth + t * 5 + b*n_truth, 1);  //5 : x, y, w, h, id
			if (!truthbox[b][t].w) break;
			n_gt++;
		}
	}
	return n_gt;
}



int entry_index(layer l, int batch, int location, int entry)
{
	int n = location / (l.w*l.h);
	int loc = location % (l.w*l.h);
	return batch*l.outputs + n*l.w*l.h*(l.coords + l.classes + 1) + entry*l.w*l.h + loc;
}

void forward_region_layer(const layer l, network state)
{

	int size = l.coords + l.classes + 1;  //coords : box ��ǥ, classes : class ����, 1 : object or not

	memcpy(l.output, state.input, l.outputs*l.batch * sizeof(float));
#ifndef GPU
	flatten(l.output, l.w*l.h, size*l.n, l.batch, 1); //l.n : anchor box ����

	for (int b = 0; b < l.batch; ++b)
	{
		for (int i = 0; i < l.h*l.w*l.n; ++i)
		{  //l.n = grid�� ancher�ڽ� ����
			int index = size*i + b*l.outputs;  //l.outputs = l.h*l.w*l.n*size
			l.output[index + 4] = logistic_activate(l.output[index + 4]); //5��° node : object or not score
		}
	}
#endif


#ifndef GPU
	if (l.softmax)
	{
		for (int b = 0; b < l.batch; ++b)
		{
			for (int i = 0; i < l.h*l.w*l.n; ++i)
			{ //l.n = grid�� ancher�ڽ� ����
				int index = size*i + b*l.outputs; //l.outputs = l.h*l.w*l.n*size
				softmax(l.output + index + 5, l.classes, 1, l.output + index + 5); //6��° ��忡�� class ���� ��ŭ
			}
		}
	}
#endif
	if (!state.train) return;
	memset(l.delta, 0, l.outputs * l.batch * sizeof(float));
	float avg_iou = 0;
	float recall = 0;
	float avg_cat = 0;
	float avg_fg_cat1 = 0;
	float avg_bg_cat1 = 0;
	float avg_fg_cat2 = 0;
	float avg_bg_cat2 = 0;
	float avg_obj = 0;
	float avg_anyobj = 0;
	int count = 0;
	int class_count = 0;
	*(l.cost) = 0;

	int n_gt, n_hn, n_fp, n_fp_nms, hn_scale = 4;
	int n_fg = 0;
	int n_pos_class = 0;
	float hn_thresh = 0.5;

	sortable_score *max_class_score = malloc(sizeof(sortable_score)*l.batch*l.outputs);
	sortable_score *object_score = malloc(sizeof(sortable_score)*l.batch*l.outputs);


	float average_bgobject_score = 0.0, average_hn_score = 0.0;
	int n_hn_total = 0;
	n_fp = 0; //mini-batch ������  hard negative mining
	int nBox = 101;
	box **truth = malloc(l.batch * sizeof(box *));
	for (int b = 0; b < l.batch; b++)
	{
		truth[b] = malloc(nBox * sizeof(box));
	}
	n_gt = get_gt_info(state.truth, l.batch, l.truths, truth);

	static float hn_rj_thresh = 0.9;


	for (int b = 0; b < l.batch; ++b)
	{
		for (int j = 0; j < l.h; ++j)
		{  //output ä�� ����
			for (int i = 0; i < l.w; ++i)
			{ //output ä�� �ʺ�
				for (int n = 0; n < l.n; ++n)
				{  //anchor box ����
					if (rand() % 10)
					{
						continue;
					}

					int index = size*(j*l.w*l.n + i*l.n + n) + b*l.outputs; //index: grid�� box�� ���� ä�ΰ���, l.ouputs : ������ ��� ����, l.h*l.w*l.n*size,  size :coords(4) + object or not(1) + class����(N)
					avg_anyobj += l.output[index + 4];  //grid�� objectness Ȯ�� ���
					if (l.output[index + 4] < hn_rj_thresh) continue;
					box pred = get_region_box(l.output, l.biases, n, index, i, j, l.w, l.h, 1);

					float best_iou = 0;
					for (int t = 0; t < nBox; ++t)
					{
						if (!truth[b][t].w) break;
						int class_id = state.truth[t * 5 + b*l.truths + 4];
						float iou = box_iou(pred, truth[b][t]);
#ifdef USING_DONTCARE_CLASS  // MISC Class 사용할 때만 활성
						if ((class_id == l.classes - BACKGROUND_CLASS) && (iou > 0)) //don' care class�� ���Ͽ��� update ����.
						{
							iou = hn_thresh;
						}
#endif

						if (iou > best_iou)
						{
							best_iou = iou;
						}
					}

					//false positive sample save
					if (best_iou < hn_thresh)
					{
						max_class_score[n_fp].probs = get_max_class_prob(&l.output[index + 5], l.classes - BACKGROUND_CLASS); //objectclass �߿��� ���� ū Ȯ������ ��������.
						max_class_score[n_fp].index = index;
						max_class_score[n_fp].bb_box = pred;

						object_score[n_fp].index = index;
						object_score[n_fp].probs = l.output[index + 4];
						object_score[n_fp].bb_box = pred;

						n_fp++;
					}



					if (*(state.seen) < 12800)
					{ //anchor box�� ������ �̵���Ų��.
						box truth = { 0 };
						truth.x = (i + .5) / l.w;  //grid �߰��� �߽� ��ǥ�� �ؼ� normalization
						truth.y = (j + .5) / l.h;
						truth.w = l.biases[2 * n] / l.w;
						truth.h = l.biases[2 * n + 1] / l.h;
						_delta_region_box(truth, l.output, l.biases, n, index, i, j, l.w, l.h, l.delta, .01, 1);
					}
				}
			}
		}
	}

	int n_positive = 0;

	for (int b = 0; b < l.batch; ++b)
	{
		for (int t = 0; t < 101; ++t)
		{
			int class_id = state.truth[t * 5 + b*l.truths + 4];

#ifdef USING_DONTCARE_CLASS  // MISC Class 사용할 때만 활성
			if (class_id == l.classes - BACKGROUND_CLASS)  //don' care class�� ���Ͽ��� update ����.
			{
				continue;
			}
#endif	

			if (!truth[b][t].w) break;
			float best_iou = 0;
			int best_index = 0;
			int best_n = 0;

			int i = (truth[b][t].x * l.w); //���� ä�� ũ�⿡ ���缭 GT ��ǥ�� �̵���
			int j = (truth[b][t].y * l.h);
			//         printf("(%d %d) %d %f %d %f\n", b, t, i, truth.x, j, truth.y);
			box truth_shift = truth[b][t];

			truth_shift.x = 0;
			truth_shift.y = 0;

			for (int n = 0; n < l.n; ++n)
			{  //l.n : anchor box ����
				int index = size*(j*l.w*l.n + i*l.n + n) + b*l.outputs;
				//				box pred = get_region_box(l.output, l.biases, n, index, i, j, l.w, l.h, 1); //biases : parse_region() ���� anchor �� ���� ũ�� ���� loading
				box pred;																	 //w h  ����ȭ[0 1]
				pred.w = l.biases[2 * n] / l.w;
				pred.h = l.biases[2 * n + 1] / l.h;

				pred.x = 0;
				pred.y = 0;


				float iou = box_iou(pred, truth_shift);
				if (iou > best_iou)
				{
					best_index = index;
					best_iou = iou;
					best_n = n;
				}
			}

			box pred = get_region_box(l.output, l.biases, best_n, best_index, i, j, l.w, l.h, 1);
			float iou = box_iou(pred, truth[b][t]);
			if (iou > .5) recall += 1;
			avg_iou += iou;
			avg_obj += l.output[best_index + 4];


			if (iou >= 0.) //ninolyc6.20180704 모든 positive update
			{
				_delta_region_box(truth[b][t], l.output, l.biases, best_n, best_index, i, j, l.w, l.h, l.delta, l.coord_scale, 1); //delta��

#ifdef 	CROSS_ENTROPY
				l.delta[best_index + 4] = l.object_scale * (iou - l.output[best_index + 4]);
#else
				l.delta[best_index + 4] = l.object_scale * (iou - l.output[best_index + 4]) * logistic_gradient(l.output[best_index + 4]);
#endif

				if (l.map) class_id = l.map[class_id];

				delta_region_class(l.output, l.delta, best_index + 5, class_id, l.classes, l.softmax_tree, l.class_scale, &avg_cat, 1);
				avg_fg_cat1 += l.output[best_index + 5 + class_id];

				for (int c_id = 0; c_id < l.classes; c_id++)
				{
					if (c_id == class_id) continue;
					avg_bg_cat1 += l.output[best_index + 5 + c_id];

				}
				n_positive++;
				++class_count;
			}

			++count;

		}
	}


	if (class_count == 0) class_count = 1;



	n_fp_nms = nms_sort_hard_negative(max_class_score, n_fp, 0.3);
	n_fp_nms = min(n_fp_nms, nms_sort_hard_negative(object_score, n_fp, 0.3));


#if 1
	//	printf("n_gt= %d, n_pos_class = %d, n_fp = %d \n", n_gt, n_pos_class, n_fp);
	n_hn = n_positive * hn_scale;
	//  n_hn = n_gt * hn_scale;
	if (n_hn > n_fp_nms)
	{
		n_hn = n_fp_nms;
		hn_rj_thresh = hn_rj_thresh * 0.99;
		printf("--------------------hn_rj_thresh = %f--------------------------------\n", hn_rj_thresh);
	}
#if 0
	for (int kk = 0; kk < n_hn; kk++)
	{
		printf("n_fp_nms = %d n_gt = %d %d) class prob = %f\n", n_fp_nms, n_gt, max_class_score[kk].index, max_class_score[kk].probs);
		//			printf("n_hn = %d %d) object prob = %f\n", n_hn, object_score[kk].index, object_score[kk].probs);
	}
#endif

	//		printf("n_hn= %d, n_fp_nms = %d n_gt = %d n_fp = %d \n", n_hn, n_fp_nms, n_gt, n_fp);
	for (int i_hn = 0; i_hn < n_hn; i_hn++)
	{
		int index = max_class_score[i_hn].index;  //class index
#if BACKGROUND_CLASS
		delta_region_class(l.output, l.delta, index + 5, l.classes - BACKGROUND_CLASS, l.classes, l.softmax_tree, l.class_scale, &avg_cat, 1);
#endif


		index = object_score[i_hn].index;   //object index
#ifdef 	CROSS_ENTROPY
		l.delta[index + 4] = l.noobject_scale * ((0 - l.output[index + 4]));
#else
		l.delta[index + 4] = l.noobject_scale * ((0 - l.output[index + 4]) * logistic_gradient(l.output[index + 4])); //noobject_scale: parse_region()���� loading
#endif



		average_hn_score += max_class_score[i_hn].probs;
		n_hn_total++;
	}
#endif




	//	printf("aver_hn_score = %f aver_bgobj_score = %f\n", average_hn_score / n_hn_total, average_bgobject_score / n_hn_total);
	//	printf("aver_hn_score = %f \n", average_hn_score / n_hn_total);

	//printf("\n");
	free(max_class_score);
	free(object_score);
	for (int b = 0; b < l.batch; b++)
	{
		free(truth[b]);

	}
	free(truth);


#ifndef GPU
	flatten(l.delta, l.w*l.h, size*l.n, l.batch, 0);
#endif
	*(l.cost) = pow(mag_array(l.delta, l.outputs * l.batch), 2);

	printf("IOU: %f, FG_Class: %f ,BG_Class: %f, Obj: %f, No Obj: %f, Recall: %f,  count: %d\n",
		avg_iou / count, avg_fg_cat1 / class_count, avg_bg_cat1 / class_count, avg_obj / count, avg_anyobj / (l.w*l.h*l.n*l.batch), recall / count, count);


}

void backward_region_layer(const layer l, network net)
{
	axpy_cpu(l.batch*l.inputs, 1, l.delta, 1, net.delta, 1);
}

void correct_region_boxes(box *boxes, int n, int w, int h, int netw, int neth)
{
	int i;
	int new_w = 0;
	int new_h = 0;
	if (((float)netw / w) < ((float)neth / h))
	{
		new_w = netw;
		new_h = (h * netw) / w;
	}
	else
	{
		new_h = neth;
		new_w = (w * neth) / h;
	}
	for (i = 0; i < n; ++i)
	{
		box b = boxes[i];
		b.x = (b.x - (netw - new_w) / 2. / netw) / ((float)new_w / netw);
		b.y = (b.y - (neth - new_h) / 2. / neth) / ((float)new_h / neth);
		b.w *= (float)netw / new_w;
		b.h *= (float)neth / new_h;
		/*if (!relative)
		{
			b.x *= w;
			b.w *= w;
			b.y *= h;
			b.h *= h;
		}*/
		boxes[i] = b;
	}
}

void get_region_boxes(layer l, int w, int h, int netw, int neth, float thresh, float **probs, box *boxes, float **masks, int only_objectness, int *map, float tree_thresh, int relative)
{
	int i, j, n, z;
	float *predictions = l.output;
	if (l.batch == 2)
	{
		float *flip = l.output + l.outputs;
		for (j = 0; j < l.h; ++j)
		{
			for (i = 0; i < l.w / 2; ++i)
			{
				for (n = 0; n < l.n; ++n)
				{
					for (z = 0; z < l.classes + l.coords + 1; ++z)
					{
						int i1 = z*l.w*l.h*l.n + n*l.w*l.h + j*l.w + i;
						int i2 = z*l.w*l.h*l.n + n*l.w*l.h + j*l.w + (l.w - i - 1);
						float swap = flip[i1];
						flip[i1] = flip[i2];
						flip[i2] = swap;
						if (z == 0)
						{
							flip[i1] = -flip[i1];
							flip[i2] = -flip[i2];
						}
					}
				}
			}
		}
		for (i = 0; i < l.outputs; ++i)
		{
			l.output[i] = (l.output[i] + flip[i]) / 2.;
		}
	}
	for (i = 0; i < l.w*l.h; ++i)
	{
		int row = i / l.w;
		int col = i % l.w;
		for (n = 0; n < l.n; ++n)
		{
			int index = n*l.w*l.h + i;
			for (j = 0; j < l.classes; ++j)
			{
				probs[index][j] = 0;
			}
			int obj_index = entry_index(l, 0, n*l.w*l.h + i, l.coords);
			int box_index = entry_index(l, 0, n*l.w*l.h + i, 0);
			int mask_index = entry_index(l, 0, n*l.w*l.h + i, 4);
			float scale = l.background ? 1 : predictions[obj_index];
			boxes[index] = get_region_box(predictions, l.biases, n, box_index, col, row, l.w, l.h, l.w*l.h);
			if (masks)
			{
				for (j = 0; j < l.coords - 4; ++j)
				{
					masks[index][j] = l.output[mask_index + j*l.w*l.h];
				}
			}

			int class_index = entry_index(l, 0, n*l.w*l.h + i, l.coords + !l.background);
			if (l.softmax_tree)
			{

				hierarchy_predictions(predictions + class_index, l.classes, l.softmax_tree, 0, l.w*l.h);
				if (map)
				{
					for (j = 0; j < 200; ++j)
					{
						int class_index = entry_index(l, 0, n*l.w*l.h + i, l.coords + 1 + map[j]);
						float prob = scale*predictions[class_index];
						probs[index][j] = (prob > thresh) ? prob : 0;
					}
				}
				else
				{
					int j = hierarchy_top_prediction(predictions + class_index, l.softmax_tree, tree_thresh, l.w*l.h);
					probs[index][j] = (scale > thresh) ? scale : 0;
					probs[index][l.classes] = scale;
				}
			}
			else
			{
				float max = 0;
				for (j = 0; j < l.classes; ++j)
				{
					int class_index = entry_index(l, 0, n*l.w*l.h + i, l.coords + 1 + j);
					float prob = scale*predictions[class_index];
					probs[index][j] = (prob > thresh) ? prob : 0;
					if (prob > max) max = prob;
				}
				probs[index][l.classes] = max;
			}
			if (only_objectness)
			{
				probs[index][0] = scale;
			}
		}
	}
	correct_region_boxes(boxes, l.w*l.h*l.n, w, h, netw, neth, relative);
}

void _get_region_boxes(image im, box_label *gt, int n_gt, layer l, int w, int h, float thresh, float **probs, box *boxes)
{
	float *predictions = l.output;
	sortable_score *object_box_score = malloc(sizeof(sortable_score)*l.batch*l.outputs);
	int box_id = 0;
	for (int i = 0; i < l.w*l.h; ++i)
	{
		int row = i / l.w;
		int col = i % l.w;
		for (int n = 0; n < l.n; ++n)
		{
			int index = i*l.n + n;
			int p_index = index * (l.classes + 5) + 4;
			int box_index = index * (l.classes + 5);

			boxes[index] = get_region_box(predictions, l.biases, n, box_index, col, row, l.w, l.h, 1);
			object_box_score[box_id].probs = predictions[p_index];
			object_box_score[box_id].index = index;
			object_box_score[box_id].bb_box = boxes[index];
			box_id++;
		}
	}

	static int r = 0, g = 0, b = 0;
#if 0 //gt
	image tmp_img = copy_image(im);
	box gt_box;
	for (int i = 0; i < n_gt; i++)
	{
		gt_box.x = gt[i].x * w;
		gt_box.y = gt[i].y * h;
		gt_box.w = gt[i].w * w;
		gt_box.h = gt[i].h * h;

		int class_index = gt[i].id;

		draw_bbox(tmp_img, gt_box, 6, 1.0, 1.0, 1.0);
	}
#endif

	//int n_object_box = nms_sort_hard_negative(object_box_score, l.w*l.h*l.n, 1.7);
	int n_object_box = l.w*l.h*l.n;

	int ttt = 0;
	for (box_id = 0; box_id < n_object_box; box_id++)
	{
		int index = object_box_score[box_id].index;
		float scale = object_box_score[box_id].probs;
		boxes[index] = object_box_score[box_id].bb_box;
		boxes[index].x *= w;
		boxes[index].y *= h;
		boxes[index].w *= w;
		boxes[index].h *= h;

		int class_index = index * (l.classes + 5) + 5;

#if 0 //gt
		if (scale > thresh)
		{
			box im_bb = boxes[index];
			r += 23;
			g += 37;
			b += 49;
			float fr = r % 256;
			float fg = g % 256;
			float fb = b % 256;
			draw_bbox(tmp_img, im_bb, 1, fr / 255, fg / 255, fb / 255);
			//printf("%f %f %f %f scale = %f \n", im_bb.x, im_bb.y, im_bb.w, im_bb.h, scale);
		}
#endif

		for (int j = 0; j < l.classes - BACKGROUND_CLASS; ++j)
		{
#if 1
			float prob = scale*predictions[class_index + j];

			/*if (prob > 0.1)
			{
			printf("%f %f %f %f %f %f\n", boxes[index].x, boxes[index].y, boxes[index].w, boxes[index].h, scale, predictions[class_index + j]);
			}
			ttt++;*/
			probs[index][j] = (prob > thresh) ? prob : 0;
			//probs[index][j] = (scale > thresh) ? scale : 0;
			//probs[index][j] = (scale > thresh) ? predictions[class_index + j] : 0;

#else
			if (scale > 0.5)
			{
				probs[index][j] = (predictions[class_index + j] > thresh) ? predictions[class_index + j] : 0;
			}
			else
			{
				probs[index][j] = 0;
			}
#endif
		}
	}
#if 0
	show_image(tmp_img, "tmp_img");

	free_image(tmp_img);
#endif

	free(object_box_score);
}

void _get_region_detections(layer l, int w, int h, int netw, int neth, float thresh, detection *dets)
{
	int i, j, n, z;
	float *predictions = l.output;
	for (i = 0; i < l.w*l.h; ++i) {
		int row = i / l.w;
		int col = i % l.w;
		for (n = 0; n < l.n; ++n) {
			int index = n*l.w*l.h + i;
			for (j = 0; j < l.classes; ++j) {
				dets[index].prob[j] = 0;
			}
			int index2 = i*l.n + n;
			int obj_index = index2 * (l.classes + 5) + 4;
			//int obj_index = entry_index(l, 0, n*l.w*l.h + i, l.coords);
			//int box_index = entry_index(l, 0, n*l.w*l.h + i, 0);
			float scale = l.background ? 1 : predictions[obj_index];
			dets[index].objectness = scale > thresh ? scale : 0;
			if (scale > thresh)
			{
				dets[index].objectness = scale;
			}
			else
			{
				dets[index].objectness = 0;
				continue;
			}
			int box_index = index2 * (l.classes + 5);
			dets[index].bbox = get_region_box(predictions, l.biases, n, box_index, col, row, l.w, l.h, 1);

			int class_index = index2 * (l.classes + 5) + 5;
			//int class_index = entry_index(l, 0, n*l.w*l.h + i, l.coords + !l.background);
			if (dets[index].objectness) {
				for (j = 0; j < l.classes - BACKGROUND_CLASS; ++j) {
					int class_index = index2 * (l.classes + 5) + 5;
					//int class_index = entry_index(l, 0, n*l.w*l.h + i, l.coords + 1 + j);
					float prob = scale*predictions[class_index + j];
					dets[index].prob[j] = (prob > thresh) ? prob : 0;
				}
			}
		}
	}
	correct_region_boxes(dets, l.w*l.h*l.n, w, h, netw, neth);
}

#ifdef GPU
void forward_region_layer_gpu(const layer l, network net)
{
	/*float *cpu_test = calloc(l.batch*l.inputs, sizeof(float));
	cuda_pull_array(net.input_gpu, cpu_test, l.batch*l.inputs);
	int test = 0;*/

	copy_gpu(l.batch*l.inputs, net.input_gpu, 1, l.output_gpu, 1);
	int b, n;
	for (b = 0; b < l.batch; ++b)
	{
		for (n = 0; n < l.n; ++n)
		{
			int index = entry_index(l, b, n*l.w*l.h, 0);
			activate_array_gpu(l.output_gpu + index, 2 * l.w*l.h, LOGISTIC);
			if (l.coords > 4)
			{
				index = entry_index(l, b, n*l.w*l.h, 4);
				activate_array_gpu(l.output_gpu + index, (l.coords - 4)*l.w*l.h, LOGISTIC);
			}
			index = entry_index(l, b, n*l.w*l.h, l.coords);
			if (!l.background)
				activate_array_gpu(l.output_gpu + index, l.w*l.h, LOGISTIC);
		}
	}

	if (l.softmax_tree)
	{
		int index = entry_index(l, 0, 0, l.coords + 1);
		softmax_tree(net.input_gpu + index, l.w*l.h, l.batch*l.n, l.inputs / l.n, 1, l.output_gpu + index, *l.softmax_tree);
	}
	else if (l.softmax)
	{
		int index = entry_index(l, 0, 0, l.coords + !l.background);
		softmax_gpu(net.input_gpu + index, l.classes + l.background, l.batch*l.n, l.inputs / l.n, l.w*l.h, 1, l.w*l.h, 1, l.output_gpu + index);
	}

	flatten_gpu(l.output_gpu, l.h*l.w, l.n*(l.coords + l.classes + 1), l.batch, 1, net.workspace);
	copy_gpu(l.batch*l.outputs, net.workspace, 1, net.output_gpu, 1);

	if (!net.train || l.onlyforward)
	{
		cuda_pull_array(net.output_gpu, l.output, l.batch*l.outputs);
		return;
	}

	cuda_pull_array(net.output_gpu, net.input, l.batch*l.inputs);
	forward_region_layer(l, net);

	if (!net.train)
		return;

	cuda_push_array(l.delta_gpu, l.delta, l.batch*l.outputs);
}

void backward_region_layer_gpu(const layer l, network net)
{
	flatten_gpu(l.delta_gpu, l.h*l.w, l.n*(l.coords + l.classes + 1), l.batch, 0, net.delta_gpu);
}
#endif

void zero_objectness(layer l)
{
	int i, n;
	for (i = 0; i < l.w*l.h; ++i)
	{
		for (n = 0; n < l.n; ++n)
		{
			int obj_index = entry_index(l, 0, n*l.w*l.h + i, l.coords);
			l.output[obj_index] = 0;
		}
	}
}