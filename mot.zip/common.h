#pragma once
#include "opencv2/core/core.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/imgcodecs/imgcodecs.hpp"
#include "opencv2/highgui/highgui.hpp"

//tensorRT
#include "class_detector.h"

//KAI POC
#define KAI_POC_MODE				0

#if KAI_POC_MODE
#define ITEM_CLASS_ID				0
#define PERSON_CLASS_ID				1
#define HAND_CLASS_ID				2
#endif

#define RUN_MODE 0 //[0]UniTraffic 
#if( RUN_MODE == 0)
#define INI_NAME				TEXT("MainCam") //SMARTFACTORY_INI_NMAE
#define	PROGRAM_TITLE			TEXT("UniTraffic")
#define STATUS_BAR_TEXT			TEXT("Unisem")
#define	PROGRAM_LOG_PREFIX		TEXT("MainCam")
#define RTSP_PORT_NUM			8801
#endif                    

#define	UDWM_PROGRAM_STATUS3	WM_APP + 905	//Cam1
#define SEND_ALIVE_MESSAGE		UDWM_PROGRAM_STATUS3

#define CUDA_GPU_ENABLE					0

//automatic incident detection system (AIDS)
#define ITS_MODE						0  //[0]not use [1]KITS-outbreak
#if ITS_MODE == 1
	#define PEDESTRIAN_CLASS_ID			4
	#define ITS_DEBUG					1  //save 2 images to debug	
    #define SPEED_STATS_PERIOD			30 //calculate average speed after each period
	//#define ITS_CROP_SHOW
#else
	//Daeju
	#define VDS_MODE					1
#endif

// === [Daeju] Enable KITS pedestrian/stop/illegal-parking features in VDS build ===
#define VDS_USE_ITS_FEATURES			1   //[0]disable [1]enable selected KITS features in VDS build

#if (ITS_MODE == 1) || (VDS_MODE == 1 && VDS_USE_ITS_FEATURES == 1)
	#define KITS_FEATURES_ENABLED		1
#else
	#define KITS_FEATURES_ENABLED		0
#endif

#if KITS_FEATURES_ENABLED == 1 && ITS_MODE == 0
	#ifndef PEDESTRIAN_CLASS_ID
		// [Daeju] Map to cls_human enum (defined later in this file).
		// In ENGINE_MODE=0 cls_human==10, in ENGINE_MODE=1 cls_human==7.
		// Token substitution; cls_human is in scope at use site (violation_process.cpp).
		#define PEDESTRIAN_CLASS_ID		cls_human
	#endif
	#ifndef ITS_DEBUG
		#define ITS_DEBUG				0
	#endif
	#ifndef SPEED_STATS_PERIOD
		#define SPEED_STATS_PERIOD		30
	#endif
#endif

//Daeju
#if VDS_MODE == 1
	#define VDS_LEFT_SIDE				1 //����
	#define VDS_RIGHT_SIDE				2 //����
    #define ROAD_LINE_MAX				8
	#define PROOF_IMAGE_DEBUG			0 //dont save image
	#define PROOF_REVERSE_IMAGE_DEBUG	0 //dont save image
	
    // for transfering
	#define PUSH_STANDBY				0
	#define PUSH_PREPARED				1
	#define PUSH_DONE					2

	#define LINE_DETERMINE				1

	struct sVehicleGap
	{
		int hasGap;
		long endTime;
		float fLength;
		float fSpeed;
	};
	enum eRoadboxPoint { lt = 0, rt, lb, rb	};
	struct sRoadbox
	{
		int use;
		cv::Point point[4];
		sVehicleGap gapData;
	};
	
#endif

#if ITS_MODE == 1 || VDS_MODE == 1
	#define XYCOOR_MODE						
	#define SPEED_KOREA_EXPRESSWAY_MODE			0 // [0]VDS Test [1]SpeedCheck as LpTrigger

	//#define SPEED_STATS_PERIOD			8 //calculate average speed after each period

	#if SPEED_KOREA_EXPRESSWAY_MODE == 1
		#define ENGINE_MODE							1	//[0] UniTraffic Model. [1] �̷��� bg Engine
	#else
		#define ENGINE_MODE							0	//[0] UniTraffic Model. [1] �̷��� bg Engine
	#endif
#endif


#define MAX_PTROAD						17
#define LPR_Y_PAD						20

//20190108 VietNam/Indo
#define COUNT_MODE_COUNTRY				0	//0: VIETNAM; 1: INDO
#define RADAR_INUSED					0	//using Radar
#define RADAR_FIRMWARE_UPDATED			1
#define HEAD_SCORE_THRESH				0.5

#define MAX_CAMERA_NUM					32
#define MAX_PTLINE						12		//number of points for ROI
#define MAX_TRACK						200		//maximum number of objects in one image
#define MAX_TRACK_COUNT					150		//20190406
#define MAX_FRAME_NUM					15		//2018.10.12 hai
#define MAX_SUB_BOX						10		//2018.10.12 hai
#define MIN_TRACK_COUNT					5


#define VIDEOLIST_MODE						0	//0: Camrea/videofile; 1: videolist
#define TENSORFLOW_CLASSIFY_USE				0
#define SHOW_AS_SIMPLE						1	//20191008 for drawbox as simple
#define SAVE_TOUCHED						0	//0: dont save, 1: save

//20200128 BacNinh
#define SIGNAL_VIOLATION_UPDATED			1	//0: basic [go straight]; 1: updated [BacNinh] 
#define SIGNAL_VIOLATION_2LINES_TOUCHED		1   //1: 2 lines; 0: just stop line


//violation code
#define AUTOBIKE_VIOLATION_CODE		00
#define SPEED_VIOLATION_CODE		01
#define SIGNAL_VIOLATION_CODE		02
#define LANE_VIOLATION_CODE			03
#define DIRECTION_VIOLATION_CODE	03 //20200128 BacNinh
#define REVERSE_VIOLATION_CODE		04 //20190523 hai reverse violation
#define ILLEGALPARKING_CODE			20
#define ACCIDENT_CODE				21
#define TRACKING_CODE				30 //20191127 hai tracking

//20190222 hai Violation color
#define BIKE_VIOLATION_CLR			0
#define SIGNAL_VIOLATION_CLR		1
#define OVER_SPEED_CLR				2
#define LOW_SPEED_CLR				3
#define LANE_VIOLATION_CLR			4
#define	ILLEGAL_PARKING_CLR			5
#define ACCIDENT_CLR				6
#define REVERSE_VIOLATION_CLR		7
#define TRACKING_CLR				8
#define PEDESTRIAN_VIO_CLR			9


//20200115 violation counting
#define AUTOBIKE_VIOLATION_CNT		0
#define SPEED_VIOLATION_CNT			1
#define SIGNAL_VIOLATION_CNT		2
#define LANE_VIOLATION_CNT			3
#define REVERSE_VIOLATION_CNT		4
#define ILLEGALPARKING_CNT			5
#define ACCIDENT_CNT				6
#define TRACKING_CNT				7
#define PEDESTRIAN_CNT				8


#define SECONDS_PER_ONE_MINUTE		60 //20190801 Indonesia POC
//#define SECONDS_PER_ONE_MINUTE		10
//#define LIMITED_WIDTH				120 //20190801 Indonesia POC
//#define LIMITED_HEIGHT				220 //20190801 Indonesia POC
#define LIMITED_WIDTH				700 
#define LIMITED_HEIGHT				480 


#define JPG_SAVE_ENABLE				1
//Bajaj Ba Gac img_count //20190406

#define RIGHT_VIOLATION_AREA		0	//from center line 0-2
#define LEFT_VIOLATION_AREA			1	//from center line 0-2
#define NO_VIOLATION_AREA			2
#define NO_DEFINE_AREA				3
#define RELEASE_LANE_VIO			4	// 2018.11.09 hai
#define RIGHT_CENTER_LANE_VIO		5	//from center line 0-2
#define LEFT_CENTER_LANE_VIO		6	//from center line 0-2

//20200128 BacNinh
#define ENTRY_START					1
#define EXIT_START					2

#define LANE_LEFT					1
#define LANE_CENTER_1				2    
#define LANE_CENTER_2				3    
#define LANE_RIGHT					4

#define UPDATED_LEFT_OUTSIDE_ROI	1
#define UPDATED_RIGHT_OUTSIDE_ROI	2
#define UPDATED_VIOLATION_AREA		3

#define GAP_Y_VIO					50		

#define CHECK_SIGNAL_VIO			0
#define CHECK_SIGNAL_CNT			1

#define CHAR_LENGTH					255
#define TIME_BUFF_LENGTH			80

/////////////common

#define PRINT_LOG_DEBUGGING			0
//#define ANOTHER_PROCESS				2 // [0]:opencv on UniTraffic, [1]UniConnection, [2]Live555&nvDec
#define RADAR_TIMER					803

#define	ALIVE_OBSERVER				WM_APP + 10001 // postmessage to Observer
#define	ALIVE_OBSERVER_RESARTED		WM_APP + 10002 // postmessage to Observer, viewer is restarting

//new param for tensorRT
#define TENSORRT_ENGINE_LOADED			1
#define UNRECOGNIZED_PRECISION_TYPE		-1
#define NOTSUPPORTED_PRECISION_TYPE		-2 
#define UNUSED_WEIGHT_LEFT				-3
#define INVALID_WEIGHT_OR_NOTFOUND		-4
#define INVALID_CALIBRATOR_INT8			-5
#define NOIMGFILE_FOR_CALIBRATION		-6
#define NOTMATCH_CFGFILE_ENFINE			-7
#define FAIL_TOBUILD_ENGINE				-8
#define INVALID_BUILT_ENGINE			-9
#define UNSUPPORTED_LAYER_TYPE			-10

#define CAMMAX_NUM					32
#define CAMGROUP_NUM				32
#define GPUNUM_MAX					16

#define BOX_IOU_THRESH				0.45

#define NUM_STREAM_MAX				8

#define IMG_CAM_MAX					NUM_STREAM_MAX
#define IMG_TEN_MAX					NUM_STREAM_MAX * 2

#define DIRECT_X_INUSED				0


enum eClassid
{
	// LP engine cannot detect small car. bg engine cannot detect large autobike
	// use COMMON UniTraffic engine (vietnam, indonesia, korea) for now
#if ENGINE_MODE == 1
	cls_car = 0		//// [---> for LP Engine]
	, cls_ban
	, cls_bus
	, cls_truck
	, cls_bike
	, cls_helmet
	, cls_head
	, cls_human
	, cls_bicycle
	, cls_lpd_1
	, cls_lpd_2
	, cls_lpd_3		// bus
	, cls_lpd_4
	, cls_lpd_5		// truck
	, cls_lpd_6		// truck
	, cls_lpd_7
	, cls_lpd_8
	, cls_lpd_9
	, cls_lpd_10		// bike
	, cls_kickboard
	, cls_total
#elif ENGINE_MODE == 0	
	cls_car					//0
	, cls_ban				//1
	, cls_bus				//2
	, cls_truck				//3
	, cls_bike_front		//4
	, cls_bike_rear			//5
	, cls_bike_side			//6
	, cls_helmet			//7
	, cls_hat				//8
	, cls_head				//9
	, cls_human				//10
	, cls_bicycle			//11
	, cls_truckbike_front	//12
	, cls_truckbike_rear	//13
	, cls_truckbike_side	//14
	, cls_umbrella			//15
	, cls_mobile			//16
	, cls_accident			//17
	, cls_total
#endif
};

typedef struct
{
	char		cfg_full_name[300];
	char		weight_full_name[300];

	int			nPrecison;
	int			nNetType;
	int			nBatchSize;

	int			nGpuId;
	float		thresh;

	bool		doSleep;
	int			queueSizeMax;

	int			cam_run_mode;

	Detector	detector_TRT;
	Config		config_TRT;

}st_param;

typedef struct
{
	cv::cuda::GpuMat g_ImgCamBuff;
	cv::cuda::GpuMat g_ImgResize;
	std::vector<Result> res_detect;
	int		nCamIndex = -1;
	float fDeltaTime;
	unsigned long long timestamp;
	int nFrames;
#if ITS_MODE == 1
#ifdef ITS_CROP_SHOW
	cv::cuda::GpuMat gImage_roicrop; //if GPU Memory not enough, do comment
#endif
	cv::Rect roi_lefttop;
#endif
}st_tensor_data;


typedef struct
{
	cv::cuda::GpuMat gImage;
	unsigned long long timestamp;
	int nFrames;
#if ITS_MODE == 1
	cv::cuda::GpuMat gImage_roicrop;
	cv::Rect roi_lefttop;
#endif
}st_queue_time;


typedef struct
{
	int class_id;
	int track_id;
	int n_person;
	int n_person_helmet;
	int max_rider_violation;
	int helmet_violation;
	char vio_type[5];
	cv::Rect bouding_box;

	// 2018.09.27 hai
	int umbrella_violation;
	int mobile_violation;

	cv::Rect Um_bouding_box;
	cv::Rect Mo_bouding_box;

} st_violation_box_info;

//// 2018.09.03
typedef struct
{
	cv::Rect bouding_box;
	int class_id;
	//float score; //2018.10.12 hai

} st_box_info;

typedef struct
{
	st_box_info head_box_info[MAX_SUB_BOX];
	int n_head_box;

}st_head_box_info;

typedef struct
{
	int n_violation;
	st_violation_box_info violation_box_info[MAX_TRACK];

	st_head_box_info head_box_list[MAX_TRACK];

} st_violation_info;



typedef struct
{
	int n_box;
	cv::Rect bouding_box;
	int class_id;
	int track_id;
	st_box_info head_box_info[MAX_TRACK];
	//st_box_info umbrella_box_info; // 2019.09.27 hai
	//st_box_info mobile_box_info; // 2019.09.27 hai

	//st_box_info mobile_box_info[MAX_TRACK]; //2018.07.30 using mobile

} st_biker_box_info;



//// 2018.09.03
typedef struct
{
	st_head_box_info head_box_list[MAX_FRAME_NUM];
	cv::Rect bouding_box[MAX_FRAME_NUM];

	int n_box_list[MAX_FRAME_NUM];
	int n_box_idx;
	int n_min_rider_idx;

	//2018.10.12 hai
	float mean_score[MAX_FRAME_NUM];
	int n_rider_histogram[MAX_SUB_BOX];
	int n_his_rider;
	int n_his_rider_index;

	st_box_info umbrella_box_info;
	st_box_info mobile_box_info;

	//2018.10.12 hai
	int nIsUmbrella;
	int nIsMobile;

	cv::Mat vio_image[MAX_FRAME_NUM]; // 2018.10.26

										//2018.10.24 hai
										//int bOverlap[MAX_FRAME_NUM];

}st_sub_box_info;

typedef struct
{
	int n_biker_box;
	st_biker_box_info biker_box_info[MAX_TRACK];

	int rider_violation_confirm[MAX_TRACK];  ////=== hai edited ===////
	int helmet_violation_confirm[MAX_TRACK];  ////=== hai edited ===////

	int TO_violation[MAX_TRACK];
	int umbrella_violation_confirm[MAX_TRACK]; // 2018.09.27 hai
	int mobile_violation_confirm[MAX_TRACK]; // 2018.09.27 hai
	int violation_confirm[MAX_TRACK]; // 2018.10.22 hai

	int n_touched_count[MAX_TRACK]; //200309 hai

} st_biker_info;


typedef struct
{
	int id = -1;
	float prob = 0.0f;
	cv::Rect rect = cv::Rect(0, 0, 0, 0);
}sObjectInfo;


typedef struct
{
	int n_head_box = 0;   // count for head/helmet/hat
	int n_helmet_box = 0; // count for helmet
	std::vector<sObjectInfo> head;
	sObjectInfo plate;
}sObject;


typedef struct
{
	float fDis_plate_top = 0.0f;
	float fDis_plate_bot = 0.0f;
}st_plate_dis;


typedef struct
{
	cv::Rect bouding_box;
	int class_id;
	float score;
	int class_group_id;

	sObject object_info;

} st_det_box_info;

typedef struct
{
	cv::Rect bouding_box;
	int track_id;
	int class_id;
	int class_group_id;
	int n_sub_box;

	st_box_info sub_box_info;

	////2018.10.12 hai
	//st_box_info umbrella_box_info;
	//st_box_info mobile_box_info;

	float mean_score;
	int track_state;

#if ENGINE_MODE == 1
	sObject object_info;
#endif

} st_mot_box_info;


typedef struct
{
	int n_track_num;
	int n_detect_num;
	int *object_flow_number;
	int *object_flow_total;
	int *object_flow_number_out; //skkang to sepertate counitng each direction
	int *object_flow_total_out;
	int b_counted[MAX_TRACK];
	int n_violated[MAX_TRACK];

	st_mot_box_info mot_box_info[MAX_TRACK];
	st_det_box_info det_box_info[MAX_TRACK];

	float s_thresh;

	int object_confirm[MAX_TRACK];  ////=== hai edited ===////
	int TO_object[MAX_TRACK];

	//for topline count //yk 2018.12.03
	int *object_flow_number_forTopline;
	int b_counted_forTopline[MAX_TRACK];
	int object_confirm_forTopline[MAX_TRACK];  ////=== hai edited ===////
	int TO_object_forTopline[MAX_TRACK];

} st_mot_info;


typedef struct
{
	cv::Mat img[2];
	cv::Rect rect[2];
	cv::Rect plate_rect[2];
}st_object_pairs;

typedef struct
{
	int nDataSave;
	int nTrackCount;
	int nIsRedSignal;
	cv::Mat pIplImage;
	cv::Mat pIplImageParkingStart;
	char timeStr[MAX_TRACK_COUNT][80];
	cv::Point track_pt[MAX_TRACK_COUNT];
	cv::Rect track_box[MAX_TRACK_COUNT];
	long diffTime[MAX_TRACK_COUNT];
	long parkingTime; //20190213 hai Parking
	int bCheckAccident;
	int bSaveAccident;
	int nVioDisplay[PEDESTRIAN_VIO_CLR + 1]; //20190222 hai Violation color

	char textViolationInfo[CHAR_LENGTH]; //20191008 for save object's violation
	float fRadarSpeed[MAX_TRACK_COUNT];	//20191210

	float fMeanRadarSpeed;
	float fTotalRadarSpeed;
	int nRadarCount;

	//20200128 BacNinh
	int nIsExitStart;
	cv::Mat pIplImageSLStart; //20200128 BacNinh - Signal/Lane
	int nIsLeftRedSignal;
	int nLaneNumber;
	int nTouchedTop;
	int nTouchedLeft;
	int nTouchedRight;
	int bSaveSignal;
	int bSaveLane;

	int bCheckGreenSignal;

#if KITS_FEATURES_ENABLED == 1
	// stop
	int bStoreImage;
	int nStopResetCnt;
	int nStopVioCnt;
	int nStopZeroCnt;
	long stopTime;

	//pedestrian
	int nPedestVioCnt;
	int nPedestResetCnt;
	int nPedestViolation;
	long appearTime;

#endif

#ifdef XYCOOR_MODE
	//X and Y calculation
	std::vector<float> nXYCOOR_distanceY;
	std::vector<float> nXYCOOR_distanceX;
	std::vector<unsigned long long> nXYCOOR_time;
	std::vector<float> nXYCOOR_fSpeed;
	std::vector<float> nXYCOOR_deltaTime;
	float fXYCOOR_speed;
	float fXYCOOR_speed_display;
	float fXYCOOR_deltaTime;
#endif
	
#if VDS_MODE == 1
	long nVDS_startTime;
	long nVDS_endTime;
	bool bVDS_started;	
	bool bVDS_ended;
	bool bVDS_started_setdone;
	bool bVDS_ended_setdone;
	int nVDS_laneNum;
	int nVDS_laneNum_temp;
	int nVDS_direction;
	//for start time
	float fVDS_ST_distanceY;		//ST: start-top of object bbox
	float fVDS_ST_distanceX;
	float fVDS_SB_distanceY;		//SB: start-bottom of object bbox
	float fVDS_SB_distanceX;
	float fVDS_carLength;
	float fVDS_carHeight;
	float fVDS_carSpeed;
	float fVDS_ocpTime;
	int nVDS_vehicleGap;

#if SPEED_KOREA_EXPRESSWAY_MODE == 1
	bool bVDS_center;
	int nVDS_center_setdone;

	float fSpeed_Center[5];
	float fDistance_Center_start[5];
	float fDistance_Center_end[5];
	float fTime_Center[5];
	
	std::vector<cv::Mat> track_image;
	std::vector<cv::Rect> track_rect;
	std::vector<cv::Rect> track_plate_rect;
	std::vector<st_plate_dis> fXYCOOR_distancePlate;
	
	st_object_pairs image_pairs[3];
	st_plate_dis fDis_plateStart[3];
	st_plate_dis fDis_plateEnd[3];
	float fSpeed_Plate[3];
	float fSpeed_Plate_fix_start[3];
	float fSpeed_Plate_fix_end[3];
	float fSpeed_Final = -1.0f;
#endif

	float fVDS_cosAngle;
	float fVDS_carTotalWidth;

	cv::Mat iVDS_startImg;
	int nVDS_pushStatus;
#endif

} st_mot_DataSave;


typedef struct
{
	int nLane;
	int nDirection;
	char tDetect[50];
	float fSpeed;
	int nOccupancyTime;
	int nCarLength;
}st_VDSData;

typedef struct  //// 2018.07.27
{
	int nLightViolation;
	int nLightTouch;
	int nPassLine;
	cv::Rect object_box;
	cv::Mat pIplImage;
	long diffTime;
} st_light_DataSave;


typedef struct  //// 2018.07.27
{
	cv::Rect LPRect;
	cv::Mat pIplImage, pLPImage;
	long lprTime, startTime, catchTime, endTime; //// 2018.09.03
	int nLaneVioCnt;
	int nLaneViolation;
	int nLPR;
	int nTrackCount;
	cv::Point PtTrackTop, PtTrackBot, PtTrackTopCen, PtTrackBotCen;
	cv::Rect rtTrackStart, rtTrackEnd;	//2018.10.26 Young
	int nTouchTop, nTouchBot;
	char save_LPimage_coordinate[CHAR_LENGTH];
	int nStartStatus, nEndStatus;

	int nFirstClass;

} st_lane_DataSave;


typedef struct  //20190523 hai reverse violation
{
	cv::Rect LPRect;
	cv::Mat pIplImage, pLPImage;
	long lprTime, startTime, catchTime, endTime; //// 2018.09.03
	int nReverseVioCnt;
	int nReverseViolation;
	int nLPR;
	int nTrackCount;
	cv::Point PtTrackTop, PtTrackBot, PtTrackTopCen, PtTrackBotCen;
	cv::Rect rtTrackStart, rtTrackEnd;	//2018.10.26 Young
	int nTouchTop, nTouchBot;
	char save_LPimage_coordinate[CHAR_LENGTH];

	int nFirstClass;

#if ITS_MODE == 1 || VDS_MODE == 1
	int bStoreImage;
	int nReverseResetCnt;
#endif

} st_reverse_DataSave;



//from common

typedef struct {
	char **names;
	float nms;
	//image **alphabet;		//20190715
	//network net;

	//layer l;
	//box *boxes;

	//Detector detector_TRT;
	//Config config_TRT;

	int nDisplayH;
	int nDisplayW;

	int nLclasses;

	//float **probs;

	cv::Scalar track_color[MAX_TRACK];
	cv::Scalar class_color[cls_total]; //20190222 hai Class color
	cv::Scalar vio_color[cls_total]; //20190222 hai Class color
	st_mot_info *mot_info;

	FILE *fp_count;
	char fp_count_end_name[300];
	char full_stats_file_path[300];
	char full_stats_file_path_temp[300];
	char timeBuf[80];

	char camera_addr[300];
	int camera_fps;
	char camera_id[100];
	char stats_result_path[300];
	char vio_result_path[300];
	char viewer_event_path[300]; //20190716 Viewer Event
	char statics_duration[5];

	int channel_id;

	int show_det_on;
	int show_mot_on;
	int show_vioInfo_on;
	int statics_as_direction;//[0] total, [1] seperate each direction(Mavens)

	float bottom_rate;
	float top_line;	//kyk 20180606

	float fRealDistance;
	float fViolationSpeed;
	float fMinimumSpeed;	//20190213 hai Minimum Speed
	int	  nIllegalTime;		//20190213 hai Parking
	float fCamHeight;		//kyk 20180713
	float fLengthLow;
	float fLengthHigh;

#ifdef XYCOOR_MODE
#if SPEED_KOREA_EXPRESSWAY_MODE == 1
	float fLengthCen;
	float fX_RightMid, fX_RightLeft;
#else
	float fStart_YBot, fStart_YCenter, fStart_YTop;
	float fPole_XLeft, fPole_XCenter, fPole_XRight;
#endif
#endif

	cv::Point ptLine[MAX_PTLINE];      // 2018.08.08
	cv::Rect rtSignalArea[3]; //20191212 skkang red,green,yellow
	cv::Rect rtLeftRedSignalArea;	//20200131
	int nCheckSignalViolation;
	int nCheckPassedTracking;
	int nCheckLaneViolation;
	int nCheckSpeedViolation;
	int nCheckBikeViolation;
	int nCheckReverseViolation;
	int nReverseDirection;

	//KAI POC
#if KAI_POC_MODE
	cv::Rect rtWorkPlace[2];
	char item_name[2][300];
#endif

	//20200128 BacNinh
	int nCheckLeftDirection;
	int nCheckRightDirection;

	int nCamNumber;
	int nWindowXPostion;
	int nWindowYPostion;

	cv::Point ptROI[4]; //20190213 hai Parking
	cv::Point ptAREA[7]; //20190213 hai Parking
	
	//RADAR
	//Radar 191205 hai
	//float fReal_M0;
	//float fReal_M2;
	float fReal_L1;
	float fReal_L3;
	float fReal_R4;
	float fReal_R5;
	int nRadarDelayTime;
	char strRadarIP[300];
	int nCheckRadarInUsed;

	int max_rider;
	int n_vio_confirm;


	int *class_group_id;
	int n_vio_head_class;
	int *vio_head_class;
	int rear_biker_id;
	int biker_group_id;
	int head_group_id;
	float head_nms;

	// 2018.09.27 hai
	int umbrella_group_id;
	int mobile_group_id;
	int vio_umbrella_class;
	int vio_mobile_class;

	st_mot_DataSave mot_DataSave[MAX_TRACK];	////=== hai edited ===////
	st_light_DataSave mot_LightSave[MAX_TRACK]; //// 2018.07.27

	st_lane_DataSave mot_LaneSave[MAX_TRACK]; //// 2018.07.31

	st_reverse_DataSave mot_ReverseSave[MAX_TRACK]; //20190523 hai reverse violation

	st_sub_box_info sub_box_list[MAX_TRACK];	//// 2018.09.03

	st_box_info umbrella_box_info[MAX_TRACK]; // 2018.09.27 hai
	st_box_info mobile_box_info[MAX_TRACK]; // 2018.09.27 hai

	int nOperationMode; //2018.10.31 Young
	int nCameraIndex;

	//ITS
	cv::Point ptRoad[MAX_PTROAD];    
	
#if SPEED_KOREA_EXPRESSWAY_MODE == 1
	cv::Point ptXspeed[5];
	int n_speed_period = 5;
#else
	// X and Y vanishing
	cv::Point ptVanish[7];
	cv::Point ptXspeed[5];
	int n_speed_period = 5;
#endif

#if VDS_MODE == 1
	int l_box_max;
	sRoadbox l_box[ROAD_LINE_MAX];
	int r_box_max;
	sRoadbox r_box[ROAD_LINE_MAX];
#endif
} st_det_mot_param;



#ifdef __cplusplus
extern "C" {
#endif

	//extern int tracking_function(Mat image, int num, box *boxes, float **probs, int classes, st_mot_info *mot_info, st_sub_box_info *sub_box_list); //// 2018.09.03
	extern int tracking_function(int nCameraIndex, cv::Mat& image, st_mot_info *mot_info, st_sub_box_info *sub_box_list, st_biker_info *biker_info, st_mot_DataSave *mot_datasave, st_det_mot_param *param, float fXratio, float fYratio); //// 2018.09.03
	extern int get_current_data_time(char *buff, char *type);
	extern int Osan_get_current_data_time(char *buff, char *type);
	//extern void object_flow_count(st_mot_info *mot_info, int num, int n_class, int reset, int line); //20190102 VN
	//extern void object_flow_count_Indo(Mat image, st_det_mot_param *param, st_mot_info *mot_info, int num, int n_class, int reset, int line, CRegion* pRegion); // 20190102 Indo
	//extern void object_flow_count_Osan(Mat image, st_mot_info *mot_info, int num, int n_class, int reset, int line); // 2018.12.13 Osan CCTV
	//extern void object_flow_count_forTopline(st_mot_info *mot_info, int num, int n_class, int reset, int line);
	//extern void object_flow_draw(Mat image, st_mot_info *mot_info, int num, char **names, int line, Mat  img_count);
	//extern void object_flow_draw_forTopline(Mat image, st_mot_info *mot_info, int num, char **names, int line);
	//extern void object_flow_save(FILE *fp, st_mot_info *mot_info, int num, int ch_id, char *time);
	extern void _do_group_nms_sort(st_det_mot_param *param);
	//extern void violation_text_display(Mat image, st_det_mot_param *param, int ntrack, int nTrackID);
	extern void release_trackingdata(int nCameraIndex);
	extern void initial_trackingdata(int nCameraIndex);


	extern void assign_object_info(sObject& return_info, sObject& object_info);
	extern void release_object_info(sObject& return_info);


#ifdef __cplusplus
}
#endif


//////int tracking_function(Mat image, int num, box *boxes, float **probs, int classes, st_mot_info *mot_info, st_sub_box_info *sub_box_list); //// 2018.09.03
////int tracking_function(Mat image, int num, box *boxes, float **probs, int classes, st_mot_info *mot_info, st_sub_box_info *sub_box_list, st_biker_info *biker_info, st_mot_DataSave *mot_datasave, st_det_mot_param *param); //// 2018.09.03
////void roi_score_probability(vector<float> &roi_score, float score_sum);
////Rect convert_rectf_to_rect(Rect_f rect_f);
////Rect_f convert_rect_to_rect_f(Rect rect);
////void get_track_channel_image(Mat &image, Mat *ch_image, st_feature &feature);
////int get_current_data_time(char *buff, char *type);
////int Osan_get_current_data_time(char *buff, char *type);
//
//#ifdef GPU
////void feature_calculate(int n_channel, int image_size, float* feature, float sum);
//void unisem_gpu_calcFeature(int n_channel, int image_size, float sum, float *feature);
//#endif