#include "argv.h"

int argv_setting(char **argv)
{
	int argc;
	argc = 1;

#if	  0
	argv[argc++] = "detector";
	argv[argc++] = "train";
	argv[argc++] = "D:/Database/7) deep_learning/UNISEM/UNISEM11.data";
	argv[argc++] = "D:/Darknet/cfg/YOLO2_v2_43_UNISEM_11class_ExtendNet.cfg";
	argv[argc++] = "D:/Darknet/weights/darknet19_448/coco5.b8.200000.21";
	//	argv[argc++] = "D:/Darknet/weights/YOLO2_v2_41_MOT_DET_ExtendNet/YOLO2_v2_41_MOT_DET_ExtendNet.weights";
	argv[argc++] = "-gpus";
	argv[argc++] = "0,1,2";
	return argc;

#elif	1
	argv[argc++] = "detector";
	argv[argc++] = "test_iter";
	argv[argc++] = "D:/Database/7) deep_learning/COCO/class5.data";
	argv[argc++] = "D:/Darknet/cfg/YOLO2_v2_43_UNISEM_11class_ExtendNet.cfg";
	argv[argc++] = "D:/Darknet/weights/YOLO2_v2_43_UNISEM_11class_ExtendNet/YOLO2_v2_43_UNISEM_11class_ExtendNet";
	argv[argc++] = "-iter";
	argv[argc++] = "8000,1000,8000";
	return argc;

#elif	0
	argv[argc++] = "convert";
	argv[argc++] = "D:/Darknet/cfg/layer30_pre23_kitti_label3.cfg";
	argv[argc++] = "D:/Darknet/weights/layer30_pre23_kitti_label3/layer30_pre23_kitti_label3_200000.weights";
	argv[argc++] = "-bytes";
	argv[argc++] = "3";
	return argc;

#elif	0
	argv[argc++] = "classifier";
	argv[argc++] = "train";
	argv[argc++] = "D:/Database/7) deep_learning/imagenet/imagenet.data";
	argv[argc++] = "D:/Darknet/cfg/darknet19_448.cfg";
	argv[argc++] = "D:/Darknet/weights/darknet19_448/darknet19_448.weights";
	argv[argc++] = "-clear";
	return argc;

#elif	0
	argv[argc++] = "classifier";
	argv[argc++] = "valid";
	argv[argc++] = "D:/Database/7) deep_learning/imagenet/imagenet.data";
	argv[argc++] = "D:/Darknet/cfg/darknet19_448.cfg";
	argv[argc++] = "D:/Darknet/weights/darknet19_448/darknet19_448.weights";
	return argc;

#elif	0
	argv[argc++] = "partial";
	argv[argc++] = "D:/Darknet/cfg/YOLO2_v2_2_COCO_train_448_80class_extended.cfg";
	argv[argc++] = "D:/Darknet/weights/YOLO2_v2_2_COCO_train_448_80class_extended/YOLO2_v2_2_COCO_train_448_80class_extended_170000.weights";
	argv[argc++] = "D:/Darknet/weights/darknet19_448/coco.ext.23";
	argv[argc++] = "23";
	return argc;

#elif	0
	argv[argc++] = "ops";
	argv[argc++] = "D:/Darknet/cfg/darknet19_448.cfg";
	return argc;
#endif

	return 0;
}