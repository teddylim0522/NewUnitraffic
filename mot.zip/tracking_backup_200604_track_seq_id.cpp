#include "tracking.h"

st_feature feature;
cl_tracking tracking[MAX_CAMERA_NUM];

int max_index_(float *a, int n)
{
	if (n <= 0) return -1;
	int i, max_i = 0;
	float max = a[0];
	for (i = 1; i < n; ++i)
	{
		if (a[i] > max)
		{
			max = a[i];
			max_i = i;
		}
	}
	return max_i;

}

void initial_trackingdata(int nCameraIndex)
{
	if (!tracking[nCameraIndex].bInitialized)
	{
		tracking[nCameraIndex].initialData();
	}
}

void release_trackingdata(int nCameraIndex)
{
	tracking[nCameraIndex].releaseData();
}


void cl_tracking::initialData()
{
	mkcf_tracker.initialData();

	s_detect = new Detect[MAX_TRACK];
	w_detect = new Detect[MAX_TRACK];
	track = new Track[MAX_TRACK];

	nTrack = 0; n_s_detect = 0; n_w_detect = 0;  nMapping = 0;

	appearance_ch_image = new Mat[APPEARANCE_CHANNEL];

	//int value[3][M = new int[MAX_TRACK];


	for (int i = 0; i < MAX_TRACK; i++)
	{
		textColorTmp[i] = Scalar(rand() % 256, rand() % 256, rand() % 256);
	}

	int test = 0;

	track_init = false;


	for (int i = 0; i < MAX_TRACK; i++)
	{
		//mapping[i] = -1;
	}

	bInitialized = true;
}

void cl_tracking::releaseData()
{
	mkcf_tracker.releaseData();
	bInitialized = false;
	delete[] track;
	delete[] s_detect;
	delete[] w_detect;

	delete[] appearance_ch_image;
}


void mKCF_Track::initialData()
{
	a = new int[10];
	//각 track에 대한 커널 알파 메모리 할당
	ALPHA = new dg_complex *[MAX_TRACK];
	for (int tr = 0; tr < MAX_TRACK; tr++)
	{
		ALPHA[tr] = new dg_complex[FFT_POINT];
	}
	//각 채널에 대한 채널 영상 메모리 할당
	channel_image = new Mat[KCF_TRACK_CHANNEL];

	//각 track, 각 채널에 대한 패치영상메모리 할당
	channel_roi_img = new Mat *[MAX_TRACK];
	for (int tr = 0; tr < MAX_TRACK; tr++)
	{
		channel_roi_img[tr] = new Mat[KCF_TRACK_CHANNEL];
	}

	//채널 roi에 대한 영상 크기 및 타입 초기화
	for (int tr = 0; tr < MAX_TRACK; tr++)
	{
		for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
		{
			channel_roi_img[tr][ch].create(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32F);
		}
	}

	//output 영상에 대한 FFT 영역에서의 메모리 할당
	Y = new dg_complex[FFT_POINT];
	Hann_filter.create(TRACK_SAMPLE_HEIGHT, TRACK_SAMPLE_WIDTH, CV_32F);
	generate_prob_out(Y);
	generate_Hann_filter(Hann_filter);
}

void mKCF_Track::releaseData()
{
	//각 track에 대한 커널 알파 메모리 해제
	for (int tr = 0; tr < MAX_TRACK; tr++)
	{
		delete[] ALPHA[tr];
	}
	delete[] ALPHA;
	//각 채널에 채널 영상 메모리 해제
	delete[] channel_image;
	//각 track, 각 채널에 대한 패치영상메모리 해제
	for (int tr = 0; tr < MAX_TRACK; tr++)
	{
		delete[] channel_roi_img[tr];
	}
	delete[] channel_roi_img;

	//output 영상에 대한 FFT 영역에서의 메모리 해제
	delete[] Y;

	delete[] a;

	if (!Hann_filter.empty())
	{
		Hann_filter.release();
	}
}


int tracking_function(int nCameraIndex, Mat& image, st_mot_info *mot_info, st_sub_box_info *sub_box_list, st_biker_info *biker_info, st_mot_DataSave *mot_datasave, st_det_mot_param *param, float fXratio, float fYratio) //hai 2019.01.14
{
	//vector<Rect_f> roi;
	//vector<float> roi_weight;
	mot_info->s_thresh = DETECT_INIT_LOW;

	Mat gray_image, hsv_image, split_image[APPEARANCE_CHANNEL];

#if 0
	if (mot_info->track_init)
	{
		tracking.track_init = true;
		for (int i = 0; i < tracking.nMapping; i++)
		{
			int id = tracking.mapping[i];
			tracking.terminate(id);
		}

		for (int i = 0; i < MAX_TRACK; i++)
		{
			tracking.track[i].IsActive = FALSE;
		}
	}
#endif
	get_detection_info(nCameraIndex, image, mot_info, fXratio, fYratio);

	Mat left_image = image.clone();

#if CUDA_GPU_ENABLE
	#if ((APPEARANCE_MODEL == 1) ||  (VISUAL_TRACKING == 1))
		Mat gray_image, hsv_image, split_image[APPEARANCE_CHANNEL];

		cv::cuda::Stream stream;
		cv::cuda::GpuMat dst, src, dstSpilt[APPEARANCE_CHANNEL];
		src.upload(left_image, stream);

		cv::cuda::cvtColor(src, dst, CV_BGR2HSV);
		cv::cuda::split(dst, dstSpilt);	

		for (int ch = 0; ch < APPEARANCE_CHANNEL; ch++)
		{
			dstSpilt[ch].download(split_image[ch]);
			tracking[nCameraIndex].appearance_ch_image[ch].create(left_image.rows, left_image.cols, CV_32F);
			split_image[ch].convertTo(tracking[nCameraIndex].appearance_ch_image[ch], CV_32FC1);
		}

	#endif
#else
	#if ((APPEARANCE_MODEL == 1) ||  (VISUAL_TRACKING == 1))
		
		cvtColor(left_image, hsv_image, CV_BGR2HSV);
		cv::split(hsv_image, split_image);

		for (int ch = 0; ch < APPEARANCE_CHANNEL; ch++)
		{
			tracking[nCameraIndex].appearance_ch_image[ch].create(left_image.rows, left_image.cols, CV_32F);
			split_image[ch].convertTo(tracking[nCameraIndex].appearance_ch_image[ch], CV_32FC1);

			//if (!split_image[ch].empty()) split_image[ch].release();
		}			

		

	#endif
#endif

#if VISUAL_TRACKING == 1
		for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
			tracking[nCameraIndex].mkcf_tracker.channel_image[ch].create(left_image.rows, left_image.cols, CV_32F);

		split_image[2].convertTo(tracking[nCameraIndex].mkcf_tracker.channel_image[0], CV_32FC1);

		//	double min_value, max_value;
		for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
		{
			//		minMaxLoc(tracking.mkcf_tracker.channel_image[ch], &min_value, &max_value);
			//		tracking.mkcf_tracker.channel_image[ch] /= max_value;	
			tracking[nCameraIndex].mkcf_tracker.channel_image[ch] /= 255;
			//		tracking.mkcf_tracker.channel_image[ch] = (tracking.mkcf_tracker.channel_image[ch] - min_value)/ (max_value - min_value);
		}

#endif

	tracking[nCameraIndex].state_update(left_image);
	//tracking.display(left_image, track_num, track_id, track_roi);
	//display
	int track_cnt = 0;
	for (int i = 0; i < tracking[nCameraIndex].nMapping; i++)
	{
		printf("[%d]nMapping %d \n", i, tracking[nCameraIndex].nMapping);

		int id = tracking[nCameraIndex].mapping[i];

		if (tracking[nCameraIndex].track[id].state == TRACK_INACTIVE || tracking[nCameraIndex].track[id].state == TRACK_INIT || tracking[nCameraIndex].track[id].state == TRACK_TERMINATE)
			continue;

		tracking[nCameraIndex].track[id].i_prevROI = convert_rectf_to_rect(tracking[nCameraIndex].track[id].f_prevROI);

		CvRect rtOrgBox;
		rtOrgBox.x = (int)((float)tracking[nCameraIndex].track[id].i_prevROI.x * fXratio);
		rtOrgBox.width = (int)((float)tracking[nCameraIndex].track[id].i_prevROI.width * fXratio);
		rtOrgBox.y = (int)((float)tracking[nCameraIndex].track[id].i_prevROI.y * fYratio);
		rtOrgBox.height = (int)((float)tracking[nCameraIndex].track[id].i_prevROI.height * fYratio);
		mot_info->mot_box_info[track_cnt].bouding_box = rtOrgBox;

		mot_info->mot_box_info[track_cnt].track_id			= id;
		mot_info->mot_box_info[track_cnt].class_id			= tracking[nCameraIndex].track[id].class_id;
		mot_info->mot_box_info[track_cnt].class_group_id	= tracking[nCameraIndex].track[id].class_group_id;
		mot_info->mot_box_info[track_cnt].mean_score		= tracking[nCameraIndex].track[id].mean_detect_score;
		mot_info->mot_box_info[track_cnt].track_state		= tracking[nCameraIndex].track[id].state;

		if (tracking[nCameraIndex].track[id].b_checked == false) //track이 초기화되면 false가 됨
		{
			mot_info->b_counted[id] = false;
			tracking[nCameraIndex].track[id].b_checked = true;
			mot_info->n_violated[id] = 0;

			mot_info->b_counted_forTopline[id] = false; //hai 2018.12.03
			//20190214 hai Counting
			mot_info->object_confirm[id] = 0;
			mot_info->TO_object[id] = 0;

			//mot_DataSave
			mot_datasave[id].nDataSave = 0;	
			mot_datasave[id].nTrackCount = 0;	

			//20200128 BacNinh Signal/Lane
			mot_datasave[id].nIsExitStart = 0;
			mot_datasave[id].bSaveLane = 0;
			mot_datasave[id].bSaveSignal = 0;
			mot_datasave[id].nIsRedSignal = 0;
			mot_datasave[id].nIsLeftRedSignal = 0;
			mot_datasave[id].nLaneNumber = 0;
			mot_datasave[id].nTouchedTop = 0;
			mot_datasave[id].nTouchedLeft = 0;
			mot_datasave[id].nTouchedRight = 0;
			mot_datasave[id].bCheckGreenSignal = 0; //200310 check signal violation for 2nd touched line - green signal

			if (!mot_datasave[id].pIplImageSLStart.empty())
			{
				mot_datasave[id].pIplImageSLStart.release();
			}

			//bike vio 191213
			for (int j = 0; j<MAX_SUB_BOX; j++)
			{
				sub_box_list[id].n_rider_histogram[j] = 0;
			}

			for (int sub_idx = 0; sub_idx < MAX_FRAME_NUM; sub_idx++)
			{
				sub_box_list[id].n_box_list[sub_idx] = 0;
				if (!param->sub_box_list[id].vio_image[sub_idx].empty())
					param->sub_box_list[id].vio_image[sub_idx].release();
			}
			sub_box_list[id].n_box_idx = -1;
			sub_box_list[id].n_min_rider_idx = -1;
			sub_box_list[id].n_his_rider = -1; 


			//radar speed
			for (int nTcnt = 0; nTcnt < MAX_TRACK_COUNT; nTcnt++)
			{
				mot_datasave[id].fRadarSpeed[nTcnt] = 0.0;
			}
			mot_datasave[id].nRadarCount = 0.0;
			mot_datasave[id].fTotalRadarSpeed = 0.0;
			mot_datasave[id].fMeanRadarSpeed = 0.0;

			if (!mot_datasave[id].pIplImage.empty())
			{
				mot_datasave[id].pIplImage.release();
			}

			//20190215 hai Parking
			mot_datasave[id].bCheckAccident = 0;
			mot_datasave[id].bSaveAccident = 0;
			mot_datasave[id].parkingTime = 0;
			if (!mot_datasave[id].pIplImageParkingStart.empty())
			{
				mot_datasave[id].pIplImageParkingStart.release();
			}

			//20190222 hai Violation color
			for (int j = 0; j < REVERSE_VIOLATION_CLR + 1; j++)
			{
				mot_datasave[id].nVioDisplay[j] = 0; //2019022
			}

			//hai 2018.12.12 reset all violation parameters for biker
			if (biker_info)
			{
				biker_info->rider_violation_confirm[id] = 0;
				biker_info->helmet_violation_confirm[id] = 0;
				biker_info->TO_violation[id] = 0;

				biker_info->umbrella_violation_confirm[id] = 0;
				biker_info->mobile_violation_confirm[id] = 0;

				biker_info->violation_confirm[id] = 0;

				biker_info->n_touched_count[id] = 0;
			}

			if (param)
			{
				//wrong lane violation
				{
					if (!param->mot_LaneSave[id].pIplImage.empty())
					{
						param->mot_LaneSave[id].pIplImage.release();
					}

					if (!param->mot_LaneSave[id].pLPImage.empty())
					{
						param->mot_LaneSave[id].pLPImage.release();
					}

					memset(&param->mot_LaneSave[id], 0, sizeof(st_lane_DataSave));

					param->mot_LaneSave[id].nStartStatus = -1;
					param->mot_LaneSave[id].nEndStatus = -1;
					param->mot_LaneSave[id].nLaneViolation = 0;
					param->mot_LaneSave[id].nLPR = 0;
					param->mot_LaneSave[id].nLaneVioCnt = 0;
					param->mot_LaneSave[id].pIplImage = NULL;
					param->mot_LaneSave[id].pLPImage = NULL;
					param->mot_LaneSave[id].nTouchBot = 0;
					param->mot_LaneSave[id].nTouchTop = 0;

					param->mot_LaneSave[id].nFirstClass = -1;
					
					param->mot_DataSave[id].nVioDisplay[LANE_VIOLATION_CLR] = 0;
				}

				//reverse violation
				{
					if (!param->mot_ReverseSave[id].pIplImage.empty())
					{
						param->mot_ReverseSave[id].pIplImage.release();
					}

					if (!param->mot_ReverseSave[id].pLPImage.empty())
					{
						param->mot_ReverseSave[id].pLPImage.release();
					}

					memset(&param->mot_ReverseSave[id], 0, sizeof(st_reverse_DataSave));
					param->mot_ReverseSave[id].nReverseViolation = 0;
					param->mot_ReverseSave[id].nLPR = 0;
					param->mot_ReverseSave[id].nReverseVioCnt = 0;
					param->mot_ReverseSave[id].pIplImage = NULL;
					param->mot_ReverseSave[id].pLPImage = NULL;
					param->mot_ReverseSave[id].nTouchBot = 0;
					param->mot_ReverseSave[id].nTouchTop = 0;
					
					param->mot_ReverseSave[id].nFirstClass = -1;

					param->mot_DataSave[id].nVioDisplay[REVERSE_VIOLATION_CLR] = 0;
				}

				//light violation 1 line touched
				param->mot_LightSave[id].nLightViolation = 0;
				param->mot_LightSave[id].nLightTouch = 0;
				param->mot_LightSave[id].nPassLine = 0;
				if (!param->mot_LightSave[id].pIplImage.empty())
				{
					param->mot_LightSave[id].pIplImage.release();
				}
			}
		}
#if 0
		if (tracking.track[id].b_tracking_success == TRUE)
			rectangle(image, tracking.track[id].i_predROI, cvScalar(128, 128, 128), 8, 1, 0);
		else
			rectangle(image, tracking.track[id].i_predROI, cvScalar(255, 255, 255), 8, 1, 0);
#endif
		track_cnt++;
	}

	if (!left_image.empty()) left_image.release();


	for (int ch = 0; ch < APPEARANCE_CHANNEL; ch++)
	{
		if (!split_image[ch].empty()) split_image[ch].release();
	}

	if (!gray_image.empty()) gray_image.release();
	if (!hsv_image.empty()) hsv_image.release();

	return track_cnt;
}

void cl_tracking::display(Mat &image, int *track_num, int *track_id, CvRect *track_roi)
{
	/*Mat src = image.clone();
	Mat dst;

	if (image.channels() == 3)
		dst = src.clone();
	else
		cvtColor(src, dst, CV_GRAY2BGR);*/

	track_num[0] = 0;
	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];
		if (track[id].state == TRACK_INACTIVE)
			continue;

		if (track[id].state == TRACK_INIT)
			continue;

		track_num[0]++;
	}

	track_roi = new CvRect[track_num[0]];
	track_id = new int[track_num[0]];
	int track_cnt = 0;
	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];
		//printf("(%d %d) track state = %d \n", i, id, track[id].state) ;
		//if ((track[id].state != TRACK_INIT) && (track[id].state != TRACK_ACTIVE))
		//if ((track[id].state == TRACK_NULL) || (track[id].state == TRACK_INIT))
		if (track[id].state == TRACK_INACTIVE)
			continue;

		/*CvRect rectTmp;
		rectTmp.x = (int)track[id].f_prevROI.x;
		rectTmp.y = (int)track[id].f_prevROI.y;
		rectTmp.width = (int)track[id].f_prevROI.width;
		rectTmp.height = (int)track[id].f_prevROI.height;*/

		if (track[id].state == TRACK_INIT)
		{
			//rectangle(dst, rectTmp, cvScalar(255, 255, 255), 2);
			continue;
		}
		else
		{
			track_roi[track_cnt].x = (int)track[id].f_prevROI.x;
			track_roi[track_cnt].y = (int)track[id].f_prevROI.y;
			track_roi[track_cnt].width = (int)track[id].f_prevROI.width;
			track_roi[track_cnt].height = (int)track[id].f_prevROI.height;
			track_id[track_cnt] = id;
			track_cnt++;

			//rectangle(dst, rectTmp, track[id].color, 3);
		}

		if (track[id].b_tracking_success == true)
		{
			//rectangle(dst, track[id].i_predROI, cvScalar(128, 128, 128), 2);
		}

		//rectangle(dst, convert_rectf_to_rect(detect[track[id].detectID].detectROI), cvScalar(0, 0, 0), 1);

		//char textTmp[CHAR_LENGTH];
		//sprintf(textTmp, "%d %d", id, track[id].cnt);
		//putText(dst, textTmp, Point((int)track[id].f_prevROI.x, (int)track[id].f_prevROI.y), FONT_HERSHEY_PLAIN, 1, track[id].color, 2);
	}
	//imshow("tracking result", dst);
	//waitKey(1);

#if SHOW_IMAGE_SAVE
	char *window_name = "tracking result";
	_mkdir(window_name);

	char file_name[CHAR_LENGTH];
	static int image_cnt = START_FRAME;
	sprintf(file_name, "%s/%d.png", window_name, image_cnt);
	imwrite(file_name, dst);
	image_cnt += SKIP;
#endif

	int test = 0;
}

void cl_tracking::state_update(Mat &image)
{
	if (n_s_detect > MAX_TRACK)
	{
		printf("The number of detect objects is more than the MAX_TRACK!!!!!!!!!!\n");
		exit(0);
		return;
	}

#if APPEARANCE_MODEL == 1
	for (int i = 0; i < n_s_detect; i++)
	{
		//detect되더라도 DETECT_SCORE_LOW 보다 작으면 initial 되지 않는다...

		//vector<float> feature;
		//		Mat *ch_image = mkcf_tracker.channel_image;
		//		Mat *ch_image = appearance_ch_image;

		get_feat_from_ch_image(appearance_ch_image, APPEARANCE_CHANNEL, s_detect[i].detectROI, s_detect[i].appearance_feature);

		//		for (int j = 0; j < N_APPEARANCE_FEATURE; j++)
//		{
//			printf("11111111111(%d, %d) = %f\n", i, j, s_detect[i].appearance_feature[j]);
//		}
//		normalize_1d_vector(s_detect[i].appearance_feature, APPEARANCE_CHANNEL, N_TRACK_GRID_X*N_TRACK_GRID_Y);
//		for (int j = 0; j < N_APPEARANCE_FEATURE; j++)
//		{
//			printf("22222222222(%d, %d) = %f\n", i, j, s_detect[i].appearance_feature[j]);
//		}
	}

	if (n_s_detect > MAX_TRACK)
	{
		printf("The number of detect objects is more than the MAX_TRACK!!!!!!!!!!\n");
		exit(0);
	}
#endif
	

#if VISUAL_TRACKING == 1		
	visual_tracking(image);
#elif MOTION_TRACKING == 1
	motion_tracking(image);
#else
	no_tracking();
#endif
	data_association();
	greedy_association();
#if APPEARANCE_MODEL == 1
	weak_data_association();
#endif
	track_update();
	overlap_track_merge();
	new_track_create();
	nMapping = 0;
	for (int i = 0; i < MAX_TRACK; i++)
	{
		if (track[i].state != TRACK_INACTIVE)
		{
			mapping[nMapping] = i;
			nMapping++;
		}
	}
	//		printf("nMapping = %d nTrack = %d\n", nMapping, nTrack);

}

bool cl_tracking::track_initialize(int track_id, int detect_id)  //ninolyc_07
{
	track[track_id].b_checked = false;

	track[track_id].class_id = s_detect[detect_id].class_id;
	track[track_id].class_group_id = s_detect[detect_id].class_group_id;

	track[track_id].f_prevROI = s_detect[detect_id].detectROI; //floating roi
	track[track_id].i_prevROI = convert_rectf_to_rect(s_detect[detect_id].detectROI); //integer roi

	track[track_id].detectScore = s_detect[detect_id].detectScore;
	track[track_id].detect_score_array[0] = s_detect[detect_id].detectScore;
	track[track_id].sum_detect_score = s_detect[detect_id].detectScore;
	track[track_id].mean_detect_score = s_detect[detect_id].detectScore;
#if APPEARANCE_MODEL == 1
	memcpy(track[track_id].prevFeature, s_detect[detect_id].appearance_feature, sizeof(float)*N_APPEARANCE_FEATURE);
#endif
	if (track[track_id].detectScore > TRACK_INIT_HIGH)
	{
		track[track_id].state = TRACK_ACTIVE;
		track[track_id].color = textColorTmp[track_id];
	}
	else
	{
		track[track_id].state = TRACK_INIT;
		track[track_id].color = Scalar(255, 255, 255);
	}

	track[track_id].cnt = 1;
	track[track_id].link_cnt = 1;


#if VISUAL_TRACKING == 1
	mkcf_tracker.train_kernel_alpha(mkcf_tracker.channel_image, mkcf_tracker.Hann_filter, track[track_id].i_prevROI, mkcf_tracker.Y, true, mkcf_tracker.ALPHA[track_id], mkcf_tracker.channel_roi_img[track_id]);
	track[track_id].mt_box_flow.clear();
#elif MOTION_TRACKING == 1
	track[track_id].mt_box_flow.clear();
#endif

	return true;
}

std::vector<float> cl_tracking::get_feat_from_detect(Mat &image, Rect_f &ROI)
{
	std::vector<float> feature;
	//feature = ROI in image
	return feature;
}

bool cl_tracking::get_feat_from_ch_image(Mat *ch_image, int n_channel, Rect_f &ROI, float *feature)
{
	int image_rows = N_TRACK_GRID_Y, image_cols = N_TRACK_GRID_X;
	int image_size = image_rows * image_cols;
	//Mat resize_image(TRACK_SAMPLE_HEIGHT, TRACK_SAMPLE_WIDTH, CV_32FC1);
	Mat roi_image[APPEARANCE_CHANNEL];
	Mat feat_image[APPEARANCE_CHANNEL], norm_feat_image[APPEARANCE_CHANNEL];

	Rect roi = convert_rectf_to_rect(ROI);



	if (roi.x < 0) roi.x = 0;
	if (roi.y < 0) roi.y = 0;
	if (roi.x + roi.width >= ch_image[0].cols) roi.width = ch_image[0].cols - roi.x;
	if (roi.y + roi.height >= ch_image[0].rows) roi.height = ch_image[0].rows - roi.y;

	//printf("%d %d %d %d\n", roi.x, roi.y, roi.width, roi.height);


	int f_id = 0;
	float sum = 0;
	if (roi.width && roi.height)
	{
		for (int ch = 0; ch < n_channel; ch++)
		{
			roi_image[ch] = ch_image[ch](roi);
			//		resize(roi_image, resize_image, Size(TRACK_SAMPLE_WIDTH, TRACK_SAMPLE_HEIGHT));
			resize(roi_image[ch], feat_image[ch], Size(N_TRACK_GRID_X, N_TRACK_GRID_Y), 0, 0, CV_INTER_NN);

			//		pooling_block(resize_image, feat_image, N_FEAT_GRID, N_FEAT_GRID, "average_pooling");


			//normalization
			cv::Scalar sum = cv::sum(feat_image[ch]);
			//norm_feat_image[ch] = feat_image[ch] / sum(0);
			norm_feat_image[ch] = feat_image[ch] / (sum(0) + 0.00001);

			memcpy(&feature[ch*image_size], norm_feat_image[ch].data, sizeof(float)*image_size);
			//		for (int id = 0; id < image_size; id++)
			//		{
			//			sum += feature[ch*image_size + id];
			//		}


#if 0
			for (int y = 0; y < image_rows; y++)
			{
				for (int x = 0; x < image_cols; x++)
				{
					float *data = (float *)feat_image.data;
					printf("feature[%d] = %f feat_image(%d %d) = %f\n", f_id, feature[f_id], x, y, data[y*image_cols + x]);
					f_id++;
				}

		}
#endif

			if (!roi_image[ch].empty()) roi_image[ch].release();
			if (!feat_image[ch].empty()) feat_image[ch].release();
			if (!norm_feat_image[ch].empty()) norm_feat_image[ch].release();
		}

#if 0
		for (int ch = 0; ch < n_channel; ch++)
		{
			for (int id = 0; id < image_size; id++)
			{
				//			printf("feature[%d] = %f \n", id, feature[ch*image_size + id]);
				feature[ch*image_size + id] /= sum;
				//			printf("sum = %f feature[%d] = %f \n", sum, id, feature[ch*image_size + id]);
	}
}
#endif
		return true;
	}
	return false;
}

void cl_tracking::visual_tracking(Mat &image)
{
	Mat *ch_image = mkcf_tracker.channel_image;
	float feat_update_weight = 0.9;
	for (int i = 0; i < nTrack; i++)
	{
		//		printf("n_track = %d %d) track \n", nTrack, i);
		int tr_id = mapping[i];
		track[tr_id].i_prevROI = convert_rectf_to_rect(track[tr_id].f_prevROI);
#if VISUAL_TRACKING	== 1
		//		printf("%d = prev(%d %d %d %d)\n", tr_id, track[tr_id].i_prevROI.x, track[tr_id].i_prevROI.y, track[tr_id].i_prevROI.width, track[tr_id].i_prevROI.height);
		track[tr_id].predScore = mkcf_tracker.predict_roi(track[tr_id].i_prevROI, tr_id, track[tr_id].i_predROI);
		//		printf("pred(%d %d %d %d) = %f \n", track[tr_id].i_predROI.x, track[tr_id].i_predROI.y, track[tr_id].i_predROI.width, track[tr_id].i_predROI.height, track[tr_id].predScore);
				//track[tr_id].predScore = 0;
		if (track[tr_id].predScore > TRACK_SUCCESS_SCORE)
		{
			//ninolyc.2018.0615. trackingÇÒ ¶§ ÀÛÀº ¿µ¿ª¿¡ ´ëÇÏ¿©´Â fail·Î Ãë±ÞÇÕ.
			CvPoint lt_pt, rd_pt;
			lt_pt.x = (track[tr_id].i_predROI.x < 0) ? 0 : track[tr_id].i_predROI.x;
			lt_pt.y = (track[tr_id].i_predROI.y < 0) ? 0 : track[tr_id].i_predROI.y;
			rd_pt.x = ((track[tr_id].i_predROI.x + track[tr_id].i_predROI.width) > image.cols) ? image.cols - 1 : track[tr_id].i_predROI.x + track[tr_id].i_predROI.width - 1;
			rd_pt.y = ((track[tr_id].i_predROI.y + track[tr_id].i_predROI.height) > image.rows) ? image.rows - 1 : track[tr_id].i_predROI.y + track[tr_id].i_predROI.height - 1;
			track[tr_id].i_predROI.x = lt_pt.x;
			track[tr_id].i_predROI.y = lt_pt.y;
			track[tr_id].i_predROI.width = rd_pt.x - lt_pt.x + 1;
			track[tr_id].i_predROI.height = rd_pt.y - lt_pt.y + 1;


			if (((rd_pt.x - lt_pt.x) < 4) || ((rd_pt.y - lt_pt.y) < 4))
			{
				track[tr_id].i_predROI = track[tr_id].i_prevROI;  //tracking error°¡ »ý±â¸é ÀÌÀü °Í »ç¿ë
//				track[tr_id].b_tracking_success = FALSE;
			}

			//track roi update ÈÄ¿¡ track parameter update ÇÑ´Ù.
			//mkcf_tracker.train_kernel_alpha(ch_image, mkcf_tracker.Hann_filter, track[tr_id].i_predROI, mkcf_tracker.Y, FALSE, mkcf_tracker.ALPHA[tr_id], mkcf_tracker.channel_roi_img[tr_id]);
			track[tr_id].f_predROI = convert_rect_to_rect_f(track[tr_id].i_predROI);
		}
		else
		{
#if MOTION_TRACKING == 0			
			track[tr_id].i_predROI = track[tr_id].i_prevROI;
			track[tr_id].f_predROI = convert_rect_to_rect_f(track[tr_id].i_predROI);
			//			track[tr_id].b_tracking_success = FALSE;
#else
			mt_box pred_box;
			pred_box.box_x = (track[tr_id].f_prevROI.x + track[tr_id].f_prevROI.width / 2.) + track[tr_id].mt_box_flow.box_x;
			pred_box.box_y = (track[tr_id].f_prevROI.y + track[tr_id].f_prevROI.height / 2.) + track[tr_id].mt_box_flow.box_y;
			pred_box.box_w = (track[tr_id].f_prevROI.width) * track[tr_id].mt_box_flow.box_w;
			pred_box.box_h = (track[tr_id].f_prevROI.height) * track[tr_id].mt_box_flow.box_h;

			track[tr_id].f_predROI.x = pred_box.box_x - pred_box.box_w / 2.0;
			track[tr_id].f_predROI.y = pred_box.box_y - pred_box.box_h / 2.0;
			track[tr_id].f_predROI.width = pred_box.box_w;
			track[tr_id].f_predROI.height = pred_box.box_h;

			CvPoint2D32f lt_pt, rd_pt;
			lt_pt.x = (track[tr_id].f_predROI.x < 0) ? 0 : track[tr_id].f_predROI.x;
			lt_pt.y = (track[tr_id].f_predROI.y < 0) ? 0 : track[tr_id].f_predROI.y;
			rd_pt.x = ((track[tr_id].f_predROI.x + track[tr_id].f_predROI.width) > image.cols) ? image.cols - 1 : track[tr_id].f_predROI.x + track[tr_id].f_predROI.width - 1;
			rd_pt.y = ((track[tr_id].f_predROI.y + track[tr_id].f_predROI.height) > image.rows) ? image.rows - 1 : track[tr_id].f_predROI.y + track[tr_id].f_predROI.height - 1;
			if (((rd_pt.x - lt_pt.x) < 4) || ((rd_pt.y - lt_pt.y) < 4))
			{
				track[tr_id].f_predROI = track[tr_id].f_prevROI;  //tracking error°¡ »ý±â¸é ÀÌÀü °Í »ç¿ë
			}
			else
			{
				track[tr_id].f_predROI.x = lt_pt.x;
				track[tr_id].f_predROI.y = lt_pt.y;
				track[tr_id].f_predROI.width = rd_pt.x - lt_pt.x + 1;
				track[tr_id].f_predROI.height = rd_pt.y - lt_pt.y + 1;
			}



			track[tr_id].i_predROI = convert_rectf_to_rect(track[tr_id].f_predROI);
			//			track[tr_id].b_tracking_success = false;
#endif
		}
		//		printf("(%f %d)\n", track[tr_id].predScore, track[tr_id].b_tracking_success);
		//		printf("visual-trackin %d = pred(%d %d %d %d)\n", tr_id, track[tr_id].i_predROI.x, track[tr_id].i_predROI.y, track[tr_id].i_predROI.width, track[tr_id].i_predROI.height);
		//		printf("visual-tracking %d = pred(%f %f %f %f)\n", tr_id, track[tr_id].f_predROI.x, track[tr_id].f_predROI.y, track[tr_id].f_predROI.width, track[tr_id].f_predROI.height);
#endif


#if   APPEARANCE_MODEL == 1
//		memcpy(track[tr_id].predFeature, track[tr_id].prevFeature, sizeof(float)*N_APPEARANCE_FEATURE);
#endif

	}

	//if (!ch_image->empty()) ch_image->release();
	/*if (ch_image)
	{
		delete ch_image;
		ch_image = NULL;
	}*/
}

void cl_tracking::motion_tracking(Mat &image)
{
	for (int i = 0; i < nTrack; i++)
	{
		//		printf("n_track = %d %d) track \n", nTrack, i);
		int tr_id = mapping[i];
		track[tr_id].i_prevROI = convert_rectf_to_rect(track[tr_id].f_prevROI);
		mt_box pred_box;
		pred_box.box_x = (track[tr_id].f_prevROI.x + track[tr_id].f_prevROI.width / 2.) + track[tr_id].mt_box_flow.box_x;
		pred_box.box_y = (track[tr_id].f_prevROI.y + track[tr_id].f_prevROI.height / 2.) + track[tr_id].mt_box_flow.box_y;
		pred_box.box_w = (track[tr_id].f_prevROI.width) * track[tr_id].mt_box_flow.box_w;
		pred_box.box_h = (track[tr_id].f_prevROI.height) * track[tr_id].mt_box_flow.box_h;

		track[tr_id].f_predROI.x = pred_box.box_x - pred_box.box_w / 2.0;
		track[tr_id].f_predROI.y = pred_box.box_y - pred_box.box_h / 2.0;
		track[tr_id].f_predROI.width = pred_box.box_w;
		track[tr_id].f_predROI.height = pred_box.box_h;


		CvPoint2D32f lt_pt, rd_pt;
		lt_pt.x = (track[tr_id].f_predROI.x < 0) ? 0 : track[tr_id].f_predROI.x;
		lt_pt.y = (track[tr_id].f_predROI.y < 0) ? 0 : track[tr_id].f_predROI.y;
		rd_pt.x = ((track[tr_id].f_predROI.x + track[tr_id].f_predROI.width) > image.cols) ? image.cols - 1 : track[tr_id].f_predROI.x + track[tr_id].f_predROI.width - 1;
		rd_pt.y = ((track[tr_id].f_predROI.y + track[tr_id].f_predROI.height) > image.rows) ? image.rows - 1 : track[tr_id].f_predROI.y + track[tr_id].f_predROI.height - 1;
		track[tr_id].f_predROI.x = lt_pt.x;
		track[tr_id].f_predROI.y = lt_pt.y;
		track[tr_id].f_predROI.width = rd_pt.x - lt_pt.x + 1;
		track[tr_id].f_predROI.height = rd_pt.y - lt_pt.y + 1;

		if (((rd_pt.x - lt_pt.x) < 4) || ((rd_pt.y - lt_pt.y) < 4))
		{
			track[tr_id].f_predROI = track[tr_id].f_prevROI;  //tracking error°¡ »ý±â¸é ÀÌÀü °Í »ç¿ë
		}
		else
		{
			track[tr_id].f_predROI.x = lt_pt.x;
			track[tr_id].f_predROI.y = lt_pt.y;
			track[tr_id].f_predROI.width = rd_pt.x - lt_pt.x + 1;
			track[tr_id].f_predROI.height = rd_pt.y - lt_pt.y + 1;
		}


		track[tr_id].i_predROI = convert_rectf_to_rect(track[tr_id].f_predROI);
		//		track[tr_id].b_tracking_success = false;


#if   APPEARANCE_MODEL == 1
//		memcpy(track[tr_id].predFeature, track[tr_id].prevFeature, sizeof(float)*N_APPEARANCE_FEATURE);
#endif

	}

}


void cl_tracking::no_tracking()
{

	for (int i = 0; i < nTrack; i++)
	{
		int tr_id = mapping[i];
		track[tr_id].i_prevROI = convert_rectf_to_rect(track[tr_id].f_prevROI);

		track[tr_id].i_predROI = track[tr_id].i_prevROI;
		track[tr_id].f_predROI = convert_rect_to_rect_f(track[tr_id].i_predROI);
		//		track[tr_id].b_tracking_success = false;
#if   APPEARANCE_MODEL == 1
//		memcpy(track[tr_id].predFeature, track[tr_id].prevFeature, sizeof(float)*N_APPEARANCE_FEATURE);
#endif

	}

}

void cl_tracking::update_feature(float *feat1, float *feat2, int n_feat, float w)
{
	for (int f = 0; f < n_feat; f++)
	{
		feat1[f] = w * feat1[f] + (1 - w) * feat2[f];
	}
}

void cl_tracking::data_association()
{
	float **cost_matrix = new float*[nMapping];
	int** data_matrix = new int*[nMapping];

	for (int i = 0; i < nMapping; i++)
		cost_matrix[i] = new float[n_s_detect];

	for (int i = 0; i < nMapping; i++)
		data_matrix[i] = new int[n_s_detect];

	similarity_calculate(cost_matrix);
	Hungarian_algorithm(nMapping, n_s_detect, cost_matrix, data_matrix);

	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];
		for (int j = 0; j < n_s_detect; j++)
		{
			if (((data_matrix[i][j] == 1) && (cost_matrix[i][j] > MIN_DISTANCE)) || ((track[id].state == TRACK_INIT) && (cost_matrix[i][j] > INIT_MIN_DISTANCE)))
				data_matrix[i][j] = 0;
		}
	}


	//i : trackID, j : detectID
	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];
		track[id].IsAssociation = false;
		track[id].detectID = -1;
	}

	for (int j = 0; j < n_s_detect; j++)
	{
		s_detect[j].IsAssociation = false;
		s_detect[j].trackID = -1;
	}

	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];
		for (int j = 0; j < n_s_detect; j++)
		{
			//			printf("(%d, %d) cost = %f da = %d\n", mapping[i], j, cost_matrix[i][j], data_matrix[i][j]);
			if (data_matrix[i][j] == 1)
			{
				track[id].IsAssociation = true;
				track[id].detectID = j;
				s_detect[j].IsAssociation = true;
				s_detect[j].trackID = id;
				track[id].class_id = s_detect[j].class_id;
				break;
				//				printf("(%d, %d) affinity_score = %f \n", mapping[i], j, track[id].affinity_score[j]);
			}
		}
	}


	for (int i = 0; i < nMapping; i++)
		delete[] cost_matrix[i];
	delete[] cost_matrix;


	for (int i = 0; i < nMapping; i++)
		delete[] data_matrix[i];
	delete[] data_matrix;
}

void cl_tracking::greedy_association()
{
	float iou_thresh = 0.6;

	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];
		if ((track[id].IsAssociation == true) || (track[id].state == TRACK_INIT))
			continue;
		for (int j = 0; j < n_s_detect; j++)
		{
			if (track[id].class_group_id != s_detect[j].class_group_id)
				continue;
			if ((s_detect[j].IsAssociation == false) && (track[id].iou_ratio_0[j] > iou_thresh))
			{
				//				printf("(%d %d) = %f\n", id, j, track[id].iou_ratio_0[j]);
				track[id].IsAssociation = true;
				track[id].detectID = j;
				s_detect[j].IsAssociation = true;
				s_detect[j].trackID = id;
				track[id].class_id = s_detect[j].class_id;
				break;

			}
		}
	}

}

int cl_tracking::re_identification(int det_id)
{
	int id;
	float affinity_thresh = 0.95;
	float max_affinity = -1;


	for (int i = 0; i < nMapping; i++)
	{
		int tr_id = mapping[i];
		if (track[tr_id].class_group_id != s_detect[det_id].class_group_id)
			continue;
		if ((!track[tr_id].IsAssociation) && (track[tr_id].state == TRACK_TERMINATE))
		{
			if (track[tr_id].affinity_score[det_id] > max_affinity)
			{
				max_affinity = track[tr_id].affinity_score[det_id];
				id = tr_id;
			}
		}
	}


	if (max_affinity > affinity_thresh)
	{
		return id;
	}
	else
	{
		return -1;
	}


}

void cl_tracking::weak_data_association()
{
	//i : trackID, j : detectID
	float weak_da_similarity_thresh = 0.5;
	float cos_appearance_thresh = 0.8;
	float cos_appearance;

	for (int j = 0; j < n_w_detect; j++)
	{
		w_detect[j].IsAssociation = false;
		w_detect[j].trackID = -1;
	}
	for (int i = 0; i < nMapping; i++)
	{
		int tr_id = mapping[i];
		track[tr_id].b_weak_association = false;
		track[tr_id].b_tracking_success = false;
	}

	for (int i = 0; i < nMapping; i++)
	{
		int tr_id = mapping[i];
		if (track[tr_id].IsAssociation)
			continue;
		float max_iou_ratio = 0;
		float iou_ratio;
		int det_id = -1;
		for (int j = 0; j < n_w_detect; j++)
		{
			if ((w_detect[j].IsAssociation) || (track[mapping[tr_id]].class_group_id != w_detect[j].class_group_id))
				continue;

			iou_ratio = rectOverlapRatio(track[tr_id].f_predROI, w_detect[j].detectROI, 0);
			if (iou_ratio > max_iou_ratio)
			{
				max_iou_ratio = iou_ratio;
				det_id = j;
			}
		}

		if (max_iou_ratio > weak_da_similarity_thresh)
		{
			get_feat_from_ch_image(appearance_ch_image, APPEARANCE_CHANNEL, w_detect[0].detectROI, w_detect[det_id].appearance_feature);
			cos_appearance = calculate_cos_n_similarity(track[tr_id].prevFeature, w_detect[det_id].appearance_feature, APPEARANCE_CHANNEL, N_GRID);

			//			printf("1111max_iou_ratio = %f, cos_appearance = %f \n", max_iou_ratio, cos_appearance);
			if (cos_appearance > cos_appearance_thresh)
			{
				//				printf("1111max_iou_ratio = %f, cos_appearance_prob = %f \n", max_iou_ratio, cos_appearance_prob);
				track[tr_id].b_weak_association = true;
				track[tr_id].detectID = det_id;
				w_detect[det_id].IsAssociation = true;
				w_detect[det_id].trackID = tr_id;
				track[tr_id].class_id = w_detect[det_id].class_id;
				track[tr_id].weak_affinity_score = cos_appearance;
			}
		}
		else
		{
			get_feat_from_ch_image(appearance_ch_image, APPEARANCE_CHANNEL, track[tr_id].f_predROI, track[tr_id].predFeature);
			cos_appearance = calculate_cos_n_similarity(track[tr_id].prevFeature, track[tr_id].predFeature, APPEARANCE_CHANNEL, N_GRID);

			//			printf("2222max_iou_ratio = %f, cos_appearance = %f \n", max_iou_ratio, cos_appearance);
			if (cos_appearance > cos_appearance_thresh)
			{
				//				printf("2222max_iou_ratio = %f, cos_appearance_prob = %f \n", max_iou_ratio, cos_appearance_prob);
				track[tr_id].b_tracking_success = true;
				track[tr_id].weak_affinity_score = cos_appearance;
			}
			else
			{
				track[tr_id].b_tracking_success = false;
			}

		}
	}
}

float cl_tracking::calculate_cos_similarity(float *hist1, float *hist2, int n_bin)
{
	double distance = 0.0;


	for (int i = 0; i < n_bin; i++)
	{
		distance += sqrt(hist1[i] * hist2[i]);
		//		printf("%d) hist1 = %f, hist2 = %f, distance = %f\n", i, hist1[i], hist2[i], sqrt(hist1[i] * hist2[i])) ;
	}
	//	printf("distance = %f\n", distance);

	return distance;
}


float cl_tracking::calculate_cos_n_similarity(float *hist1, float *hist2, int n_ch, int n_bin)
{
	double mul_distance = 1.0;

	for (int ch = 0; ch < n_ch; ch++)
	{
		double distance = 0.0;
		int index = ch * n_bin;
		for (int i = 0; i < n_bin; i++)
		{
			distance += sqrt(hist1[index + i] * hist2[index + i]);
			//			printf("%d) hist1 = %f, hist2 = %f, distance = %f\n", index + i, hist1[index + i], hist2[index + i], sqrt(hist1[index + i] * hist2[index + i])) ;
		}
		mul_distance *= distance;

		//		printf("distance = %f\n", distance);

	}
	//	printf("mul_distance = %f\n", mul_distance);

	return mul_distance;
}

float cl_tracking::calulate_l2_dist(float *hist1, float *hist2, int n_bin)
{
	double distance = 0.0;


	for (int i = 0; i < n_bin; i++)
	{
		distance += (hist1[i] - hist2[i])*(hist1[i] - hist2[i]);
		//		printf("%d) hist1 = %f, hist2 = %f, distance = %f\n", i, hist1[i], hist2[i], (hist1[i] - hist2[i])*(hist1[i] - hist2[i]));
	}
	//	printf("distance = %f\n", distance);

	return sqrt(distance);
}


float cl_tracking::calulate_l1_dist(float *hist1, float *hist2, int n_bin)
{
	double distance = 0.0;


	for (int i = 0; i < n_bin; i++)
	{
		distance += abs(hist1[i] - hist2[i]);
		//		printf("%d) hist1 = %f, hist2 = %f, distance = %f\n", i, hist1[i], hist2[i], abs(hist1[i] - hist2[i]));
	}
	//	printf("distance = %f\n", distance);

	return distance;
}

float cl_tracking::calulate_l1_n_dist(float *hist1, float *hist2, int n_ch, int n_bin)
{
	double mul_distance = 1.0;

	for (int ch = 0; ch < n_ch; ch++)
	{
		double distance = 0.0;
		int index = ch * n_bin;
		for (int i = 0; i < n_bin; i++)
		{
			distance += abs(hist1[index + i] - hist2[index + i]);
			//			printf("%d) hist1 = %f, hist2 = %f, distance = %f\n", index + i, hist1[index + i], hist2[index + i], abs(hist1[index + i] - hist2[index + i])) ;
		}
		mul_distance *= (1 - distance);

		//		printf("distance = %f\n", 1 - distance);

	}
	//	printf("mul_distance = %f\n", mul_distance);

	return (1 - mul_distance);
}

void cl_tracking::normalize_1d_vector(float *hist, int n_ch, int n_bin)
{

	for (int ch = 0; ch < n_ch; ch++)
	{
		double sum = 0.0;

		int index = ch * n_bin;
		for (int i = 0; i < n_bin; i++)
		{
			sum += hist[index + i];
			printf("hist[%d] = %f\n", index + i, hist[index + i]);
		}
		printf("sum = %f\n", sum);
		for (int i = 0; i < n_bin; i++)
		{
			hist[index + i] = hist[index + i] / sum;
			//			printf("norm_hist[%d] = %f\n", index + i, hist[indexn + i]);
		}
	}

}

void cl_tracking::similarity_calculate(float **cost_matrix)
{
	float iou_ratio_0, iou_ratio_1;
	float size_sim_score;
	float weighted_iou_distance;
	float detect_score_weight = 1, track_score_weight = 1;
	float cos_similarity = 0;
	float iou_prob, size_prob, Bhattacharyya_prob;
	float iou_ramda = 5, size_rameda = 20, bh_ramda = 1;
	float score_weight = 0.5;

	for (int i = 0; i < nMapping; i++)
		for (int j = 0; j < n_s_detect; j++)
			cost_matrix[i][j] = -1;

	for (int i = 0; i < nMapping; i++)
	{
		int tr_id = mapping[i];
		track_score_weight = (1 - score_weight)*track[tr_id].mean_detect_score + score_weight;
		for (int j = 0; j < n_s_detect; j++)
		{
			detect_score_weight = (1 - score_weight)*s_detect[j].detectScore + score_weight;
			//			printf("%f\n", track[mapping[i]].sum_detect_score);
			if (track[tr_id].class_group_id == s_detect[j].class_group_id)
			{
				rectOverlapRatio_2x_all(track[tr_id].f_predROI, s_detect[j].detectROI, iou_ratio_0, iou_ratio_1);
				size_sim_score = size_similiar_score(track[tr_id].f_predROI, s_detect[j].detectROI);
				iou_prob = exp(-iou_ramda * (1 - iou_ratio_0) * (1 - iou_ratio_0) * (1 - iou_ratio_0));
				size_prob = exp(-size_rameda * (1 - size_sim_score)* (1 - size_sim_score));
				//				printf("d[%d] = (%f %f %f %f)\n", j, s_detect[j].detectROI.x, detect[j].detectROI.y, detect[j].detectROI.width, detect[j].detectROI.height);
				//				printf("t[%d] = (%f %f %f %f)\n", i, track[tr_id].f_predROI.x, track[tr_id].f_predROI.y, track[tr_id].f_predROI.width, track[tr_id].f_predROI.height);
#if APPEARANCE_MODEL == 1
				cos_similarity = calculate_cos_n_similarity(track[tr_id].prevFeature, s_detect[j].appearance_feature, APPEARANCE_CHANNEL, N_GRID);
				//				cos_similarity = 1 - calulate_l1_n_dist(track[tr_id].prevFeature, s_detect[j].appearance_feature, APPEARANCE_CHANNEL, N_TRACK_GRID_X*N_TRACK_GRID_Y);
				Bhattacharyya_prob = exp(-bh_ramda * (1 - cos_similarity)* (1 - cos_similarity));

				//				printf("%d) cos_similarity = %f, l1_n_dist = %f\n", j, cos_similarity, app_matrix[i][j]);
				weighted_iou_distance = 1 - track_score_weight * detect_score_weight*size_prob*iou_prob*Bhattacharyya_prob;
				//				weighted_iou_distance = 1 - size_prob*iou_prob*Bhattacharyya_prob;
				//				weighted_iou_distance = 1 - Bhattacharyya_prob;
				track[tr_id].affinity_score[j] = cos_similarity;

#else
				weighted_iou_distance = 1 - track_score_weight * detect_score_weight*size_prob*iou_prob;
#endif

				cost_matrix[i][j] = weighted_iou_distance;
				track[tr_id].iou_ratio_0[j] = iou_ratio_0;
				track[tr_id].iou_ratio_1[j] = iou_ratio_1;

				//				printf("%d) c_M[%d][%d] = %f, iou_s = %f, size_sim_s = %f, Bhatt_s = %f cos_sim = %f\n", j, mapping[i], j, cost_matrix[i][j], iou_prob, size_prob, Bhattacharyya_prob, cos_similarity);
				//				printf("(%d %d) iou_s = %f, Bhatt_s = %f cos_sim = %f\n", mapping[i], j, iou_prob, Bhattacharyya_prob, cos_similarity);
			}
			else
			{
				cost_matrix[i][j] = 1;
			}
			//			printf("(%d %d) = %f\n", i, j, cost_matrix[i][j]);
			}
		}
	}

float cl_tracking::rectOverlapRatio(Rect_f a, Rect_f b, int type)
{
	//overlap is invalid in the beginning
	float o = -1;

	float aPointX1 = a.x;
	float aPointY1 = a.y;
	float aPointX2 = a.x + a.width - 1;
	float aPointY2 = a.y + a.height - 1;

	float bPointX1 = b.x;
	float bPointY1 = b.y;
	float bPointX2 = b.x + b.width - 1;
	float bPointY2 = b.y + b.height - 1;

	//get overlapping area
	float x1 = max(aPointX1, bPointX1);
	float y1 = max(aPointY1, bPointY1);
	float x2 = min(aPointX2, bPointX2);
	float y2 = min(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
		return 0;

	//get overlapping areas
	float inter = w * h;
	float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
	float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

	//intersection over union overlap depending on users choice
	if (type == 0)
	{
		o = inter / (a_area + b_area - inter);
	}
	else
	{
		o = (a_area > b_area) ? inter / b_area : inter / a_area;
	}


	return o;
}

void cl_tracking::rectOverlapRatio_all(Rect_f a, Rect_f b, float &iou_ratio1, float &iou_ratio2)
{
	//overlap is invalid in the beginning

	float aPointX1 = a.x;
	float aPointY1 = a.y;
	float aPointX2 = a.x + a.width - 1;
	float aPointY2 = a.y + a.height - 1;

	float bPointX1 = b.x;
	float bPointY1 = b.y;
	float bPointX2 = b.x + b.width - 1;
	float bPointY2 = b.y + b.height - 1;

	//get overlapping area
	float x1 = max(aPointX1, bPointX1);
	float y1 = max(aPointY1, bPointY1);
	float x2 = min(aPointX2, bPointX2);
	float y2 = min(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
	{
		iou_ratio1 = 0;
		iou_ratio2 = 0;
	}
	else
	{
		//get overlapping areas
		float inter = w * h;
		float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
		float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);
		iou_ratio1 = inter / (a_area + b_area - inter);
		iou_ratio2 = (a_area > b_area) ? inter / b_area : inter / a_area;
	}
}

void cl_tracking::rect_including(Rect_f a, Rect_f b, float &big_overlap, float &small_overlap)
{
	//overlap is invalid in the beginning

	float aPointX1 = a.x;
	float aPointY1 = a.y;
	float aPointX2 = a.x + a.width - 1;
	float aPointY2 = a.y + a.height - 1;

	float bPointX1 = b.x;
	float bPointY1 = b.y;
	float bPointX2 = b.x + b.width - 1;
	float bPointY2 = b.y + b.height - 1;

	//get overlapping area
	float x1 = max(aPointX1, bPointX1);
	float y1 = max(aPointY1, bPointY1);
	float x2 = min(aPointX2, bPointX2);
	float y2 = min(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
	{
		big_overlap = 0;
		small_overlap = 0;
	}
	else
	{

		//get overlapping areas
		float inter = w * h;
		float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
		float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

		// intersectionÀÌ Å« ¹Ú¿¡½º ¾ó¸¶³ª °ãÄ¡´ÂÁö
		big_overlap = (a_area > b_area) ? inter / a_area : inter / b_area;
		//	intersectionÀÌ ÀÛÀº ¹Ú½º¿¡ ¾ó¸¶³ª °ãÄ¡´ÂÁö
		small_overlap = (a_area > b_area) ? inter / b_area : inter / a_area;
	}

}
float cl_tracking::rectOverlapRatio_2x(Rect_f a, Rect_f b, int type)
{
	//overlap is invalid in the beginning
	float o = -1;

	float aPointX1 = a.x - a.width*0.5;
	float aPointY1 = a.y - a.height*0.5;;
	float aPointX2 = a.x + 2 * a.width - 1;
	float aPointY2 = a.y + 2 * a.height - 1;

	float bPointX1 = b.x - b.width*0.5;
	float bPointY1 = b.y - b.height*0.5;
	float bPointX2 = b.x + 2 * b.width - 1;
	float bPointY2 = b.y + 2 * b.height - 1;

	//get overlapping area
	float x1 = max(aPointX1, bPointX1);
	float y1 = max(aPointY1, bPointY1);
	float x2 = min(aPointX2, bPointX2);
	float y2 = min(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
		return 0;

	//get overlapping areas
	float inter = w * h;
	float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
	float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

	//intersection over union overlap depending on users choice
	if (type == 0)
	{
		o = inter / (a_area + b_area - inter);
	}
	else
	{
		o = (a_area > b_area) ? inter / b_area : inter / a_area;
	}

	//overlap
	return o;
}


void cl_tracking::rectOverlapRatio_2x_all(Rect_f a, Rect_f b, float &iou_0, float &iou_1)
{
	//overlap is invalid in the beginning
	float o = -1;

	float aPointX1 = a.x - a.width*0.5;
	float aPointY1 = a.y - a.height*0.5;;
	float aPointX2 = a.x + 2 * a.width - 1;
	float aPointY2 = a.y + 2 * a.height - 1;

	float bPointX1 = b.x - b.width*0.5;
	float bPointY1 = b.y - b.height*0.5;
	float bPointX2 = b.x + 2 * b.width - 1;
	float bPointY2 = b.y + 2 * b.height - 1;

	//get overlapping area
	float x1 = max(aPointX1, bPointX1);
	float y1 = max(aPointY1, bPointY1);
	float x2 = min(aPointX2, bPointX2);
	float y2 = min(aPointY2, bPointY2);

	//compute width and height of overlapping area
	float w = x2 - x1;
	float h = y2 - y1;

	//set invalid entries to 0 overlap
	if (w <= 0 || h <= 0)
	{
		iou_0 = 0;
		iou_1 = 0;
	}
	else
	{

		//get overlapping areas
		float inter = w * h;
		float a_area = (aPointX2 - aPointX1) * (aPointY2 - aPointY1);
		float b_area = (bPointX2 - bPointX1) * (bPointY2 - bPointY1);

		iou_0 = inter / (a_area + b_area - inter);
		iou_1 = (a_area > b_area) ? inter / b_area : inter / a_area;
	}


}

float cl_tracking::size_similiar_score(Rect_f a, Rect_f b)
{

	float size_similiar, w_dist, h_dist;
	float size_weight = 4;

	w_dist = size_weight * (1 - b.width / a.width) * (1 - b.width / a.width);
	h_dist = size_weight * (1 - b.height / a.height) * (1 - b.height / a.height);
	size_similiar = 1 - MIN(1.0, w_dist*h_dist);

	return size_similiar;
}

void cl_tracking::new_track_create()
{
	//Da_Matrix º¸°í
	for (int j = 0; j < n_s_detect; j++)
	{
		if (s_detect[j].IsAssociation == false)
		{
			//			printf("%d detect\n", j) ;
//			if (new_track_confirm(j))  //overlap_track_merge()ÇÔ¼ö¸¦ »ç¿ëÇÏ¸é »ý·«ÇØµµ µÊ.
			{
#if (APPEARANCE_MODEL == 1)				
				int tr_id = re_identification(j);
#else
				int tr_id = -1;
#endif
				if (tr_id < 0)
				{
					creat(j);
				}
				else
				{
					track_initialize(tr_id, j);
				}
			}
		}
	}
}

void cl_tracking::overlap_track_merge()
{
	float iou_ratio, including_ratio;
	float iou_ratio_thresh = 0.6, including_ratio_thresh = 0.9;
	bool b_new_track_true = true;
	for (int i = 0; i < nMapping; i++)
	{
		int tr_id1 = mapping[i];
		if (track[tr_id1].state != TRACK_ACTIVE)
			continue;
		for (int j = i + 1; j < nMapping; j++)
		{
			int tr_id2 = mapping[j];
			if ((track[tr_id2].state != TRACK_ACTIVE) || (track[tr_id1].class_group_id != track[tr_id2].class_group_id))
				continue;

			rectOverlapRatio_all(track[tr_id1].f_prevROI, track[tr_id2].f_prevROI, iou_ratio, including_ratio);

			if ((including_ratio > including_ratio_thresh) || (iou_ratio > iou_ratio_thresh))
			{

				if (track[tr_id1].mean_detect_score < track[tr_id2].mean_detect_score)
				{
					track[tr_id1].state = TRACK_TERMINATE;
					track[tr_id1].cnt = 0;
					track[tr_id1].link_cnt = 0;
				}
				else
				{
					track[tr_id2].state = TRACK_TERMINATE;
					track[tr_id2].cnt = 0;
					track[tr_id2].link_cnt = 0;
				}
#if 0
				if ((track[tr_id1].mean_detect_score < track[tr_id2].mean_detect_score) && (track[tr_id1].mean_detect_score < TRACK_ACTIVE_LOW))
				{
					track[tr_id1].state = TRACK_TERMINATE;
					track[tr_id1].cnt = 0;
					track[tr_id1].link_cnt = 0;
				}
				else if ((track[tr_id1].mean_detect_score >= track[tr_id2].mean_detect_score) && (track[tr_id2].mean_detect_score < TRACK_ACTIVE_LOW))
				{
					track[tr_id2].state = TRACK_TERMINATE;
					track[tr_id2].cnt = 0;
					track[tr_id2].link_cnt = 0;
				}
#endif
			}
		}
	}
}

bool cl_tracking::new_track_confirm(int det_id)
{
	float iou_ratio;
	float iou_thresh = 0.6;
	bool b_new_track_true = true;
	for (int i = 0; i < nMapping; i++)
	{
		int tr_id = mapping[i];

		iou_ratio = rectOverlapRatio(track[tr_id].f_prevROI, s_detect[det_id].detectROI, 1);

		//		printf("(%f %f)\n", iou_ratio, track[tr_id].iou_ratio_1[det_id]);
		if (iou_ratio > iou_thresh)
		{
			//			printf("(%d %d) iou_ratio = %f\n", det_id, tr_id, iou_ratio);
			b_new_track_true = false;
			return b_new_track_true;
		}
	}
	return b_new_track_true;
}


void cl_tracking::track_update()  //ninolyc_07
{
	float feat_update_weight = FEATURE_UPDATE_WEIGHT;
	float detect_weight, track_weight, previous_weight;

	float sum_detect_score, mean_detect_score;

	for (int i = 0; i < nMapping; i++)
	{
		int id = mapping[i];
		int det_id = track[id].detectID;
		if (track[id].state == TRACK_INACTIVE)
			continue;


		//		printf("----%d) f_prevROI = (%f %f %f %f)\n", id, track[id].f_prevROI.x, track[id].f_prevROI.y, track[id].f_prevROI.width, track[id].f_prevROI.height);
		float prior_weight = 0.7;
		float track_prior = 0.8;
		float track_weight = 0.7;
#if APPEARANCE_MODEL == 1
		float track_affinity_score = track[id].affinity_score[det_id];
#else
		float track_affinity_score = 0.95;
#endif

		if ((track[id].IsAssociation == true) || (track[id].b_weak_association == true))
		{
			if (track[id].IsAssociation == true)
				detect_weight = track_affinity_score * prior_weight;
			else
				detect_weight = track[id].weak_affinity_score * prior_weight;
			track_weight = (1 - detect_weight) * track_prior;
			previous_weight = (1 - detect_weight) * (1 - track_prior);
		}
		else if (track[id].b_tracking_success == true)
		{
			detect_weight = 0;
			track_weight = track[id].weak_affinity_score * prior_weight;
			previous_weight = (1 - track_weight);
		}
		else
		{
			detect_weight = 0;
			previous_weight = 1 - track_weight;
		}

		if ((track[id].IsAssociation == false) && (track[id].b_weak_association == false))
		{
			track[id].detectScore = 0;
			if (!track[id].b_tracking_success)
				track[id].link_cnt--;

			if (track[id].link_cnt < 0) track[id].link_cnt = 0;
		}
		else
		{
			if (track[id].IsAssociation == true)
				track[id].detectScore = s_detect[track[id].detectID].detectScore;
			else
				track[id].detectScore = w_detect[track[id].detectID].detectScore;

			track[id].link_cnt++;
			if (track[id].link_cnt > TRACK_LINK_N) track[id].link_cnt = TRACK_LINK_N;
		}

		track[id].detect_score_array[track[id].cnt%TRACK_ARRAY_N] = track[id].detectScore;
		track[id].cnt++;
		int max_array;
		if (track[id].cnt < TRACK_ARRAY_N)
		{
			max_array = track[id].cnt;
		}
		else
		{
			max_array = TRACK_ARRAY_N;
		}
		sum_detect_score = 0;
		for (int n = 0; n < max_array; n++)
		{
			sum_detect_score += track[id].detect_score_array[n];
		}
		mean_detect_score = sum_detect_score / max_array;

		track[id].sum_detect_score = sum_detect_score;
		track[id].mean_detect_score = mean_detect_score;

		Rect_f prev_roi = track[id].f_prevROI;


		if (track[id].IsAssociation == true)
		{
			track[id].f_prevROI = track_roi_update(track[id].f_predROI, s_detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, previous_weight);
		}
		else if (track[id].b_weak_association == true)
		{
			track[id].f_prevROI = track_roi_update(track[id].f_predROI, w_detect[track[id].detectID].detectROI, track[id].f_prevROI, track_weight, detect_weight, previous_weight);
		}
		else
		{
			track[id].f_prevROI = track_roi_update(track[id].f_predROI, s_detect[0].detectROI, track[id].f_prevROI, track_weight, detect_weight, previous_weight);
		}

		if (track[id].state == TRACK_INIT)
		{

			if (((track[id].cnt >= TRACK_INIT_COUNT) && (mean_detect_score > TRACK_INIT_LOW)) || (track[id].detectScore > TRACK_INIT_HIGH))
			{
				track[id].state = TRACK_ACTIVE;
				track[id].color = textColorTmp[id];
			}
			//			else if (mean_detect_score < TRACK_INIT_LOW)
			else if ((track[id].detectScore < DETECT_INIT_LOW) && (track[id].link_cnt <= 0))
			{
				terminate(id);
			}
			if (track[id].IsAssociation == true)
			{

#if APPEARANCE_MODEL == 1
				int nFeature = N_APPEARANCE_FEATURE;
				for (int k = 0; k < nFeature; k++)
					track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*s_detect[track[id].detectID].appearance_feature[k]);
#endif
			}
			else if (track[id].b_weak_association == true)
			{

#if APPEARANCE_MODEL == 1
				int nFeature = N_APPEARANCE_FEATURE;
				for (int k = 0; k < nFeature; k++)
					track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*w_detect[track[id].detectID].appearance_feature[k]);
#endif
			}

		}
		else if (track[id].state == TRACK_ACTIVE)
		{
			track[id].term_cnt = 0;

			if (track[id].IsAssociation == true)
			{
#if APPEARANCE_MODEL == 1
				int nFeature = N_APPEARANCE_FEATURE;
				for (int k = 0; k < nFeature; k++)
					track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*s_detect[track[id].detectID].appearance_feature[k]);
#endif

			}
			else if (track[id].b_weak_association == true)
			{

#if APPEARANCE_MODEL == 1
				int nFeature = N_APPEARANCE_FEATURE;
				for (int k = 0; k < nFeature; k++)
					track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*w_detect[track[id].detectID].appearance_feature[k]);
#endif
			}

			if (((mean_detect_score < TRACK_ACTIVE_LOW) && (track[id].link_cnt <= 0)) || (mean_detect_score < TRACK_TERM_LOW))
			{
				track[id].state = TRACK_TERMINATE;
				track[id].cnt = 0;
				track[id].link_cnt = 0;
			}

		}
		else if (track[id].state == TRACK_TERMINATE)
		{
			track[id].term_cnt++;

			if (track[id].IsAssociation == true)
			{
#if APPEARANCE_MODEL == 1
				//prevFeature = 0.3*prevFeature + 0.7*detectFeature
				int nFeature = N_APPEARANCE_FEATURE;
				for (int k = 0; k < nFeature; k++)
					track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*s_detect[track[id].detectID].appearance_feature[k]);
#endif
			}
			else if (track[id].b_weak_association == true)
			{
#if APPEARANCE_MODEL == 1
				int nFeature = N_APPEARANCE_FEATURE;
				for (int k = 0; k < nFeature; k++)
					track[id].prevFeature[k] = (float)(feat_update_weight*track[id].prevFeature[k] + (1 - feat_update_weight)*w_detect[track[id].detectID].appearance_feature[k]);
#endif
			}
			if (track[id].detectScore > TRACK_INIT_LOW) //track tereminate »óÅÂ¿¡¼­ ´Ù½Ã active »óÅÂ·Î °¥·Á¸é score low ÀÌ»óÀÌ µÇ¾î¾ßµÈ´Ù.
			{
				track[id].state = TRACK_ACTIVE;
			}
			else if ((mean_detect_score < TRACK_TERM_LOW) && (track[id].term_cnt > TRACK_TERM_N))
			{
				terminate(id);
			}

		}

		if (track[id].state == TRACK_ACTIVE)
			track[id].IsActive = true;
#if VISUAL_TRACKING == 1
		//visual tracking update
		if ((track[id].state != TRACK_INACTIVE) && ((track[id].IsAssociation == true) || (track[id].b_weak_association == true)))
		{
			Rect i_roi = convert_rectf_to_rect(track[id].f_prevROI);

			mkcf_tracker.train_kernel_alpha(mkcf_tracker.channel_image, mkcf_tracker.Hann_filter, i_roi, mkcf_tracker.Y, false, mkcf_tracker.ALPHA[id], mkcf_tracker.channel_roi_img[id]);
		}
#endif
#if MOTION_TRACKING == 1 || VISUAL_TRACKING == 1
		float ramda1 = 0.5, ramda2 = 0.9;
		if (track[id].state != TRACK_INACTIVE)
		{
			track[id].mt_box_flow.box_x = ramda1 * track[id].mt_box_flow.box_x + (1 - ramda1) * ((track[id].f_prevROI.x + track[id].f_prevROI.width / 2.) - (prev_roi.x + prev_roi.width / 2.));
			track[id].mt_box_flow.box_y = ramda1 * track[id].mt_box_flow.box_y + (1 - ramda1) * ((track[id].f_prevROI.y + track[id].f_prevROI.height / 2.) - (prev_roi.y + prev_roi.height / 2.));
			track[id].mt_box_flow.box_w = ramda2 * track[id].mt_box_flow.box_w + (1 - ramda2) * (track[id].f_prevROI.width / (prev_roi.width + 0.00001));
			track[id].mt_box_flow.box_h = ramda2 * track[id].mt_box_flow.box_h + (1 - ramda2) * (track[id].f_prevROI.height / (prev_roi.height + 0.00001));

		}

#endif
		//		printf("%d) status = %d da = %d track = %d\n", id, track[id].state, track[id].IsAssociation, track[id].b_tracking_success);
		//		printf("%d) f_prevROI = (%f %f %f %f)\n", id, track[id].f_prevROI.x, track[id].f_prevROI.y, track[id].f_prevROI.width, track[id].f_prevROI.height);
		//		printf("detect_roi = (%f %f %f %f)\n", s_detect[track[id].detectID].detectROI.x, detect[track[id].detectID].detectROI.y, detect[track[id].detectID].detectROI.width, detect[track[id].detectID].detectROI.height);
		//		printf("f_pred_roi = (%f %f %f %f)\n", track[id].f_predROI.x, track[id].f_predROI.y, track[id].f_predROI.width, track[id].f_predROI.height);

		//		printf("weight = (%f %f %f)\n", track_weight, detect_weight, predict_weight);

	}

}


Rect_f cl_tracking::track_roi_update(Rect_f src_roi1, Rect_f src_roi2, Rect_f src_roi3, float weight1, float weight2, float weight3)
{
	Rect_f dst_roi;
	float w1 = weight1;
	float w2 = weight2;
	float w3 = weight3;
	dst_roi.x = (float)(w1*src_roi1.x + w2 * src_roi2.x + w3 * src_roi3.x);
	dst_roi.y = (float)(w1*src_roi1.y + w2 * src_roi2.y + w3 * src_roi3.y);
	dst_roi.width = (float)(w1*src_roi1.width + w2 * src_roi2.width + w3 * src_roi3.width);
	dst_roi.height = (float)(w1*src_roi1.height + w2 * src_roi2.height + w3 * src_roi3.height);
	return dst_roi;
}




#if 0  //ninolyc_07
void cl_tracking::creat(int detectID)
{
	int i;
	for (i = 0; i < MAX_TRACK; i++)
	{
		//		printf("%d) = %d %d\n", i, track[i].IsActive, track[i].state);
		if (track[i].state == TRACK_INACTIVE)
		{
			if (track_initialize(i, detectID))
			{
				nTrack++;
			}
			break;

		}
	}

	if (i == MAX_TRACK)
	{
		printf("The number of track objects is more than the MAX_TRACK!!!!!!!!!!\n");
		exit(0);
	}
}
#else
void cl_tracking::creat(int detectID) //ninolyc_07
{
	static int track_seq_id = 0; //ÇÏ³ªÀÇ sequence¿¡¼­ uniqueÇÑ track id
	if (track_init) //sequence°¡ »õ·Î½ÃÀÛÇÏ¸é track_seq_idµµ ÃÊ±âÈ­
	{
		track_seq_id = 0;
		track_init = false;
	}
	bool b_find = false; //ÇÒ´çÇÑ track id¸¦ Ã£À¸¸é true

	int track_seq_end = (track_seq_id - 1 + MAX_TRACK) % MAX_TRACK; //track_seq_endÇöÀçÀÇ track_seq_idº¸´Ù 1ÀûÀº °ª (0ÀÏ ¶§´Â MAX_TRACK-1 ÀÌ µÊ)

	int tr_id = track_seq_id;

	int nCnt = 0;

	while (tr_id != track_seq_end)  //¸ðµç °¡´ÉÇÑ track id¸¦ °Ë»öÇØº½
	{
		//		printf("(%d)   %d)= %d\n", nTrack, tr_id, track[tr_id].IsActive);
		if (track[tr_id].state == TRACK_INACTIVE)
		{
			b_find = true;
			track_seq_id = tr_id;
			break;
		}
		tr_id = (tr_id + 1) % MAX_TRACK; 

		nCnt++;

	}


	if (b_find == true)
	{
		if (track_initialize(track_seq_id, detectID))
		{
			nTrack++;
			track_seq_id++;
			track_seq_id = track_seq_id % MAX_TRACK;
		}
	}
	else
	{
		printf("The number of track objects is more than the MAX_TRACK!!!!!!!!!!\n");
		exit(0);
	}



}
#endif

void cl_tracking::terminate(int id)
{
	//	track[id].IsActive = FALSE;
	track[id].state = TRACK_INACTIVE;

	track[id].cnt = 0;
	track[id].link_cnt = 0;
	track[id].term_cnt = 0;
	track[id].color = Scalar(255, 255, 255);

	//previous
	track[id].f_prevROI.clear();
	track[id].detectScore = 0;

	//	float detect_score_array[TRACK_ARRAY_N];  //ninolyc_07

	for (int i = 0; i < TRACK_ARRAY_N; i++)
		track[id].detect_score_array[i] = 0;

	track[id].sum_detect_score = 0;
	track[id].mean_detect_score = 0;


	//next
	track[id].f_predROI.clear();
	track[id].predScore = 0;


	//association
	track[id].IsAssociation = false;
	track[id].b_weak_association = false;
	track[id].detectID = -1;

	nTrack--;
}

void mKCF_Track::generate_prob_out(dg_complex *Y)
{
	Mat image(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
	CvPoint2D32f center;
	float band_width2 = (float)(TRACK_LEARNING_WIDTH*TRACK_LEARNING_HEIGHT) / 256;
	center.x = (TRACK_LEARNING_WIDTH) / 2.;
	center.y = (TRACK_LEARNING_HEIGHT) / 2.;
	for (int y = 0; y < TRACK_LEARNING_HEIGHT; y++)
	{
		float *value = image.ptr<float>(y);
		for (int x = 0; x < TRACK_LEARNING_WIDTH; x++)
		{
			value[x] = exp(-((center.x - x)*(center.x - x) + (center.y - y)*(center.y - y)) / band_width2);
		}
	}
	mat_to_complex(image, Y);
#ifdef _2D_FFT_USE
	_fft2D(Y, image.cols, image.rows, FFT_FORWARD);
	//_fft(Y, FFT_POINT, FFT_FORWARD);
#else
	fft(Y, FFT_POINT);
#endif

	if (!image.empty()) image.release();

}

void mKCF_Track::generate_Hann_filter(Mat &filter)
{
	int n_pixel = filter.rows * filter.cols;
	for (int y = 0; y < filter.rows; y++)
	{
		float *pixel = filter.ptr<float>(y);
		for (int x = 0; x < filter.cols; x++)
		{
			//pixel[x] = sin(CV_PI*x/(filter.cols-1))*sin(CV_PI*y/(filter.rows-1));
			//pixel[x] = 0.5 - 0.5 * cos (2*CV_PI*x/filter.cols);
			pixel[x] = 0.25 * (1 - cos(2 * CV_PI*x / (filter.cols - 1))) * (1 - cos(2 * CV_PI*y / (filter.rows - 1)));
		}
	}
}

void mKCF_Track::train_kernel_alpha(Mat *image, Mat &hann_filter, Rect src_roi, dg_complex *Y, bool init, dg_complex *ALPHA, Mat *ch_roi)
{
	Mat resize_roi_image;
	Mat periodic_roi_img(TRACK_SAMPLE_HEIGHT, TRACK_SAMPLE_WIDTH, CV_32FC1);
	Mat *pooling_img = new Mat[KCF_TRACK_CHANNEL];
	Mat k(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
	dg_complex *C_ALPHA = new dg_complex[FFT_POINT];
	int n_gm_channel;
#ifdef GM_CHANNEL
	n_gm_channel = 1;
#else
	n_gm_channel = 0;
#endif

	for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
	{
		pooling_img[ch].create(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
		get_searching_roi(image[ch], src_roi, resize_roi_image, TRACK_SEARCHING_SCALE);
		resize_roi_image = resize_roi_image - 0.5;
		periodic_roi_img = resize_roi_image.mul(hann_filter);
		pooling_block(periodic_roi_img, pooling_img[ch], TRACK_CELL_WIDTH, TRACK_CELL_HEIGHT, "average_pooling");
	}
	get_gaussian_correlation(pooling_img, pooling_img, k);
	get_kernel_alpha(k, Y, C_ALPHA);

	if (!resize_roi_image.empty()) resize_roi_image.release();
	if (!periodic_roi_img.empty()) periodic_roi_img.release();
	if (!k.empty()) k.release();

#if 0
	Mat disp_image1;
	convertScaleAbs(k, disp_image1, 255, 0);
	imshow("output_image1", disp_image1);
	cvWaitKey(0);
#endif

	for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
	{
		if (init)
		{
			ch_roi[ch] = pooling_img[ch].clone();
			memcpy(ALPHA, C_ALPHA, sizeof(dg_complex)*FFT_POINT);
		}
		else
		{
			ch_roi[ch] = (1.0 - FILTER_LEARNING_RATE) * ch_roi[ch] + FILTER_LEARNING_RATE * pooling_img[ch];
			alpha_update(C_ALPHA, ALPHA, FFT_POINT, FILTER_LEARNING_RATE);
		}
	}

	delete[] C_ALPHA;
	delete[] pooling_img;
}


void mKCF_Track::alpha_update(dg_complex *C_ALPHA, dg_complex *U_ALPHA, int n_point, float update_rate)
{
	for (int k = 0; k < n_point; k++)
	{
		U_ALPHA[k].Im = update_rate * C_ALPHA[k].Im + (1 - update_rate) * U_ALPHA[k].Im;
		U_ALPHA[k].Re = update_rate * C_ALPHA[k].Re + (1 - update_rate) * U_ALPHA[k].Re;
		//printf("%d) re = %f im = %f\n", k, C_ALPHA[k].Re, C_ALPHA[k].Im);
	}
}

void mKCF_Track::get_gaussian_correlation(Mat *x1, Mat *x2, Mat &k)
{
	dg_complex *X1 = new dg_complex[FFT_POINT];
	dg_complex *X2 = new dg_complex[FFT_POINT];
	dg_complex *X1_X2 = new dg_complex[FFT_POINT];
	dg_complex *SUM_X1_X2 = new dg_complex[FFT_POINT];
	float sum_x1_2 = 0, sum_x2_2 = 0;

	Mat sum_x1_x2(x1[0].rows, x1[0].cols, CV_32FC1, Scalar(0));
	Mat d(x1[0].rows, x1[0].cols, CV_32FC1);
	float sigma = 0.2;

	for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
	{
		sum_x1_2 += sum(x1[ch].mul(x1[ch]))[0];
		sum_x2_2 += sum(x2[ch].mul(x2[ch]))[0];

		mat_to_complex(x1[ch], X1);
		mat_to_complex(x2[ch], X2);
#ifdef _2D_FFT_USE
		_fft2D(X1, x1[0].cols, x1[0].rows, FFT_FORWARD);
		_fft2D(X2, x2[0].cols, x2[0].rows, FFT_FORWARD);
		//_fft(X1, FFT_POINT, FFT_FORWARD);
		//_fft(X2, FFT_POINT, FFT_FORWARD);
#else
		fft(X1, FFT_POINT);
		fft(X2, FFT_POINT);
#endif
		complex_conjugate_vector(X1, FFT_POINT, X1);
		complex_multiplier_vector(X1, X2, FFT_POINT, X1_X2);
		if (ch == 0)
		{
			memcpy(SUM_X1_X2, X1_X2, sizeof(dg_complex)*FFT_POINT);
		}
		else
		{
			for (int p = 0; p < FFT_POINT; p++)
			{
				SUM_X1_X2[p].Im += X1_X2[p].Im;
				SUM_X1_X2[p].Re += X1_X2[p].Re;
			}
		}
	}
#ifdef _2D_FFT_USE
	_fft2D(SUM_X1_X2, x1[0].cols, x1[0].rows, FFT_BACKWARD);
#else
	ifft(SUM_X1_X2, FFT_POINT);
#endif
	complex_to_mat(SUM_X1_X2, FFT_POINT, sum_x1_x2);
	//rearrange(sum_x1_x2);

	max(((sum_x1_2 + sum_x2_2) - 2. * sum_x1_x2) / (x1[0].rows * x1[0].cols), 0, d);
	exp((-d / (sigma * sigma)), k);

	if (!sum_x1_x2.empty()) sum_x1_x2.release();
	if (!d.empty()) d.release();

	delete[] SUM_X1_X2;
	delete[] X1;
	delete[] X2;
	delete[] X1_X2;
}

void mKCF_Track::get_searching_roi(Mat &image, Rect src_roi, Mat &resize_roi_image, float searching_scale)
{
	Mat roi_image;
	Mat roi_padding_image;
	bool b_padding = false;

	int img_width = image.cols;
	int img_height = image.rows;
	CvPoint lt_pt, rb_pt;
	int left_border = 0, right_border = 0, up_border = 0, down_border = 0;
	float searching_margin = (searching_scale - 1) / 2.0;

	get_candidate_region(image, src_roi, searching_margin, lt_pt, rb_pt);
	if (lt_pt.x < 0)
	{
		left_border = -lt_pt.x;
		lt_pt.x = 0;
		b_padding = true;
	}
	if (lt_pt.y < 0)
	{
		up_border = -lt_pt.y;
		lt_pt.y = 0;
		b_padding = true;
	}

	if (rb_pt.x >= img_width)
	{
		right_border = rb_pt.x - img_width + 1;
		rb_pt.x = img_width - 1;
		b_padding = true;
	}

	if (rb_pt.y >= img_height)
	{
		down_border = rb_pt.y - img_height + 1;
		rb_pt.y = img_height - 1;
		b_padding = true;
	}
	Rect searching_region;
	searching_region.x = lt_pt.x;
	searching_region.y = lt_pt.y;
	searching_region.width = rb_pt.x - lt_pt.x + 1;
	searching_region.height = rb_pt.y - lt_pt.y + 1;
	roi_image = image(searching_region);
	if (b_padding == false)
	{
		roi_padding_image = image(searching_region);
	}
	else
	{
		roi_image = image(searching_region);
		copyMakeBorder(roi_image, roi_padding_image, up_border, down_border, left_border, right_border, BORDER_REPLICATE);
	}

	resize(roi_padding_image, resize_roi_image, Size(TRACK_SAMPLE_WIDTH, TRACK_SAMPLE_HEIGHT));

	if(!roi_image.empty()) roi_image.release();
	if(!roi_padding_image.empty()) roi_padding_image.release();
}

void mKCF_Track::get_candidate_region(Mat &src_image, Rect src_roi, float factor, CvPoint &lt_pt, CvPoint &rb_pt)
{
	lt_pt.x = src_roi.x - src_roi.width*factor;
	lt_pt.y = src_roi.y - src_roi.height*factor;

	rb_pt.x = src_roi.x + src_roi.width - 1 + src_roi.width*factor;
	rb_pt.y = src_roi.y + src_roi.height - 1 + src_roi.height*factor;
}

void mKCF_Track::get_kernel_alpha(Mat &k, dg_complex *Y, dg_complex *A)
{
	dg_complex *K = new dg_complex[FFT_POINT];
	mat_to_complex(k, K);
#ifdef _2D_FFT_USE
	_fft2D(K, k.cols, k.rows, FFT_FORWARD);
	//_fft(K, FFT_POINT, FFT_FORWARD);
#else
	fft(K, FFT_POINT);
#endif
	complex_division_vector(Y, K, FFT_POINT, A);

	delete[] K;
}


#define N_SCALE_STEP   1
float mKCF_Track::predict_roi(Rect src_roi, int tr_id, Rect &dst_roi)
{

#if N_SCALE_STEP == 1
	float score;
	Rect tmp_roi;
	tmp_roi = src_roi;
	score = get_kernel_correlation_out(channel_image, Hann_filter, ALPHA[tr_id], channel_roi_img[tr_id], Y, tmp_roi);

	dst_roi = tmp_roi;

	return score;

#else

	float score[N_SCALE_STEP];
	Rect multi_scale_roi[N_SCALE_STEP];
	float multi_scale_factor[N_SCALE_STEP] = { 0.9, 1.0, 1.1 };
	float multi_scale_prior[N_SCALE_STEP] = { 0.95, 1.0, 0.95 };
	get_kernel_correlation_out(channel_image, Hann_filter, ALPHA[tr_id], channel_roi_img[tr_id], Y, src_roi);
	get_multi_scale_roi(src_roi, multi_scale_roi, multi_scale_factor, N_SCALE_STEP);

	float max_score = -1.0;
	int max_score_id = 0;
	for (int scale_step = 0; scale_step < N_SCALE_STEP; scale_step++)
	{
		score[scale_step] = multi_scale_prior[scale_step] * get_kernel_correlation_out(channel_image, Hann_filter, ALPHA[tr_id], channel_roi_img[tr_id], Y, multi_scale_roi[scale_step]);
		if (score[scale_step] > max_score)
		{
			max_score = score[scale_step];
			max_score_id = scale_step;
		}

		//		printf("score[%d] = %f\n", scale_step, score[scale_step]);
	}

	dst_roi = multi_scale_roi[max_score_id];

	return max_score;

#endif
}





void mKCF_Track::get_multi_scale_roi(Rect src_roi, Rect *multi_scale_roi, float *multi_scale_factor, int n_multi_roi)
{
	CvPoint2D32f cent_point;
	cent_point.x = src_roi.x + src_roi.width / 2.0;
	cent_point.y = src_roi.y + src_roi.height / 2.0;
	float f_width, f_height;
	for (int sc = 0; sc < n_multi_roi; sc++)
	{
		f_width = src_roi.width * multi_scale_factor[sc];
		f_height = src_roi.height * multi_scale_factor[sc];
		//¹Ý¿Ã¸²
		multi_scale_roi[sc].x = cent_point.x - f_width / 2 + 0.5;
		multi_scale_roi[sc].y = cent_point.y - f_height / 2 + 0.5;
		multi_scale_roi[sc].width = f_width + 0.5;
		multi_scale_roi[sc].height = f_height + 0.5;
	}
}

float mKCF_Track::get_kernel_correlation_out(Mat *image, Mat &hann_filter, dg_complex *ALPHA, Mat *ch_roi_image, dg_complex *Y, Rect &roi)
{
	Mat resize_roi_image;
	Mat periodic_roi_img(TRACK_SAMPLE_HEIGHT, TRACK_SAMPLE_WIDTH, CV_32FC1);
	Mat *pooling_img = new Mat[KCF_TRACK_CHANNEL];
	Mat k(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
	Mat prob_map(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
	int n_gm_channel;
#ifdef GM_CHANNEL
	n_gm_channel = 1;
#else
	n_gm_channel = 0;
#endif

	for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
	{
		pooling_img[ch].create(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32FC1);
		get_searching_roi(image[ch], roi, resize_roi_image, TRACK_SEARCHING_SCALE);
		resize_roi_image = resize_roi_image - 0.5;

		periodic_roi_img = resize_roi_image.mul(hann_filter);
		pooling_block(periodic_roi_img, pooling_img[ch], TRACK_CELL_WIDTH, TRACK_CELL_HEIGHT, "average_pooling");

#if 0
		cv::Mat disp_image1, disp_image2, disp_image3, disp_image4;
		convertScaleAbs(ch_roi_image[ch], disp_image1, 255, 0);
		convertScaleAbs(resize_roi_image, disp_image2, 255, 0);
		convertScaleAbs(periodic_roi_img, disp_image3, 255, 0);
		convertScaleAbs(pooling_img[ch], disp_image4, 255, 0);

		imshow("output_image1", disp_image1);
		imshow("output_image2", disp_image2);
		imshow("output_image3", disp_image3);
		imshow("output_image4", disp_image3);

		cvWaitKey(0);
#endif
	}
	get_gaussian_correlation(ch_roi_image, pooling_img, k);

	get_prob_out_map(k, ALPHA, prob_map);

#if 0
	cv::Mat disp_image1, disp_image2;
	convertScaleAbs(k, disp_image1, 255, 0);
	convertScaleAbs(prob_map, disp_image2, 255, 0);

	imshow("output_image1", disp_image1);
	imshow("output_image2", disp_image2);

	cvWaitKey(0);

#endif

	CvPoint2D32f max_peak;
	float max_value;
	max_peak.x = TRACK_LEARNING_WIDTH / 2;
	max_peak.y = TRACK_LEARNING_HEIGHT / 2;
	max_value = 0.0;


	if (!resize_roi_image.empty()) resize_roi_image.release();
	if (!periodic_roi_img.empty()) periodic_roi_img.release();
	if (!k.empty()) k.release();

	if (get_max_peak_and_value(prob_map, max_peak, max_value))
	{
		if (!prob_map.empty()) prob_map.release();
		delete[] pooling_img;
		return 0;
	}
	else
	{
		Rect src_roi = roi;
		get_roi_from_peak(max_peak, src_roi, roi);

		delete[] pooling_img;
		if (!prob_map.empty()) prob_map.release();
		return max_value;
	}

}

void mKCF_Track::get_prob_out_map(Mat &k, dg_complex *A, Mat &prob_map)
{
	dg_complex *K = new dg_complex[FFT_POINT];
	dg_complex *G = new dg_complex[FFT_POINT];

	mat_to_complex(k, K);
#ifdef _2D_FFT_USE
	_fft2D(K, k.cols, k.rows, FFT_FORWARD);
	//_fft(K, FFT_POINT, FFT_FORWARD);
#else
	fft(K, FFT_POINT);
#endif
	complex_multiplier_vector(K, A, FFT_POINT, G);
#ifdef _2D_FFT_USE
	_fft2D(G, k.cols, k.rows, FFT_BACKWARD);
	//_fft(G, FFT_POINT, FFT_BACKWARD);
#else
	ifft(G, FFT_POINT);
#endif
	complex_to_mat(G, FFT_POINT, prob_map);

	delete[] K;
	delete[] G;
}

bool mKCF_Track::get_max_peak_and_value(Mat &prob_map, CvPoint2D32f &max_peak, float &max_value)
{
	float  sec_max_value, diff_value;
	CvPoint2D32f sec_max_peak;

	for (int y = 0; y < TRACK_LEARNING_HEIGHT; y++)
	{
		float *value = prob_map.ptr<float>(y);
		for (int x = 0; x < TRACK_LEARNING_WIDTH; x++)
		{
			if (value[x] > max_value)
			{
				sec_max_value = max_value;
				sec_max_peak.x = max_peak.x;
				sec_max_peak.y = max_peak.y;

				max_value = value[x];
				max_peak.x = (float)x;
				max_peak.y = (float)y;
			}
			//if (((x==31) && (y==31)) || ((x==31) && (y==32)) || ((x==31) && (y==33)) || ((x==32) && (y==31)) || ((x==32) && (y==32)) || ((x==32) && (y==33)) || ((x==33) && (y==31)) || ((x==33) && (y==32)) || ((x==33) && (y==33)))
			//printf("(%d %d) = %f\n", x, y, value[x]);
		}
	}

	//	printf("(%f %f) = %f (%f %f) = %f\n", max_peak.x, max_peak.y, max_value, sec_max_peak.x, sec_max_peak.y, sec_max_value);

	if ((abs(max_peak.x - sec_max_peak.x) > 1) || (abs(max_peak.y - sec_max_peak.y) > 1))
	{
		//		printf("(%f %f) = %f (%f %f) = %f\n", max_peak.x, max_peak.y, max_value, sec_max_peak.x, sec_max_peak.y, sec_max_value);
		return true;
	}
	else
	{
		return false;
	}
	return true;
}

void mKCF_Track::get_roi_from_peak(CvPoint2D32f peak, Rect src_roi, Rect &dst_roi)
{
	CvPoint2D32f center, roi_center;
	float resize_factor_x = (float)src_roi.width*TRACK_SEARCHING_SCALE / TRACK_SAMPLE_WIDTH;
	float resize_factor_y = (float)src_roi.height*TRACK_SEARCHING_SCALE / TRACK_SAMPLE_HEIGHT;

	center.x = peak.x*TRACK_CELL_WIDTH*resize_factor_x;
	center.y = peak.y*TRACK_CELL_HEIGHT*resize_factor_y;

	roi_center.x = center.x - (TRACK_SEARCHING_SCALE - 1)*src_roi.width / 2.0;
	roi_center.y = center.y - (TRACK_SEARCHING_SCALE - 1)*src_roi.height / 2.0;

	dst_roi.x = roi_center.x - (float)(src_roi.width) / 2.0 + src_roi.x + 0.5;
	dst_roi.y = roi_center.y - (float)(src_roi.height) / 2.0 + src_roi.y + 0.5;

	dst_roi.width = src_roi.width;
	dst_roi.height = src_roi.height;
	//printf("x = %f, y = %f \n", center.x, center.y);
}

void roi_score_probability(std::vector<float> &roi_score, float MIN_SCOREscore_sum)
{
#if 0
	float quarter_max_score = score_sum / 4;
	float hit_threshold_score = abs(DT_HIT_THRESHOLD);
	for (int id = 0; id < (int)roi_score.size(); id++)
	{
		//		printf("1) roi_score[%d] = %f \n", id, roi_score[id]);
		roi_score[id] = MIN(MAX(0.0, (hit_threshold_score + roi_score[id]) / quarter_max_score), 1.0);
		//		printf("2) roi_score[%d] = %f \n", id, roi_score[id]);
	}
#else

	return;

	int max_score = DETECT_SCORE_HIGH;
	int min_score = DETECT_SCORE_LOW;
	float score_bias = 0.5;

	for (int id = 0; id < (int)roi_score.size(); id++)
	{
		if (roi_score[id] > 0)
		{
			roi_score[id] = score_bias + (1 - score_bias) * MIN(1.0, roi_score[id] / max_score);
		}
		else
		{
			roi_score[id] = score_bias - score_bias * MIN(1.0, roi_score[id] / min_score);
		}

		//		printf("2) norm_score = %f roi_score[%d] = %f \n", norm_score, id, roi_score[id]);
	}

#endif
}

Rect convert_rectf_to_rect(Rect_f rect_f)
{
	Rect rect;
	rect.x = rect_f.x + 0.5;
	rect.y = rect_f.y + 0.5;
	rect.width = rect_f.width + 0.5;
	rect.height = rect_f.height + 0.5;

	return rect;
}

Rect_f convert_rect_to_rect_f(Rect rect)
{
	Rect_f rect_f;
	rect_f.x = rect.x;
	rect_f.y = rect.y;
	rect_f.width = rect.width;
	rect_f.height = rect.height;

	return rect_f;
}

void get_track_channel_image(Mat &image, Mat *ch_image, st_feature &feature)
{
	int n_bin = feature.n_bin;
	int n_grad_channel = feature.n_bin + feature.n_grad_mag;
	int n_channel = feature.n_channel;

	for (int k = 0; k < APPEARANCE_CHANNEL; k++)
	{
		ch_image[k].create(image.rows, image.cols, CV_32F);
		ch_image[k].setTo(Scalar(0.0));
	}

	if (feature.use_color_channel)
	{
#if YCBCR444
		if (image.type() == CV_32FC3)
		{
			yc_to_ch_image_32F(image, &ch_image[APPEARANCE_CHANNEL - 3]);
		}
		else if (image.type() == CV_8UC3)
		{
			yc_to_ch_image(image, &ch_image[APPEARANCE_CHANNEL - 3]);
		}
		else
		{
			printf("Not supported format!\n");
		}
#else
		_luv_to_ch_image(image, &ch_image[TRACK_CHANNEL - 3]);
#endif
	}
	else
		image.convertTo(ch_image[APPEARANCE_CHANNEL - 1], CV_32FC1);

#ifdef GM_CHANNEL
	if (feature.use_color_channel)
	{
		Mat grad_image, mag_image;
		grad_image.create(image.rows, image.cols, CV_32F);
		mag_image = ch_image[0];

		Mat grad_image_tmp[3], mag_image_tmp[3];
		for (int ch = 0; ch < 3; ch++)
		{
			grad_image_tmp[ch].create(image.rows, image.cols, CV_32F);
			mag_image_tmp[ch].create(image.rows, image.cols, CV_32F);
			get_mag_grad_image(ch_image[ch + 1], grad_image_tmp[ch], mag_image_tmp[ch]);
		}

		max_mag_grad_image(grad_image_tmp, mag_image_tmp, grad_image, mag_image);
	}
	else
	{
		Mat grad_image, mag_image;
		grad_image.create(image.rows, image.cols, CV_32F);
		mag_image = ch_image[0];
		get_mag_grad_image(ch_image[1], grad_image, mag_image);
	}
#endif

	for (int ch = 0; ch < APPEARANCE_CHANNEL; ch++)
	{
		double min_value, max_value;
		minMaxLoc(ch_image[ch], &min_value, &max_value);
		ch_image[ch] /= max_value;
	}
}


void cl_tracking::write_track_result(FILE *eval_fp, int frame_id)
{
	for (int i = 0; i < nMapping; i++)
	{
		int track_id = mapping[i];
		if ((track[track_id].state == TRACK_INACTIVE) || (track[track_id].state == TRACK_INIT) || (track[track_id].state == TRACK_TERMINATE))
			continue;

		CvRect rectTmp;
		rectTmp.x = (int)track[track_id].f_prevROI.x;
		rectTmp.y = (int)track[track_id].f_prevROI.y;
		rectTmp.width = (int)track[track_id].f_prevROI.width;
		rectTmp.height = (int)track[track_id].f_prevROI.height;

		track_id += 1;  //1부터 id를 저장하기 위해서..for matlab evaluation

		fprintf(eval_fp, "%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", frame_id, track_id, rectTmp.x, rectTmp.y, rectTmp.width, rectTmp.height, 1, -1, -1, -1);
	}
}

int get_current_data_time(char *buff, char *type)
{
	std::time_t rawtime;
	std::tm* timeinfo;
	std::time(&rawtime);
	int result = 0;

	timeinfo = std::localtime(&rawtime);
	std::strftime(buff, 80, "%Y%m%d%H%M%S", timeinfo);
//	printf("11111111111)%d\n", timeinfo->tm_sec);
	if (strcmp(type, "M") == 0)
	{
		result = timeinfo->tm_sec;
	}
	if (strcmp(type, "H") == 0)
	{
		result = timeinfo->tm_min;
	}
	if (strcmp(type, "D") == 0)
	{
		result = timeinfo->tm_hour;
	}

	return result;
}


int Osan_get_current_data_time(char *buff, char *type)
{
	std::time_t rawtime;
	std::tm* timeinfo;
	std::time(&rawtime);
	int result = 0;

	timeinfo = std::localtime(&rawtime);
	std::strftime(buff, 80, "%Y.%m.%d %H:%M:%S", timeinfo);
	//	printf("11111111111)%d\n", timeinfo->tm_sec);
	if (strcmp(type, "M") == 0)
	{
		result = timeinfo->tm_sec;
	}
	if (strcmp(type, "H") == 0)
	{
		result = timeinfo->tm_min;
	}
	if (strcmp(type, "D") == 0)
	{
		result = timeinfo->tm_hour;
	}

	return result;
}

void get_detection_info(int nCameraIndex, Mat& image, st_mot_info *mot_info, float fXratio, float fYratio)
{
	int n_s_detect = 0, n_w_detect = 0;
	float lu_pt_x, lu_pt_y, rd_pt_x, rd_pt_y;
	CvRect rtTemp;
	int nMinBoxSize = 2;
	for (int i = 0; i < mot_info->n_detect_num; i++)
	{
		if (mot_info->det_box_info[i].class_group_id < 0)
			continue;

		rtTemp = mot_info->det_box_info[i].bouding_box;

		CvRect rtResBox;
		rtResBox.x		= (int)((float)rtTemp.x			/ fXratio);
		rtResBox.width	= (int)((float)rtTemp.width		/ fXratio);
		rtResBox.y		= (int)((float)rtTemp.y			/ fYratio);
		rtResBox.height = (int)((float)rtTemp.height	/ fYratio);

		if (rtResBox.x < 0)
			rtResBox.x = 0;
		if (rtResBox.y < 0)
			rtResBox.y = 0;
		if (rtResBox.x >=	image.cols - nMinBoxSize)
			rtResBox.x =	image.cols - nMinBoxSize;
		if (rtResBox.y >=	image.rows - nMinBoxSize)
			rtResBox.y =	image.rows - nMinBoxSize;

		if (rtResBox.width < nMinBoxSize)
			rtResBox.width = nMinBoxSize;
		if (rtResBox.height < nMinBoxSize)
			rtResBox.height = nMinBoxSize;

		if (rtResBox.x + rtResBox.width >= image.cols - nMinBoxSize)
			rtResBox.width = image.cols - rtResBox.x - 1;
		if (rtResBox.y + rtResBox.height >= image.rows - nMinBoxSize)
			rtResBox.height = image.rows - rtResBox.y - 1;

		mot_info->det_box_info[i].bouding_box = rtResBox;

		if (mot_info->det_box_info[i].score > mot_info->s_thresh)
		{
			//lu_pt_x = (mot_info->det_box_info[i].bouding_box.x < 0) ? 0 : mot_info->det_box_info[i].bouding_box.x;
			//lu_pt_y = (mot_info->det_box_info[i].bouding_box.y < 0) ? 0 : mot_info->det_box_info[i].bouding_box.y;
			//rd_pt_x = ((mot_info->det_box_info[i].bouding_box.x + mot_info->det_box_info[i].bouding_box.width) > image.cols) ? (image.cols - 1) : (mot_info->det_box_info[i].bouding_box.x + mot_info->det_box_info[i].bouding_box.width - 1);
			//rd_pt_y = ((mot_info->det_box_info[i].bouding_box.y + mot_info->det_box_info[i].bouding_box.height) > image.rows) ? (image.rows - 1) : (mot_info->det_box_info[i].bouding_box.y + mot_info->det_box_info[i].bouding_box.height - 1);

			/*tracking[nCameraIndex].s_detect[n_s_detect].detectROI.x = lu_pt_x;
			tracking[nCameraIndex].s_detect[n_s_detect].detectROI.y = lu_pt_y;
			tracking[nCameraIndex].s_detect[n_s_detect].detectROI.width = rd_pt_x - lu_pt_x + 1;
			tracking[nCameraIndex].s_detect[n_s_detect].detectROI.height = rd_pt_y - lu_pt_y + 1;*/

			tracking[nCameraIndex].s_detect[n_s_detect].detectROI.x			= rtResBox.x;
			tracking[nCameraIndex].s_detect[n_s_detect].detectROI.y			= rtResBox.y;
			tracking[nCameraIndex].s_detect[n_s_detect].detectROI.width		= rtResBox.width;
			tracking[nCameraIndex].s_detect[n_s_detect].detectROI.height	= rtResBox.height;


			tracking[nCameraIndex].s_detect[n_s_detect].detectScore = mot_info->det_box_info[i].score;

			tracking[nCameraIndex].s_detect[n_s_detect].class_id = mot_info->det_box_info[i].class_id;
			tracking[nCameraIndex].s_detect[n_s_detect].class_group_id = mot_info->det_box_info[i].class_group_id;
			n_s_detect++;
		}
		else
		{
			//lu_pt_x = (mot_info->det_box_info[i].bouding_box.x < 0) ? 0 : mot_info->det_box_info[i].bouding_box.x;
			//lu_pt_y = (mot_info->det_box_info[i].bouding_box.y < 0) ? 0 : mot_info->det_box_info[i].bouding_box.y;
			//rd_pt_x = ((mot_info->det_box_info[i].bouding_box.x + mot_info->det_box_info[i].bouding_box.width) > image.cols) ? (image.cols - 1) : (mot_info->det_box_info[i].bouding_box.x + mot_info->det_box_info[i].bouding_box.width - 1);
			//rd_pt_y = ((mot_info->det_box_info[i].bouding_box.y + mot_info->det_box_info[i].bouding_box.height) > image.rows) ? (image.rows - 1) : (mot_info->det_box_info[i].bouding_box.y + mot_info->det_box_info[i].bouding_box.height - 1);


			tracking[nCameraIndex].w_detect[n_w_detect].detectROI.x			= rtResBox.x;
			tracking[nCameraIndex].w_detect[n_w_detect].detectROI.y			= rtResBox.y;
			tracking[nCameraIndex].w_detect[n_w_detect].detectROI.width		= rtResBox.width;
			tracking[nCameraIndex].w_detect[n_w_detect].detectROI.height	= rtResBox.height;


			tracking[nCameraIndex].w_detect[n_w_detect].detectScore = mot_info->det_box_info[i].score;

			tracking[nCameraIndex].w_detect[n_w_detect].class_id = mot_info->det_box_info[i].class_id;
			tracking[nCameraIndex].w_detect[n_w_detect].class_group_id = mot_info->det_box_info[i].class_group_id;
			n_w_detect++;
		}

	}
	tracking[nCameraIndex].n_s_detect = n_s_detect;
	tracking[nCameraIndex].n_w_detect = n_w_detect;
}




