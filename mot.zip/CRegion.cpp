
#include "CRegion.h"
#include "Windows.h"
#include "param_set.h"
#include "complex.h"

CRegion::CRegion()
{
	m_nSelectedPoint = -1;

	a02 = b02 = c02 = 0.0; // wrong lane violation 2018.08.08
	a13 = b13 = c13 = 0.0; // wrong lane violation 2018.08.08
	a45 = b45 = c45 = 0.0; // wrong lane violation 2018.08.08

	aO = bO = cO = 0.0;	 //0-2 line
	aI = bI = cI = 0.0;  //1-3 line

	aR_wL = bR_wL = cR_wL = 0.0; //Left vanish
	aR_wR = bR_wR = cR_wR = 0.0; //Right vanish

	aR_hT = bR_hT = cR_hT = 0.0; //top vanish
	aR_hB = bR_hB = cR_hB = 0.0; //bottom vanish

	m_bUseYparabol = m_bUseXparabol = false;

#if VDS_MODE == 1
	for (int i = 0; i < ROAD_LINE_MAX; i++)
	{
		l_box[i].use = 0;
		r_box[i].use = 0;
	}

	for (int k = 0; k < 2; k++)
	{
		for (int i = 0; i < ROAD_LINE_MAX; i++)
		{
			m_startCnt[k][i] = 0;
			m_EndCnt[k][i] = 0;
		}
	}

	fLoopLength = 0.0f;
#endif
}

CRegion::~CRegion()
{
}


void CRegion::CRegion_set_Xspeed_points(cv::Point* _ptXspeed)
{
	for (int nPt = 0; nPt < 5; nPt++) // 2018.08.08
	{
		m_ptXspeed[nPt].x = _ptXspeed[nPt].x;
		m_ptXspeed[nPt].y = _ptXspeed[nPt].y;
	}
}

void CRegion::CRegion_update_Xspeed_points(int nCameraIndex)
{
	//  3    4
	// 2  1  0

	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH];
	sprintf(currentPath, "%s", getModulPath());

	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	char tmp[32]; tmp[0] = '\0';
	_itoa(m_ptXspeed[0].y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "XSPEED_Y", tmp, strIniFilePath);

	for (int i = 0; i < 4; i++)
	{
		char strParams[100];
		sprintf(strParams, "XSPEED_%d_X", i);
		_itoa(m_ptXspeed[i].x, (LPSTR)(LPCSTR)tmp, 10);
		WritePrivateProfileString("Position", strParams, tmp, strIniFilePath);
	}
}

cv::Point* CRegion::CRegion_get_Xspeed_points()
{
	return m_ptXspeed;
}

#if VDS_MODE == 1

void CRegion::CRegion_calculate_XspeedROI_params(CCamPosition* pCamPosition, int nHeight, float fXRightMid, float fXRightLeft)
{
	//  3    4
	// 2  1  0

	// sample
	/*
		a02 = (float)(m_ptLine[2].y - m_ptLine[0].y);
		b02 = (float)(m_ptLine[0].x - m_ptLine[2].x);
		c02 = a02 * (m_ptLine[0].x) + b02 * (m_ptLine[0].y);
	*/

	// [automatically draw vanishing line]
	// loop 1 - line left [0---2] and line right [1---3]
	float aL = (float)(l_box[0].point[0].y - l_box[0].point[2].y);
	float bL = (float)(l_box[0].point[2].x - l_box[0].point[0].x);
	float cL = aL * (l_box[0].point[2].x) + bL * (l_box[0].point[2].y);

	float aR = (float)(l_box[0].point[1].y - l_box[0].point[3].y);
	float bR = (float)(l_box[0].point[3].x - l_box[0].point[1].x);
	float cR = aR * (l_box[0].point[1].x) + bR * (l_box[0].point[1].y);

	// Y vanishing point
	if (aL * bR - aR * bL != 0.0f)
	{
		m_ptXspeed[0].x = m_ptXspeed[4].x = (cL * bR - cR * bL) / (aL * bR - aR * bL);
	}


	aR_wL = (float)(m_ptXspeed[3].y - m_ptXspeed[2].y);
	bR_wL = (float)(m_ptXspeed[2].x - m_ptXspeed[3].x);
	cR_wL = aR_wL * float(m_ptXspeed[2].x) + bR_wL * float(m_ptXspeed[2].y);

	aR_wR = (float)(m_ptXspeed[4].y - m_ptXspeed[0].y);
	bR_wR = (float)(m_ptXspeed[0].x - m_ptXspeed[4].x);
	cR_wR = aR_wR * float(m_ptXspeed[0].x) + bR_wR * float(m_ptXspeed[0].y);

	// a * x + b * y = c
	// a * Il + b * Rl = c  // left image pt/ road pt    |image pt: I[0] - I[2]
	// a * Im + b * Rm = c  // middle image pt / road pt |image pt: I[0] - I[1]

	// Rl = fXRightLeft
	// Rm = fRightMid

	// Il = m_ptXspeed[0].x - m_ptXspeed[2].x
	// Im = m_ptXspeed[0].x - m_ptXspeed[1].x

	// convert 
	// a = Rm - Rl			
	// b = Il - Im
	// c = a * Il + b * Rl

	aX_coord = (float)(fXRightMid - fXRightLeft);
	bX_coord = (float)(m_ptXspeed[0].x - m_ptXspeed[2].x) - float(m_ptXspeed[0].x - m_ptXspeed[1].x);
	cX_coord = aX_coord * float(m_ptXspeed[0].x - m_ptXspeed[2].x) + bX_coord * fXRightLeft;


	float fDistanceLoop0 = pCamPosition->CCamPosition_Ydistance_calculation(nHeight, l_box[0].point[0].y);
	float fDistanceLoop2 = pCamPosition->CCamPosition_Ydistance_calculation(nHeight, l_box[0].point[2].y);

	fLoopLength = abs(fDistanceLoop2 - fDistanceLoop0);

}

#endif

// SIMPLE_MODE
void CRegion::CRegion_get_distance_simple(CCamPosition* pCamPosition, int nHeight, cv::Point ptCrt, float& fDistanceY, float& fDistanceX)
{
	fDistanceY = pCamPosition->CCamPosition_Ydistance_calculation(nHeight, ptCrt.y);

	fDistanceX = 0.0f;

	//  3    4
	// 2  1  0

	// sample
	// X = -(b / a)*Y + (c / a);
	// Y = -(a / b)*X + (c / b);

	if (bX_coord != 0 && aR_wR != 0 && aR_wL != 0)
	{
		// for current
		float fLeft = -(bR_wL / aR_wL) * (float)ptCrt.y + (cR_wL / aR_wL);
		float fRight = -(bR_wR / aR_wR) * (float)ptCrt.y + (cR_wR / aR_wR);

		if ((fLeft - fRight) != 0.0f)
		{
			float fprojected = (float)(m_ptXspeed[2].x - m_ptXspeed[0].x) * ((float)ptCrt.x - fRight) / (float)(fLeft - fRight) + (float)m_ptXspeed[0].x;
			float fSx = (float)m_ptXspeed[0].x - fprojected;

			fDistanceX = -((float)aX_coord / (float)bX_coord) * (float)fSx + (float)cX_coord / (float)bX_coord;
		}
	}
	
}


// GENERAL MODE
//for X and Y distance calculation

void CRegion::CRegion_setVanishing(cv::Point* _ptVanish)
{
	for (int nPt = 0; nPt < 7; nPt++) // 2018.08.08
	{
		m_ptVanish[nPt].x = _ptVanish[nPt].x;
		m_ptVanish[nPt].y = _ptVanish[nPt].y;
	}
}

void CRegion::CRegion_update_vanish_points(int nCameraIndex)
{
	// 0   6
	// 1
	// 2  3  4  5

	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH];
	sprintf(currentPath, "%s", getModulPath());

	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	char tmp[32]; tmp[0] = '\0';
	/*_itoa(m_ptVanish[0].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "POLE_LINE_X", tmp, strIniFilePath);*/

	_itoa(m_ptVanish[0].y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "POLE_LINE_YTOP", tmp, strIniFilePath);

	_itoa(m_ptVanish[1].y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "POLE_LINE_YCENTER", tmp, strIniFilePath);

	_itoa(m_ptVanish[2].y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "POLE_LINE_YBOT", tmp, strIniFilePath);

	_itoa(m_ptVanish[3].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "POLE_LINE_XLEFT", tmp, strIniFilePath);

	_itoa(m_ptVanish[4].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "POLE_LINE_XCENTER", tmp, strIniFilePath);

	_itoa(m_ptVanish[5].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "POLE_LINE_XRIGHT", tmp, strIniFilePath);

	_itoa(m_ptVanish[6].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "VANISH_TOP_X", tmp, strIniFilePath);
}

cv::Point* CRegion::CRegion_getVanish()
{
	return m_ptVanish;
}


void CRegion::CRegion_setRoad(cv::Point* _ptRoad)
{
	for (int nPt = 0; nPt < MAX_PTROAD; nPt++) // 2018.08.08
	{
		m_ptRoad[nPt].x = _ptRoad[nPt].x;
		m_ptRoad[nPt].y = _ptRoad[nPt].y;
	}
}

float CRegion::CRegion_determinantOfMatrix(float mat[3][3])
{
	float ans;
	ans = mat[0][0] * (mat[1][1] * mat[2][2] - mat[2][1] * mat[1][2])
		- mat[0][1] * (mat[1][0] * mat[2][2] - mat[1][2] * mat[2][0])
		+ mat[0][2] * (mat[1][0] * mat[2][1] - mat[1][1] * mat[2][0]);
	return ans;
}

void CRegion::CRegion_get_TranformCoeffs(int nCoord, float coeff[3][4])
{
	// Matrix d1 using coeff as given in cramer's rule
	float d[3][3] = {
		{ coeff[0][0], coeff[0][1], coeff[0][2] },
		{ coeff[1][0], coeff[1][1], coeff[1][2] },
		{ coeff[2][0], coeff[2][1], coeff[2][2] },
	};

	float d1[3][3] = {
		{ coeff[0][3], coeff[0][1], coeff[0][2] },
		{ coeff[1][3], coeff[1][1], coeff[1][2] },
		{ coeff[2][3], coeff[2][1], coeff[2][2] },
	};

	float d2[3][3] = {
		{ coeff[0][0], coeff[0][3], coeff[0][2] },
		{ coeff[1][0], coeff[1][3], coeff[1][2] },
		{ coeff[2][0], coeff[2][3], coeff[2][2] },
	};

	float d3[3][3] = {
		{ coeff[0][0], coeff[0][1], coeff[0][3] },
		{ coeff[1][0], coeff[1][1], coeff[1][3] },
		{ coeff[2][0], coeff[2][1], coeff[2][3] },
	};

	/*d = a11 *a22*a33 + a12*a23*a31 + a13 * a21*a32 - a13 * a22*a31 - a12 * a21*a33 - a11 * a23*a32;

	dx = b1 * a22*a33 + a12 * a23*b3 + b2 * a32*a13 - a13 * a22*b3 - a12 * b2*a33 - a23 * a32*b1;
	dy = a11 * b2*a33 + b1 * a23*a31 + a21 * b3*a13 - a13 * b2*a31 - b1 * a21*a33 - a23 * b3*a11;
	dz = a11 * a22*b3 + a12 * b2*a31 + a21 * a32*b1 - b1 * a22*a31 - a12 * a21*b3 - b2 * a32*a11;*/

	// Calculating Determinant of Matrices d, d1, d2, d3
	float D = CRegion_determinantOfMatrix(d);
	float D1 = CRegion_determinantOfMatrix(d1);
	float D2 = CRegion_determinantOfMatrix(d2);
	float D3 = CRegion_determinantOfMatrix(d3);


	if (D == 0)
	{
		return;
	}
	else
	{
		if (nCoord == 0) //Y coordinate
		{
			m_fa = (float)(D1 / D);
			m_fc = (float)(D2 / D);
			m_fd = (float)(D3 / D);
		}
		else
		{
			m_faX = (float)(D1 / D);
			m_fcX = (float)(D2 / D);
			m_fdX = (float)(D3 / D);
		}
	}
}


void CRegion::CRegion_calculate_tranformation(int nDisplayHei, int nDisplayWid, float fStartYBot, float fStartYCen, float fStartYTop, float fPoleXleft, float fPoleXcen, float fPoleXright)
{
	CRegion_calculate_vanishing_params(nDisplayHei, nDisplayWid);

	// [------- Y COORDINATION CALCULATION --------]
	//calculate ratio for the region from 0 to 200m
	//R0, R100, R200 (real road points)
	//S0, S100, S200 (screen points) are corresponding to m_ptVanish[2], m_ptVanish[1], m_ptVanish[0]

	//	 a*S^2 + R*S + c*S + d*R = 0, --> b = 1
	//---------------------------------------------
	//   a*S0^2 + c*S0 + d*R0 + R0*S0 = 0
	//   a*S100^2 + c*S100 + d*R100 + R100*S100 = 0
	//   a*S200^2 + c*S200 + d*R200 + R200*S200 = 0
	//   
	//  now -> calculate a as x, c as y, d as z -> equation: a11x + a12y + a13z + b1 = 0 
	//---------------------------------------------

	m_fa = 0.0f;
	m_fc = 0.0f;
	m_fd = 0.0f;

	m_fRYbot = fStartYBot;
	m_fRYcen = fStartYCen;
	m_fRYtop = fStartYTop;

	if (m_bUseYparabol) // parabol coefficient
	{
		//assume values as
		float a11, a12, a13, a21, a22, a23, a31, a32, a33, b1, b2, b3;

		a11 = (float)((nDisplayHei - m_ptVanish[2].y) * (nDisplayHei - m_ptVanish[2].y));	//S0^2 top
		a12 = (float)(nDisplayHei - m_ptVanish[2].y);										//S0
		a13 = (float)(m_fRYbot);															//R0
		b1 = (float)(m_fRYbot * a12);														//R0*S0

		a21 = (float)((nDisplayHei - m_ptVanish[1].y) * (nDisplayHei - m_ptVanish[1].y));	//S100^2 center
		a22 = (float)(nDisplayHei - m_ptVanish[1].y);										//S100
		a23 = (float)(m_fRYcen);															//R100
		b2 = (float)(m_fRYcen * a22);														//R100*S100

		a31 = (float)((nDisplayHei - m_ptVanish[0].y) * (nDisplayHei - m_ptVanish[0].y));	//S200^2 bottom
		a32 = (float)(nDisplayHei - m_ptVanish[0].y);										//S200
		a33 = (float)(m_fRYtop);															//R200
		b3 = (float)(m_fRYtop * a32);														//R200*S200

		// coeff metrix
		float coeff[3][4] = {
			{ a11, a12, a13, -b1 },
			{ a21, a22, a23, -b2 },
			{ a31, a32, a33, -b3 },
		};

		CRegion_get_TranformCoeffs(0, coeff);
	}
	else // linear coefficient
	{
		// 0  -> top (x, y)->(nDisplayHei - m_ptVanish[0].y, m_fRYtop)
		// 1
		// 2  -> bot (x, y)->(nDisplayHei - m_ptVanish[2].y, m_fRYbot)

		// a = 0.y - 2.y
		// b = 2.x - 0.x
		// c = a * 2.x + b * 2.y

		aH = (float)(m_fRYtop - m_fRYbot);
		bH = (float)((nDisplayHei - m_ptVanish[2].y) - (nDisplayHei - m_ptVanish[0].y));
		cH = aH * (nDisplayHei - m_ptVanish[2].y) + bH * (m_fRYbot);
	}

	// [------- X COORDINATION CALCULATION --------]
	// 0   6
	// 1
	// 2  3  4  5

	//for pole left and right reference coordinate
	m_faX = 0.0f;
	m_fcX = 0.0f;
	m_fdX = 0.0f;

	m_fPXleft = fPoleXleft;
	m_fPXcen = fPoleXcen;
	m_fPXright = fPoleXright;

	if (m_bUseXparabol) // parabol coefficient
	{
		//assume values as
		float a11H, a12H, a13H, a21H, a22H, a23H, a31H, a32H, a33H, b1H, b2H, b3H;

		a11H = (float)(abs(m_ptVanish[0].x - m_ptVanish[3].x) * abs(m_ptVanish[0].x - m_ptVanish[3].x));		//Sleft^2
		a12H = (float)abs(m_ptVanish[0].x - m_ptVanish[3].x);													//Sleft
		a13H = (float)(m_fPXleft);																				//Rleft
		b1H = (float)(m_fPXleft * a12H);																		//Rleft*Sleft

		a21H = (float)(abs(m_ptVanish[0].x - m_ptVanish[4].x) * abs(m_ptVanish[0].x - m_ptVanish[4].x));		//Scen^2
		a22H = (float)abs(m_ptVanish[0].x - m_ptVanish[4].x);													//Scen
		a23H = (float)(m_fPXcen);																				//Rcen
		b2H = (float)(m_fPXcen * a22H);																			//Rcen*Scen

		a31H = (float)(abs(m_ptVanish[0].x - m_ptVanish[5].x) * abs(m_ptVanish[0].x - m_ptVanish[5].x));		//Sright^2
		a32H = (float)abs(m_ptVanish[0].x - m_ptVanish[5].x);													//Sright
		a33H = (float)(m_fPXright);																				//Rright
		b3H = (float)(m_fPXright * a32H);																		//Rright*Sright

		// coeff metrix
		float coeffH[3][4] = {
			{ a11H, a12H, a13H, -b1H },
			{ a21H, a22H, a23H, -b2H },
			{ a31H, a32H, a33H, -b3H },
		};

		CRegion_get_TranformCoeffs(1, coeffH);
	}
	else // linear coefficient
	{
		//  2  [3]  4  5 -> left (x, y)->(abs(m_ptVanish[0].x - m_ptVanish[3].x), m_fPXleft)
		//  2   3  [4] 5 -> cen  (x, y)->(abs(m_ptVanish[0].x - m_ptVanish[4].x), m_fPXcen)

		// a = 3.y - 4.y
		// b = 4.x - 3.x
		// c = a * 4.x + b * 4.y

		aW = (float)(m_fPXleft - m_fPXcen);
		bW = (float)(abs(m_ptVanish[0].x - m_ptVanish[4].x) - abs(m_ptVanish[0].x - m_ptVanish[3].x));
		cW = aW * (abs(m_ptVanish[0].x - m_ptVanish[4].x)) + bW * (m_fPXcen);
	}


#if VDS_MODE == 1
	// calculate loop length
	float fDistanceLoop0 = CRegion_get_Ydistance(nDisplayHei, l_box[0].point[0].x, l_box[0].point[0].y);
	float fDistanceLoop2 = CRegion_get_Ydistance(nDisplayHei, l_box[0].point[2].x, l_box[0].point[2].y);

	fLoopLength = abs(fDistanceLoop2 - fDistanceLoop0);

#endif
}




void CRegion::CRegion_get_XYdistance(int nHeight, int nPtY, int nPtX, float& fDistanceY, float& fDistanceX)
{
	float fSy = (float)(nHeight - nPtY);

	//float fDistance = 0.0f, fDistanceY = 0.0f, fDistanceX = 0.0f;

	//get X distance
	fDistanceX = CRegion_get_Xdistance(nPtX, nPtY);

#if ITS_MODE == 1
	// distance with Y value
	//---------------------------------------------
	//   a*Sx^2 + Rx*Sx + c*Sx + d*Rx = 0
	//   Rx*(Sx + d) = -(a*Sx^2 + c*Sx)
	//---------------------------------------------
	if ((fSy + m_fd) != 0.0f)
	{
		//get Y distance
		fDistanceY = -(m_fa * fSy * fSy + m_fc * fSy) / (fSy + m_fd) - m_fRYbot;

		//return fDistanceY;
	}
	else
	{
		fDistanceY = 0.0f;
		//return 0.0f;
	}
#elif VDS_MODE == 1
	// distance with projected of Y value
	fDistanceY = CRegion_get_Ydistance(nHeight, nPtX, nPtY);
#else
	fDistanceY = 0.0f;
#endif


#if 0
	//---------------------------------------------
	//   m*Sx^2 + Rx^2 + c*Sx + d*Rx = 0
	//   Rx^2 + d*Rx + (a*Sx^2 + c*Sx) = 0 [ax^2 + bx + c = 0]
	//---------------------------------------------

	float a = 1.0f, b = m_fd, c = m_fa * fSx * fSx + m_fc * fSx;

	float delta = b * b - 4 * a*c;

	if (m_fa != 0 && m_fc != 0 && m_fd != 0)
	{
		if (delta == 0.0f)
		{
			fDistance = -b / (2 * a);
		}
		else if (delta > 0)
		{
			delta = sqrt(delta);
			float x1 = (-b + delta) / (2 * a);
			float x2 = (-b - delta) / (2 * a);
			fDistance = max(x1, x2);
			if (fDistance > m_fR200)
			{
				if (x1 <= m_fR200) fDistance = x1 - m_fR0;
				else if (x2 <= m_fR200) fDistance = x2 - m_fR0;
			}
			else
			{
				fDistance = fDistance - m_fR0;
			}
		}

		return round(fDistance);
	}
	else
	{
		return 0;
	}
#endif
}


float CRegion::CRegion_get_XTop(int nPtBotX, int nPtBotY, int nPtTopY)
{
	float fXBotLeft, fXTopLeft, fXBotRight, fXTopRight, fPtTopX;

	if (aR_wL != 0 && aR_wR != 0)
	{
		fXBotLeft = -((float)bR_wL / (float)aR_wL) * (float)nPtBotY + (float)cR_wL / (float)aR_wL;
		fXBotRight = -((float)bR_wR / (float)aR_wR) * (float)nPtBotY + (float)cR_wR / (float)aR_wR;

		fXTopLeft = -((float)bR_wL / (float)aR_wL) * (float)nPtTopY + (float)cR_wL / (float)aR_wL;
		fXTopRight = -((float)bR_wR / (float)aR_wR) * (float)nPtTopY + (float)cR_wR / (float)aR_wR;

		if ((fXBotRight - fXBotLeft) != 0)
		{
			fPtTopX = (((float)nPtBotX - fXBotLeft) * (float)(fXTopRight - fXTopLeft)) / (float)(fXBotRight - fXBotLeft) + (float)fXTopLeft;
			return fPtTopX;
		}
		else
		{
			return 0.0f;
		}
	}
}

void CRegion::CRegion_get_Angle_Width(int nPtLeftX, int nPtCenX, int nPtRightX, int nPtY, float &fCosAngle, float &fTotalWidth)
{
	float fXLeft, fXRight, fPtLeftXProjected, fPtRightXProjected, fPtCenXProjected;

	if (aR_wL != 0 && aR_wR != 0)
	{
		fXLeft = -((float)bR_wL / (float)aR_wL) * (float)nPtY + (float)cR_wL / (float)aR_wL;
		fXRight = -((float)bR_wR / (float)aR_wR) * (float)nPtY + (float)cR_wR / (float)aR_wR;

		if ((fXRight - fXLeft) != 0)
		{
			fPtLeftXProjected = (((float)nPtLeftX - fXLeft) * (float)(m_ptVanish[5].x - m_ptVanish[2].x)) / (float)(fXRight - fXLeft) + (float)m_ptVanish[2].x;
			fPtRightXProjected = (((float)nPtRightX - fXLeft) * (float)(m_ptVanish[5].x - m_ptVanish[2].x)) / (float)(fXRight - fXLeft) + (float)m_ptVanish[2].x;
			fPtCenXProjected = (((float)nPtCenX - fXLeft) * (float)(m_ptVanish[5].x - m_ptVanish[2].x)) / (float)(fXRight - fXLeft) + (float)m_ptVanish[2].x;

			float fSxLeft = abs((float)m_ptVanish[0].x - fPtLeftXProjected); //calculate pixel from origin
			float fSxRight = abs((float)m_ptVanish[0].x - fPtRightXProjected); //calculate pixel from origin

			if (m_bUseXparabol)
			{
				if ((fSxLeft + m_fdX) != 0.0f && (fSxRight + m_fdX) != 0.0f)
				{
					//get X distance
					float fDistanceLeftX = -(m_faX * fSxLeft * fSxLeft + m_fcX * fSxLeft) / (fSxLeft + m_fdX); //distance from origin (line of symmetry)
					float fDistanceRightX = -(m_faX * fSxRight * fSxRight + m_fcX * fSxRight) / (fSxRight + m_fdX); //distance from origin (line of symmetry)

					if (m_ptVanish[0].x - fPtLeftXProjected > 0)
						fDistanceLeftX = fDistanceLeftX * (-1.0f); // because of symmetry

					if (m_ptVanish[0].x - fPtRightXProjected > 0)
						fDistanceRightX = fDistanceRightX * (-1.0f); // because of symmetry

					fTotalWidth = abs(fDistanceRightX - fDistanceLeftX);

				}
			}
			else
			{
				if (bW != 0)
				{
					float fDistanceLeftX = -((float)aW / (float)bW) * (float)fSxLeft + (float)cW / (float)bW;
					float fDistanceRightX = -((float)aW / (float)bW) * (float)fSxRight + (float)cW / (float)bW;

					if (m_ptVanish[0].x - fPtLeftXProjected > 0)
						fDistanceLeftX = fDistanceLeftX * (-1.0f); // because of symmetry

					if (m_ptVanish[0].x - fPtRightXProjected > 0)
						fDistanceRightX = fDistanceRightX * (-1.0f); // because of symmetry

					fTotalWidth = abs(fDistanceRightX - fDistanceLeftX);
				}
			}

			// calculate cosAngle
			float fTotal = (nPtCenX - fPtCenXProjected) * (nPtCenX - fPtCenXProjected) + (m_ptVanish[2].y - nPtY)*(m_ptVanish[2].y - nPtY);
			if (fTotal != 0.0f)
				fCosAngle = abs(nPtCenX - fPtCenXProjected) / sqrt(fTotal);
		}
	}
}

float CRegion::CRegion_get_Xdistance(int nPtX, int nPtY)
{
	// 0   6
	// 1
	// 2  3  4  5

	float fXLeft, fXRight, fPtXprojected, fDistanceX;

	if (aR_wL != 0 && aR_wR != 0)
	{
		fXLeft = -((float)bR_wL / (float)aR_wL) * (float)nPtY + (float)cR_wL / (float)aR_wL;
		fXRight = -((float)bR_wR / (float)aR_wR) * (float)nPtY + (float)cR_wR / (float)aR_wR;

		if ((fXRight - fXLeft) != 0)
		{
			fPtXprojected = (((float)nPtX - fXLeft) * (float)(m_ptVanish[5].x - m_ptVanish[2].x)) / (float)(fXRight - fXLeft) + (float)m_ptVanish[2].x;
		}
		else
		{
			return 0.0f;
		}
	}
	else
	{
		return 0.0f;
	}

	float fSx = abs((float)m_ptVanish[0].x - fPtXprojected); //calculate pixel from origin

	if (m_bUseXparabol)
	{
		if ((fSx + m_fdX) != 0.0f)
		{
			//get X distance
			fDistanceX = -(m_faX * fSx * fSx + m_fcX * fSx) / (fSx + m_fdX); //distance from origin (line of symmetry)

			if (m_ptVanish[0].x - fPtXprojected > 0) fDistanceX = fDistanceX * (-1.0f); // because of symmetry

			return fDistanceX;
		}
		else
		{
			return 0.0f;
		}
	}
	else
	{
		if (bW != 0)
		{
			fDistanceX = -((float)aW / (float)bW) * (float)fSx + (float)cW / (float)bW;
			if (m_ptVanish[0].x - fPtXprojected > 0) fDistanceX = fDistanceX * (-1.0f); // because of symmetry
			return fDistanceX;
		}
		else
		{
			return 0.0f;
		}
	}

}


float CRegion::CRegion_get_Ydistance(int nHeight, int nPtX, int nPtY)
{
	// loop1_0 loop1_1  --> line 1
	// loop1_2 loop1_3  --> line 2

	// line of symmetry
	// 0
	// 1
	// 2

	float fS1, fS2, fO1, fO2, fPtYprojected, fDistanceY;

	if (bR_hT != 0 && bR_hB != 0)
	{
		// intersections of loop1's lines with line of horizontal symmetry
		fS1 = -((float)aR_hT / (float)bR_hT) * (float)m_ptVanish[0].x + (float)cR_hT / (float)bR_hT;
		fS2 = -((float)aR_hB / (float)bR_hB) * (float)m_ptVanish[0].x + (float)cR_hB / (float)bR_hB;

		// intersections of loop1's lines with object line
		fO1 = -((float)aR_hT / (float)bR_hT) * (float)nPtX + (float)cR_hT / (float)bR_hT;
		fO2 = -((float)aR_hB / (float)bR_hB) * (float)nPtX + (float)cR_hB / (float)bR_hB;


		if ((fO2 - fO1) != 0)
		{
			fPtYprojected = (((float)nPtY - fO1)) * (fS2 - fS1) / (fO2 - fO1) + fS1;
		}
		else
		{
			return 0.0f;
		}
	}
	else
	{
		return 0.0f;
	}

	float fSy = abs((float)nHeight - fPtYprojected); //calculate pixel from origin

	if (m_bUseYparabol)
	{
		if ((fSy + m_fd) != 0.0f)
		{
			//get Y distance
			//fDistanceY = -(m_fa * fSy * fSy + m_fc * fSy) / (fSy + m_fd) - m_fRYbot; //distance from bottom point as ITS_MODE
			fDistanceY = -(m_fa * fSy * fSy + m_fc * fSy) / (fSy + m_fd); //distance from image lowest point

			return fDistanceY;
		}
		else
		{
			return 0.0f;
		}
	}
	else
	{
		if (bH != 0)
		{
			fDistanceY = -((float)aH / (float)bH) * (float)fSy + (float)cH / (float)bH;
			return fDistanceY;
		}
		else
		{
			return 0.0f;
		}
	}
}


cv::Point* CRegion::CRegion_getRoad()
{
	return m_ptRoad;
}


void CRegion::CRegion_update_road_points(int nPt, int nCameraIndex)
{
	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH], strPointX[100], strPointY[100];
	sprintf(currentPath, "%s", getModulPath());

	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	sprintf(strPointX, "ROAD_POINT_X_%d", nPt);
	sprintf(strPointY, "ROAD_POINT_Y_%d", nPt);

	char tmp[32]; tmp[0] = '\0';
	_itoa(m_ptRoad[nPt].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", strPointX, tmp, strIniFilePath);
	_itoa(m_ptRoad[nPt].y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", strPointY, tmp, strIniFilePath);
}

void CRegion::CRegion_setLine(cv::Point* _ptLine)
{
	for (int nPt = 0; nPt < MAX_PTLINE; nPt++) // 2018.08.08
	{
		m_ptLine[nPt].x = _ptLine[nPt].x;
		m_ptLine[nPt].y = _ptLine[nPt].y;
	}

	if (MAX_PTLINE >= 10)
	{
		m_ptLine[1].y = m_ptLine[0].y;
		m_ptLine[3].y = m_ptLine[2].y;
		m_ptLine[4].y = m_ptLine[0].y;
		m_ptLine[5].y = m_ptLine[2].y;
		m_ptLine[6].y = m_ptLine[0].y;
		m_ptLine[7].y = m_ptLine[2].y;
		m_ptLine[8].y = m_ptLine[0].y;
		m_ptLine[9].y = m_ptLine[2].y;
	}
}

cv::Point* CRegion::CRegion_getLine()
{
	return m_ptLine;
}

void CRegion::CRegion_setROI(cv::Point* _ptROI)
{
	//20190213 hai Parking
	for (int nPt = 0; nPt < 4; nPt++)
	{
		m_ptROI[nPt].x = _ptROI[nPt].x;
		m_ptROI[nPt].y = _ptROI[nPt].y;
	}
	m_ptROI[1].y = _ptROI[0].y;
	m_ptROI[3].y = _ptROI[2].y;
}

cv::Point* CRegion::CRegion_getROI()
{
	return m_ptROI;
}

//20190423 Daewoo
void CRegion::CRegion_setAREA(cv::Point* _ptAREA)
{
	for (int nPt = 0; nPt < 7; nPt++)
	{
		m_ptAREA[nPt].x = _ptAREA[nPt].x;
		m_ptAREA[nPt].y = _ptAREA[nPt].y;
	}
}

cv::Point* CRegion::CRegion_getAREA()
{
	return m_ptAREA;
}



int CRegion::CRegion_getXwithIndex(int mode, int _index)
{
	if (mode == 1)
	{
		return m_ptLine[_index].x;
	}
	else if (mode == 2)
	{
		return m_ptROI[_index].x;
	}
	//20190423 Daewoo
	else if (mode == 3)
	{
		return m_ptAREA[_index].x;
	}
	else if (mode == 4)//ITS-Road
	{
		return m_ptRoad[_index].x;
	}

	return 0;
}

int CRegion::CRegion_getYwithIndex(int mode, int _index)
{
	if (mode == 1)
	{
		return m_ptLine[_index].y;
	}
	else if (mode == 2)
	{
		return m_ptROI[_index].y;
	}
	//20190423 Daewoo
	else if (mode == 3)
	{
		return m_ptAREA[_index].y;
	}
	else if (mode == 4)//ITS-Road
	{
		return m_ptRoad[_index].y;
	}

	return 0;
}

void CRegion::CRegion_setRtSignalArea(int index, cv::Rect _rtSignalArea)
{
	m_rtSignalArea[index] = _rtSignalArea;
}

cv::Rect CRegion::CRegion_getRtSignalArea(int index)
{
	return m_rtSignalArea[index];
}

void CRegion::CRegion_setRtLeftRedSignalArea(cv::Rect _rtLeftRedSignalArea)
{
	m_rtLeftRedSignalArea = _rtLeftRedSignalArea;
}


cv::Rect CRegion::CRegion_getRtLeftRedSignalArea()
{
	return m_rtLeftRedSignalArea;
}


cv::Point CRegion::CRegion_setPoint(int mode, int _index)// mode[1] : setPoint with Line, mode[2] : setPoint with ROI
{
	if (mode == 1)
	{
		return cv::Point(m_ptLine[_index].x, m_ptLine[_index].y);
	}
	else if (mode == 2)
	{
		return cv::Point(m_ptROI[_index].x, m_ptROI[_index].y);
	}
	//20190423 Daewoo
	else if (mode == 3)
	{
		return cv::Point(m_ptAREA[_index].x, m_ptAREA[_index].y);
	}
	else if (mode == 4) //ITS-Road
	{
		return cv::Point(m_ptRoad[_index].x, m_ptRoad[_index].y);
	}

	return cv::Point(0, 0);
}

void CRegion::CRegion_update_line_points(int nPt, int nCameraIndex)
{
	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH], strPointX[100], strPointY[100];
	sprintf(currentPath, "%s", getModulPath());

	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	sprintf(strPointX, "LINE_POINT_X_%d", nPt);
	sprintf(strPointY, "LINE_POINT_Y_%d", nPt);

	char tmp[32]; tmp[0] = '\0';
	_itoa(m_ptLine[nPt].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", strPointX, tmp, strIniFilePath);
	_itoa(m_ptLine[nPt].y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", strPointY, tmp, strIniFilePath);
}

//20190213 hai Parking
void CRegion::CRegion_update_ROI_points(int nPt, int nCameraIndex)
{
	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH], strPointX[100], strPointY[100];
	sprintf(currentPath, "%s", getModulPath());
	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	sprintf(strPointX, "ROI_POINT_X_%d", nPt + 1);
	sprintf(strPointY, "ROI_POINT_Y_%d", nPt + 1);

	char tmp[32]; tmp[0] = '\0';
	_itoa(m_ptROI[nPt].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", strPointX, tmp, strIniFilePath);
	_itoa(m_ptROI[nPt].y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", strPointY, tmp, strIniFilePath);
}


//20190423 Daewoo
void CRegion::CRegion_update_AREA_points(int nPt, int nCameraIndex)
{
	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH], strPointX[100], strPointY[100];
	sprintf(currentPath, "%s", getModulPath());
	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	sprintf(strPointX, "AREA_POINT_X_%d", nPt + 1);
	sprintf(strPointY, "AREA_POINT_Y_%d", nPt + 1);

	char tmp[32]; tmp[0] = '\0';
	_itoa(m_ptAREA[nPt].x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", strPointX, tmp, strIniFilePath);
	_itoa(m_ptAREA[nPt].y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", strPointY, tmp, strIniFilePath);
}

void CRegion::CRegion_update_Signal_points(int index, int nCameraIndex)
{
	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH];
	sprintf(currentPath, "%s", getModulPath());
	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	char tmp[32]; tmp[0] = '\0';
	char* color[3] = { "RED", "GREEN", "YELLOW" };
	char key[32];

	_itoa(m_rtSignalArea[index].x, (LPSTR)(LPCSTR)tmp, 10);
	wsprintf(key, "SIGNAL%s_POINT_X", color[index]);
	WritePrivateProfileString("Position", key, tmp, strIniFilePath);

	_itoa(m_rtSignalArea[index].y, (LPSTR)(LPCSTR)tmp, 10);
	wsprintf(key, "SIGNAL%s_POINT_Y", color[index]);
	WritePrivateProfileString("Position", key, tmp, strIniFilePath);

	_itoa(m_rtSignalArea[index].width, (LPSTR)(LPCSTR)tmp, 10);
	wsprintf(key, "SIGNAL%s_POINT_WIDTH", color[index]);
	WritePrivateProfileString("Position", key, tmp, strIniFilePath);

	_itoa(m_rtSignalArea[index].height, (LPSTR)(LPCSTR)tmp, 10);
	wsprintf(key, "SIGNAL%s_POINT_HEIGHT", color[index]);
	WritePrivateProfileString("Position", key, tmp, strIniFilePath);
}

void CRegion::CRegion_update_LeftRedSignal_points(int nCameraIndex)
{
	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH];
	sprintf(currentPath, "%s", getModulPath());
	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	char tmp[32]; tmp[0] = '\0';
	_itoa(m_rtLeftRedSignalArea.x, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "LEFT_SIGNALRED_POINT_X", tmp, strIniFilePath);
	_itoa(m_rtLeftRedSignalArea.y, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "LEFT_SIGNALRED_POINT_Y", tmp, strIniFilePath);

	_itoa(m_rtLeftRedSignalArea.width, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "LEFT_SIGNALRED_POINT_WIDTH", tmp, strIniFilePath);
	_itoa(m_rtLeftRedSignalArea.height, (LPSTR)(LPCSTR)tmp, 10);
	WritePrivateProfileString("Position", "LEFT_SIGNALRED_POINT_HEIGHT", tmp, strIniFilePath);
}

void CRegion::CRegion_copy(int mode, cv::Point * _point)
{
	if (mode == 1)
	{
		for (int nPt = 0; nPt < MAX_PTLINE; nPt++) // 2018.08.08
		{
			_point[nPt].x = m_ptLine[nPt].x;
			_point[nPt].y = m_ptLine[nPt].y;
		}
	}
	else if (mode == 2)
	{
		for (int nPt = 0; nPt < 4; nPt++)
		{
			_point[nPt].x = m_ptROI[nPt].x;
			_point[nPt].y = m_ptROI[nPt].y;
		}
	}
	//20190423 Daewoo
	else if (mode == 3)
	{
		for (int nPt = 0; nPt < 7; nPt++)
		{
			_point[nPt].x = m_ptAREA[nPt].x;
			_point[nPt].y = m_ptAREA[nPt].y;
		}
	}
	else if (mode == 4) //ITS-Road
	{
		for (int nPt = 0; nPt < MAX_PTROAD; nPt++)
		{
			_point[nPt].x = m_ptRoad[nPt].x;
			_point[nPt].y = m_ptRoad[nPt].y;
		}
	}
}

void CRegion::CRegion_calculate_line_params()
{
	// Line AB represented as ax + by = c

	if (MAX_PTLINE >= 10)
	{
		// line 0-2
		a02 = (float)(m_ptLine[2].y - m_ptLine[0].y);
		b02 = (float)(m_ptLine[0].x - m_ptLine[2].x);
		c02 = a02 * (m_ptLine[0].x) + b02 * (m_ptLine[0].y);

		// line 1-3
		a13 = (float)(m_ptLine[3].y - m_ptLine[1].y);
		b13 = (float)(m_ptLine[1].x - m_ptLine[3].x);
		c13 = a13 * (m_ptLine[1].x) + b13 * (m_ptLine[1].y);

		// line 4-5
		a45 = (float)(m_ptLine[5].y - m_ptLine[4].y);
		b45 = (float)(m_ptLine[4].x - m_ptLine[5].x);
		c45 = a45 * (m_ptLine[4].x) + b45 * (m_ptLine[4].y);

		// line 6-7
		a67 = (float)(m_ptLine[7].y - m_ptLine[6].y);
		b67 = (float)(m_ptLine[6].x - m_ptLine[7].x);
		c67 = a67 * (m_ptLine[6].x) + b67 * (m_ptLine[6].y);

		// line 8-9
		a89 = (float)(m_ptLine[9].y - m_ptLine[8].y);
		b89 = (float)(m_ptLine[8].x - m_ptLine[9].x);
		c89 = a89 * (m_ptLine[8].x) + b89 * (m_ptLine[8].y);

		//20190213 hai Parking
		// line 0-2
		aO = (float)(m_ptROI[2].y - m_ptROI[0].y);
		bO = (float)(m_ptROI[0].x - m_ptROI[2].x);
		cO = aO * (m_ptROI[0].x) + bO * (m_ptROI[0].y);

		// line 1-3
		aI = (float)(m_ptROI[3].y - m_ptROI[1].y);
		bI = (float)(m_ptROI[1].x - m_ptROI[3].x);
		cI = aI * (m_ptROI[1].x) + bI * (m_ptROI[1].y);
	}
}

void CRegion::CRegion_calculate_vanishing_params(int nDisplayHei, int nDisplayWid)
{
#if VDS_MODE == 1
	//[X COORDINATION]
	// loop 1 - line 1 [0---1] and line 2 [2---3]

	//l_box[0].point[0]   l_box[0].point[1]
	aR_hT = (float)(l_box[0].point[0].y - l_box[0].point[1].y);
	bR_hT = (float)(l_box[0].point[1].x - l_box[0].point[0].x);
	cR_hT = aR_hT * (l_box[0].point[1].x) + bR_hT * (l_box[0].point[1].y);

	//l_box[0].point[2]   l_box[0].point[3]
	aR_hB = (float)(l_box[0].point[2].y - l_box[0].point[3].y);
	bR_hB = (float)(l_box[0].point[3].x - l_box[0].point[2].x);
	cR_hB = aR_hB * (l_box[0].point[3].x) + bR_hB * (l_box[0].point[3].y);

	// X vanishing point
	if (aR_hT * bR_hB - aR_hB * bR_hT != 0.0f)
	{
		m_ptVanishX.x = (cR_hT * bR_hB - cR_hB * bR_hT) / (aR_hT * bR_hB - aR_hB * bR_hT);
		m_ptVanishX.y = (cR_hB * aR_hT - cR_hT * aR_hB) / (aR_hT * bR_hB - aR_hB * bR_hT);
	}
	else
	{
		// parabel -> use linear equation
		m_ptVanishX.x = m_ptVanish[0].x + 2 * nDisplayWid;
		m_ptVanishX.y = nDisplayHei;
	}

	if (abs(m_ptVanishX.x - m_ptVanish[0].x) < 2 * nDisplayWid)
	{
		m_bUseXparabol = true;
	}
	else
	{
		m_bUseXparabol = false; //-> use line equation
	}

	if (bR_hB != 0)
		fLoopAngle = atan(-aR_hB / bR_hB);
	else
		fLoopAngle = 0;

	//[Y COORDINATION]
	// loop 1 - line left [0---2] and line right [1---3]
	float aL = (float)(l_box[0].point[0].y - l_box[0].point[2].y);
	float bL = (float)(l_box[0].point[2].x - l_box[0].point[0].x);
	float cL = aL * (l_box[0].point[2].x) + bL * (l_box[0].point[2].y);

	float aR = (float)(l_box[0].point[1].y - l_box[0].point[3].y);
	float bR = (float)(l_box[0].point[3].x - l_box[0].point[1].x);
	float cR = aR * (l_box[0].point[1].x) + bR * (l_box[0].point[1].y);

	// Y vanishing point
	if (aL * bR - aR * bL != 0.0f)
	{
		m_ptVanishY.x = (cL * bR - cR * bL) / (aL * bR - aR * bL);
		m_ptVanishY.y = (cR * aL - cL * aR) / (aL * bR - aR * bL);
	}
	else
	{
		// parabel -> use linear equation
		m_ptVanishY.x = nDisplayWid;
		m_ptVanishY.y = (-1) * nDisplayHei;
	}

	// 0   6
	// 1
	// 2  3  4  5
	m_ptVanish[0].x = m_ptVanish[1].x = m_ptVanish[2].x = m_ptVanishY.x;
#endif

	aR_wL = (float)(m_ptVanish[0].y - m_ptVanish[2].y);
	bR_wL = (float)(m_ptVanish[2].x - m_ptVanish[0].x);
	cR_wL = aR_wL * (m_ptVanish[2].x) + bR_wL * (m_ptVanish[2].y);

	if (m_ptVanish[0].x <= m_ptVanish[3].x) // 0/2 left-3 cen-4 right-5
	{
		aR_wR = (float)(m_ptVanish[6].y - m_ptVanish[5].y);
		bR_wR = (float)(m_ptVanish[5].x - m_ptVanish[6].x);
		cR_wR = aR_wR * (m_ptVanish[5].x) + bR_wR * (m_ptVanish[5].y);
	}
	else // left-3 cen-4 right-5 2/0
	{
		aR_wR = (float)(m_ptVanish[6].y - m_ptVanish[3].y);
		bR_wR = (float)(m_ptVanish[3].x - m_ptVanish[6].x);
		cR_wR = aR_wR * (m_ptVanish[3].x) + bR_wR * (m_ptVanish[3].y);
	}

	if (abs(m_ptVanishY.y - nDisplayHei) < 2 * nDisplayHei)
	{
		m_bUseYparabol = true;
	}
	else
	{
		m_bUseYparabol = false; //-> use line equation
	}
}

int CRegion::CRegion_AccidentCheckArea(int _mode, int _Y)
{
	if (_mode == 0)
	{
		return (int)(-(bO / aO)*_Y + (cO / aO)); //nPtROIx02
	}
	else if (_mode == 1)
	{
		return (int)(-(bI / aI)*_Y + (cI / aI)); //nPtROIx13
	}

	return 0;
}

//int CRegion::CRegion_get_Lane_Xvalue(int nLine, int _Y)
int CRegion::CRegion_get_Lane_Xvalue(int nLine, int _Y)
{
	//return (int)(-(b02 / a02)*_Y + (c02 / a02));

	if (nLine == 1)
		return (int)(-(b13 / a13)*_Y + (c13 / a13));
	else if (nLine == 2)
		return (int)(-(b02 / a02)*_Y + (c02 / a02));
	else if (nLine == 3)
		return (int)(-(b45 / a45)*_Y + (c45 / a45));
}



//20200128 BacNinh
int CRegion::CRegion_Object_outside_LeftRight(int nResImg_W, int nPtX, int nPtY) // 2018.11.09 hai
{
	int nGapX = 10;
	int nGapBot = 50;
	int nGapTop = 30;

	if (a02 != 0 && a13 != 0 && a45 != 0)
	{
		int nPtLaneX02 = (int)(-(b02 / a02)*nPtY + (c02 / a02));
		int nPtLaneX13 = (int)(-(b13 / a13)*nPtY + (c13 / a13));
		int nPtLaneX45 = (int)(-(b45 / a45)*nPtY + (c45 / a45));

		int nTop = 0, nBot = 0, nLeft = 0, nRight = 0;

		if (m_ptLine[2].y >= m_ptLine[0].y)
		{
			nTop = m_ptLine[0].y;
			nBot = m_ptLine[2].y;
		}
		else
		{
			nTop = m_ptLine[2].y;
			nBot = m_ptLine[0].y;
		}


		if (m_ptLine[1].x >= m_ptLine[3].x)
		{
			nLeft = m_ptLine[3].x;
		}
		else
		{
			nLeft = m_ptLine[1].x;
		}

		if (m_ptLine[4].x >= m_ptLine[5].x)
		{
			nRight = m_ptLine[4].x;
		}
		else
		{
			nRight = m_ptLine[5].x;
		}

		if (max(0, nPtLaneX13 - nGapX) == 0)
			nPtLaneX13 = nLeft;
		else
			nPtLaneX13 = nPtLaneX13 - nGapX;

		if (min(nPtLaneX45 + nGapX, nResImg_W - 1) == nResImg_W - 1)
			nPtLaneX45 = nRight;
		else
			nPtLaneX45 = nPtLaneX45 + nGapX;

		if (nPtX <= nPtLaneX13 && nPtY > nTop && nPtY <= max(m_ptLine[10].y, nTop + nGapTop))
			return UPDATED_LEFT_OUTSIDE_ROI;
		else if (nPtX >= nPtLaneX45 && nPtY > nTop && nPtY <= max(m_ptLine[11].y, nTop + nGapTop))
			return UPDATED_RIGHT_OUTSIDE_ROI;
	}

	return NO_DEFINE_AREA;
}


int CRegion::CRegion_Object_IsinArea(int nPtX, int nPtY, int nBoxWidth) // 2018.11.09 hai
{
	/*int nResPtX = (int)((float)nPtX / fXratio);
	int nResPtY = (int)((float)nPtY / fYratio);
	int nResBoxWidth = (int)((float)nBoxWidth / fXratio);*/

	if (a02 != 0 && a13 != 0 && a45 != 0)
	{
		int nPtLaneX02 = (int)(-(b02 / a02)*nPtY + (c02 / a02));
		int nPtLaneX13 = (int)(-(b13 / a13)*nPtY + (c13 / a13));
		int nPtLaneX45 = (int)(-(b45 / a45)*nPtY + (c45 / a45));

		int nTop = 0;
		int nBot = 0;
		if (m_ptLine[2].y >= m_ptLine[0].y)
		{
			nTop = m_ptLine[0].y;
			nBot = m_ptLine[2].y;
		}
		else
		{
			nTop = m_ptLine[2].y;
			nBot = m_ptLine[0].y;
		}

#if VDS_MODE == 1
		if (nPtX > nPtLaneX02 && nPtY >= nTop && nPtY <= nBot)
			return VDS_RIGHT_SIDE;
		else if (nPtX < nPtLaneX02 && nPtY >= nTop && nPtY <= nBot)
			return VDS_LEFT_SIDE;
	}

	return 0;
#else
		if ((nPtX + nBoxWidth / 5) <= nPtLaneX02 && nPtX >= nPtLaneX13 && nPtY >= nTop && nPtY <= nBot)
			return LEFT_VIOLATION_AREA; //left
		else if (nPtX >= (nPtLaneX02 + nBoxWidth / 5) && nPtX <= nPtLaneX45 && nPtY >= nTop && nPtY <= nBot)
			return RIGHT_VIOLATION_AREA; //right
		else if (nPtX > nPtLaneX02 && nPtX <= nPtLaneX45)
			return RIGHT_CENTER_LANE_VIO;
		else if (nPtX < nPtLaneX02 && nPtX >= nPtLaneX13)
			return LEFT_CENTER_LANE_VIO;
		else if (nPtX < nPtLaneX13 || nPtX > nPtLaneX45 || nPtY < max(0, nTop - (int)(1.5 * (float)GAP_Y_VIO)) || nPtY >(nBot + (int)(1.5 * (float)GAP_Y_VIO)))
			return NO_VIOLATION_AREA;
}
	return NO_DEFINE_AREA;
#endif

}

int CRegion::CRegion_line_touch_forLaneVio_topbot(int nPtY, int nPtHeight, int line, bool bTop)
{
	if (bTop)
	{
		if (line < nPtY && line + nPtHeight / 2 > nPtY)
		{
			return true;
		}
		else
		{
			return false;
		}
		return false;
	}
	else
	{
		if (line >= nPtY && (line - nPtHeight / 4) < nPtY)
		{
			return true;
		}
		else
		{
			return false;
		}
		return false;
	}
}

int CRegion::CRegion_line_touch_forLaneVio_side(int nPtX1, int nPtX2, int nPtY)
{
	if (a02 != 0 && a13 != 0 && a45 != 0)
	{
		int nPtLaneX02 = (int)(-(b02 / a02)*nPtY + (c02 / a02));

		int comp_1 = 0;
		int comp_2 = 0;
		if (m_ptLine[2].y >= m_ptLine[0].y)
		{
			comp_1 = m_ptLine[0].y;
			comp_2 = m_ptLine[2].y;
		}
		else
		{
			comp_1 = m_ptLine[2].y;
			comp_2 = m_ptLine[0].y;
		}

		if (nPtX1 <= nPtLaneX02 && nPtLaneX02 <= nPtX2 && nPtY > comp_1 && nPtY < comp_2)
			return 1;
	}

	return 0;
}

bool CRegion::CRegion_line_touch_save_LPImage(int nPtY, int nPtHeight, int line)
{
	if (line >= nPtY && (line - nPtHeight / 4) < nPtY)
	{
		return true;
	}
	else
	{
		return false;
	}
	return false;
}


//// when the box touches the line and goes out, count it. 2018.08.31
bool CRegion::CRegion_line_touch_count(cv::Rect detectBox, cv::Point ptCountLine[2], int nTrackID)
{
	bool bIsCount = false;
	bool bIsDetectBoxOutsideTheLine = false;

	printf("Track[%d] %d %d %d %d", nTrackID, ptCountLine[0].x, ptCountLine[0].y, ptCountLine[1].x, ptCountLine[1].y);

	int nXdiff = ptCountLine[0].x - ptCountLine[1].x;
	int nYdiff = ptCountLine[0].y - ptCountLine[1].y;

	//x = c
	if (nXdiff == 0)
	{
		if (detectBox.x <= ptCountLine[0].x && ptCountLine[0].x <= detectBox.x + detectBox.width)
		{
			//line touch
		}
		else
		{
			bIsDetectBoxOutsideTheLine = true;
		}
	}
	//y = b
	else if (nYdiff == 0)
	{
		if (detectBox.y <= ptCountLine[0].y && ptCountLine[0].y <= detectBox.y + detectBox.height)
		{
			//line touch
		}
		else
		{
			bIsDetectBoxOutsideTheLine = true;
		}
	}
	//y = ax + b
	else
	{
		float a = (float)nYdiff / (float)nXdiff;
		float b = (float)(ptCountLine[0].y) - (a * (float)ptCountLine[0].x);

		//Is there a detectBox outside the line?		
		if (detectBox.y > a * detectBox.x + b)
		{
			if (detectBox.y > a * (detectBox.x + detectBox.width) + b)
				if (detectBox.y + detectBox.height > a * (detectBox.x) + b)
					if (detectBox.y + detectBox.height > a * (detectBox.x + detectBox.width) + b)
						bIsDetectBoxOutsideTheLine = true;
		}
		else
		{
			if (detectBox.y < a * (detectBox.x + detectBox.width) + b)
				if (detectBox.y + detectBox.height < a * (detectBox.x) + b)
					if (detectBox.y + detectBox.height < a * (detectBox.x + detectBox.width) + b)
						bIsDetectBoxOutsideTheLine = true;
		}
	}

	//Final decision
	if (bIsDetectBoxOutsideTheLine)
	{
		//line touch end	
		if (nHumanCountCheck[nTrackID] > 0)
		{
			nHumanCountCheck[nTrackID]--;
			if (nHumanCountCheck[nTrackID] == 0)
			{
				//count
				bIsCount = true;
			}
		}
		else
		{
			nHumanCountCheck[nTrackID] = 0;
		}
	}
	else
	{
		//line touch
		nHumanCountCheck[nTrackID] = 5;
	}

	return bIsCount;
}

//// light violation 2018.07.27

bool CRegion::CRegion_line_touch_forLightVio_start(int nPtStartY, int nPtStopY, int line)
{
	if (line >= nPtStartY && line < nPtStopY)
	{
		return true;
	}
	else
	{
		return false;
	}
}

//// light violation 2018.07.27

bool CRegion::CRegion_line_touch_forLightVio_stop(int nPtStopY, int nPtHeight, int line)
{
	if (line >= nPtStopY && (line - nPtHeight) < nPtStopY)
	{
		return true;
	}
	else
	{
		return false;
	}
}



//KAI POC
void CRegion::CRegion_setRtKAIWorkPlace(int index, cv::Rect _rtArea)
{
	m_rtKAIWorkPlace[index] = _rtArea;
}

cv::Rect CRegion::CRegion_getRtKAIWorkPlace(int index)
{
	return m_rtKAIWorkPlace[index];
}

void CRegion::CRegion_update_KAIWorkPlace(int index, int nCameraIndex)
{
	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH];
	sprintf(currentPath, "%s", getModulPath());
	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	char tmp[32]; tmp[0] = '\0';
	char key[32];

	_itoa(m_rtKAIWorkPlace[index].x, (LPSTR)(LPCSTR)tmp, 10);
	wsprintf(key, "WORKPLACE_%d_X", index);
	WritePrivateProfileString("Position", key, tmp, strIniFilePath);

	_itoa(m_rtKAIWorkPlace[index].y, (LPSTR)(LPCSTR)tmp, 10);
	wsprintf(key, "WORKPLACE_%d_Y", index);
	WritePrivateProfileString("Position", key, tmp, strIniFilePath);

	_itoa(m_rtKAIWorkPlace[index].width, (LPSTR)(LPCSTR)tmp, 10);
	wsprintf(key, "WORKPLACE_%d_WIDTH", index);
	WritePrivateProfileString("Position", key, tmp, strIniFilePath);

	_itoa(m_rtKAIWorkPlace[index].height, (LPSTR)(LPCSTR)tmp, 10);
	wsprintf(key, "WORKPLACE_%d_HEIGHT", index);
	WritePrivateProfileString("Position", key, tmp, strIniFilePath);
}

#if ITS_MODE == 1
sIOUbox CRegion::CRegion_getIOU_BOXwithMask(cv::Rect box, cv::Mat & total, cv::Mat & left, cv::Mat & right)
{
	bool check_with_imshow = FALSE;// TRUE;
	sIOUbox iou;

	cv::Mat mask_box = cv::Mat::zeros(total.rows, total.cols, CV_8UC1);
	cv::rectangle(mask_box, box, cv::Scalar(255), -1);

	//total ROI IOU
	cv::Mat mask_and = cv::Mat::zeros(total.rows, total.cols, CV_8UC1);
	bitwise_and(mask_box, total, mask_and);
	int cnt = 0;
	for (int i = 0; i < total.cols * total.rows; i++)
	{
		if (mask_and.data[i])
			cnt++;
	}
	iou.total = ((float)cnt / (float)((box.width) * (box.height)));
	if (check_with_imshow && iou.total > 0.0f)
	{
		cv::imshow("and_total", mask_and);
		cv::waitKey(1);
	}

	//left ROI IOU
	mask_and = cv::Mat::zeros(total.rows, total.cols, CV_8UC1);
	bitwise_and(mask_box, left, mask_and);
	cnt = 0;
	for (int i = 0; i < total.cols * total.rows; i++)
	{
		if (mask_and.data[i])
			cnt++;
	}
	iou.left = ((float)cnt / (float)((box.width) * (box.height)));
	if (check_with_imshow && iou.left > 0.0f)
	{
		cv::imshow("and_left", mask_and);
		cv::waitKey(1);
	}

	//right ROI IOU
	mask_and = cv::Mat::zeros(total.rows, total.cols, CV_8UC1);
	bitwise_and(mask_box, right, mask_and);
	cnt = 0;
	for (int i = 0; i < total.cols * total.rows; i++)
	{
		if (mask_and.data[i])
			cnt++;
	}
	iou.right = ((float)cnt / (float)((box.width) * (box.height)));
	if (check_with_imshow && iou.right > 0.0f)
	{
		cv::imshow("and_right", mask_and);
		cv::waitKey(1);
	}

	mask_and.release();

	iou.side = 0;
	if (iou.total >= 0.3f) //determine load side	
	{
		cv::Point boxCenterBottom(box.x + box.width / 2, box.y);

		int x = -1, x_left = -1, x_right = -1;

		for (int i = 1; i <= 10; i += 3)
		{
			cv::Point top = m_ptRoad[i].y < m_ptRoad[i + 3].y ? m_ptRoad[i] : m_ptRoad[i + 3];
			cv::Point bot = m_ptRoad[i].y < m_ptRoad[i + 3].y ? m_ptRoad[i + 3] : m_ptRoad[i];

			cv::Point top_left = m_ptRoad[i - 1].y < m_ptRoad[i + 2].y ? m_ptRoad[i - 1] : m_ptRoad[i + 2];
			cv::Point bot_left = m_ptRoad[i - 1].y < m_ptRoad[i + 2].y ? m_ptRoad[i + 2] : m_ptRoad[i - 1];

			cv::Point top_right = m_ptRoad[i + 1].y < m_ptRoad[i + 4].y ? m_ptRoad[i + 1] : m_ptRoad[i + 4];
			cv::Point bot_right = m_ptRoad[i + 1].y < m_ptRoad[i + 4].y ? m_ptRoad[i + 4] : m_ptRoad[i + 1];

			// top(x1,y1), bot(x2,y2)
			// y - y1 = ((y2 - y1) / (x2 - x1)) * (x - x1) <= straight line equation with 2 point
			// x = ((x2 - x1) / (y2 - y1)) * (y - y1) + x1

			if (boxCenterBottom.y > top.y && boxCenterBottom.y <= bot.y)
				x = (int)(((float)(bot.x - top.x) / (float)(bot.y - top.y)) * (float)(boxCenterBottom.y - top.y)) + top.x; //center line

			if (boxCenterBottom.y > top_left.y && boxCenterBottom.y <= bot_left.y)
				x_left = (int)(((float)(bot_left.x - top_left.x) / (float)(bot_left.y - top_left.y)) * (float)(boxCenterBottom.y - top_left.y)) + top_left.x;

			if (boxCenterBottom.y > top_right.y && boxCenterBottom.y <= bot_right.y)
				x_right = (int)(((float)(bot_right.x - top_right.x) / (float)(bot_right.y - top_right.y)) * (float)(boxCenterBottom.y - top_right.y)) + top_right.x;
		}

		if ((x_left <= boxCenterBottom.x && boxCenterBottom.x <= x) && (iou.left > 0.5f && iou.right < 0.5f))
			iou.side = 1; //left
		else if ((x < boxCenterBottom.x && boxCenterBottom.x <= x_right) && (iou.right > 0.5f && iou.left < 0.5f))
			iou.side = 2; //right

		//char ioulog[128];
		//sprintf(ioulog, "total(%.4f) left(%.4f) right(%.4f) side(%d)\n", iou.total, iou.left, iou.right, iou.side);
		//OutputDebugString(ioulog);
	}
	return iou;
}
#endif

#if VDS_MODE ==1
void CRegion::CRegion_copy_raodbox(int lBoxMax, sRoadbox * leftbox, int rBoxMax, sRoadbox * rightbox)
{
	l_box_max = lBoxMax;
	r_box_max = rBoxMax;
	for (int k = 0; k < 2; k++)
	{
		sRoadbox* roadbox = (k == 0) ? leftbox : rightbox;
		sRoadbox* this_roadbox = (k == 0) ? l_box : r_box;
		for (int i = 0; i < ROAD_LINE_MAX; i++)
		{
			if (k == 0 && i < l_box_max)
				this_roadbox[i].use = 1;

			if (k == 1 && i < r_box_max)
				this_roadbox[i].use = 1;

			for (int j = 0; j < 4; j++) //eRoadboxPoint
			{
				this_roadbox[i].point[j].x = roadbox[i].point[j].x;
				this_roadbox[i].point[j].y = roadbox[i].point[j].y;
			}
		}
	}
}

void CRegion::CRegion_update_roadbox(int nPt, int nCameraIndex, eRoadboxPoint point, int side)
{
	char currentPath[MAX_PATH], strIniFilePath[MAX_PATH], strPointX[100], strPointY[100];
	sprintf(currentPath, "%s", getModulPath());

	wsprintf(strIniFilePath, "%s\\MainCam%d.ini", currentPath, nCameraIndex + 1);

	char tmpSide;
	char* Points[4] = { "LT", "RT", "LB", "RB" };

	sRoadbox* roadbox = nullptr;
	char tmpX[32]; tmpX[0] = '\0';
	char tmpY[32]; tmpY[0] = '\0';

	if (side == 0) //Left Side
	{
		tmpSide = 'L';
		roadbox = l_box;
	}
	else //Right Side
	{
		tmpSide = 'R';
		roadbox = r_box;
	}

	_itoa(roadbox[nPt].point[point].x, (LPSTR)(LPCSTR)tmpX, 10);
	_itoa(roadbox[nPt].point[point].y, (LPSTR)(LPCSTR)tmpY, 10);

	sprintf(strPointX, "ROAD_%cBOX_%s_X_%d", tmpSide, Points[point], nPt + 1);
	sprintf(strPointY, "ROAD_%cBOX_%s_Y_%d", tmpSide, Points[point], nPt + 1);

	WritePrivateProfileString("Position", strPointX, tmpX, strIniFilePath);
	WritePrivateProfileString("Position", strPointY, tmpY, strIniFilePath);
}

int CRegion::CRegion_roadbox_determine(st_det_mot_param *param, int nTrack, cv::Rect rtResBox, cv::Mat& image, unsigned long long timestamp)
{
	int nClassID = param->mot_info->mot_box_info[nTrack].class_id;
	int nTrackID = param->mot_info->mot_box_info[nTrack].track_id;

	//cv::Mat check;
	//check = image.clone();
	//cv::rectangle(check, rtResBox, cv::Scalar(255, 255, 255));
	//cv::imshow("check", check); cv::waitKey(1);

	for (int k = 0; k < 2; k++)
	{
		sRoadbox* rb = (k == 0) ? l_box : r_box; //roadbox
		int rb_max = (k == 0) ? l_box_max : r_box_max;
		for (int i = 0; i < ROAD_LINE_MAX; i++)
		{
			if (!rb[i].use)
				continue;

			cv::Point boxPoint;
			boxPoint.x = rtResBox.x + (rtResBox.width) / 2.0f;
			boxPoint.y = rtResBox.y + rtResBox.height;

			cv::Point left, right;
			int comp;
			if (k == 0)
			{
				left = (param->mot_DataSave[nTrackID].bVDS_started != TRUE) ? rb[i].point[0] : rb[i].point[2];
				right = (param->mot_DataSave[nTrackID].bVDS_started != TRUE) ? rb[i].point[1] : rb[i].point[3];

				comp = rb[i].point[2].y < rb[i].point[3].y ? rb[i].point[2].y : rb[i].point[3].y; //smaller
			}
			else
			{
				left = (param->mot_DataSave[nTrackID].bVDS_started != TRUE) ? rb[i].point[2] : rb[i].point[0];
				right = (param->mot_DataSave[nTrackID].bVDS_started != TRUE) ? rb[i].point[3] : rb[i].point[1];

				comp = rb[i].point[0].y > rb[i].point[1].y ? rb[i].point[0].y : rb[i].point[1].y; //bigger
			}

			//to determine lane number

			// top(x1,y1), bot(x2,y2)
			// x = ((x2 - x1) / (y2 - y1)) * (y - y1) + x1
			cv::Point top, bot;
			top = rb[i].point[0];
			bot = rb[i].point[2];
			int gap = 0;
			if (i != 0)
			{
				top.x = (int)(((float)rb[i].point[0].x + (float)rb[i - 1].point[1].x) / 2.0f);
				bot.x = (int)(((float)rb[i].point[2].x + (float)rb[i - 1].point[3].x) / 2.0f);
			}
			float x_left = (float)(bot.x - top.x) / (float)(bot.y - top.y) * (float)(boxPoint.y - top.y) + (float)top.x - gap;

			top = rb[i].point[1];
			bot = rb[i].point[3];
			if (i != (rb_max - 1))
			{
				top.x = (int)(((float)rb[i].point[1].x + (float)rb[i + 1].point[0].x) / 2.0f);
				bot.x = (int)(((float)rb[i].point[3].x + (float)rb[i + 1].point[2].x) / 2.0f);
			}
			float x_right = (float)(bot.x - top.x) / (float)(bot.y - top.y) * (float)(boxPoint.y - top.y) + (float)top.x + gap;


			//degree = atan(b/a) , b:height, a:bottom(width)
			//float a = float(rb[i].point[3].x - rb[i].point[1].x);
			//float b = float(rb[i].point[3].y - rb[i].point[1].y);
			float a = float(bot.x - top.x);
			float b = float(bot.y - top.y);
			float degree = a == 0 ? 90 : atan(b / a) * 180.0f / PI;
			//char log[126]; sprintf(log, "degree: %3.6f\n", degree); OutputDebugString(log);			


			int box_point = 0;
			float degree_ratio = (90.0f - fabs(degree)) / 90.0f;
			float widthRatio = 0.0f;
			if (degree <= 0.0)
			{
				widthRatio = (0.5f - 0.5f*degree_ratio) < 0.25f ? 0.25f : (0.5f - 0.5f*degree_ratio);
				box_point = rtResBox.x + (rtResBox.width) * widthRatio;
			}
			else
			{
				widthRatio = (0.5f + 0.5f * degree_ratio) > 0.75f ? 0.75f : (0.5f + 0.5f * degree_ratio);
				box_point = rtResBox.x + (rtResBox.width) * widthRatio;
			}

			if (!(x_left < box_point && box_point <= x_right))
				continue;

			// left(x1,y1), right(x2,y2)
			// y - y1 = ((y2 - y1) / (x2 - x1)) * (x - x1) <= straight line equation with 2 point
			// y = ((y2 - y1) / (x2 - x1)) * (x - x1) + y1
			// x = ((x2 - x1) / (y2 - y1)) * (y - y1) + x1
			float y = (float)(right.y - left.y) / (float)(right.x - left.x) * (float)(boxPoint.x - left.x) + (float)left.y;
			if (param->mot_DataSave[nTrackID].bVDS_started != TRUE) //determine object in roadbox
			{
				if ((k == 0 && boxPoint.y > y && boxPoint.y < comp) || (k == 1 && boxPoint.y < y && boxPoint.y > comp))
				{
					m_startCnt[k][i]++;
					//if ((m_startCnt[k][i]++) == 1000)
					//{
					//	m_startCnt[k][i] = 0;
					//	m_EndCnt[k][i] -= 1000;
					//}

					param->mot_DataSave[nTrackID].bVDS_started = TRUE;
					param->mot_DataSave[nTrackID].nVDS_startTime = timestamp;
					if (k == 1)
						param->mot_DataSave[nTrackID].nVDS_laneNum = i + 1;
					if (k == 0)
						param->mot_DataSave[nTrackID].nVDS_laneNum = l_box_max - i;
					break;
				}
			}
			else //determine line number of object
			{

#if SPEED_KOREA_EXPRESSWAY_MODE == 1

				float y_center = float(rb[i].point[0].y + rb[i].point[1].y + rb[i].point[2].y + rb[i].point[3].y) / 4.0f;

				if (param->mot_DataSave[nTrackID].bVDS_center != TRUE)
				{
					if (k == 0 && boxPoint.y >= y_center && boxPoint.y < y)
					{
						param->mot_DataSave[nTrackID].bVDS_center = TRUE;
					}
					else if (k == 1 && boxPoint.y <= y_center && boxPoint.y > y)
					{
						param->mot_DataSave[nTrackID].bVDS_center = TRUE;
					}
				}
#endif
				if (param->mot_DataSave[nTrackID].bVDS_ended != TRUE)
				{
					if (m_EndCnt[k][i] > 999)
					{
						m_startCnt[k][i] -= m_EndCnt[k][i];
						m_EndCnt[k][i] -= m_EndCnt[k][i];
					}

					if (k == 0)
					{
						if (boxPoint.y > y)
						{
							m_EndCnt[k][i]++;
							param->mot_DataSave[nTrackID].bVDS_ended = TRUE;
							param->mot_DataSave[nTrackID].nVDS_endTime = timestamp;
							//param->mot_DataSave[nTrackID].nVDS_laneNum = l_box_max - i;
						}
						else
							param->mot_DataSave[nTrackID].nVDS_laneNum_temp = l_box_max - i;
					}
					else if (k == 1)
					{
						if (boxPoint.y < y)
						{
							m_EndCnt[k][i]++;
							param->mot_DataSave[nTrackID].bVDS_ended = TRUE;
							param->mot_DataSave[nTrackID].nVDS_endTime = timestamp;
							//param->mot_DataSave[nTrackID].nVDS_laneNum = i + 1;
						}
						else
							param->mot_DataSave[nTrackID].nVDS_laneNum_temp = i + 1;
					}

					break;
				}
			}
		}
	}

	return param->mot_DataSave[nTrackID].nVDS_laneNum;
}
#endif