#pragma once
#include "common.h""

class CCamPosition
{
public:
	int m_nStartY;
	int m_nEndY;

	float m_fCamHeight;
	float m_fLengthLow;
#if SPEED_KOREA_EXPRESSWAY_MODE == 1
	float m_fLengthCen;
#else
	float m_fLengthHigh;
#endif

	float m_Alpha;
	float m_Teta;
	float m_fLengthScreen;
	float m_fHeightCenter;
	float m_fLengLowScr;
	float m_AlphaTop;
	float m_AlphaTouch;
	float m_fTopReal;
	float m_fTouchReal;

public:
	CCamPosition(void* _param);
	~CCamPosition();
	void CCamPosition_SetViolationLine(int _comp1, int _comp2, float _inH, void*_param);
	int CCamPosition_GetStartY();
	int CCamPosition_GetEndY();
	float CCamPosition_GetRealDistance();
	float CCamPosition_Ydistance_calculation(int nHeight, int nTrackPtY/*, float& fUndercarriageD*/);
	void calculate_CCamPosition(void* _param);
};