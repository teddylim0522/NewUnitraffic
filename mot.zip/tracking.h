#pragma once

#include <opencv2/core/types_c.h>
#include "opencv2/imgproc/imgproc.hpp"
using namespace cv;

#include "complex.h"
#include "hungarian_method.h"
#include "feature.h"

//#include "darknet.h"

#include "argv.h"
#include "common.h"

#include <ctime>

struct Rect_f
{
	float x;
	float y;
	float width;
	float height;

	Rect_f()
	{
		x = 0;
		y = 0;
		width = 0;
		height = 0;
	}
	Rect_f(float x_, float y_, float width_, float height_)
	{
		x = x_;
		y = y_;
		width = width_;
		height = height_;
	}

	void clear()
	{
		x = (float)0;
		y = (float)0;
		width = (float)0;
		height = (float)0;
	}
};


//motion tracker
struct mt_box
{
	float box_x;
	float box_y;
	float box_w;
	float box_h;

	void clear()
	{
		box_x = (float)0;
		box_y = (float)0;
		box_w = (float)1.0;
		box_h = (float)1.0;
	}
};



#define TRACK_INACTIVE					0
#define TRACK_INIT						1
#define TRACK_ACTIVE					2
#define TRACK_TERMINATE					3


#define MOTION_TRACKING                 1
#define VISUAL_TRACKING                 0
#define APPEARANCE_MODEL                1

/////////////////����� ����///////////////////////////////
#define DETECTION_MIN_THRESH            0.2 //ninolyc_07

//*MOT�� ��, detection score�� Ȯ�����·� ��ȯ�ϱ� ���Ͽ� ���
#define DETECT_SCORE_HIGH               100 ;
#define DETECT_SCORE_LOW                -10.0 ;
#if PUBLIC_DETECT_RESULTS
#define DETECT_PROBABILITY_LOW          0.65
#define DETECT_PROBABILITY_HIGH         0.9 //ninolyc_07
#else
#define DETECT_PROBABILITY_LOW          0.2 //ninolyc_07
#define DETECT_PROBABILITY_HIGH         0.9 //ninolyc_07
#endif
//////////////////////////////////////////////////////////////
#if VDS_MODE == 1
#define DETECT_INIT_LOW                     0.2//ninolyc_07
#define TRACK_INIT_LOW                      0.2 //ninolyc_07
#define TRACK_INIT_HIGH                     0.3 //ninolyc_07
#define TRACK_ACTIVE_LOW                    0.2//ninolyc_07
#define TRACK_TERM_LOW                      0.1 //ninolyc_07
#define TRACK_INIT_COUNT					2
#else
#define DETECT_INIT_LOW                     0.3//ninolyc_07
#define TRACK_INIT_LOW                      0.5 //ninolyc_07
#define TRACK_INIT_HIGH                     0.8 //ninolyc_07
#define TRACK_ACTIVE_LOW                    0.2//ninolyc_07
#define TRACK_TERM_LOW                      0.1 //ninolyc_07
#define TRACK_INIT_COUNT					3
#endif


//#define TRACK_TERM_COUNT				-3
#define INIT_MIN_DISTANCE				0.7
#define MIN_DISTANCE					0.7

#define TRACK_LINK_N                    8
#define TRACK_ARRAY_N				    10 //ninolyc_07
#define TRACK_TERM_N                    10

//mKCF visual tracking ����
#define TRACK_SAMPLE_WIDTH				64
#define TRACK_SAMPLE_HEIGHT				64
#define TRACK_SEARCHING_SCALE			2.5
#define TRACK_CELL_WIDTH				4
#define TRACK_CELL_HEIGHT				4
#define TRACK_LEARNING_WIDTH			(int)(TRACK_SAMPLE_WIDTH/ TRACK_CELL_WIDTH)
#define TRACK_LEARNING_HEIGHT			(int)(TRACK_SAMPLE_HEIGHT/ TRACK_CELL_HEIGHT)
#define FFT_POINT						(int)(TRACK_LEARNING_WIDTH*TRACK_LEARNING_HEIGHT)

#define TRACK_SUCCESS_SCORE				0.15
#define FILTER_LEARNING_RATE			0.125

#define _2D_FFT_USE						1
#define FFT_FORWARD						1
#define FFT_BACKWARD					-1

//#define GM_CHANNEL                     
#ifdef GM_CHANNEL 
#if N_COLOR_CHANNEL 
#define APPEARANCE_CHANNEL			4
#else
#define APPEARANCE_CHANNEL			2
#endif
#else
#ifdef N_COLOR_CHANNEL
#define APPEARANCE_CHANNEL			3
#else
#define APPEARANCE_CHANNEL			1
#endif
#endif

#define KCF_TRACK_CHANNEL               1

#define N_FEAT_GRID                     16
#define N_TRACK_GRID_X                  TRACK_SAMPLE_WIDTH/N_FEAT_GRID
#define N_TRACK_GRID_Y                  TRACK_SAMPLE_HEIGHT/N_FEAT_GRID
#define N_GRID                          N_TRACK_GRID_X*N_TRACK_GRID_Y

#define N_APPEARANCE_FEATURE            N_TRACK_GRID_X*N_TRACK_GRID_Y*APPEARANCE_CHANNEL

#define FEATURE_UPDATE_WEIGHT           0.6

class Track
{
public:
	bool IsActive;
	bool b_checked;
	int state;
	int cnt;
	int link_cnt;
	int term_cnt;
	Scalar color;
	bool b_tracking_success;

	int class_id;
	int class_group_id;

	//previous
	Rect_f f_prevROI;
	Rect i_prevROI;
	float detectScore;
	float detect_score_array[TRACK_ARRAY_N];  //ninolyc_07
	float sum_detect_score;
	float mean_detect_score;
	float *prevFeature;

	//motion tracker
	mt_box mt_box_flow;


	//predict
	Rect_f f_predROI;
	Rect i_predROI;
	float predScore;
	float *predFeature;

	float weak_affinity_score;
	float *affinity_score;
	float *iou_ratio_0;
	float *iou_ratio_1;

	//association
	bool IsAssociation;
	bool b_weak_association;
	int detectID;

	sObject object_info;

	Track()
	{
		IsActive = false;
		b_checked = false;
		state = TRACK_INACTIVE;
		cnt = 0;
		link_cnt = 0; 
		term_cnt = 0;
		color = Scalar(255, 255, 255);

		class_id = -1;

		//previous
		f_prevROI.clear();
		detectScore = 0;
		for (int i = 0; i < TRACK_ARRAY_N; i++)
			detect_score_array[i] = 0;
		prevFeature = new float[N_APPEARANCE_FEATURE];

		//next
		f_predROI.clear();
		predScore = 0;
		predFeature = new float[N_APPEARANCE_FEATURE];


		//association
		IsAssociation = false;
		b_weak_association = false;
		detectID = -1;

		//visual tracking
		b_tracking_success = false;

		affinity_score = new float[MAX_TRACK];
		iou_ratio_0 = new float[MAX_TRACK];
		iou_ratio_1 = new float[MAX_TRACK];

		//motion tracker
		mt_box_flow.clear();


		object_info.n_head_box = 0;
		object_info.head.clear();

		object_info.plate.id = -1;
		object_info.plate.prob = 0.0f;
		object_info.plate.rect = cv::Rect(0, 0, 0, 0);

	}
	~Track()
	{
		if (prevFeature)
		{
			delete[] prevFeature;
			prevFeature = nullptr;
		}
		if (predFeature)
		{
			delete[] predFeature;
			predFeature = nullptr;
		}
		if (affinity_score)
		{
			delete[] affinity_score;
			affinity_score = nullptr;
		}
		if (iou_ratio_0)
		{
			delete[] iou_ratio_0;
			iou_ratio_0 = nullptr;
		}
		if (iou_ratio_1)
		{
			delete[] iou_ratio_1;
			iou_ratio_1 = nullptr;
		}
	};
};

class mKCF_Track
{
public:
	//visual tracking
	dg_complex **ALPHA;
	Mat *channel_image;
	Mat **channel_roi_img;

	int *a;

	Mat Hann_filter;
	dg_complex *Y;

	mKCF_Track()
	{

		a = new int[10];
		//�� track�� ���� Ŀ�� ���� �޸� �Ҵ�
		ALPHA = new dg_complex *[MAX_TRACK];
		for (int tr = 0; tr < MAX_TRACK; tr++)
		{
			ALPHA[tr] = new dg_complex[FFT_POINT];
		}
		//�� ä�ο� ���� ä�� ���� �޸� �Ҵ�
		channel_image = new Mat[KCF_TRACK_CHANNEL];

		//�� track, �� ä�ο� ���� ��ġ����޸� �Ҵ�
		channel_roi_img = new Mat *[MAX_TRACK];
		for (int tr = 0; tr < MAX_TRACK; tr++)
		{
			channel_roi_img[tr] = new Mat[KCF_TRACK_CHANNEL];
		}

		//ä�� roi�� ���� ���� ũ�� �� Ÿ�� �ʱ�ȭ
		for (int tr = 0; tr < MAX_TRACK; tr++)
		{
			for (int ch = 0; ch < KCF_TRACK_CHANNEL; ch++)
			{
				channel_roi_img[tr][ch].create(TRACK_LEARNING_HEIGHT, TRACK_LEARNING_WIDTH, CV_32F);
			}
		}

		//output ���� ���� FFT ���������� �޸� �Ҵ�
		Y = new dg_complex[FFT_POINT];
		Hann_filter.create(TRACK_SAMPLE_HEIGHT, TRACK_SAMPLE_WIDTH, CV_32F);
		generate_prob_out(Y);
		generate_Hann_filter(Hann_filter);

	}

	~mKCF_Track()
	{
		////�� track�� ���� Ŀ�� ���� �޸� ����
		//for (int tr = 0; tr < MAX_TRACK; tr++)
		//{
		//	delete[] ALPHA[tr];
		//}
		//delete[] ALPHA;
		////�� ä�ο� ä�� ���� �޸� ����
		//delete[] channel_image;
		////�� track, �� ä�ο� ���� ��ġ����޸� ����
		//for (int tr = 0; tr < MAX_TRACK; tr++)
		//{
		//	delete[] channel_roi_img[tr];
		//}
		//delete[] channel_roi_img;

		////output ���� ���� FFT ���������� �޸� ����
		//delete[] Y;
	}

	void initialData();
	void releaseData();
	void generate_prob_out(dg_complex *Y);
	void generate_Hann_filter(Mat &filter);
	void train_kernel_alpha(Mat *image, Mat &hann_filter, Rect src_roi, dg_complex *Y, bool init, dg_complex *ALPHA, Mat *ch_roi);
	void alpha_update(dg_complex *C_ALPHA, dg_complex *U_ALPHA, int n_point, float update_rate);
	void get_searching_roi(Mat &image, Rect src_roi, Mat &resize_roi_image, float searching_scale);
	void get_gaussian_correlation(Mat *x1, Mat *x2, Mat &k);
	void get_candidate_region(Mat &src_image, Rect src_roi, float factor, cv::Point &lt_pt, cv::Point &rb_pt);
	void get_kernel_alpha(Mat &k, dg_complex *Y, dg_complex *A);
	float predict_roi(Rect src_roi, int tr_id, Rect &dst_roi);
	void get_multi_scale_roi(Rect src_roi, Rect *multi_scale_roi, float *multi_scale_factor, int n_multi_roi);
	float get_kernel_correlation_out(Mat *image, Mat &hann_filter, dg_complex *ALPHA, Mat *ch_roi_image, dg_complex *Y, Rect &roi);
	void get_prob_out_map(Mat &k, dg_complex *A, Mat &prob_map);
	bool get_max_peak_and_value(Mat &prob_map, CvPoint2D32f &max_peak, float &max_value);
	void get_roi_from_peak(CvPoint2D32f peak, Rect src_roi, Rect &dst_roi);

};

class Detect
{
public:
	bool IsAssociation;
	bool b_weak_association;
	int trackID;
	int class_id;
	int class_group_id;

	Rect_f detectROI;
	float detectScore;
	float *appearance_feature;

	int detect_id;

	sObject object_info;

	Detect()
	{
		IsAssociation = false;
		b_weak_association = false;
		trackID = -1;

		detectROI.clear();
		detectScore = 0;;
		appearance_feature = new float[N_APPEARANCE_FEATURE];

		object_info.n_head_box = 0;
		object_info.n_helmet_box = 0;
		object_info.head.clear();

		object_info.plate.id = -1;
		object_info.plate.prob = 0.0f;
		object_info.plate.rect = cv::Rect(0, 0, 0, 0);
	}
	~Detect()
	{
		delete[] appearance_feature;
	};
};

class cl_tracking
{
public:
	Track *track;//[MAX_TRACK];
				 //mkcf tracker class ����
	mKCF_Track mkcf_tracker;
	int nTrack;
	Mat *appearance_ch_image;

	Detect *s_detect;//[MAX_TRACK];
	Detect *w_detect;

	Scalar textColorTmp[MAX_TRACK];
	int track_seq_id;

	int mapping[MAX_TRACK];
	int nMapping;


	int n_s_detect;
	int n_w_detect;
	int track_init;

	bool bInitialized;

	cl_tracking()
	{
		track_seq_id = 0;
		s_detect = new Detect[MAX_TRACK];
		w_detect = new Detect[MAX_TRACK];
		track = new Track[MAX_TRACK];

		nTrack = 0; n_s_detect = 0; n_w_detect = 0;  nMapping = 0;

		appearance_ch_image = new Mat[APPEARANCE_CHANNEL];

		//int value[3][M = new int[MAX_TRACK];


		for (int i = 0; i < MAX_TRACK; i++)
		{
			textColorTmp[i] = Scalar(rand() % 256, rand() % 256, rand() % 256);
		}

		int test = 0;

		track_init = false;

		bInitialized = true;
	}
	~cl_tracking()
	{
		/*if(track) delete[] track;
		if(s_detect) delete[] s_detect;
		if(w_detect) delete[] w_detect;

		if(appearance_ch_image) delete[] appearance_ch_image;*/
	};

	void initialData();
	void releaseData();

	void display(Mat &image, int *track_num, int *track_id, cv::Rect *track_roi);
	void write_track_result(FILE *eval_fp, int frame_id);

	void state_update(Mat &image);
	std::vector<float> get_feat_from_detect(Mat &image, Rect_f &ROI);
	bool get_feat_from_ch_image(Mat *ch_image, int n_channel, Rect_f &ROI, float *feature);

	void visual_tracking(Mat &image);
	//motion tracking
	void motion_tracking(Mat &image);
	void no_tracking();
	void data_association();
	void greedy_association();
	void weak_data_association();
	int re_identification(int det_id);
	float calculate_cos_similarity(float *hist1, float *hist2, int n_bin);
	float calculate_cos_n_similarity(float *hist1, float *hist2, int n_ch, int n_bin);
	float calulate_l2_dist(float *hist1, float *hist2, int n_bin);
	float calulate_l1_dist(float *hist1, float *hist2, int n_bin);
	float calulate_l1_n_dist(float *hist1, float *hist2, int n_ch, int n_bin);
	void normalize_1d_vector(float *hist, int n_ch, int n_bin);
	void similarity_calculate(float **cost_matrix);
	float rectOverlapRatio(Rect_f a, Rect_f b, int type);
	void rectOverlapRatio_all(Rect_f a, Rect_f b, float &iou_ratio1, float &iou_ratio2);
	void rect_including(Rect_f a, Rect_f b, float &big_overlap, float &small_overlap);
	float rectOverlapRatio_2x(Rect_f a, Rect_f b, int type);
	void rectOverlapRatio_2x_all(Rect_f a, Rect_f b, float &iou_0, float &iou_1);
	float size_similiar_score(Rect_f a, Rect_f b);
	void update_feature(float *feat1, float *feat2, int n_feat, float w);

	void new_track_create();
	void track_update();
	void overlap_track_merge();
	bool new_track_confirm(int id);

	Rect_f cl_tracking::track_roi_update(Rect_f src_roi1, Rect_f src_roi2, Rect_f src_roi3, float weight1, float weight2, float weight3);
	bool track_initialize(int track_id, int detect_id);
	void creat(int detectID);
	void terminate(int trackID);
};



//int tracking_function(Mat image, int num, box *boxes, float **probs, int classes, st_mot_info *mot_info, st_sub_box_info *sub_box_list); //// 2018.09.03
int tracking_function(int nCameraIndex, Mat& image, st_mot_info *mot_info, st_sub_box_info *sub_box_list, st_biker_info *biker_info, st_mot_DataSave *mot_datasave, st_det_mot_param *param, float fXratio, float fYratio); //// 2018.09.03
void roi_score_probability(std::vector<float> &roi_score, float score_sum);
Rect convert_rectf_to_rect(Rect_f rect_f);
Rect_f convert_rect_to_rect_f(Rect rect);
void get_track_channel_image(Mat &image, Mat *ch_image, st_feature &feature);
int get_current_data_time(char *buff, char *type);
void get_detection_info(int nCameraIndex, Mat& image, st_mot_info *mot_info, float fXratio, float fYratio);
int Osan_get_current_data_time(char *buff, char *type);
void release_trackingdata(int nCameraIndex);
void initial_trackingdata(int nCameraIndex);

void assign_object_info(sObject& return_info, sObject& object_info);
void release_object_info(sObject& return_info);

#ifdef GPU
//void feature_calculate(int n_channel, int image_size, float* feature, float sum);
void unisem_gpu_calcFeature(int n_channel, int image_size, float sum, float *feature);
#endif