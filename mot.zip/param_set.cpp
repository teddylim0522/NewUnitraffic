
#include "param_set.h"
#include "argv.h"
#include <iostream>
#include <Windows.h>

char* getModulPath()
{
	static char currentPath[MAX_PATH];
	memset(currentPath, 0, MAX_PATH);
	DWORD dwLength = GetModuleFileNameA(nullptr, currentPath, MAX_PATH);
	if (0 != dwLength)
	{
		char* path = currentPath + dwLength;
		while (--path != currentPath && *path != '\\');
		if (*path == '\\')
		{
			*path = '\0';
		}
	}

	return currentPath;
}

void makeViolationDirectory(st_det_mot_param * param)
{
	//20190219 folder create	
	char save_path[CHAR_LENGTH];
	char currentPath[MAX_PATH];
	
	if (strcmp(param->vio_result_path, "files") == 0)
	{		
		sprintf(currentPath, "%s", getModulPath());
	}
	else
	{
		char* path = strtok(param->vio_result_path, "files");
		sprintf(currentPath, "%s", path);
	}	

	sprintf(save_path, "%s/files", currentPath);
	CreateFolder(save_path, sizeof(save_path));

	sprintf(save_path, "%s/files/count", currentPath);
	CreateFolder(save_path, sizeof(save_path));

	sprintf(save_path, "%s/files/stats", currentPath);
	//RemoveDirectory(save_path);

	SHFILEOPSTRUCT fileop;
	fileop.hwnd = NULL;    // no status display
	fileop.wFunc = FO_DELETE;  // delete operation
	fileop.pFrom = (LPCSTR)save_path;  // source file name as double null terminated string
	fileop.pTo = NULL;    // no destination needed
	fileop.fFlags = FOF_NOCONFIRMATION | FOF_SILENT;  // do not prompt the user
	fileop.fAnyOperationsAborted = FALSE;
	fileop.lpszProgressTitle = NULL;
	fileop.hNameMappings = NULL;
	int ret = SHFileOperation(&fileop);

	CreateFolder(save_path, sizeof(save_path));
	wsprintf(param->stats_result_path, "%s", save_path);

	sprintf(save_path, "%s/files/violation", currentPath);
	CreateFolder(save_path, sizeof(save_path));
	wsprintf(param->vio_result_path, "%s", save_path);

	//20190716 Viewer Event 
	sprintf(save_path, "%s/files/event", currentPath);
	CreateFolder(save_path, sizeof(save_path));
	wsprintf(param->viewer_event_path, "%s", save_path);

	char *vio_file_path = param->vio_result_path;
	//sprintf(save_path, "%s/stats", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));

	sprintf(save_path, "%s/lpr", vio_file_path);
	CreateFolder(save_path, sizeof(save_path));
	sprintf(save_path, "%s/lpr/input", vio_file_path);
	CreateFolder(save_path, sizeof(save_path));
#if SPEED_KOREA_EXPRESSWAY_MODE == 1
	sprintf(save_path, "%s/lpr/mot", vio_file_path);
	CreateFolder(save_path, sizeof(save_path));
#endif


#if ITS_MODE == 1
	sprintf(save_path, "%s/kits_event", currentPath);
	CreateFolder(save_path, sizeof(save_path));
#elif VDS_MODE == 1
	sprintf(save_path, "%s/VDS_data", currentPath);
	CreateFolder(save_path, sizeof(save_path));
	sprintf(save_path, "%s/VDS_data/images", currentPath);
	CreateFolder(save_path, sizeof(save_path));
	sprintf(save_path, "%s/VDS_data/logs", currentPath);
	CreateFolder(save_path, sizeof(save_path));
#endif


#if CHECK_SIGNAL_VIO

	sprintf(save_path, "%s/check_signal", vio_file_path);
	CreateFolder(save_path, sizeof(save_path));

#endif

	//sprintf(save_path, "%s/bike", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/speed", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/signal", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/lane", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/reverse", vio_file_path); //20190523 hai reverse violation
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/tracking", vio_file_path); //20191127 hai tracking 
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/accident", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/stoparea", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/bikeMonitering", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));

	//sprintf(save_path, "%s/bikeTemp", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/speedTemp", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/signalTemp", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/laneTemp", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/accidentTemp", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/stopareaTemp", vio_file_path);
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/reverseTemp", vio_file_path); //20190523 hai reverse violation
	//CreateFolder(save_path, sizeof(save_path));
	//sprintf(save_path, "%s/trackingTemp", vio_file_path); //20191127 hai tracking 
	//CreateFolder(save_path, sizeof(save_path));
}


bool CreateFolder(char* strPath, int nLength)
{
	char tmpPath[MAX_PATH];
	ZeroMemory(tmpPath, sizeof(tmpPath));

	char destPath[MAX_PATH];
	ZeroMemory(destPath, sizeof(destPath));
	wsprintf(destPath, "%s", strPath);
	if (strcmp((const char*)destPath, (const char*)"") == 0)
		return false;

	if (!CreateDirectory(strPath, NULL)) {
		DWORD dwResult = GetLastError();
		if (dwResult == ERROR_INVALID_NAME || dwResult == ERROR_PATH_NOT_FOUND) {
			int pos = ReverseFindChar(strPath, '\\');
			strncpy(tmpPath, strPath, pos - 1);
			if (!CreateFolder(tmpPath, (int)strlen(tmpPath)))
				return false;
			else {
				if (!CreateDirectory(destPath, NULL))
					return false;
			}
		}
		else if (dwResult == ERROR_ALREADY_EXISTS)
			return true;
		else
			return false;
	}
	return true;
}


//========================================================================================
// Return position num of string
//========================================================================================
int ReverseFindChar(char *strPath, char delimiter)
{
	char *pdest;
	int result = -1;

	pdest = strrchr(strPath, delimiter);
	if (pdest == NULL) return result;
	else result = (int)(pdest - strPath + 1);

	return result;
}


bool param_initialize(st_det_mot_param *param, st_biker_info* biker_info)
{
	if (param)
	{
		for (int id = 0; id < MAX_TRACK; id++)	////=== hai edited ===////
		{
			if (param->mot_info)
			{
				param->mot_info->b_counted[id] = false;
				param->mot_info->b_counted_forTopline[id] = false; //hai 2018.12.03
				param->mot_info->n_violated[id] = 0;
				//20190214 hai Counting
				param->mot_info->object_confirm[id] = 0;
				param->mot_info->TO_object[id] = 0;
			}

			//mot_DataSave		
			param->mot_DataSave[id].nDataSave = 0;
			param->mot_DataSave[id].nTrackCount = 0;

			//20200128 BacNinh
			param->mot_DataSave[id].nIsExitStart = 0;
			param->mot_DataSave[id].bSaveLane = 0;
			param->mot_DataSave[id].bSaveSignal = 0;
			param->mot_DataSave[id].nIsRedSignal = 0;
			param->mot_DataSave[id].nIsLeftRedSignal = 0;
			param->mot_DataSave[id].nLaneNumber = 0;
			param->mot_DataSave[id].nTouchedTop = 0;
			param->mot_DataSave[id].nTouchedLeft = 0;
			param->mot_DataSave[id].nTouchedRight = 0;
			param->mot_DataSave[id].bCheckGreenSignal = 0; //200310 check signal violation for 2nd touched line - green signal

			if (!param->mot_DataSave[id].pIplImageSLStart.empty())
			{
				param->mot_DataSave[id].pIplImageSLStart.release();
			}

			//bike vio 191213
			for (int j = 0; j < MAX_SUB_BOX; j++)
			{
				param->sub_box_list[id].n_rider_histogram[j] = 0;
			}

			for (int sub_idx = 0; sub_idx < MAX_FRAME_NUM; sub_idx++)
			{
				param->sub_box_list[id].n_box_list[sub_idx] = 0;
				if (!param->sub_box_list[id].vio_image[sub_idx].empty())
					param->sub_box_list[id].vio_image[sub_idx].release();
			}
			param->sub_box_list[id].n_box_idx = -1;
			param->sub_box_list[id].n_min_rider_idx = -1;
			param->sub_box_list[id].n_his_rider = -1;


			//radar speed
			for (int nTcnt = 0; nTcnt < MAX_TRACK_COUNT; nTcnt++)
			{
				param->mot_DataSave[id].fRadarSpeed[nTcnt] = 0.0;
			}

			param->mot_DataSave[id].nRadarCount = 0.0;
			param->mot_DataSave[id].fTotalRadarSpeed = 0.0;
			param->mot_DataSave[id].fMeanRadarSpeed = 0.0;

			if (!param->mot_DataSave[id].pIplImage.empty())
			{
				param->mot_DataSave[id].pIplImage.release();
			}

			//20190215 hai Parking
#if ITS_MODE
			//pedestrian
			param->mot_DataSave[id].nPedestVioCnt = 0;
			param->mot_DataSave[id].nPedestResetCnt = 0;
			param->mot_DataSave[id].nPedestViolation = 0;
			param->mot_DataSave[id].appearTime = 0;
			
			//stop
			param->mot_DataSave[id].bStoreImage = 0;
			param->mot_DataSave[id].nStopResetCnt = 0;
			param->mot_DataSave[id].nStopVioCnt = 0;
			param->mot_DataSave[id].nStopZeroCnt = 0;
			param->mot_DataSave[id].stopTime = 0;
#endif
			//X and Y calculation
#ifdef XYCOOR_MODE
			std::vector<float>().swap(param->mot_DataSave[id].nXYCOOR_distanceY);
			std::vector<float>().swap(param->mot_DataSave[id].nXYCOOR_distanceX);
			std::vector<unsigned long long>().swap(param->mot_DataSave[id].nXYCOOR_time);
			std::vector<float>().swap(param->mot_DataSave[id].nXYCOOR_fSpeed);
			std::vector<float>().swap(param->mot_DataSave[id].nXYCOOR_deltaTime);
			param->mot_DataSave[id].fXYCOOR_speed = -1.0f;
			param->mot_DataSave[id].fXYCOOR_speed_display = -1.0f;
			param->mot_DataSave[id].fXYCOOR_deltaTime = 0.0f;
#endif

#if VDS_MODE == 1
			param->mot_DataSave[id].nVDS_startTime = -1;
			param->mot_DataSave[id].nVDS_endTime = -1;
			param->mot_DataSave[id].bVDS_started = FALSE;			
			param->mot_DataSave[id].bVDS_ended = FALSE;
			param->mot_DataSave[id].bVDS_started_setdone = FALSE;
			param->mot_DataSave[id].bVDS_ended_setdone = FALSE;
			param->mot_DataSave[id].nVDS_laneNum = -1;
			param->mot_DataSave[id].nVDS_direction = 0;
			param->mot_DataSave[id].fVDS_ST_distanceY = -1.0f;
			param->mot_DataSave[id].fVDS_ST_distanceX = -1.0f;
			param->mot_DataSave[id].fVDS_SB_distanceY = -1.0f;
			param->mot_DataSave[id].fVDS_SB_distanceX = -1.0f;
			param->mot_DataSave[id].fVDS_carLength = 0.0f;
			param->mot_DataSave[id].fVDS_carHeight = 0.0f;
			param->mot_DataSave[id].fVDS_carSpeed = 0.0f;
			param->mot_DataSave[id].fVDS_ocpTime = 0.0f;
			param->mot_DataSave[id].nVDS_vehicleGap = 0;
			param->mot_DataSave[id].nVDS_pushStatus = PUSH_STANDBY;
			if (!param->mot_DataSave[id].iVDS_startImg.empty())
			{
				param->mot_DataSave[id].iVDS_startImg.release();
			}
			param->mot_DataSave[id].fVDS_cosAngle = 0.0f;
			param->mot_DataSave[id].fVDS_carTotalWidth = 0.0f;

#if SPEED_KOREA_EXPRESSWAY_MODE == 1
			param->mot_DataSave[id].fXYCOOR_distancePlate.clear();
			param->mot_DataSave[id].track_rect.clear();
			param->mot_DataSave[id].track_plate_rect.clear();
			param->mot_DataSave[id].bVDS_center = FALSE;
			param->mot_DataSave[id].nVDS_center_setdone = 0;
			param->mot_DataSave[id].fSpeed_Final = -1.0f;
			for (int idx = 0; idx < 3; idx++)
			{
				param->mot_DataSave[id].fSpeed_Center[idx] = -1.0f;
				param->mot_DataSave[id].fSpeed_Plate[idx] = -1.0f;
				param->mot_DataSave[id].fSpeed_Plate_fix_start[idx] = -1.0f;
				param->mot_DataSave[id].fSpeed_Plate_fix_end[idx] = -1.0f;

				if (param->mot_DataSave[id].image_pairs[idx].img[0].empty() == false)
					param->mot_DataSave[id].image_pairs[idx].img[0].release();
				if (param->mot_DataSave[id].image_pairs[idx].img[1].empty() == false)
					param->mot_DataSave[id].image_pairs[idx].img[1].release();

				param->mot_DataSave[id].image_pairs[idx].rect[0] = cv::Rect(0, 0, 0, 0);
				param->mot_DataSave[id].image_pairs[idx].rect[1] = cv::Rect(0, 0, 0, 0);

				param->mot_DataSave[id].image_pairs[idx].plate_rect[0] = cv::Rect(0, 0, 0, 0);
				param->mot_DataSave[id].image_pairs[idx].plate_rect[1] = cv::Rect(0, 0, 0, 0);

				param->mot_DataSave[id].fDis_plateStart[idx].fDis_plate_top = 0.0f;
				param->mot_DataSave[id].fDis_plateStart[idx].fDis_plate_bot = 0.0f;

				param->mot_DataSave[id].fDis_plateEnd[idx].fDis_plate_top = 0.0f;
				param->mot_DataSave[id].fDis_plateEnd[idx].fDis_plate_bot = 0.0f;
			}

			for (int idx = 3; idx < 5; idx++)
			{
				param->mot_DataSave[id].fSpeed_Center[idx] = -1.0f;
				param->mot_DataSave[id].fDistance_Center_start[idx] = 0.0f;
				param->mot_DataSave[id].fDistance_Center_end[idx] = 0.0f;
				param->mot_DataSave[id].fTime_Center[idx] = 0.0f;
			}

			for (int idx = 0; idx < param->mot_DataSave[id].track_image.size(); idx++)
			{
				if (param->mot_DataSave[id].track_image[idx].empty() == false)
					param->mot_DataSave[id].track_image[idx].release();
			}
#endif
#endif

			param->mot_DataSave[id].bCheckAccident = 0;
			param->mot_DataSave[id].bSaveAccident = 0;
			param->mot_DataSave[id].parkingTime = 0;
			if (!param->mot_DataSave[id].pIplImageParkingStart.empty())
			{
				param->mot_DataSave[id].pIplImageParkingStart.release();
			}

			//20190222 hai Violation color
			for (int j = 0; j < PEDESTRIAN_VIO_CLR + 1; j++)
			{
				param->mot_DataSave[id].nVioDisplay[j] = 0;
			}

			//hai 2018.12.12 reset all violation parameters for biker
			if (biker_info)
			{
				biker_info->rider_violation_confirm[id] = 0;
				biker_info->helmet_violation_confirm[id] = 0;
				biker_info->TO_violation[id] = 0;

				biker_info->umbrella_violation_confirm[id] = 0;
				biker_info->mobile_violation_confirm[id] = 0;

				biker_info->violation_confirm[id] = 0;

				biker_info->n_touched_count[id] = 0; //200309 hai
			}

			//wrong lane violation
			{
				if (!param->mot_LaneSave[id].pIplImage.empty())
				{
					param->mot_LaneSave[id].pIplImage.release();
				}

				if (!param->mot_LaneSave[id].pLPImage.empty())
				{
					param->mot_LaneSave[id].pLPImage.release();
				}

				memset(&param->mot_LaneSave[id], 0, sizeof(st_lane_DataSave));

				param->mot_LaneSave[id].nStartStatus = -1;
				param->mot_LaneSave[id].nEndStatus = -1;
				param->mot_LaneSave[id].nLaneViolation = 0;
				param->mot_LaneSave[id].nLPR = 0;
				param->mot_LaneSave[id].nLaneVioCnt = 0;
				param->mot_LaneSave[id].pIplImage = NULL;
				param->mot_LaneSave[id].pLPImage = NULL;
				param->mot_LaneSave[id].nTouchBot = 0;
				param->mot_LaneSave[id].nTouchTop = 0;

				param->mot_LaneSave[id].nFirstClass = -1;
			}

			//reverse violation
			{
#if ITS_MODE == 1 || VDS_MODE == 1
				param->mot_ReverseSave[id].bStoreImage = 0;
				param->mot_ReverseSave[id].nReverseResetCnt = 0;
#endif
				if (!param->mot_ReverseSave[id].pIplImage.empty())
				{
					param->mot_ReverseSave[id].pIplImage.release();
				}

				if (!param->mot_ReverseSave[id].pLPImage.empty())
				{
					param->mot_ReverseSave[id].pLPImage.release();
				}

				memset(&param->mot_ReverseSave[id], 0, sizeof(st_reverse_DataSave));
				param->mot_ReverseSave[id].nReverseViolation = 0;
				param->mot_ReverseSave[id].nLPR = 0;
				param->mot_ReverseSave[id].nReverseVioCnt = 0;
				param->mot_ReverseSave[id].pIplImage = NULL;
				param->mot_ReverseSave[id].pLPImage = NULL;
				param->mot_ReverseSave[id].nTouchBot = 0;
				param->mot_ReverseSave[id].nTouchTop = 0;

				param->mot_ReverseSave[id].nFirstClass = -1;
			}

			//light violation 1 line touched
			param->mot_LightSave[id].nLightViolation = 0;
			param->mot_LightSave[id].nLightTouch = 0;
			param->mot_LightSave[id].nPassLine = 0;
			if (!param->mot_LightSave[id].pIplImage.empty())
			{
				param->mot_LightSave[id].pIplImage.release();
			}
		}

		if (param->mot_info)
		{
			for (int c_id = 0; c_id < param->nLclasses - BACKGROUND_CLASS; c_id++)
			{
				param->mot_info->object_flow_number[c_id] = 0;
				param->mot_info->object_flow_total[c_id] = 0; //20190214 hai Status Log

				param->mot_info->object_flow_number_out[c_id] = 0;//20191211 skkang stats each direction
				param->mot_info->object_flow_total_out[c_id] = 0;
			}
		}
	}

	return TRUE;
}


void setMode(st_det_mot_param *param, int nMode)
{
	param->nOperationMode = nMode;
}


bool getMode(st_det_mot_param *param, int nMode)
{
	if (param->nOperationMode == OPERATION_MODE_DISPLAY)
		return false;
	else if (param->nOperationMode == OPERATION_MODE_ALL)
		return true;
	else if (nMode & param->nOperationMode)
		return true;

	return false;
}