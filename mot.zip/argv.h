﻿int argv_setting(char **argv);
/*************Train detector*************/
#define LOAD_DATA_DETECTION_ORI		1

#define GT_VIEW						0
#if GT_VIEW
#define TRAIN_DETECTOR_THREADS		1
#else
#define TRAIN_DETECTOR_THREADS		6
#endif



/*************Test detector*************/
#if 0
#define INRIA						1
#define LIST_PATH					"D:/Database/1) INRIA/INRIA/test.list"
#elif 0
#define NEXT_CHIP					1
#define LIST_PATH					"D:/Database/8) next_chip/00017_캠퍼스.list"
#elif 0
#define MOT17det_TRAIN				1
#define LIST_PATH					"D:/Database/5) MOT/MOT17det/train.list"
#elif 0
#define MOT17det_TEST				1
#define LIST_PATH					"D:/Database/5) MOT/MOT17det/test.list"
#elif 0
#define CITYSCAPES_TRAIN			1
#define LIST_PATH					"D:/Database/7) deep_learning/Cityscapes/train34.list"
#elif 0
#define CITYSCAPES_TEST				1
#define LIST_PATH					"D:/Database/7) deep_learning/Cityscapes/test34.list"
#elif 0
#define KITTI_TRAIN					1
#define LIST_PATH					"D:/Database/4) KITTI/object/train.list"
#elif 0
#define KITTI_TRAIN_SORT			1
#define LIST_PATH					"D:/Database/4) KITTI/object/train_sort.list"
#elif 0
#define KITTI_TRAIN_VAL				1
#define LIST_PATH					"D:/Database/4) KITTI/object/train_val.list"
#elif 0
#define KITTI_TEST					1
#define LIST_PATH					"D:/Database/4) KITTI/object/test.list"
#elif 1
#define LABFIS				        1
#define LIST_PATH					"D:/Database/LABFIS/ca4.list"
#endif

#define WEBCAM						0
#define RTSP						1

#define TRACKING					1

#define EVAL						0
#define FP_BASE_FIX					0
#define FP_BASE_NAME				"YOLO2 v2 41 MOT DET ExtendNet"
#define FP_EVAL_MOVE				0
#define FP_EVAL_DIR					"D:/Darknet/eval/YOLO2 v2 41 MOT DET ExtendNet"

#define FREEZE_LAYER				0  //transfer learning freeze layer
#define BACKGROUND_CLASS            0  //background class를 사용하려면 1로 설정
#define NMS_IOU                     0.45  //NNS를 위한 IOU thresh
#define DETECT_THRESH               0.3  //positive 객체를 위한 thresh

#define IMAGE_START					0//start: 0
#define WAIT_KEY					1
#define GT_SHOW						0

#define IMAGE_SAVE					0
#define IMAGE_SAVE_DIR				"C:/Users/kms/Desktop/layer30_pre23_kitti_416"

#if _RELEASE
#define IMAGE_LOAD_THREAD
#endif



