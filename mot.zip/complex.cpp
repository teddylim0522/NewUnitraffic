
#include "complex.h"

/*----------------------------------------------------------------------*/
/* Truncated Stockham algorithm for multi-column vector,
X(n1,n2) <- F_n1 X(n1,n2)
x[] input data of size n, viewed as n1 = n/n2 by n2 dimensional
array, flag =+1 forward transform, -1 for backward transform, y[] is
working space, which must be n in size. This function is supposed
to be internal (static), not used by application. Note that the
terminology of column or row respect to algorithms in the Loan's
book is reversed, because we use row major convention of C.
*/
static void stockham(dg_complex *x, int n, int flag, int n2, dg_complex *y)
{
	dg_complex *y_orig, *tmp;
	int i, j, k, k2, Ls, r, jrs;
	int half, m, m2;
	double wr, wi, tr, ti;

	y_orig = y;
	r = half = n >> 1;
	Ls = 1; /* Ls=L/2 is the L star */

	while (r >= n2) { /* loops log2(n/n2) times */
		tmp = x; /* swap pointers, y is always old */
		x = y; /* x is always for new data */
		y = tmp;
		m = 0; /* m runs over first half of the array */
		m2 = half; /* m2 for second half, n2=n/2 */
		for (j = 0; j < Ls; ++j) {
			wr = cos(CV_PI*j / Ls); /* real and imaginary part */
			wi = -flag * sin(CV_PI*j / Ls); /* of the omega */
			jrs = j*(r + r);
			for (k = jrs; k < jrs + r; ++k) { /* "butterfly" operation */
				k2 = k + r;
				tr = wr*y[k2].Re - wi*y[k2].Im; /* complex multiply, w*y */
				ti = wr*y[k2].Im + wi*y[k2].Re;
				x[m].Re = y[k].Re + tr;
				x[m].Im = y[k].Im + ti;
				x[m2].Re = y[k].Re - tr;
				x[m2].Im = y[k].Im - ti;
				++m;
				++m2;
			}
		}
		r >>= 1;
		Ls <<= 1;
	};

	if (y != y_orig) { /* copy back to permanent memory */
		for (i = 0; i < n; ++i) { /* if it is not already there */
			y[i] = x[i]; /* performed only if log2(n/n2) is odd */
		}
	}

	assert(Ls == n / n2); /* ensure n is a power of 2 */
	assert(1 == n || m2 == n); /* check array index within bound */
}

/* The Cooley-Tukey multiple column algorithm, see page 124 of Loan.
 x[] is input data, overwritten by output, viewed as n/n2 by n2
 array. flag = 1 for forward and -1 for backward transform.
 */
void cooley_tukey(dg_complex *x, int n, int flag, int n2)
{
	dg_complex c;
	int i, j, k, m, p, n1;
	int Ls, ks, ms, jm, dk;
	double wr, wi, tr, ti;

	n1 = n / n2; /* do bit reversal permutation */
	for (k = 0; k < n1; ++k) { /* This is algorithms 1.5.1 and 1.5.2. */
		j = 0;
		m = k;
		p = 1; /* p = 2^q, q used in the book */
		while (p < n1) {
			j = 2 * j + (m & 1);
			m >>= 1;
			p <<= 1;
		}
		assert(p == n1); /* make sure n1 is a power of two */
		if (j > k) {
			for (i = 0; i < n2; ++i) { /* swap k <-> j row */
				c = x[k*n2 + i]; /* for all columns */
				x[k*n2 + i] = x[j*n2 + i];
				x[j*n2 + i] = c;
			}
		}
	}
	/* This is (3.1.7), page 124 */
	p = 1;
	while (p < n1) {
		Ls = p;
		p <<= 1;
		jm = 0; /* jm is j*n2 */
		dk = p*n2;
		for (j = 0; j < Ls; ++j) {
			wr = cos(CV_PI*j / Ls); /* real and imaginary part */
			wi = -flag * sin(CV_PI*j / Ls); /* of the omega */
			for (k = jm; k < n; k += dk) { /* "butterfly" */
				ks = k + Ls*n2;
				for (i = 0; i < n2; ++i) { /* for each row */
					m = k + i;
					ms = ks + i;
					tr = wr*x[ms].Re - wi*x[ms].Im;
					ti = wr*x[ms].Im + wi*x[ms].Re;
					x[ms].Re = x[m].Re - tr;
					x[ms].Im = x[m].Im - ti;
					x[m].Re += tr;
					x[m].Im += ti;
				}
			}
			jm += n2;
		}
	}
}

/* 1D Fourier transform:
 Simply call stockham with proper arguments.
 Allocated working space of size n dynamically.
 */
void _fft(dg_complex *x, int n, int flag)
{
	dg_complex *y;

	assert(1 == flag || -1 == flag);
	y = (dg_complex *)malloc(n*sizeof(dg_complex));
	assert(NULL != y);
	stockham(x, n, flag, 1, y);
	free(y);
}

/* 3D Fourier transform:
 The index for x[m] is mapped to (i,j,k) by
 m = k + n3*j + n3*n2*i, i.e. the row major convention of C.
 All indices start from 0.
 This algorithm requires working space of n2*n3.
 Stockham is efficient, good stride feature, but takes extra
 memory same size as input data; Cooley-Tukey is in place,
 so we take a compromise of the two.
 */

void _fft2D(dg_complex *x, int n1, int n2, int flag)
{
	dg_complex *y;
	int i, n;

	assert(1 == flag || -1 == flag);
	n = n1*n2;
	y = (dg_complex *)malloc(n2*sizeof(dg_complex));
	assert(NULL != y);

	for (i = 0; i < n; i += n2) { /* FFT in y */
		stockham(x + i, n2, flag, 1, y);
	}
	free(y);
	cooley_tukey(x, n, flag, n2); /* FFT in x */
}

void _fft3D(dg_complex *x, int n1, int n2, int n3, int flag)
{
	dg_complex *y;
	int i, n, n23;

	assert(1 == flag || -1 == flag);
	n23 = n2*n3;
	n = n1*n23;
	y = (dg_complex *)malloc(n23*sizeof(dg_complex));
	assert(NULL != y);

	for (i = 0; i < n; i += n3) { /* FFT in z */
		stockham(x + i, n3, flag, 1, y);
	}
	for (i = 0; i < n; i += n23) { /* FFT in y */
		stockham(x + i, n23, flag, n3, y);
	}
	free(y);
	cooley_tukey(x, n, flag, n23); /* FFT in x */
}

void fft(dg_complex *v, int n)
{
	dg_complex *tmp = new dg_complex[n];
	if (n > 1)
	{			/* otherwise, do nothing and return */
		int k, m; dg_complex z, w, *vo, *ve;
		ve = tmp; vo = tmp + n / 2;
		for (k = 0; k < n / 2; k++)
		{
			ve[k] = v[2 * k];
			vo[k] = v[2 * k + 1];
		}
		fft(ve, n / 2);		/* FFT on even-indexed elements of v[] */
		fft(vo, n / 2);		/* FFT on odd-indexed elements of v[] */
		for (m = 0; m < n / 2; m++)
		{
			w.Re = cos(2 * PI*m / (double)n);
			w.Im = -sin(2 * PI*m / (double)n);
			z.Re = w.Re*vo[m].Re - w.Im*vo[m].Im;	/* Re(w*vo[m]) */
			z.Im = w.Re*vo[m].Im + w.Im*vo[m].Re;	/* Im(w*vo[m]) */
			v[m].Re = ve[m].Re + z.Re;
			v[m].Im = ve[m].Im + z.Im;
			v[m + n / 2].Re = ve[m].Re - z.Re;
			v[m + n / 2].Im = ve[m].Im - z.Im;
		}
	}
	delete[] tmp;
}

void ifft(dg_complex *v, int n)
{
	dg_complex *tmp = new dg_complex[n];
	if (n > 1)
	{			/* otherwise, do nothing and return */
		int k, m; dg_complex z, w, *vo, *ve;
		ve = tmp; vo = tmp + n / 2;
		for (k = 0; k < n / 2; k++)
		{
			ve[k] = v[2 * k];
			vo[k] = v[2 * k + 1];
		}
		ifft(ve, n / 2);		/* FFT on even-indexed elements of v[] */
		ifft(vo, n / 2);		/* FFT on odd-indexed elements of v[] */
		for (m = 0; m < n / 2; m++)
		{
			w.Re = cos(2 * PI*m / (double)n);
			w.Im = sin(2 * PI*m / (double)n);
			z.Re = w.Re*vo[m].Re - w.Im*vo[m].Im;	/* Re(w*vo[m]) */
			z.Im = w.Re*vo[m].Im + w.Im*vo[m].Re;	/* Im(w*vo[m]) */
			v[m].Re = ve[m].Re + z.Re;
			v[m].Im = ve[m].Im + z.Im;
			v[m + n / 2].Re = ve[m].Re - z.Re;
			v[m + n / 2].Im = ve[m].Im - z.Im;
		}
	}
	delete[] tmp;
}

void complex_add(dg_complex a, dg_complex b, dg_complex &c)
{
	c.Re = (a.Re + b.Re);
	c.Im = (a.Im + b.Im);
}

void complex_subtraction(dg_complex a, dg_complex b, dg_complex &c)
{
	c.Re = (a.Re - b.Re);
	c.Im = (a.Im - b.Im);
}

void complex_multiplier(dg_complex a, dg_complex b, dg_complex &c)
{
	c.Re = (a.Re * b.Re) - (a.Im * b.Im);
	c.Im = (a.Re * b.Im) + (a.Im * b.Re);
}

void complex_division(dg_complex a, dg_complex b, dg_complex &c)
{
	float denominator = (b.Re * b.Re) + (b.Im * b.Im) + 1.0;

	c.Re = ((a.Re * b.Re) + (a.Im * b.Im)) / denominator;
	c.Im = ((a.Im * b.Re) - (a.Re * b.Im)) / denominator;
}

void complex_conjugate(dg_complex a, dg_complex &b)
{
	b.Re = a.Re;
	b.Im = -a.Im;
}

void complex_add_vector(dg_complex *a, dg_complex *b, int n_point, dg_complex *c)
{
	for (int i = 0; i < n_point; i++)
	{
		complex_add(a[i], b[i], c[i]);
	}
}

void complex_multiplier_vector(dg_complex *a, dg_complex *b, int n_point, dg_complex *c)
{
	for (int i = 0; i < n_point; i++)
	{
		complex_multiplier(a[i], b[i], c[i]);
	}
}

void complex_division_vector(dg_complex *a, dg_complex *b, int n_point, dg_complex *c)
{
	for (int i = 0; i < n_point; i++)
	{
		complex_division(a[i], b[i], c[i]);
	}
}

void complex_conjugate_vector(dg_complex *a, int n_point, dg_complex *b)
{
	for (int i = 0; i < n_point; i++)
	{
		complex_conjugate(a[i], b[i]);
	}
}

void get_X_x_X_c(dg_complex *F, dg_complex *F_Fc, int n_point)
{
	for (int k = 0; k < n_point; k++)
	{
		F_Fc[k].Re = (F[k].Re * F[k].Re) + (F[k].Im * F[k].Im);
		F_Fc[k].Im = 0;
	}
}

void mat_to_complex(Mat &image, dg_complex *c_x)
{
	int k = 0;
	for (int y = 0; y < image.rows; y++)
	{
		float *value = image.ptr<float>(y);
		for (int x = 0; x < image.cols; x++)
		{
			c_x[k].Re = value[x];
			c_x[k].Im = 0;
			k++;
		}
	}
}

void complex_to_mat(dg_complex *c_x, int n_point, Mat &image)
{
	int k = 0;
	for (int y = 0; y < image.rows; y++)
	{
		float *value = image.ptr<float>(y);
		for (int x = 0; x < image.cols; x++)
		{
			value[x] = c_x[k].Re / n_point;
			//if (value[x] < 0 ) value[x] = 0;
			//printf("(%d, %d) = %f\n", x, y, value[x]);
			k++;
		}
		//printf("\n");
	}
}