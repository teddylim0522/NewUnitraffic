#include <opencv2/core/types_c.h>
#include "opencv2/imgproc/imgproc.hpp"

using namespace cv;

//channel
#define YCBCR444								1 //global
#define YCBCR422								0 //global
#define YCBCR420								0 //global

#define USE_HYBRID								0 //global
#define N_COLOR_CHANNEL							1 //feature

//feature
#define PEDESTRIAN								1
#if PEDESTRIAN
	#if SAMPLE_32_64
		#define SAMPLE_WIDTH					32
		#define SAMPLE_HEIGHT					64
		#define CELL_WIDTH						2
		#define CELL_HEIGHT						2
	#else
		#define SAMPLE_WIDTH					64
		#define SAMPLE_HEIGHT					128
		#define CELL_WIDTH						4
		#define CELL_HEIGHT						4
	#endif

#elif VEHICLE
	#define SAMPLE_WIDTH						64
	#define SAMPLE_HEIGHT						64
	#define CELL_WIDTH							4
	#define CELL_HEIGHT							4
#endif

#define N_HOR_CELL								(SAMPLE_WIDTH/CELL_WIDTH)
#define N_VER_CELL								(SAMPLE_HEIGHT/CELL_HEIGHT)

#define N_BIN									6
#define N_GRAD_MAG								1

#if N_COLOR_CHANNEL
	#if USE_HYBRID
		#define N_LAST_CHANNEL					1
		#define N_CHANNEL						(N_BIN + N_GRAD_MAG + N_LAST_CHANNEL)
	#else
		#define N_LAST_CHANNEL					3
		#define N_CHANNEL						(N_BIN + N_GRAD_MAG + N_LAST_CHANNEL)
	#endif
#else
	#define N_LAST_CHANNEL						1
	#define N_CHANNEL							(N_BIN + N_GRAD_MAG + N_LAST_CHANNEL)
#endif

#define N_HIST_FEATURE							(N_HOR_CELL*N_VER_CELL*N_CHANNEL)

#define AVERAGE_POOLING							1
#define MAX_POOLING								0

#if USE_HYBRID
	#define RRIOR_Y_WEIGHT						1.0
#else
	#define RRIOR_Y_WEIGHT						0.203125
#endif

#if N_COLOR_CHANNEL
	#if USE_HYBRID
		#define LOCAL_NORM_FACTOR				20
	#else
		#define LOCAL_NORM_FACTOR				5
	#endif
#else
	#define LOCAL_NORM_FACTOR					20
#endif

struct st_feature
{
	bool use_color_channel;

	int sample_width;
	int sample_height;
	int cell_width;
	int cell_height;
	int n_hor_cell;
	int n_ver_cell;

	int n_bin;
	int n_grad_mag;

	int n_last_channel;
	int n_channel;
	int n_hist_feature;

	char *pooling_type;

	st_feature()
	{
		use_color_channel = (bool)N_COLOR_CHANNEL;

		sample_width = (int)SAMPLE_WIDTH;
		sample_height = (int)SAMPLE_HEIGHT;
		cell_width = (int)CELL_WIDTH;
		cell_height = (int)CELL_HEIGHT;
		n_hor_cell = (int)N_HOR_CELL;
		n_ver_cell = (int)N_VER_CELL;

		n_bin = (int)N_BIN;
		n_grad_mag = (int)N_GRAD_MAG;

		n_last_channel = (int)N_LAST_CHANNEL;
		n_channel = (int)N_CHANNEL;
		n_hist_feature = (int)N_HIST_FEATURE;

		pooling_type = AVERAGE_POOLING ? "average_pooling" :
			MAX_POOLING ? "max_pooling" : "average_pooling";

		//printf("st_feature\n");
	}
};

void get_channel_image(Mat &image, Mat *ch_image, Mat *ag_ch_image, st_feature &feature);
void get_octave_channel_image(Mat &image, Mat *ch_image, st_feature &feature);
void get_fast_channel_image(Mat *ch_image, Mat *f_ch_image, int n_channel, float scale);
void rgb_to_luv(Mat &rgb_image, Mat &luv_image);
void _rgb_to_yc(Mat &rgb_image, Mat &yc_image);
void rgb_to_yc(Mat &rgb_image, Mat &yc_image);
void _rgb_to_yc_32F(Mat &rgb_image, Mat &yc_image);
void yc_to_rgb(Mat &yc_image, Mat &rgb_image);
void yc444_to_yc422(Mat &yc444, Mat &yc422);
void yc444_to_yc422_2(Mat &yc444, Mat &yc422);
void yc444_to_yc420(Mat &yc444, Mat &yc420);
void yc422_to_yc444(Mat &yc422, Mat &yc444);
void yc_to_ch_image(Mat &yc_image, Mat *ch_image);
void yc_to_ch_image_32F(Mat &yc_image, Mat *ch_image);
void image_to_ch_image_32F(Mat &yc_image, Mat *ch_image);
void image_to_ch_image(Mat &yc_image, Mat *ch_image);
void _channel_split(Mat &color_image, Mat *ch_image);
void _channel_merge(Mat *ch_image, Mat &color_image);
void _luv_to_ch_image(Mat &luv_image, Mat *ch_image);
void luv_to_ch_image(Mat &luv_image, Mat &ch_image);
void get_mag_grad_image(Mat &image, Mat &grd_image, Mat &mag_image);
float get_approximate_angle(float dx, float dy, int angle_step);
float get_0_to_45_angle(float a, float b, int angle_step);
void max_mag_grad_image(Mat *_grad_image, Mat *_mag_image, Mat &grad_image, Mat &mag_image);
void get_grad_ch_image(Mat &grad_image, Mat &mag_image, Mat *ch_image, int n_bin);
void get_pooling_image(Mat *ch_image, Mat *pooling_image, st_feature &feature);
void get_pooling_channel_image(Mat *ch_image, Mat *ag_ch_image, st_feature &feature);
void pooling_block(Mat &src_image, Mat &dst_image, int x_block, int y_block, char *pooling_type);
void channel_gaussian_blur(Mat *src_ch_image, Mat *dst_ch_image, int n_channel);
void local_normalization(Mat *image, int n_channel, int block_size, float min_value);
void generate_feature_vectors_from_window(Mat *ag_image, CvMat *t_data, int index, st_feature &feature, int auto_retrain_padding_size);
void generate_feature_vectors_from_full_image(Mat *ag_image, CvMat *t_data, int x_start, int y_start, st_feature &feature);
void generate_feature_rows_from_full_image(Mat *ag_image, CvMat *b_data, int x_start, st_feature &feature) ;
void get_feature_vector_from_feature_rows(Mat *ag_image, CvMat *s_feat, CvMat *t_feat, int y_start, st_feature &feature, int n_copy) ;
void _Sobel(Mat &src, Mat &dst, int ddepth, int dx, int dy, int ksize);
void _Sobel2(Mat &src, Mat &dst, int ddepth, int dx, int dy, int ksize, double **corner_value_x, double **corner_value_y);
void _GaussianBlur2(Mat &src, Mat &dst, Size ksize, double sigmaX, double **corner_value_x, double **corner_value_y);
void _GaussianBlur(Mat &src, Mat &dst, Size ksize, double sigmaX);
void _resize(Mat &src, Mat &dst, Size dsize, double fx = 1.0, double fy = 1.0, int interpolation = 1);
void _resize_8U(Mat &src, Mat &dst);
void _resize_8U_2x_HW(Mat &src, Mat &dst);
void _resize_2x_HW(Mat &src, Mat &dst);
void _resize_32F(Mat &src, Mat &dst);
void _local_normalization(Mat *image, int n_channel, int block_size, float min_value, float thresh);
void _global_normalization(Mat *ch_image, int n_channel, float global_value);
void _color_conversion(Mat &image, Mat &conv_image, bool b_train);
void feature_cutting_precision(CvMat *feature, int prec_leng, int s_ch, int e_ch);
void channel_cutting_precision(Mat *ch_image, st_feature &feature, int prec_leng);
void yc422_interpolation(Mat &in, Mat &out);