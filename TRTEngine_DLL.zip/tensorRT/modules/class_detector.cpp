#include "class_detector.h"
#include "class_yolo_detector.hpp"

class Detector::Impl
{
public:
	Impl() {}

	~Impl(){}

	YoloDectector _detector;
};

Detector::Detector()
{
	_impl = new Impl();
}

Detector::~Detector()
{
	if (_impl)
	{
		resetData();
		delete _impl;
		_impl = nullptr;
	}
}

void Detector::init(const Config &config)
{
	nInitilized = 0;

	if (!_impl)
	{
		_impl = new Impl();
	}

	_impl->_detector.init(config);

	nInitilized = _impl->_detector.nInitilized;

	if (nInitilized <= 0)
	{
		releaseNetwork();

		return;
	}

	nInputNetW = _impl->_detector.nInputNetW;

	nInputNetH = _impl->_detector.nInputNetH;

	nInputNetNumClasses = _impl->_detector.nInputNetNumClasses;
}

bool Detector::detect(cv::cuda::GpuMat &mat_image, std::vector<std::vector<Result>> &vec_result, int nWidth, int nHeight, int nStreamIndex)
{
	if (_impl->_detector.detect(mat_image, vec_result, nWidth, nHeight, nStreamIndex))
		return true;
	else
		return false;

}


void Detector::resetData()
{
	//_impl->_detector._p_net->releaseNet();
	for (uint32_t i = 0; i < _impl->_detector.trtInput.size(); ++i)
	{
		//cudaFree(_impl->_detector.trtInput[i].data);
		if (!_impl->_detector.trtInput[i].empty())
			_impl->_detector.trtInput[i].release();
	}

	std::vector<cv::cuda::GpuMat>().swap(_impl->_detector.trtInput);

	std::vector<cv::Size>().swap(_impl->_detector.trtSize);
}


void Detector::releaseNetwork()
{
	if (_impl)
	{
		_impl->_detector._p_net->releaseNet();

		if (_impl->_detector._p_net)
		{
			Yolo * ptr = _impl->_detector._p_net.release();
			_impl->_detector._p_net.get_deleter() (ptr);
			_impl->_detector._p_net = nullptr;
		}

		for (uint32_t i = 0; i < _impl->_detector.trtInput.size(); ++i)
		{
			//cudaFree(_impl->_detector.trtInput[i].data);
			if (!_impl->_detector.trtInput[i].empty())
				_impl->_detector.trtInput[i].release();
		}
		std::vector<cv::cuda::GpuMat>().swap(_impl->_detector.trtInput);

		std::vector<cv::Size>().swap(_impl->_detector.trtSize);

		delete _impl;
		_impl = nullptr;
	}
}