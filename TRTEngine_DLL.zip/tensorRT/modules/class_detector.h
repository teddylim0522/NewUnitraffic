#ifndef CLASS_DETECTOR_H_
#define CLASS_DETECTOR_H_

#include "API.h"
#include <iostream>
#include <opencv2/opencv.hpp>

struct Result
{
	int		 id		= -1;
	float	 prob	= 0.f;
	cv::Rect rect;

	int	 assigned_id = -1;
	float iou = 0.0f;
};

enum ModelType
{
	YOLOV2 = 0,
	YOLOV3,
	YOLOV2_TINY,
	YOLOV3_TINY,
	YOLOV4,
	YOLOV4_TINY,
	YOLOV5
};

enum Precision
{
	TENSOR_INT8 = 0,
	FP16,
	FP32
};

struct Config
{
	std::string file_model_cfg					= "configs/yolov3.cfg";

	std::string file_model_weights				= "configs/yolov3.weights";

	float detect_thresh							= 0.9f;

	float nms_thresh							= 0.5f;

	ModelType	net_type						= YOLOV3;

	Precision	inference_precison				= TENSOR_INT8;
	
	int	gpu_id									= 0;

	std::string calibration_image_list_file_txt = "configs/calibration_images.txt";

	int n_batch_size							= 1;

	int n_stream_max							= 1;

	int n_EngineIndex = -1;

	void* hMutex = nullptr;
};

class API Detector
{
public:
	explicit Detector();

	~Detector();

	void init(const Config &config);

	bool detect(cv::cuda::GpuMat& mat_image, std::vector<std::vector<Result>> &vec_result, int nWidth, int nHeight, int nStreamIndex);

	void resetData();

	void releaseNetwork();

public:
	int nInputNetW;
	int nInputNetH;
	int nInputNetNumClasses;
	int nInitilized;

private:
	
	Detector(const Detector &);
	const Detector &operator =(const Detector &);
	class Impl;
	Impl *_impl;
};

#endif // !CLASS_QH_DETECTOR_H_