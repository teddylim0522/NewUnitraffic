﻿/**
MIT License
Copyright (c) 2018 NVIDIA CORPORATION. All rights reserved.
*/

#ifndef __PLUGIN_LAYER_H__
#define __PLUGIN_LAYER_H__

#include <cassert>
#include <cstring>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

#include "NvInferPlugin.h"
#include "NvInferRuntimePlugin.h"

#define NV_CUDA_CHECK(status) { if (status != 0) { std::cout << "Cuda failure: " << cudaGetErrorString(status) << " in file " << __FILE__ << " at line " << __LINE__ << std::endl; abort(); } }

cudaError_t cudaYoloLayerV3(const void* input, void* output, const uint32_t& batchSize, const uint32_t& n_grid_h_, const uint32_t& n_grid_w_, const uint32_t& numOutputClasses, const uint32_t& numBBoxes, uint64_t outputSize, cudaStream_t stream);

class YoloLayerV3 : public nvinfer1::IPluginV2IOExt
{
public:
    YoloLayerV3(const void* data, size_t length);
    YoloLayerV3(const uint32_t& numBoxes, const uint32_t& numClasses, const uint32_t& grid_h_, const uint32_t& grid_w_);
    ~YoloLayerV3() = default;
    int getNbOutputs() const noexcept override;
    nvinfer1::Dims getOutputDimensions(int index, const nvinfer1::Dims* inputs, int nbInputDims) noexcept override;
    int initialize() noexcept override;
    void terminate() noexcept override;
    size_t getWorkspaceSize(int maxBatchSize) const noexcept override;
    int32_t enqueue(int32_t batchSize, void const* const* inputs, void* const* outputs, void* workspace, cudaStream_t stream) noexcept override;
    size_t getSerializationSize() const noexcept override;
    void serialize(void* buffer) const noexcept override;
    const char* getPluginType() const noexcept override;
    const char* getPluginVersion() const noexcept override;
    void destroy() noexcept override;
    nvinfer1::IPluginV2IOExt* clone() const noexcept override;
    void setPluginNamespace(const char* pluginNamespace) noexcept override;
    const char* getPluginNamespace() const noexcept override;
    nvinfer1::DataType getOutputDataType(int index, const nvinfer1::DataType* inputTypes, int nbInputs) const noexcept override;
    bool isOutputBroadcastAcrossBatch(int outputIndex, const bool* inputIsBroadcasted, int nbInputs) const noexcept override;
    bool canBroadcastInputAcrossBatch(int inputIndex) const noexcept override;
    void configurePlugin(const nvinfer1::PluginTensorDesc* in, int nbInput, const nvinfer1::PluginTensorDesc* out, int nbOutput) noexcept override;
    bool supportsFormatCombination(int pos, const nvinfer1::PluginTensorDesc* inOut, int nbInputs, int nbOutputs) const noexcept override;
private:
    template <typename T> void write(char*& buffer, const T& val) const { *reinterpret_cast<T*>(buffer) = val; buffer += sizeof(T); }
    template <typename T> void read(const char*& buffer, T& val) { val = *reinterpret_cast<const T*>(buffer); buffer += sizeof(T); }
    uint32_t m_NumBoxes;
    uint32_t m_NumClasses;
    uint32_t m_GridSize;
    uint64_t m_OutputSize;
    uint32_t _n_grid_h;
    uint32_t _n_grid_w;
    std::string m_Namespace;
};

class YoloLayerV3Creator : public nvinfer1::IPluginCreator
{
public:
    YoloLayerV3Creator();
    ~YoloLayerV3Creator() override = default;
    const char* getPluginName() const noexcept override;
    const char* getPluginVersion() const noexcept override;
    const nvinfer1::PluginFieldCollection* getFieldNames() noexcept override;
    nvinfer1::IPluginV2IOExt* createPlugin(const char* name, const nvinfer1::PluginFieldCollection* fc) noexcept override;
    nvinfer1::IPluginV2IOExt* deserializePlugin(const char* name, const void* serialData, size_t serialLength) noexcept override;
    void setPluginNamespace(const char* pluginNamespace) noexcept override;
    const char* getPluginNamespace() const noexcept override;
private:
    std::string m_Namespace;
    nvinfer1::PluginFieldCollection m_FC{};
    std::vector<nvinfer1::PluginField> m_Fields;
};

REGISTER_TENSORRT_PLUGIN(YoloLayerV3Creator);

#endif // __PLUGIN_LAYER_H__
