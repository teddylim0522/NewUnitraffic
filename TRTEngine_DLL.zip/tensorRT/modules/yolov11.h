#ifndef CLASS_YOLOV11_H_
#define CLASS_YOLOV11_H_
#include "yolo.h"

class YoloV11 : public Yolo
{
public:
	YoloV11(const uint32_t batchSize, const uint32_t numStream,
		const NetworkInfo& network_info_,
		const InferParams& infer_params_,
		int& nInitilized);

private:
	std::vector<BBoxInfo> decodeTensor(const int imageIdx,
		const int imageH,
		const int imageW,
		const TensorInfo& tensor) override;
};

#endif
