#include "yolov11.h"

YoloV11::YoloV11(const uint32_t batchSize, const uint32_t numStream,
	const NetworkInfo& network_info_,
	const InferParams& infer_params_, int& nInitilized) :
	Yolo(batchSize, numStream, network_info_, infer_params_, nInitilized) {}

std::vector<BBoxInfo> YoloV11::decodeTensor(const int imageIdx, const int imageH,
	const int imageW, const TensorInfo& tensor)
{
	std::vector<BBoxInfo> binfo;

	// YOLOv11 output: [batch, 4+C, N]
	// tensor.hostBuffer layout per image: (4+C) * N floats
	const int C = tensor.numClasses;
	const int channels = 4 + C;
	const int N = static_cast<int>(tensor.volume / channels);
	const float* output = &tensor.hostBuffer[imageIdx * tensor.volume];

	// Stretch inverse: GPU path uses plain cv::cuda::resize (not letterbox)
	const float inv_sx = static_cast<float>(imageW) / static_cast<float>(m_InputW);
	const float inv_sy = static_cast<float>(imageH) / static_cast<float>(m_InputH);

	for (int i = 0; i < N; ++i)
	{
		// [4+C, N] layout: output[channel * N + i]
		const float cx = output[0 * N + i];
		const float cy = output[1 * N + i];
		const float w  = output[2 * N + i];
		const float h  = output[3 * N + i];

		// find max class score (no objectness in YOLOv11)
		float maxProb = 0.0f;
		int maxIndex = -1;
		for (int c = 0; c < C; ++c)
		{
			float prob = output[(4 + c) * N + i];
			if (prob > maxProb)
			{
				maxProb = prob;
				maxIndex = c;
			}
		}

		if (maxProb < m_ProbThresh) continue;

		// cx,cy,w,h -> x1,y1,x2,y2 in network input space
		float x1 = cx - w / 2.0f;
		float y1 = cy - h / 2.0f;
		float x2 = cx + w / 2.0f;
		float y2 = cy + h / 2.0f;

		x1 = clamp(x1, 0, m_InputW);
		y1 = clamp(y1, 0, m_InputH);
		x2 = clamp(x2, 0, m_InputW);
		y2 = clamp(y2, 0, m_InputH);

		// stretch inverse -> original image coordinates
		BBoxInfo bbi;
		bbi.box.x1 = x1 * inv_sx;
		bbi.box.y1 = y1 * inv_sy;
		bbi.box.x2 = x2 * inv_sx;
		bbi.box.y2 = y2 * inv_sy;

		bbi.label = maxIndex;
		bbi.prob = maxProb;
		bbi.classId = getClassId(maxIndex);
		binfo.push_back(bbi);
	}

	return binfo;
}
