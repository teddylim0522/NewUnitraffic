#ifndef CLASS_YOLO_DETECTOR_HPP_
#define CLASS_YOLO_DETECTOR_HPP_

#include <opencv2/opencv.hpp>
#include "ds_image.h"
#include "trt_utils.h"
#include "yolo.h"
#include "yolov2.h"
#include "yolov3.h"
#include "yolov4.h"
#include "yolov5.h"

#include <experimental/filesystem>
#include <fstream>
#include <string>
#include <chrono>
#include <stdio.h>  /* defines FILENAME_MAX */

#include "class_detector.h"
#include "class_timer.hpp"

#include <Windows.h>

class YoloDectector
{
public:
	YoloDectector()
	{

	}
	~YoloDectector()
	{
		//20201119
		if (_p_net)
		{
			_p_net->releaseNet();
		}
	}

	void init(const Config &config)
	{
		_config = config;

		try
		{
			this->set_gpu_id(_config.gpu_id);

			this->parse_config();

			this->build_net();

			if (_p_net)
			{
				nInputNetW = _p_net->getInputW();
				nInputNetH = _p_net->getInputH();
				nInputNetNumClasses = _p_net->getNumClasses();
			}
		}
		catch (const std::exception &e)
		{
			std::string msg = std::string("YoloDectector::init() failed: ") + e.what();
			OutputDebugStringA(msg.c_str());
			std::cerr << msg << std::endl;
			_p_net = nullptr;
		}
	}


	bool detect(cv::cuda::GpuMat& mat_image, std::vector<std::vector<Result>> &vec_result, int nWidth, int nHeight, int nStreamIndex)
	{
		clock_t start_time = clock();

		vec_result.clear();

		cv::cuda::setDevice(gpu_id);

		cv::cuda::GpuMat imageRGBA_FC4;

		try
		{
			cv::cuda::GpuMat tmpImage = mat_image.clone();
			cv::cuda::Stream cvstream;
			tmpImage.convertTo(imageRGBA_FC4, CV_32FC4, 1, cvstream);
			//mat_image.convertTo(imageRGBA_FC4, CV_32FC4, 1);

			cvstream.waitForCompletion();

			trtInput.push_back(imageRGBA_FC4);

			trtSize.push_back(cv::Size(nWidth, nHeight));

			if (!tmpImage.empty())
				tmpImage.release();
		}
		catch (const cv::Exception& ex)
		{
			return false;
		}

		if (trtInput.size() >= _config.n_batch_size)
		{
			if (!_p_net)
			{
				trtInput.clear();
				trtSize.clear();
				return false;
			}
			//this->set_gpu_id(_config.gpu_id);
			//cv::cuda::GpuMat& input, const uint32_t batchSize, int nWidth, int nHeight, int nStreamIndex, int gpu_id

			//20200804 skkang, managing engine schedule
			DWORD ret = WaitForSingleObject(_config.hMutex, INFINITE);

			////write log 20200804
			//SYSTEMTIME  tCurTime;
			//::GetLocalTime(&tCurTime);
			//char todayfolder[MAX_PATH], fileName[MAX_PATH];
			//wsprintf(todayfolder, "CommLog\\%04d%02d%02d", (int)tCurTime.wYear, (int)tCurTime.wMonth, (int)tCurTime.wDay);			
			//wsprintf(fileName, "%s\\Mutex_Log_%04d%02d%02d_%02d.log", todayfolder, tCurTime.wYear, tCurTime.wMonth, tCurTime.wDay, _config.gpu_id + 1);
			//FILE *log;
			//if (fopen_s(&log, fileName, "at") == 0)
			//{
			//	fprintf_s(log, "[%02d:%02d:%02d:%03d] %d Engine doInference\n", tCurTime.wHour, tCurTime.wMinute, tCurTime.wSecond, tCurTime.wMilliseconds, _config.n_EngineIndex);
			//	fclose(log);
			//	log = nullptr;
			//}

			_p_net->doInference(trtInput, _config.n_batch_size, _p_net->getInputW(), _p_net->getInputH(), nStreamIndex, gpu_id);

			ReleaseMutex(_config.hMutex);

			for (uint32_t i = 0; i < _config.n_batch_size; ++i)
			{
				if (!trtInput[i].empty())
					trtInput[i].release();

				auto binfo = _p_net->decodeDetections(i, trtSize[i].height, trtSize[i].width, nStreamIndex);

				auto remaining = nmsAllClasses(_p_net->getNMSThresh(), binfo, _p_net->getNumClasses(), _vec_net_type[_config.net_type]);

				std::vector<Result> res_tmp;

				for (const auto &b : remaining)
				{
					Result res;
					res.id = b.label;
					res.prob = b.prob;
					const int x = round(b.box.x1);
					const int y = round(b.box.y1);
					const int w = round(b.box.x2 - b.box.x1);
					const int h = round(b.box.y2 - b.box.y1);
					res.rect = cv::Rect(x, y, w, h);
					res_tmp.push_back(res);
				}

				vec_result.push_back(res_tmp);
				std::vector<Result>().swap(res_tmp);
			}                                          

			std::vector<cv::cuda::GpuMat>().swap(trtInput);
			std::vector<cv::Size>().swap(trtSize);

			//_p_net->releaseMemory(nStreamIndex);
		}

		if (!imageRGBA_FC4.empty())
			imageRGBA_FC4.release();

		return true;
	}

private:

	void set_gpu_id(const int id = 0)
	{
		gpu_id = id;
		cudaError_t status = cudaSetDevice(id);
		if (status != cudaSuccess)
		{
			std::string error = "gpu id :" + std::to_string(id) + " cudaSetDevice failed: " + cudaGetErrorString(status) + "\n";
			OutputDebugString(error.c_str());
			std::cout << error;
			throw std::runtime_error(error);
		}
	}

	void parse_config()
	{
		_yolo_info.networkType = _vec_net_type[_config.net_type];
		_yolo_info.configFilePath = _config.file_model_cfg;
		_yolo_info.wtsFilePath = _config.file_model_weights;
		_yolo_info.precision = _vec_precision[_config.inference_precison];
		_yolo_info.deviceType = "kGPU";
		auto npos = _yolo_info.wtsFilePath.rfind(".weights");
		if (npos == std::string::npos)
			npos = _yolo_info.wtsFilePath.rfind(".wts");
		if (npos == std::string::npos)
		{
			std::string error = "wts file not recognised: " + _yolo_info.wtsFilePath + ". File needs to be of '.weights' or '.wts' format\n";
			OutputDebugString(error.c_str());
			std::cout << error;
			throw std::runtime_error(error);
		}
		_yolo_info.data_path = _yolo_info.wtsFilePath.substr(0, npos);
		_yolo_info.calibrationTablePath = _yolo_info.data_path + "-calibration.table";
		_yolo_info.inputBlobName = "data";

		_infer_param.printPerfInfo = false;
		_infer_param.printPredictionInfo = false;
		_infer_param.calibImages = _config.calibration_image_list_file_txt;
		_infer_param.calibImagesPath = "";
		_infer_param.probThresh = _config.detect_thresh;
		//_infer_param.nmsThresh = 0.5;
		_infer_param.nmsThresh = _config.nms_thresh;
	}

	void build_net()
	{
		nInitilized = 0;

		if ((_config.net_type == YOLOV2) || (_config.net_type == YOLOV2_TINY))
		{
			_p_net = std::unique_ptr<Yolo>{ new YoloV2(_config.n_batch_size, _config.n_stream_max, _yolo_info, _infer_param, nInitilized) };
		}
		else if ((_config.net_type == YOLOV3) || (_config.net_type == YOLOV3_TINY))
		{
			_p_net = std::unique_ptr<Yolo>{ new YoloV3(_config.n_batch_size, _config.n_stream_max, _yolo_info, _infer_param, nInitilized) };
		}
		else if( (_config.net_type == YOLOV4) || (_config.net_type == YOLOV4_TINY))
		{
			_p_net = std::unique_ptr<Yolo>{ new YoloV4(_config.n_batch_size, _config.n_stream_max, _yolo_info,_infer_param, nInitilized) };
		}
		else if (_config.net_type == YOLOV5)
		{
			_p_net = std::unique_ptr<Yolo>{ new YoloV5(_config.n_batch_size, _config.n_stream_max, _yolo_info,_infer_param, nInitilized) };
		}
		else
		{
			assert(false && "Unrecognised network_type.");
		}
	}

private:
	Config _config;
	NetworkInfo _yolo_info;
	InferParams _infer_param;
	int gpu_id;

	std::vector<std::string> _vec_net_type{ "yolov2","yolov3","yolov2-tiny","yolov3-tiny","yolov4","yolov4-tiny","yolov5" };
	std::vector<std::string> _vec_precision{ "kINT8","kHALF","kFLOAT" };
	Timer _m_timer;

public:
	int nInputNetW;
	int nInputNetH;
	int nInputNetNumClasses;
	int nInitilized;

	std::unique_ptr<Yolo> _p_net = nullptr;
	std::vector<cv::cuda::GpuMat> trtInput;
	std::vector<cv::Size> trtSize;
};


#endif
