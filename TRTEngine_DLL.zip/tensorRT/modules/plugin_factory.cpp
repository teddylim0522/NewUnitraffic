﻿#include "plugin_factory.h"
#include "trt_utils.h"

/******* YoloLayerV3 - IPluginV2IOExt implementation *******/

YoloLayerV3::YoloLayerV3(const void* data, size_t length)
{
    const char *d = static_cast<const char*>(data), *a = d;
    read(d, m_NumBoxes);
    read(d, m_NumClasses);
    read(d, _n_grid_h);
    read(d, _n_grid_w);
    read(d, m_OutputSize);
    assert(d == a + length);
}

YoloLayerV3::YoloLayerV3(const uint32_t& numBoxes, const uint32_t& numClasses, const uint32_t& grid_h_, const uint32_t& grid_w_)
    : m_NumBoxes(numBoxes), m_NumClasses(numClasses), _n_grid_h(grid_h_), _n_grid_w(grid_w_)
{
    assert(m_NumBoxes > 0);
    assert(m_NumClasses > 0);
    assert(_n_grid_h > 0);
    assert(_n_grid_w > 0);
    m_OutputSize = _n_grid_h * _n_grid_w * (m_NumBoxes * (4 + 1 + m_NumClasses));
}

int YoloLayerV3::getNbOutputs() const noexcept { return 1; }

nvinfer1::Dims YoloLayerV3::getOutputDimensions(int index, const nvinfer1::Dims* inputs, int nbInputDims) noexcept
{
    assert(index == 0);
    assert(nbInputDims == 1);
    return inputs[0];
}

int YoloLayerV3::initialize() noexcept { return 0; }
void YoloLayerV3::terminate() noexcept {}
size_t YoloLayerV3::getWorkspaceSize(int maxBatchSize) const noexcept { return 0; }

int32_t YoloLayerV3::enqueue(int32_t batchSize, void const* const* inputs, void* const* outputs, void* workspace, cudaStream_t stream) noexcept
{
    NV_CUDA_CHECK(cudaYoloLayerV3(inputs[0], outputs[0], batchSize, _n_grid_h, _n_grid_w, m_NumClasses, m_NumBoxes, m_OutputSize, stream));
    return 0;
}

size_t YoloLayerV3::getSerializationSize() const noexcept
{
    return sizeof(m_NumBoxes) + sizeof(m_NumClasses) + sizeof(_n_grid_h) + sizeof(_n_grid_w) + sizeof(m_OutputSize);
}

void YoloLayerV3::serialize(void* buffer) const noexcept
{
    char *d = static_cast<char*>(buffer), *a = d;
    write(d, m_NumBoxes);
    write(d, m_NumClasses);
    write(d, _n_grid_h);
    write(d, _n_grid_w);
    write(d, m_OutputSize);
    assert(d == a + getSerializationSize());
}

const char* YoloLayerV3::getPluginType() const noexcept { return "YoloLayerV3"; }
const char* YoloLayerV3::getPluginVersion() const noexcept { return "1"; }
void YoloLayerV3::destroy() noexcept { delete this; }

nvinfer1::IPluginV2IOExt* YoloLayerV3::clone() const noexcept
{
    auto* p = new YoloLayerV3(m_NumBoxes, m_NumClasses, _n_grid_h, _n_grid_w);
    p->setPluginNamespace(m_Namespace.c_str());
    return p;
}

void YoloLayerV3::setPluginNamespace(const char* pluginNamespace) noexcept { m_Namespace = pluginNamespace; }
const char* YoloLayerV3::getPluginNamespace() const noexcept { return m_Namespace.c_str(); }

nvinfer1::DataType YoloLayerV3::getOutputDataType(int index, const nvinfer1::DataType* inputTypes, int nbInputs) const noexcept
{
    return nvinfer1::DataType::kFLOAT;
}

bool YoloLayerV3::isOutputBroadcastAcrossBatch(int outputIndex, const bool* inputIsBroadcasted, int nbInputs) const noexcept { return false; }
bool YoloLayerV3::canBroadcastInputAcrossBatch(int inputIndex) const noexcept { return false; }

void YoloLayerV3::configurePlugin(const nvinfer1::PluginTensorDesc* in, int nbInput, const nvinfer1::PluginTensorDesc* out, int nbOutput) noexcept
{
    assert(nbInput == 1);
}

bool YoloLayerV3::supportsFormatCombination(int pos, const nvinfer1::PluginTensorDesc* inOut, int nbInputs, int nbOutputs) const noexcept
{
    return inOut[pos].format == nvinfer1::TensorFormat::kLINEAR && inOut[pos].type == nvinfer1::DataType::kFLOAT;
}

/******* YoloLayerV3Creator *******/

YoloLayerV3Creator::YoloLayerV3Creator() { m_FC.nbFields = 0; m_FC.fields = nullptr; }
const char* YoloLayerV3Creator::getPluginName() const noexcept { return "YoloLayerV3"; }
const char* YoloLayerV3Creator::getPluginVersion() const noexcept { return "1"; }
const nvinfer1::PluginFieldCollection* YoloLayerV3Creator::getFieldNames() noexcept { return &m_FC; }

nvinfer1::IPluginV2IOExt* YoloLayerV3Creator::createPlugin(const char* name, const nvinfer1::PluginFieldCollection* fc) noexcept
{
    return nullptr; // Created programmatically, not from field collection
}

nvinfer1::IPluginV2IOExt* YoloLayerV3Creator::deserializePlugin(const char* name, const void* serialData, size_t serialLength) noexcept
{
    auto* p = new YoloLayerV3(serialData, serialLength);
    p->setPluginNamespace(m_Namespace.c_str());
    return p;
}

void YoloLayerV3Creator::setPluginNamespace(const char* pluginNamespace) noexcept { m_Namespace = pluginNamespace; }
const char* YoloLayerV3Creator::getPluginNamespace() const noexcept { return m_Namespace.c_str(); }
